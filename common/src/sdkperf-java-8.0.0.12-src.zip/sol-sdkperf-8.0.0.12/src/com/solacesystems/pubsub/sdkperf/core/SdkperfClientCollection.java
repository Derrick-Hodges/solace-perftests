/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.common.util.CPUUsage;
import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericRestMode;
import com.solacesystems.pubsub.sdkperf.core.Constants.InternalApiMode;
import com.solacesystems.pubsub.sdkperf.core.PerfStats.PerfStatType;
import com.solacesystems.pubsub.sdkperf.util.MemoryUtils;

/**
 * This class represents a collection of clients and presents
 * an interface so that actions can be performed on one or more
 * of these clients.  For example starting publishing.
 * 
 * This collection keeps the following internal lists:
 *      - CscsmpClient - For connection management, publishing,
 *                       subscribing, etc.
 *      - PubThread - 1 per client publishing threads.
 *      - CacheThread - 1 per client cache requesting thread.
 */
public class SdkperfClientCollection extends AbstractClientCollection {
	private static final Log Trace = LogFactory.getLog(SdkperfClientCollection.class);

	private int _pubsPerSession;
	private List<SdkperfPubThread> _pubThreads;
	private List<CacheThread> _cacheThreads;
	private List<QueueBrowserThread> _qbThreads;
	
	public SdkperfClientCollection(RuntimeProperties prop, CPUUsage cpuMon) throws Exception {
		super(prop, cpuMon);
		_pubThreads = new ArrayList<SdkperfPubThread>(_numClients);
		_qbThreads = new ArrayList<QueueBrowserThread>(_numClients);
		_cacheThreads = new ArrayList<CacheThread>(_numClients);
		
		_pubThreads.clear();
		_cacheThreads.clear();
		_qbThreads.clear();

		_pubsPerSession = _rprops.getIntegerProperty(RuntimeProperties.NUM_PUBS_PER_SESSION).intValue();

		if(prop.getProperty(RuntimeProperties.API_MODE) == InternalApiMode.REST ) {
		
			if(prop.getProperty(RuntimeProperties.RESTCLIENT_MODE)==null){
				prop.setProperty(RuntimeProperties.RESTCLIENT_MODE,GenericRestMode.HTTPCLIENT);
			}
			
		} 
		
		
		if(_createClients){
			int numOfEscap=_clients.size()-_numClients;
			
			for(int i=0;i<_clients.size();i++){
				if(i<numOfEscap)
					continue;
				
				AbstractClient client=_clients.get(i);
				for (int p = 0; p < _pubsPerSession; p++) {
					SdkperfPubThread pubThread = new SdkperfPubThread (client, p);
					_pubThreads.add(pubThread);
				}
				
				CacheThread cacheThread = new CacheThread (client);
				_cacheThreads.add(cacheThread);
				
				QueueBrowserThread qbThread = new QueueBrowserThread (client);
				_qbThreads.add(qbThread);
				
				
			}
			
			
		}
		
		if (Trace.isDebugEnabled()) {
			Trace.debug(String.format("ClientCollection preparing %s clients...", _numClients));
		}
	}
	
	
	// This constructor was added to allow interaction with an application, it should generally
	// not be used for other reasons.
	public SdkperfClientCollection(RuntimeProperties prop, List<AbstractClient> clientList) throws Exception {
		super(prop, clientList);
		
		_pubThreads = new ArrayList<SdkperfPubThread>(_numClients);
		_qbThreads = new ArrayList<QueueBrowserThread>(_numClients);
		_cacheThreads = new ArrayList<CacheThread>(_numClients);

		_pubThreads.clear();
		_cacheThreads.clear();
		_qbThreads.clear();
		_clients.clear();
		_pubsPerSession = _rprops.getIntegerProperty(RuntimeProperties.NUM_PUBS_PER_SESSION).intValue();

		_clients.addAll(clientList);
		
		for (int i = 0; i < _clients.size(); i++) {
			
			int clientId = i + 1;
			
			AbstractClient client = _clients.get(i);
			// initialize the client
			client.init(prop, clientId);
			
			for (int p = 0; p < _pubsPerSession; p++) {
				SdkperfPubThread pubThread = new SdkperfPubThread (client, p);
				_pubThreads.add(pubThread);
			}
			
			CacheThread cacheThread = new CacheThread (client);
			_cacheThreads.add(cacheThread);
			
			QueueBrowserThread qbThread = new QueueBrowserThread (client);
			_qbThreads.add(qbThread);
			
		}
		
		if (Trace.isDebugEnabled()) {
			Trace.debug(String.format("ClientCollection preparing %s clients...", _numClients));
		}
	}

	
	/////////////////////////////////////////////////////////////////
	// Cache Requesting Methods
	@Override
	public void startCacheRequesting(List<String> topics, RuntimeProperties reqProps) throws Exception {
		if (isCacheRequesting())
			throw new IllegalStateException(
				"Already started cache requesting, must call stopCacheRequesting before starting again.");
		
		if (topics == null) 
	    {
			throw new PubSubException("Must specify a publish topic list.");
	    }
		
		final int numTotalMsgs = reqProps.getIntegerProperty(RuntimeProperties.CACHE_NUM_REQ).intValue();
		final int numMsgsPerThread = (numTotalMsgs / _numClients);

		for (CacheThread cache: _cacheThreads) {
			cache.start(topics, numMsgsPerThread, reqProps);
		}
		
        // Wait some time to verify they're all down
		for (int check_count = 0; check_count < 1000; check_count++) {
			if (isCacheRequesting() || isDoneCacheRequesting())
				break;
			
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
			}
		}
	}

	@Override
	public void stopCacheRequesting() throws PubSubException {
		
		// Shutdown all pubs
		for (CacheThread cache : _cacheThreads) {
			try {
				cache.stop();
			} catch (Exception e) {
				Trace.error("Error: failed to stop cache threads.");
				throw new PubSubException("Failed to stop cache threads.");
			}
		}
		
		// Wait some time to verify they're all down
		for (int check_count = 0; check_count < 1000; check_count++) {
			if (!isCacheRequesting())
				break;
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
			}
		}
		if (isCacheRequesting()) {
			Trace.error("Error: failed to stop publishers.");
			throw new PubSubException("Failed to stop publishers.");
		}
	}

	@Override
	public boolean isCacheRequesting() {
	    boolean isCacheRequesting = false;
	    for (CacheThread cacheThread : _cacheThreads) 
	    {
	        if (cacheThread.isRequesting() == true) {
	        	isCacheRequesting = true;
	            break;
	        }
	    }
	    
	    return isCacheRequesting;
	}

	/////////////////////////////////////////////////////////////////
	// Publishing Methods
	@SuppressWarnings("unchecked")
	@Override
	public void startPublishing(RuntimeProperties pubprops) throws Exception {
		if (isPublishing())
			throw new IllegalStateException(
				"Already publishing, must call stopPublishing before starting again.");
		
		if ((_rprops.getProperty(RuntimeProperties.STRUCT_DATA_MSGS_LIST) != null)
				&& (_rprops.getBooleanProperty(RuntimeProperties.WANT_ORDER_CHECK) ||
					_rprops.getBooleanProperty(RuntimeProperties.WANT_LATENCY) ||
					_rprops.getBooleanProperty(RuntimeProperties.WANT_PAYLOAD_CHECK) ||
					_rprops.getBooleanProperty(RuntimeProperties.WANT_LOSS_AND_DUPLICATE_DETECTION)))
		{
			throw new PubSubException("Cannot use order check, loss/duplicate detection, latency or payload check with structured messages");
	    }
		
		// Cannot have msg rate is max with burst mode or smooth publishers.
		if (pubprops.getBooleanProperty(RuntimeProperties.MSG_RATE_IS_MAX) &&
			((pubprops.getDoubleProperty(RuntimeProperties.BURST_DURATION) > 0 && 
			  pubprops.getDoubleProperty(RuntimeProperties.INTER_BURST_DURATION) > 0) || 
			 pubprops.getBooleanProperty(RuntimeProperties.WANT_SMOOTH_PUB_CALC_LAT))) {
			throw new PubSubException("Unsupported publish combination.  Cannot use message rate target of max with smooth pubs or bursty pubs.");
		}
		
		this.waitForAdPubAcks(pubprops);
		
		// doclist is a not a list of immutable objects, it not shared with all pubs
		// each pub takes a copy of the list so that tool data can be updated
		// on message publish.
		// To save on memory, the call to create a doc list will also erase
		// loaded message buffers since they will then have been copied to the
		// MsgRep objects.
		List<BasicMsgRep> doclist;
		if(pubprops.getStringProperty(RuntimeProperties.APPLICATION_SERVER_COMMAND) != null &&
				pubprops.getStringProperty(RuntimeProperties.APPLICATION_SERVER_COMMAND).length() > 0) {
			// We fall in a special mode where we will be publishing messages containing
			// another sdkperf command.
			doclist = createDoclistForApplicationServerCommand(pubprops);

		}
		else if (pubprops.getProperty(RuntimeProperties.STRUCT_DATA_MSGS_LIST) != null)
		{
			doclist = createDoclistForStructMsgs(pubprops);
		}
		else if (pubprops.getProperty(RuntimeProperties.SMF_BINARY_FILE_LIST) != null)
		{
			doclist = createDoclistFromBinarySmf(pubprops);
		}
		else
		{
			doclist = createDoclist(pubprops);
		}
		pubprops.setProperty(RuntimeProperties.PUBLISH_FILE_LIST, null);
		pubprops.setProperty(RuntimeProperties.PUBLISH_ATTACH_LIST, null);
		
	    if(pubprops.getStringProperty(RuntimeProperties.HTTP_CONTENT_ENCODING) != null) {
	    	for(BasicMsgRep m : doclist) {
	    		m.setHttpContentEncoding(pubprops.getStringProperty(RuntimeProperties.HTTP_CONTENT_ENCODING));
	    	}
	    }
	    if(pubprops.getStringProperty(RuntimeProperties.HTTP_CONTENT_TYPE) != null) {
	    	for(BasicMsgRep m : doclist) {
	    		m.setHttpContentType(pubprops.getStringProperty(RuntimeProperties.HTTP_CONTENT_TYPE));
	    	}
	    }
		
		List<String> transactedSessionNameList = (List<String>)pubprops.getProperty(RuntimeProperties.TRANSACTED_SESSION_NAME_LIST);

		if (transactedSessionNameList != null &&
				transactedSessionNameList.size() > 0 && 
				_pubsPerSession != 1) {
			throw new PubSubException("Error.  PubsPerSession > 1 and transactions not supported together.");
		}
		
		// If trying to publish with transactions then we need to make sure that the session names list is the same length as the clients list.
		if (transactedSessionNameList != null &&
				transactedSessionNameList.size() > 0 &&
				transactedSessionNameList.size() != _pubThreads.size()) {
			throw new PubSubException("Error trying to publishing using transacted sessions.  Session names list not equal to num clients");
		}
		
		final long numTotalMsgs = pubprops.getLongProperty(RuntimeProperties.NUM_MSGS_TO_PUBLISH).longValue();
		
		
		/*
		 * Line 299,300,301,302 are being implemented for SocketClient when using automation. 
		 * SocketCLient need to know how much message he need to publish.
		 */
		for (AbstractClient client : _clients) {
			client._numMsgPub = numTotalMsgs;
			client._numMsgsPubOffset=1;
			client._isStartPub=true;
		}

		
		final long numMsgsPerPub = (numTotalMsgs / _numClients / _pubsPerSession);
		
		String transactedSessionName = "";
		
		if(pubprops.getProperty(RuntimeProperties.API_MODE) == InternalApiMode.JNI) {
			System.out.println("Attempting to launch GC...");
			System.gc();
			Thread.sleep(1000);
			MemoryUtils.printGcInformation(true);
		}
		
		
		for (int i = 0; i < _pubThreads.size(); i++) {
			SdkperfPubThread pub = _pubThreads.get(i);
			if (transactedSessionNameList != null &&
					transactedSessionNameList.size() > 0) {
				transactedSessionName = transactedSessionNameList.get(i);
			}
			
			if ((pubprops.getBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION)) && 
				(pubprops.getIntegerProperty(RuntimeProperties.AD_TRANSACTION_SIZE) > 0)) {
				this.initXaTransactions(transactedSessionName, i);
			}
			
			pub.startPublish(doclist, numMsgsPerPub, pubprops, transactedSessionName);
		}
		
        // Wait some time to verify they're all down
		for (int check_count = 0; check_count < 1000; check_count++) {
			if (isPublishing() || isDonePublishing())
				break;
			
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
			}
		}
	}

	@Override
	public void stopPublishing() throws PubSubException {
		
		// Shutdown all pubs
		for (SdkperfPubThread pub : _pubThreads) {
			try {
				pub.stopPublish();
			} catch (Exception e) {
				Trace.error("Error: failed to stop pub threads.");
				throw new PubSubException("Failed to stop pub threads.");
			}
		}
		
		// Wait some time to verify they're all down
		for (int check_count = 0; check_count < 1000; check_count++) {
			if (!isPublishing())
				break;
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
			}
		}
		if (isPublishing()) {
			Trace.error("Error: failed to stop publishers.");
			throw new PubSubException("Failed to stop publishers.");
		}
	}

	@Override
	public boolean isPublishing() {
	    boolean isPublishing = false;
	    for (SdkperfPubThread pubThread : _pubThreads) 
	    {
	        if (pubThread.isPublishing() == true) {
	            isPublishing = true;
	            break;
	        }
	    }
	    
	    return isPublishing;
	}

	///////////////////////////////////////////////////////////////////////
	// Queue Browsing Access
	@Override
	public void startQueueBrowsing(List<String> queues, String selector, RuntimeProperties props) throws Exception {
		if (isQueueBrowsing())
			throw new IllegalStateException(
				"Already started cache requesting, must call stopCacheRequesting before starting again.");
		
		if (queues == null) 
	    {
			throw new PubSubException("Must specify a queues list.");
	    }
		
		for (QueueBrowserThread qbThread : _qbThreads) {
			qbThread.start(queues, selector, props);
		}
		
        // Wait some time to verify they're all down
		for (int check_count = 0; check_count < 1000; check_count++) {
			if (isQueueBrowsing() || isDoneQueueBrowsing())
				break;
			
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
			}
		}
	}

	@Override
	public void stopQueueBrowsing() throws PubSubException {
		
		// Shutdown all pubs
		for (QueueBrowserThread qbThread : _qbThreads) {
			try {
				qbThread.stop();
			} catch (Exception e) {
				Trace.error("Error: failed to stop queue browsing.");
				throw new PubSubException("Failed to stop queue browsing.", e);
			}
		}
		
		// Wait some time to verify they're all down
		for (int check_count = 0; check_count < 1000; check_count++) {
			if (!isQueueBrowsing())
				break;
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
			}
		}
		if (!isQueueBrowsing()) {
			Trace.info("Successfully stopped queue browsing.");
		} else {
			Trace.error("Error: failed to stop queue browsing.");
			throw new PubSubException("Failed to stop queue browsing.");
		}
	}

	@Override
	public boolean isQueueBrowsing() {
	    boolean isQB = false;
	    for (QueueBrowserThread qbThread : _qbThreads) 
	    {
	        if (qbThread.isReceiving() == true) {
	        	isQB = true;
	            break;
	        }
	    }
	    
	    return isQB;
	}

	///////////////////////////////////////////////////////////////////////
	// Stats Access
	@Override
	public void resetStats(final int clientidx) {
		super.resetStats(clientidx);

		if (clientidx == ALL_CLIENT_INDEX) {
			for (SdkperfPubThread pubThread : _pubThreads) {
				pubThread.resetStats();
			}
			for (CacheThread cacheThread : _cacheThreads) {
				cacheThread.resetTimes();
			}
			for (QueueBrowserThread qbThread : _qbThreads) {
				qbThread.resetTimes();
			}
			
		} else {
			_pubThreads.get(clientidx).resetStats();
			_cacheThreads.get(clientidx).resetTimes();
			_qbThreads.get(clientidx).resetTimes();
		}
	}

	@Override
	public double getTxThroughput() {
		
		long pubStartTime = this.getPubStartTimeInNanos();
		long cacheStartTime = this.getCacheStartTimeInNanos();
		
		long startTime = 0;
	    if (pubStartTime != 0 && cacheStartTime != 0) {
	        startTime = (pubStartTime < cacheStartTime) ? pubStartTime : cacheStartTime;
	    } else if (pubStartTime != 0) {
	        startTime = pubStartTime;
	    } else if (cacheStartTime != 0) {
	        startTime = cacheStartTime;
	    }
	    
		if (startTime == 0) return 0;
		
		long pubET = this.getPubEndTimeInNanos();
		long cacheET = this.getCacheEndTimeInNanos();
		long endTime = (pubET > cacheET) ? pubET : cacheET;
		
		/*
		 * This lets us get up-to-date throughput stats while publishing, but
		 * uses the "REAL" start/end times when calling after publishing is
		 * finished.
		 */
		if (endTime == 0) {
			endTime = System.nanoTime();
		} 

		long msgsPublished;
		try {
			msgsPublished = this.getSdkStat(GenericStatType.TOTAL_MSGS_SENT, ALL_CLIENT_INDEX);
		} catch (PubSubException e) {
			Trace.error("Error while getting sdk stat.", e);
			return 0;
		}
		long timeDiffInNanos = endTime - startTime;

		if (timeDiffInNanos <= 0) {
			return 0;
		} else {
			return ((msgsPublished * 1000000000) / timeDiffInNanos);
		}
	}
	
	@Override
	public PerfStats getTxStats(final int clientidx) {
		PerfStats ret_stats;
		if (clientidx == ALL_CLIENT_INDEX) {
			int latBuckets = 0;
			int latGranularity = 0;
			double warmup = 0;
			ret_stats = new PerfStats(
					"aggregate", 
					latBuckets, 
					latGranularity, 
					warmup);
			for (SdkperfPubThread pubThread : _pubThreads) {
				ret_stats.aggregate(pubThread.getTxStats());
			}
		} else {
			ret_stats = _pubThreads.get(clientidx).getTxStats();
		}
		return ret_stats;
	}
	
	/////////////////////////////////////////////////////////////
	// Other Methods

	@Override
	public String toString() {
		// Returns a huge per-client dump of names / SDK stats.
		StringBuffer buf = new StringBuffer();
		for (AbstractClient client : _clients) {
			buf.append(client.toString()).append("\n");
		}
		
	    if (_rprops.getBooleanProperty(RuntimeProperties.WANT_SMOOTH_PUB_CALC_LAT)) {
	    	
	    	buf.append("Smooth Pub Calculated Latency: \n");
	    	
	    	for (SdkperfPubThread pub : _pubThreads) {
	    		buf.append("Client Name          = ").append(pub.getClientName()).append("\n");
	    		buf.append("Num Times Behind     = ").append(pub.getTxStats().getStat(PerfStatType.PSM_NUM_TIMES_BEHIND)).append("\n");
	    		buf.append("Max Time Behind (us) = ").append(pub.getTxStats().getStatInUSec(PerfStatType.PSM_MAX_CYCLES_BEHIND)).append("\n");      
	        }
	    }
		return buf.toString();
	}
	
	/////////////////////////////////////////////////////////////
	// Private methods
	private boolean isDoneCacheRequesting() {
	    boolean isDoneRequesting = true;
	    for (CacheThread cacheThread : _cacheThreads) 
	    {
	        if (cacheThread.isDoneRequesting() == false) {
	        	isDoneRequesting = false;
	            break;
	        }
	    }
	    
	    return isDoneRequesting;
	}
	
	private boolean isDonePublishing() {
	    boolean isDonePublishing = true;
	    for (SdkperfPubThread pubThread : _pubThreads) 
	    {
	        if (pubThread.isDonePublishing() == false) {
	        	isDonePublishing = false;
	            break;
	        }
	    }
	    
	    return isDonePublishing;
	}
	
	private boolean isDoneQueueBrowsing() {
	    boolean isDoneRequesting = true;
	    for (QueueBrowserThread qbThread : _qbThreads) 
	    {
	        if (qbThread.isDoneReceiving() == false) {
	        	isDoneRequesting = false;
	            break;
	        }
	    }
	    
	    return isDoneRequesting;
	}
		
	private long getPubStartTimeInNanos()
	{
		long startTime = 0;
	    for (SdkperfPubThread pub : _pubThreads) 
	    {
	        if (pub.getStartTimeInNanos() != 0) 
	        {
	            if (startTime == 0) 
	            {
	                startTime = pub.getStartTimeInNanos();
	            } 
	            else if (pub.getStartTimeInNanos() < startTime) 
	            {
	                startTime = pub.getStartTimeInNanos();
	            }
	        }
	    }
	    
	    return startTime;
	}

	private long getPubEndTimeInNanos()
	{
		long endTime = 0;
		for (SdkperfPubThread pub : _pubThreads) 
		{
			 if (pub.getEndTimeInNanos() > endTime) {
	           endTime = pub.getEndTimeInNanos();
	        }
	    }
	    
	    return endTime;
	}

	@Override
	protected long getLastPubTimeInNanos()
	{
		long lastPubTime = 0;
		for (SdkperfPubThread pub : _pubThreads) 
		{
			 if (pub.getLastPubTimeInNanos() > lastPubTime) {
				 lastPubTime = pub.getLastPubTimeInNanos();
	        }
	    }
	    
	    return lastPubTime;
	}
	
	@Override
	protected void setLastPubTimeInNanos(long timeInNanos, int clientidx)
	{
		_pubThreads.get(clientidx).setLastPubTimeInNanos(timeInNanos);
	}

	private long getCacheStartTimeInNanos()
	{
		long startTime = 0;
	    for (CacheThread cache : _cacheThreads) 
	    {
	        if (cache.getStartTimeInNanos() != 0) 
	        {
	            if (startTime == 0) 
	            {
	                startTime = cache.getStartTimeInNanos();
	            } 
	            else if (cache.getStartTimeInNanos() < startTime) 
	            {
	                startTime = cache.getStartTimeInNanos();
	            }
	        }
	    }
	    
	    return startTime;
	}

	private long getCacheEndTimeInNanos()
	{
		long endTime = 0;
		for (CacheThread cache : _cacheThreads) 
		{
			 if (cache.getEndTimeInNanos() > endTime) {
	           endTime = cache.getEndTimeInNanos();
	        }
	    }
	    
	    return endTime;
	}

}
