/** 
 *  Copyright 2009-2017 Solace Corporation. All rights reserved.
 *  
 *  http://www.solacesystems.com
 *  
 *  This source is distributed WITHOUT ANY WARRANTY or support;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 *  A PARTICULAR PURPOSE.  All parts of this program are subject to
 *  change without notice including the program's CLI options.
 *
 *  Unlimited use and re-distribution of this unmodified source code is   
 *  authorized only with written permission.  Use of part or modified  
 *  source code must carry prominent notices stating that you modified it, 
 *  and give a relevant date.
 */
package com.solacesystems.pubsub.sdkperf.util;


public class Timing {

	private static double _toMicroSeconds = 1000.0;

	static {
		System.out.println("Run Info: Using Java Nanosecond Timer for Timing");
	}

	public static long getClockValue() {
		return System.nanoTime();
	}

	public static double microSecDivisor() {
		return _toMicroSeconds;
	}

	public static long clockSpeedInHz() {
		return (long) (_toMicroSeconds * 1000000L);
	}

}