package com.solacesystems.pubsub.sdkperf.jcsmpcore;

import com.solacesystems.pubsub.sdkperf.core.AbstractMessageAckData;

public class JcsmpMessageAckData extends AbstractMessageAckData {

	private String _destination;
	private boolean _isTopic;
	private JcsmpWrappedMessage _message;
	
	public JcsmpMessageAckData (String destination, boolean isTopic, JcsmpWrappedMessage message) {
		_destination = destination;
		_isTopic = isTopic;
		_message = message;
	}
	
	public boolean isFromFlow (String destination, boolean isTopic) {
		if ((destination.equals(_destination)) && (isTopic == _isTopic)) {
			return true;
		} else {
			return false;
		}
	}
	
	public JcsmpWrappedMessage getMessage() {
		return _message;
	}
	
}