/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.config;

import java.io.IOException;
import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.commons.cli.ParseException;
import org.apache.commons.lang.NullArgumentException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.pubsub.sdkperf.core.AbstractCacheLiveDataAction;
import com.solacesystems.pubsub.sdkperf.core.Constants;
import com.solacesystems.pubsub.sdkperf.core.Constants.EndpointAccessType;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericAuthenticationScheme;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericServerConnectionType;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericSupportedAckEvent;
import com.solacesystems.pubsub.sdkperf.core.Constants.InternalApiMode;
import com.solacesystems.pubsub.sdkperf.core.Constants.ReconnectFailAction;
import com.solacesystems.pubsub.sdkperf.core.Constants.ToolMode;
import com.solacesystems.pubsub.sdkperf.core.GenericMessageDeliveryMode;
import com.solacesystems.pubsub.sdkperf.core.PubSubException;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.ClientModeType;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.SubscriberDestinationsType;
import com.solacesystems.pubsub.sdkperf.util.PerfIO;
import com.solacesystems.pubsub.sdkperf.util.SdkperfConstants;



/**
 * Builder for RuntimeProperties.
 */
public class RuntimePropertiesBuilder {

	
	private static final Log Trace = LogFactory.getLog(RuntimePropertiesBuilder.class);

	
	private RuntimeProperties _prop;
	
	private	String _xmlDocsList 		= "";
	private	String _attachedDocsList 	= "";
	private String _smfBinaryFilesList  = "";
	
	public RuntimePropertiesBuilder() {
		_prop = new RuntimeProperties();
	}
	
	public RuntimePropertiesBuilder(RuntimeProperties rp) {
		_prop = rp;
	}

	public RuntimeProperties getRuntimeProperties() {
		return _prop;
	}
	
	public void setNumClients(int num) {
		if(num<0)
			throw new IllegalArgumentException("Number of Client (-cc) argument must be greater than 0");
		_prop.setIntegerProperty(RuntimeProperties.NUM_CLIENTS, num);
	}
	
	public void setNumPubsPerSession(int num) {
		_prop.setIntegerProperty(RuntimeProperties.NUM_PUBS_PER_SESSION, num);
	}
	
	public void setPubEndDelay(int seconds) {
		_prop.setIntegerProperty(RuntimeProperties.PUBLISH_END_DELAY_IN_SEC,
			seconds);
	}

	public void setRatePerPub(double rate) {
		if(rate<0)
			throw new IllegalArgumentException("Message Rate (-mr) argument must be greater or equal 0");
		_prop.setDoubleProperty(RuntimeProperties.PUBLISH_RATE_PER_PUB, rate);
	}

	public void setMsgRateIsMax(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.MSG_RATE_IS_MAX, value);
	}
	
	public void setIgnoreExistsErrors(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.IGNORE_EXISTS_ERRORS, value);
	}
	
	public void setNumMsgsToPublish(long num) {
		_prop.setLongProperty(RuntimeProperties.NUM_MSGS_TO_PUBLISH, num);
	}

	public void setXmlPayloadSize(List<Integer> sizes) {
		_prop.setProperty(RuntimeProperties.XML_PAYLOAD_SIZE_LIST, sizes);
	}
	
	public void setAttachmentSize(List<Integer> sizes) {
		_prop.setProperty(RuntimeProperties.ATTACHMENT_SIZE_LIST, sizes);
	}
	
	public static List<Integer> tokenizeIntegers(String str, String delim) {
		StringTokenizer tok = new StringTokenizer(str, delim);
		List<Integer> integers = new ArrayList<Integer>();
		while (tok.hasMoreTokens()) {
			String tokenValue = tok.nextToken();
			integers.add(Integer.parseInt(tokenValue));
		}
		return integers;
	}
	
	public void setXmlPayloadSweep(String value) throws PubSubException {
		List<String> values = csv2List(value);
		if (values.size() != 3) {
			throw new PubSubException("ERROR: Must specify start,step,end in bytes for msx-sweep: " + value);
		}
		
		int start = Integer.parseInt(values.get(0));
        int step = Integer.parseInt(values.get(1));
        int end = Integer.parseInt(values.get(2));
        List<Integer> ints = new ArrayList<Integer>();
        for (int i = 0; (start + i) <= end; i += step) {
        	ints.add(start + i);
        }
		_prop.setProperty(RuntimeProperties.XML_PAYLOAD_SIZE_LIST, ints);
	}
	
	public void setAttachmentSweep(String value) throws PubSubException {
		List<String> values = csv2List(value);
		if (values.size() != 3) {
			throw new PubSubException("ERROR: Must specify start,step,end in bytes for msa-sweep: " + value);
		}
		
		int start = Integer.parseInt(values.get(0));
        int step = Integer.parseInt(values.get(1));
        int end = Integer.parseInt(values.get(2));
        List<Integer> ints = new ArrayList<Integer>();
        for (int i = 0; (start + i) <= end; i += step) {
        	ints.add(start + i);
        }
		_prop.setProperty(RuntimeProperties.ATTACHMENT_SIZE_LIST, ints);
	}
	
	public void setMsgDMQEligible(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.MSG_DMQ_ELIGIBLE, value);
	}
	
	public void setMsgTTL(long value) {
		_prop.setLongProperty(RuntimeProperties.MSG_TTL, value);
	}
	public void setElidingEligible(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.MSG_ELIDING_ELIGIBLE, value);
	}
	
	public void setWantMsgDump(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_MSG_DUMP, value);
	}
	
	public void setMsgDumpDirectory(String value) {
		_prop.setProperty(RuntimeProperties.MSG_DUMP_DIR, value);
	}
	
	public void setClientMode(ClientModeType value) {
		// passing value of an enum like in the case of SubscriberDestinationsType
		_prop.setProperty(RuntimeProperties.CLIENT_MODE, value);
	}
	
	public void setClientMode(String value) {
		if (value.equals("sink")) {
			setWantMsgReflect(false);
			setClientMode(ClientModeType.SINK);
		} else{
			setWantMsgReflect(true);
			setClientMode(ClientModeType.REPLY);
			// We could be tempted to set 
			//   pb.setWantReplyTopic(true);
			// here because we need some address to which
			// we would reply, but this would be wrong
			// because the whole sender<->reflector setup
			// can be done with two instances of sdkperf.
			// Only the sender needs to write the replyTo
			// values in the messages.
		} 
	
	}
	
	public void setWantMsgReflect(boolean value) {
		_prop.setProperty(RuntimeProperties.WANT_MSG_REFLECT, value);
	}
	
	public void setWantReplyTopic(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_REPLY_TOPIC, value);
	}
	
	public void setWantReplyTemporaryQueue(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_REPLY_TEMPORARY_QUEUE, value);
	}
	
	public void setHttpContentEncoding(String value) {
		_prop.setProperty(RuntimeProperties.HTTP_CONTENT_ENCODING, value);
	}
	
	public void setHttpContentType(String value) {
		_prop.setProperty(RuntimeProperties.HTTP_CONTENT_TYPE, value);
	}
	
	public void setReplyToPostfix(String value) {
		if(value != null && value.length() > 0)
			_prop.setBooleanProperty(RuntimeProperties.WANT_REPLY_TOPIC, true);
		_prop.setProperty(RuntimeProperties.REPLY_TO_POSTFIX, value);
	}
	
	public void setReplyToString(String value) {
		if(value != null && value.length() > 0)
			_prop.setBooleanProperty(RuntimeProperties.WANT_REPLY_TOPIC, true);
		_prop.setProperty(RuntimeProperties.REPLY_TO_STRING, value);
	}
	
	public void setClientHost(String host) throws ParseException {
		_prop.setProperty(RuntimeProperties.CLIENT_IP_ADDR, host);
	}

	public void setClientUsername(String name) {
		_prop.setProperty(RuntimeProperties.CLIENT_USERNAME, name);
	}
	
	public void setClientVpn(String name) {
		_prop.setProperty(RuntimeProperties.CLIENT_VPN, name);
	}
	
	public void setClientNamePrefix(String name) {
		_prop.setProperty(RuntimeProperties.CLIENT_NAME_PREFIX, name);
	}

	public void setClientPassword(String passw) {
		_prop.setProperty(RuntimeProperties.CLIENT_PASSWORD, passw);
	}

	public void setClientDescription(String value) {
		_prop.setProperty(RuntimeProperties.CLIENT_DESCRIPTION, value);
	}
	
	public void setClientDtoLocalPri(int value) {
		_prop.setProperty(RuntimeProperties.CLIENT_DTO_LOCAL_PRIORITY, value);
	}
	
	public void setClientDtoNetworkPri(int value) {
		_prop.setProperty(RuntimeProperties.CLIENT_DTO_NETWORK_PRIORITY, value);
	}
	
	public void setRestServerConnectionType(GenericServerConnectionType value){
		_prop.setProperty(RuntimeProperties.RESTSERVER_CONNECTION_TYPE, value);
	}
	
	public void setRestServerKeyStore(String value){
		_prop.setProperty(RuntimeProperties.SSL_REST_KEY_STORE, value);
	}
	
	public void setRestServerTrustStore(String value){
		_prop.setProperty(RuntimeProperties.SSL_REST_TRUST_STORE, value);
	}
	
	public void setRestServerKeyStorePass(String value){
		_prop.setProperty(RuntimeProperties.SSL_REST_KEY_STORE_PASSWORD, value);
	}
	
	public void setRestServerPrivatekeyStorePassword (String value){
		_prop.setProperty(RuntimeProperties.SSL_REST_PRIVATE_KEY_PASSWORD, value);
	}
	
	public void setRestServerTrustStorePass(String value){
		_prop.setProperty(RuntimeProperties.SSL_REST_TRUST_STORE_PASSWORD, value);
	}
	
	public void setClientCompressionLevel(int value) {
		_prop.setProperty(RuntimeProperties.CLIENT_COMPRESSION_LEVEL, value);
	}
	
	public void setPublishCos(int value) throws PubSubException {
		_prop.setIntegerProperty(RuntimeProperties.PUBLISH_COS, value);
	}
	
	public void setPublishToOne(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.PUBLISH_TO_ONE, value);
	}
	
	public void setPublishStreamOffset(int value) {
		_prop.setIntegerProperty(RuntimeProperties.PUB_STREAM_ID_OFFSET, value);
	}

	public void setPublishOrderOffset(int value) {
		_prop.setIntegerProperty(RuntimeProperties.PUB_ORDER_OFFSET, value);
	}
	
	public void setServerPortList(String serverPortList) {
		try {
			Set<Integer> portList = csv2IntSet(serverPortList);
			_prop.setProperty(RuntimeProperties.SERVER_PORT_LIST, portList);
		} catch (NumberFormatException e) {
			Trace.warn("Unable to parse -spl argument. It must contain a valid comma-separated list of ports (integers).");
			throw e;
		}
	}
	

	public void setWantTcpNoDelay(boolean val) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_TCP_NODELAY, val);
	}
	
	public void setChangeClientNameFlag(boolean val) {
		_prop.setBooleanProperty(RuntimeProperties.CHANGE_CLIENT_NAMES_FLAG, val);
	}
	
	public void setXmlDocs(String fileList) {
		_xmlDocsList = fileList;
	}
	
	public void loadXmlDocs() throws IOException {
		if(_xmlDocsList != null && !_xmlDocsList.equals("")){
			List<ByteBuffer> contentBufs = fileListToContentBuffers(_xmlDocsList);
			_prop.setProperty(RuntimeProperties.PUBLISH_FILE_LIST, contentBufs);
		}
	}

	
	public void setAttachmentDocs(String fileList) {
		_attachedDocsList = fileList;
	}
	
	public void loadAttachmentDocs() throws IOException {
		if(_attachedDocsList != null && !_attachedDocsList.equals("")){
			List<ByteBuffer> contentBufs = fileListToContentBuffers(_attachedDocsList);
			_prop.setProperty(RuntimeProperties.PUBLISH_ATTACH_LIST, contentBufs);
		}
	}
	
	public void setSmfBinaryFiles(String fileList) {
		_smfBinaryFilesList = fileList;
	}
	
	public void loadSmfBinaryFiles() throws IOException {
		if(_smfBinaryFilesList != null && !_smfBinaryFilesList.equals("")){
			List<ByteBuffer> contentBufs = fileListToContentBuffers(_smfBinaryFilesList);
			_prop.setProperty(RuntimeProperties.SMF_BINARY_FILE_LIST, contentBufs);
		}
	}
		

	public void setMessageType(GenericMessageDeliveryMode msgDeliveryMode) {
		_prop.setProperty(RuntimeProperties.PUB_MESSAGE_TYPE, msgDeliveryMode);
	}
	

	public void setMessageType(String msgDeliveryModeStr) {
		setMessageType(RuntimePropertiesBuilder.getMessageDeliveryMode(msgDeliveryModeStr));
	}
	
	public void setPubTopics(List<String> inputTopicsList) {
		if (inputTopicsList != null && inputTopicsList.size() > 0) {
			List<String> topics = new LinkedList<String>();
			Iterator<String> it = inputTopicsList.iterator();
			while (it.hasNext()) {
				String next = it.next();
				if (next != null && !next.equals("")) {
					topics.add(next);
				}
			}
			if (topics.size() > 0) {
				_prop.setProperty(RuntimeProperties.PUBLISH_TOPIC_LIST, topics);
			}
		}
	}
	
	
	public void setRestIps(List<String> inputTopicsList) {
		
		if (inputTopicsList != null && inputTopicsList.size() > 0) {
			List<String> ips = new LinkedList<String>();
			Iterator<String> it = inputTopicsList.iterator();
			while (it.hasNext()) {
				String next = it.next();
				if (next != null && !next.equals("")) {
					ips.add(next);
				}
			}
			if (ips.size() > 0) {
				_prop.setProperty(RuntimeProperties.REST_IP_LIST, ips);
			}
		}else {
			throw new IllegalArgumentException("-lip argument must be passed with at least one ip adress");
		}
		
	}
	
	
	public void setSubscriberTopicPrefixedList(String prefix,long numTopics){
		

		StringBuilder sb=new StringBuilder();

		int topicPrefLen=prefix.length();
		int sbSize=topicPrefLen+7;

		sb.ensureCapacity((sbSize*(int)numTopics)+1);
		
		 for(int i=1;i<=numTopics;i++){
			 
			 
			 
			 if(i>1){
				 sb.append(","+prefix);
			 }else{
				 sb.append(prefix);
			 }
			 
			 
			 for(int j=0;j<6-(int)(Math.log10(i)+1);j++){
				 sb.append(0);
			 }
			 sb.append(i);

				
		 }
		 
		 loadDestListFromList(RuntimeProperties.SUB_TOPIC_LISTS, sb.toString());
		 _prop.setProperty(RuntimeProperties.SUB_DESTINATION_TYPE, SubscriberDestinationsType.TOPIC);

	
	}
	
	public void setRestServerResponseLogic(String value){

		String[] restParams=value.split("\\,");
		if(restParams.length%2!=0){
			throw new IllegalArgumentException("Invalid arguments passed with -rsrco");
		}
		
		int[] restParamsInt=new int[restParams.length];
		
		for(int i=0;i<restParams.length;i++){
		
			try{
				restParamsInt[i]=Integer.valueOf(restParams[i]);;
			} catch(Exception e){
				throw new IllegalArgumentException("non-integer arguments passed with -rsrco");
			}
			
		}
		
		_prop.setProperty(RuntimeProperties.RESTSERVER_PROB_RESP, restParamsInt);
		
	}
	
	public  void setPublisherTopicPrefixedList(String prefix,long numTopics){
		
		List<String>  topicList=new ArrayList<String>();
		StringBuilder sb=new StringBuilder();
		sb.append(prefix);
		int topicPrefLen=prefix.length();
		int sbSize=topicPrefLen+6;

		sb.ensureCapacity(sbSize);
		
		 for(int i=1;i<=numTopics;i++){
			 
			 
			 
			 if(i>1){
				 sb.delete(topicPrefLen,topicPrefLen+6 );
			 }
			 
			
			 
			 for(int j=0;j<6-(int)(Math.log10(i)+1);j++){
				 sb.append(0);
			 }
			 sb.append(i);
			 topicList.add(sb.toString());
				
		 }
		 
		 _prop.setProperty(RuntimeProperties.PUBLISH_TOPIC_LIST, topicList);
		
	}
	
	
	public void setPublisherTopicLists(String csv) {
		setPubTopics(csv2List(csv));
	}
	
	public void setNumMessageProducer(int value) {
		if(value < 1) {
			throw new IllegalArgumentException("Invalid number of message producers provided. Accepted values: >= 1");
		}
		_prop.setIntegerProperty(RuntimeProperties.NUM_MESSAGE_PRODUCER, value);
	}
	
	public int getNumMessageProducer() {
		return _prop.getIntegerProperty(RuntimeProperties.NUM_MESSAGE_PRODUCER);
	}
	
	
	public void setRestIpList(String csv) {
		setRestIps(csv2List(csv));
	}
	
	
	public void setPublisherQueueLists(String csv) {
		setPubQueues(csv2List(csv));
	}
	
	
	public void setPubQueues(List<String> inputQueuesList) {
		if (inputQueuesList != null && inputQueuesList.size() > 0) {
			List<String> queues = new LinkedList<String>();
			Iterator<String> it = inputQueuesList.iterator();
			while (it.hasNext()) {
				String next = it.next();
				if (next != null && !next.equals("")) {
					queues.add(next);
				}
			}
			if (queues.size() > 0) {
				_prop.setProperty(RuntimeProperties.PUBLISH_QUEUE_LIST, queues);
			}
		}
	}
	
	public void setExtraProps(String extraProps) throws IOException {
		if (extraProps != null && !extraProps.equals("")) {
			StringTokenizer tok = new StringTokenizer(extraProps, ",");
			List<String> extraPropsList = new ArrayList<String>();
			while (tok.hasMoreTokens()) {
				String tokenValue = tok.nextToken();
				extraPropsList.add(tokenValue);
			}
			setExtraPropsList(extraPropsList);
		} else {
			throw new IOException("Extra properties set incorrectly.");
		}
	}
	
	public void setCustomPropertyList(String customProp) throws IOException {
		if (customProp != null && !customProp.equals("")) {
			StringTokenizer tok = new StringTokenizer(customProp, ",");
			List<String> customPropList = new ArrayList<String>();
			
			int pos = 0;
			while (tok.hasMoreTokens()) {
				String tokenValue = tok.nextToken();
				
				if(pos % 3 == 0) {
					// Must be a valid Java type
					if (!tokenValue.equalsIgnoreCase("Boolean")
							&& !tokenValue.equalsIgnoreCase("String")
							&& !tokenValue.equalsIgnoreCase("Double")
							&& !tokenValue.equalsIgnoreCase("Float")
							&& !tokenValue.equalsIgnoreCase("Int")
							&& !tokenValue.equalsIgnoreCase("Long")
							&& !tokenValue.equalsIgnoreCase("Short")) {
						throw new IOException(
								"Invalid Type for custom JMS Properties. Accepted values are: String, Boolean, Double, Float, Int, Long, Short.");
					}
				}
				
				customPropList.add(tokenValue);
				pos++;
			}
			
			if(customPropList.size() % 3 != 0) {
				throw new IOException("Invalid custom Properties, valid format is \"type,name,value\" (e.g. \"Boolean,PropName,true\").");
			}
			
			setCustomProperty(customPropList);
		} else {
			throw new IOException("Invalid custom Properties.");
		}
	}

	
	public void setExtraPropsList(List<String> extraProps) throws IOException {
		if(extraProps != null && extraProps.size() > 0) {
			_prop.setProperty(RuntimeProperties.EXTRA_PROP_LIST, (Object) extraProps);
		}
		else {
			throw new  IOException("Extra properties list set incorrectly.");
		}
	}
	
	public void setCustomProperty(List<String> customJmsProps) throws IOException {
		if(customJmsProps != null && customJmsProps.size() > 0) {
			_prop.setProperty(RuntimeProperties.CUSTOM_PROPERTIES_LIST, (Object) customJmsProps);
		}
		else {
			throw new  IOException("Custom JMS Properties could not be successfully set.");
		}
	}
	
			
	public void setSubscriberNotificationQueueDepth(int sz) {
		_prop.setProperty(RuntimeProperties.SUB_NOTIFICATION_QUEUE_DEPTH, sz);
	}
	
	public void setSubscriberQueueLists(String queuesStr) {
		loadDestListFromList(RuntimeProperties.SUB_QUEUE_LISTS, queuesStr);
		_prop.setProperty(RuntimeProperties.SUB_DESTINATION_TYPE, SubscriberDestinationsType.QUEUE);
	}
	
	public void setSubscriberQueuesFileList(String fileList) throws IOException {
		List<List<String>> queuesLists = fileListToLineLists(fileList);
		_prop.setProperty(RuntimeProperties.SUB_QUEUE_LISTS, queuesLists);
		_prop.setProperty(RuntimeProperties.SUB_DESTINATION_TYPE, SubscriberDestinationsType.QUEUE);
	}
	
	public void setSubscriberDTELists(String dteStr) {
		loadDestListFromList(RuntimeProperties.SUB_DTE_LISTS, dteStr);
		_prop.setProperty(RuntimeProperties.SUB_DESTINATION_TYPE, SubscriberDestinationsType.TOPIC);
	}
	
	public void setSubscriberDTEFileList(String fileList) throws IOException {
		List<List<String>> topicLists = fileListToLineLists(fileList);
		_prop.setProperty(RuntimeProperties.SUB_DTE_LISTS, topicLists);
		_prop.setProperty(RuntimeProperties.SUB_DESTINATION_TYPE, SubscriberDestinationsType.TOPIC);
	}
	
	public void setSubscriberTopicLists(String topicsStr) {
		loadDestListFromList(RuntimeProperties.SUB_TOPIC_LISTS, topicsStr);
		_prop.setProperty(RuntimeProperties.SUB_DESTINATION_TYPE, SubscriberDestinationsType.TOPIC);
	}
	
	
	public void setSubscriberTopicsFileList(String fileList) throws IOException {
		List<List<String>> topicLists = fileListToLineLists(fileList);
		_prop.setProperty(RuntimeProperties.SUB_TOPIC_LISTS, topicLists);
		_prop.setProperty(RuntimeProperties.SUB_DESTINATION_TYPE, SubscriberDestinationsType.TOPIC);
	}
	
	public void setNumTempQueueEndpoints(int value) {
		_prop.setProperty(RuntimeProperties.NUM_TEMP_QUEUE_ENDPOINTS, value);
	}
	
	public void setNumTempTopicEndpoints(int value) {
		_prop.setProperty(RuntimeProperties.NUM_TEMP_TOPIC_ENDPOINTS, value);
	}
	
	public void setSelectorLists(String csv) {
		loadDestListFromList(RuntimeProperties.SELECTOR_LIST, csv);
	}
	
	public void setSelectorFileList(String fileList) throws IOException {
		List<List<String>> selectorsLists = fileListToLineLists(fileList);
		_prop.setProperty(RuntimeProperties.SELECTOR_LIST, selectorsLists);
	}
	
	
	public void setSubscriberRemove(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_REMOVE_SUBSCRIBER, value);
	}
	
	public void setWantSubscriptionMemory(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_SUBSCRIPTION_MEMORY, value);
	}
	
	public void setWantQueueBrowsing(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_QUEUE_BROWSER, value);
	}
	
	public void setQBDeleteBuf(int value) {
		_prop.setIntegerProperty(RuntimeProperties.QB_DELETE_BUFFER, value);
	}
	
	public void setQBDeleteFrequency(int value) {
		_prop.setIntegerProperty(RuntimeProperties.QB_DELETE_FREQUENCY, value);
	}
	
	public void setQueueBrowseDelete(String value) throws ParseException {
		try {
			StringTokenizer tok = new StringTokenizer(value, ",");
			int intValue = Integer.parseInt(tok.nextToken());
			setQBDeleteFrequency(intValue);
			if (tok.hasMoreTokens()) {
				intValue = Integer.parseInt(tok.nextToken());
				setQBDeleteBuf(intValue);
			} else {
				setQBDeleteBuf(0);
			}
		} catch (NumberFormatException nfe) {
			throw new ParseException("Error parsing F,B format.");
		}
	}
	
	public void setSubMsgQueueDepth(int value) {
		_prop.setIntegerProperty(RuntimeProperties.SUB_MSG_QUEUE_DEPTH, value);
	}
	
	public void setSubDelay(int value) {
		_prop.setIntegerProperty(RuntimeProperties.SUBSCRIBER_SUB_DELAY, value);
	}

	public void setSubDelayCount(int value) {
		_prop.setIntegerProperty(RuntimeProperties.SLOW_SUB_DELAY_COUNT, value);
	}
		
	public void setSubRateInterval(int sri) {
		_prop.setIntegerProperty(RuntimeProperties.SUBSCRIBER_RATE_INTERVAL, sri);
		
	}
	
	public void setSubscriberPerSubThruStats(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_PER_SUB_THRU_STATS, value);
	}
	
	public void setWantSubscriptionRateStats(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_SUBSCRIPTION_RATE_STATS, value);
	}
	
	
	
	
	
	
	
	/**
	 * Do not notify sender if a message fails to be enqueued to the endpoint.
	 */
	
	
	
	public void setDiscardNotifySender(String value) {
		
		if (value != null && value.equals("on")) {
			_prop.setIntegerProperty(RuntimeProperties.DISCARD_NOTIFY_SENDER, Constants.DISCARD_NOTIFY_SENDER_ON );
		} else if (value != null && value.equals("off")) {
			_prop.setIntegerProperty(RuntimeProperties.DISCARD_NOTIFY_SENDER, Constants.DISCARD_NOTIFY_SENDER_OFF);
		} else {
			//  The -1 is used to symbolize that we won't set that property
			//  and leave it to be the default value to be set by the SDK
			//  further down the stream.
			_prop.setIntegerProperty(RuntimeProperties.DISCARD_NOTIFY_SENDER, -1);
		}
	}
	
	public void setAdPubWindowSize(int apw) {
		_prop.setIntegerProperty(RuntimeProperties.AD_PUB_WINDOW_SIZE, apw);
	}
	public void setAdPubAckTimeout(int apa) {
		_prop.setIntegerProperty(RuntimeProperties.AD_PUB_ACK_TIMEOUT, apa);
	}
	public void setAdPubMaxResends(int amr) {
		_prop.setIntegerProperty(RuntimeProperties.AD_PUB_MAX_RESEND, amr);
	}
	public void setAdSubWindowSize(int asw) {
		_prop.setIntegerProperty(RuntimeProperties.AD_SUB_WINDOW_SIZE, asw);
	}
	public void setAdSubAckTimeout(int asa) {
		_prop.setIntegerProperty(RuntimeProperties.AD_SUB_ACK_TIMEOUT, asa);
	}
	public void setAdSubThreshold(int awt) {
		_prop.setIntegerProperty(RuntimeProperties.AD_SUB_WINDOW_THRESHOLD, awt);
	}
	public void setAdTransactionSize(int value) {
		_prop.setIntegerProperty(RuntimeProperties.AD_TRANSACTION_SIZE, value);
	}
	public void setWantXaTransaction(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION, value);
	}
	public void setWantOnePhaseCommitTransaction(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.XA_WANT_ONE_PHASE_COMMIT_TRANSACTION, value);
	}
	public void setNumMsgsPerTransactionSegment(int value) {
		_prop.setIntegerProperty(RuntimeProperties.XA_NUM_MSGS_PER_TRANSACTION_SEGMENT, value);
	}
	public void setNumSuspendedTransactions(int value) {
		_prop.setIntegerProperty(RuntimeProperties.XA_NUM_SUSPENDED_TRANSACTIONS, value);
	}
	public void setWantProducerConsumersTransaction(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.AD_WANT_PRODUCER_CONSUMERS_TRANSACTION, value);
	}
	public void setXaTransactionIdleTimeout(int value) {
		_prop.setIntegerProperty(RuntimeProperties.XA_TRANSACTION_IDLE_TIMEOUT, value);
	}
	public void setTransactionPhaseDelayBeforeSuspending(int value) {
		_prop.setIntegerProperty(RuntimeProperties.XA_TRANSACTION_PHASE_DELAY_BEFORE_SUSPENDING, value);
	}
	public void setTransactionPhaseDelayBeforeEnding(int value) {
		_prop.setIntegerProperty(RuntimeProperties.XA_TRANSACTION_PHASE_DELAY_BEFORE_ENDING, value);
	}
	public void setTransactionPhaseDelayBeforePreparing(int value) {
		_prop.setIntegerProperty(RuntimeProperties.XA_TRANSACTION_PHASE_DELAY_BEFORE_PREPARING, value);
	}
	public void setTransactionPhaseDelayBeforeCommitting(int value) {
		_prop.setIntegerProperty(RuntimeProperties.XA_TRANSACTION_PHASE_DELAY_BEFORE_COMMITTING, value);
	}
	public void setWantActiveFlowIndication(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.AD_WANT_ACTIVE_FLOW_INDICATION, value);
	}
	public void setAckImmediatelyInterval(int value) {
		_prop.setIntegerProperty(RuntimeProperties.AD_ACK_IMMEDIATELY_INTERVAL, value);
	}
	public void setAdTransactionRollbackInterval(int value) {
		_prop.setIntegerProperty(RuntimeProperties.AD_TRANSACTION_ROLLBACK_INTERVAL, value);
	}
	public void setAdTransactionIdleTime(int value) {
		_prop.setIntegerProperty(RuntimeProperties.AD_TRANSACTION_IDLE_TIME, value);
	}
	public void setWantPubAckOrderCheck(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.AD_WANT_PUB_ACK_ORDER_CHECK, value);
	}
	
	public void setTransactedSessionNameList(List<String> value) {
		_prop.setProperty(RuntimeProperties.TRANSACTED_SESSION_NAME_LIST, value);
	}
	
	public void setWantCidStat(boolean cid) {
		_prop.setBooleanProperty(RuntimeProperties.CID_STATS, cid);
	}
	public void setWantDIStat(boolean cid) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_DI_STATS, cid);
	}
	
	public void setWantVerbose(boolean verbose) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_VERBOSE, verbose);
	}

	public void setWantContextPerClient(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_CONTEXT_PER_CIENT, value);
	}
	
	public void setWantNoLocal(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_NO_LOCAL, value);
	}
	
	public void setWantClientAck(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_CLIENT_ACK, value);
	}

	public void setWantClientAckThread(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_CLIENT_ACK_THREAD, value);
	}

	public void setClientAckSkipNum(int value) {
		_prop.setIntegerProperty(RuntimeProperties.CLIENT_ACK_SKIP_NUM, value);
	}

	public void setClientAckFlushQueue(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.CLIENT_ACK_FLUSH_QUEUE, value);
	}
	
	public void setClientAckQueueReverse(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.CLIENT_ACK_QUEUE_REVERSE, value);
	}

	public void setClientAckRandomDepth(int value) {
		_prop.setIntegerProperty(RuntimeProperties.CLIENT_ACK_RANDOM_DEPTH, value);
	}
	
	public void setWantQuiet(boolean quiet) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_QUIET, quiet);
	}
	
	public void setWantVersion(boolean wantVersion) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_VERSIONPRINT, wantVersion);
	}
			
	public void setWantMessageContentExamined(boolean wantMEC) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_MESSAGE_EXAMINE_CONTENT, wantMEC);
	}
	
	public void setWantOrderCheck(boolean wantOrderCheck) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_ORDER_CHECK, wantOrderCheck);		
	}
	
	public void setWantLossAndDuplicateDetection(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_LOSS_AND_DUPLICATE_DETECTION, value);		
	}
	
	public void setWantOrderMemory(boolean flag) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_ORDER_MEMORY, flag);		
	}
	
	public void setWantSmoothPubCalcLat(boolean flag) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_SMOOTH_PUB_CALC_LAT, flag);		
	}
	
	public void setDefaultStructuredDataList() {
		List<Integer> sdmList = new LinkedList<Integer>();
		sdmList.add(SdkperfConstants.SDM_ID_ALL);
		setStructuredDataList(sdmList);
	}
	public void setStructuredDataList(List<Integer> list) {
		_prop.setProperty(RuntimeProperties.STRUCT_DATA_MSGS_LIST, list);
		setWantStructMsgCheck(true);
	}
	
	public void setWantStructMsgCheck(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_STRUCT_MSG_CHECK, value);
		
	}
	
	public void setWantLatency(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_LATENCY, value);
	}
	
	public void setWantFullLatencyStats(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_FULL_LATENCY_STATS, value);
	}
	
	public void setLatencyBuckets(int buckets) {
		_prop.setIntegerProperty(RuntimeProperties.LATENCY_BUCKETS, buckets);
	}
	
	public void setLatencyGranularity(int granularity) {
		_prop.setIntegerProperty(RuntimeProperties.LATENCY_GRANULARITY, granularity);
	}
	
	public void setLatencyWarmupInSec(double warmup) {
		_prop.setDoubleProperty(RuntimeProperties.LATENCY_WARMUP_IN_SECS, warmup);
	}
	
	public void setWantPayloadCheck(boolean wantPayloadCheck) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_PAYLOAD_CHECK, wantPayloadCheck);
	}
	
	public void setWantUD(boolean wantUD) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_UD, wantUD);		
	}
	
	public void setWantClientSynchronousReceive(boolean wantSyncReceive) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_SYNC_RECEIVE, wantSyncReceive);		
	}
	
	public void setOptionFilePath(String optionFile) {
		_prop.setProperty(RuntimeProperties.OPTION_FILE, optionFile);
	}
	
	public void setJMSCF(String value) {
		_prop.setProperty(RuntimeProperties.JMS_CONNECTION_FACTORY, value);
	}
	
	public void setOptimizeJMSForDirectDelivery(boolean value) {
	    _prop.setBooleanProperty(RuntimeProperties.SOLACE_JMS_OPTIMIZE_DIRECT, value);
	}
	
	public void setJMSSubscriberAckMode(int mode) {
		_prop.setIntegerProperty(RuntimeProperties.JMS_SUBACK_MODE, mode);
	}
	
	public void setReappplySubscriptions(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_SUBSCRIPTION_MEMORY, value);
	}
	public void setCachePropName(String value) {
		_prop.setProperty(RuntimeProperties.CACHE_PROP_NAME, value);
		this.setCacheWantStats(true);
	}
	
	public void setCachePropMaxMsgsPerTopic(int value) {
		_prop.setIntegerProperty(RuntimeProperties.CACHE_PROP_MAX_MSGS_PER_TOPIC, value);
	}
	
	public void setCachePropMaxAge(int value) {
		_prop.setIntegerProperty(RuntimeProperties.CACHE_PROP_MAX_AGE, value);
	}
	
	public void setCachePropTimeoutInMsec(int value) {
		_prop.setIntegerProperty(RuntimeProperties.CACHE_PROP_TIMEOUT_IN_MSEC, value);
	}
	
	public void setCacheWantRequestsOnSubscribe(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.CACHE_WANT_REQUESTS_ON_SUBSCRIBE, value);
	}
	
	public void setCacheReqMsgRate(int value) {
		_prop.setIntegerProperty(RuntimeProperties.CACHE_REQ_MSG_RATE, value);
	}
	
	public void setCacheWantStats(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.CACHE_WANT_STATS, value);
	}
	
	public void setCacheNumReq(int value) {
		_prop.setIntegerProperty(RuntimeProperties.CACHE_NUM_REQ, value);
	}

	public void setCacheLiveDataAction(String value) throws PubSubException {
		AbstractCacheLiveDataAction action = AbstractCacheLiveDataAction.valueOf(value.toUpperCase());
		_prop.setProperty(RuntimeProperties.CACHE_LIVE_DATA_ACTION, action);
	}
	
	public void setCacheReqMinSequence(long value) {
		_prop.setLongProperty(RuntimeProperties.CACHE_REQ_MIN_SEQUENCE_NUM, value);
	}
	public void setCacheReqMaxSequence(long value) {
		_prop.setLongProperty(RuntimeProperties.CACHE_REQ_MAX_SEQUENCE_NUM, value);
	}
	public void setCacheReqWaitForConfirm(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.CACHE_REQ_WAIT_FOR_CONFIRM, value);
	}
	
	public void setReadTimeoutInMsec(int value) {
		_prop.setIntegerProperty(RuntimeProperties.READ_TIMEOUT_IN_MSEC, value);
	}
	
	public void setKeepaliveIntervalInMsec(int value) {
		_prop.setIntegerProperty(RuntimeProperties.KEEPALIVE_INTERVAL_MSEC, value);
	}
	public void setReconnectAttempts(int value) {
		// As discussed in bug #47057, less than -2 means "use api default"
		if (value >= -2) {
			_prop.setIntegerProperty(RuntimeProperties.RECONNECT_ATTEMPTS, value);
		} else {
			_prop.setProperty(RuntimeProperties.RECONNECT_ATTEMPTS, null);
		}
	}
	public void setReconnectFailAction(ReconnectFailAction rfa) {
		_prop.setProperty(RuntimeProperties.RECONNECT_FAIL_ACTION, rfa);
	}
	public void setReconnectIntervalInMsec(int value) {
		// As discussed in bug #47057, less than -2 means "use api default"
		if (value >= -2) {
			_prop.setIntegerProperty(RuntimeProperties.RECONNECT_INTERVAL_MSEC, value);
		}
	}
	public void setJNDIforJMS(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_JNDI_FOR_JMS, value);
	}
	
	public void setBurstDuration(double value) {
		_prop.setDoubleProperty(RuntimeProperties.BURST_DURATION, value);
	}

	public void setInterBurstDuration(double value) {
		_prop.setDoubleProperty(RuntimeProperties.INTER_BURST_DURATION, value);
	}
	
	public void setProvisionEndpoints(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_PROVISIONED_ENDPOINT, value);
	}
	
	public void setPEPremision(String value) {
		_prop.setProperty(RuntimeProperties.PE_PERMISSION, value);
	}
	
	public void setPEAccessType(EndpointAccessType value) {
		_prop.setProperty(RuntimeProperties.PE_ACCESS_TYPE, value);
	}
	
	public void setPEQuota(int value) {
		_prop.setIntegerProperty(RuntimeProperties.PE_QUOTA_MB, value);
	}
	
	public void setPEMAxMsgSize(int value) {
		_prop.setIntegerProperty(RuntimeProperties.PE_MAXMSG_SIZE, value);
	}

	public void setPEMaxMsgRedelivery(int value) {
		_prop.setIntegerProperty(RuntimeProperties.PE_MAX_MSG_REDELIVERY, value);
	}
	
	public void setPERespectTTL(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.PE_RESPECT_TTL, value);
	}
	
	public void setStopOnError(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_STOP_ON_ERROR, value);
	}
	
	public void setPubSendVectSize(int value) {
		_prop.setIntegerProperty(RuntimeProperties.PUB_SEND_VECT_SIZE, value);
	}
	
	public void setSubscriptionClientName(String value) {
		_prop.setProperty(RuntimeProperties.SUBSCRIPTION_CLIENT_NAME, value);
	}
	
	public void setWantCutThroughPersistence(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_CUT_THROUGH_PERSISTENCE, value);
	}
	
	public void setWantUserPropToolData(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_USER_PROP_TOOL_DATA, value);
	}
	
	public void setWantNonBlockingConnect(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_NON_BLOCKING_CONNECT, value);
	}
	
	public void setClientTransportProtocol(String value) {
		_prop.setProperty(RuntimeProperties.WEB_TRANSPORT_PROTOCOL, value);		
	}
	
	public void setWebTransportProtocolList(String value) {
		_prop.setProperty(RuntimeProperties.WEB_TRANSPORT_PROTOCOL_LIST, value);		
	}
	
	public void setClientTransportProtocolDowngradeTimeout(String value) {
		_prop.setProperty(RuntimeProperties.TRANSPORT_PROTOCOL_DOWNGRADE_TIMEOUT_MS, value);		
	}
	
	public void setWantPerMessageDetails(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.WANT_PER_MESSAGE_DETAILS, value);		
	}	
	
	public void setToolMode(String value) {
		ToolMode tm = null;
		if (value.equalsIgnoreCase("rtrperf"))
			tm = ToolMode.RTRPERF;
		else if (value.equalsIgnoreCase("sdkperf"))
			tm = ToolMode.SDKPERF;
		else {
			throw new IllegalArgumentException("Provided invalid tool mode: " + value);
		}
		
		_prop.setProperty(RuntimeProperties.TOOL_MODE, tm);
	}
	
	public void setToolMode(ToolMode tm) {
		if (tm == null)
			throw new NullArgumentException("Provided invalid tool mode (null).");

		_prop.setProperty(RuntimeProperties.TOOL_MODE, tm);
	}
	
	public void setToolApi(String value) {
		InternalApiMode apiMode = null;
		if (value.equalsIgnoreCase("jcsmp"))
			apiMode = InternalApiMode.JCSMP;
		else if (value.equalsIgnoreCase("jms"))
			apiMode = InternalApiMode.JMS;
		else if (value.equalsIgnoreCase("jni"))
			apiMode = InternalApiMode.JNI;
		else if (value.equalsIgnoreCase("rest"))
			apiMode = InternalApiMode.REST;
		else if (value.equalsIgnoreCase("mqtt"))
			apiMode = InternalApiMode.MQTT;
		else if (value.equalsIgnoreCase("javascript"))
            apiMode = InternalApiMode.JAVASCRIPT;
		else if (value.equalsIgnoreCase("actionscript"))
            apiMode = InternalApiMode.ACTIONSCRIPT;
		else if (value.equalsIgnoreCase("silverlight"))
            apiMode = InternalApiMode.SILVERLIGHT;
		else if (value.equalsIgnoreCase("thirdparty"))
			apiMode = InternalApiMode.THIRDPARTY;
		else {
			throw new IllegalArgumentException("Provided invalid tool mode: " + value);
		}
		
		_prop.setProperty(RuntimeProperties.API_MODE, apiMode);
	}
	
	public void setTransferEncoding(String value){		
		if(value.equalsIgnoreCase("chunked"))
			_prop.setProperty(RuntimeProperties.REST_DATA_MODE, Constants.GenericTransferEncoding.CHUNKED);
		else if (value.equalsIgnoreCase("compress"))
			_prop.setProperty(RuntimeProperties.REST_DATA_MODE, Constants.GenericTransferEncoding.COMPRESS);
		else if (value.equalsIgnoreCase("deflate"))
			_prop.setProperty(RuntimeProperties.REST_DATA_MODE, Constants.GenericTransferEncoding.DEFLATE);
		else if (value.equalsIgnoreCase("gzip"))
			_prop.setProperty(RuntimeProperties.REST_DATA_MODE, Constants.GenericTransferEncoding.GZIP);
		else if (value.equalsIgnoreCase("identity"))
			_prop.setProperty(RuntimeProperties.REST_DATA_MODE, Constants.GenericTransferEncoding.IDENTITY);
		else
			throw new IllegalArgumentException("Provided Invalid tranfer encoding option: "+value);
	}
	
	public void setRestMode(String value){
		if(value.equalsIgnoreCase("httpclient"))
			_prop.setProperty(RuntimeProperties.RESTCLIENT_MODE, Constants.GenericRestMode.HTTPCLIENT);
		else if(value.equalsIgnoreCase("socket"))
			_prop.setProperty(RuntimeProperties.RESTCLIENT_MODE, Constants.GenericRestMode.SOCKET);
		else 
			throw new IllegalArgumentException("Provided Invalid REST Client Mode: " + value);
	}
		
	public void setMqttPublishQos(int value) {
		
		if(value >= 0 && value <= 2)
		    _prop.setIntegerProperty(RuntimeProperties.MQTT_PUBLISH_QOS, value);
		else
			throw new IllegalArgumentException("Invalid MQTT Publisher QoS provided, accepted values are: 0, 1 and 2.");
	}

	public void setMqttSubscribeQos(int value) {
		if(value >= 0 && value <= 2)
		    _prop.setIntegerProperty(RuntimeProperties.MQTT_SUBSCRIBE_QOS, value);
		else
			throw new IllegalArgumentException("Invalid MQTT Subscription QoS provided, accepted values are: 0, 1 and 2.");
	}

	public void setMQTTWillMsgTopic(String value){
		_prop.setProperty(RuntimeProperties.MQTT_WILL_TOPIC, value);
	}
	
	public void setMQTTWillMsgSize(int size){
		
		if(size < 0) {
			throw new IllegalArgumentException("Invalid MQTT Will Message Size provided: " + size);
		}
		
		_prop.setIntegerProperty(RuntimeProperties.MQTT_WILL_MSG_SIZE, size);
	}
	
	public void setMqttWantCleanConnect(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.MQTT_WANT_CLEAN_CONNECT, value);
	}
	
	public void setMQTTWillMsgQos(int value){
		
		if(value < 0 || value > 2){
			throw new IllegalArgumentException("Invalid MQTT Will Message QoS provided: " + value);
		}
		
		_prop.setIntegerProperty(RuntimeProperties.MQTT_WILL_QOS, value);
	}
	
	public void setMQTTWillMsgRetained(boolean value){
		_prop.setBooleanProperty(RuntimeProperties.MQTT_WILL_RETAINED, value);
	}
	
	public void setToolExternalClientClassString(String value) {
		_prop.setProperty(RuntimeProperties.TOOL_THIRD_PARTY_EXTERNAL_CLIENT_CLASS, value);
	}
	
	public void setAckEventMode(String value) {		
		if (value.equalsIgnoreCase("per-message")) {
			_prop.setProperty(RuntimeProperties.AD_ACK_EVENT_MODE, GenericSupportedAckEvent.PER_MSG);
		} else if (value.equalsIgnoreCase("windowed")) {
			_prop.setProperty(RuntimeProperties.AD_ACK_EVENT_MODE, GenericSupportedAckEvent.WINDOWED);
		} else if (!value.equalsIgnoreCase("")) {
			throw new IllegalArgumentException("Provided ack event mode: " + value);
		}
	}
	
	public void setWebMessagingBrowserType(String value) {
	    _prop.setProperty(RuntimeProperties.WEB_MESSAGING_BROWSER_TYPE, value);
	}
	
	public void setWebMessagingGotoURL(String value) {
        _prop.setProperty(RuntimeProperties.WEB_MESSAGING_GOTO_URL, value);
    }
	
	public void setWebMessagingTransportScheme(String value) {
        _prop.setProperty(RuntimeProperties.WEB_MESSAGING_TRANSPORT_SCHEME, value);
    }
	
	public void setWebMessagingUseProxy(boolean value) {
        _prop.setBooleanProperty(RuntimeProperties.WEB_MESSAGING_USE_PROXY, value);
    }
	
	public void setWantDispatchSession(boolean value) {
        _prop.setBooleanProperty(RuntimeProperties.WANT_DISPATCH_SESSION, value);
    }
	
   public void setWebMessagingSendBufferMaxSize(int value) {
        _prop.setIntegerProperty(RuntimeProperties.WEB_MESSAGING_SEND_BUFFER_MAX_SIZE, value);
    }
   
    public void setWebMessagingMaxWebPayload(int value) {
        _prop.setIntegerProperty(RuntimeProperties.WEB_MESSAGING_MAX_WEB_PAYLOAD, value);
    }
	
	public void setCallbackOnReactorThread(boolean value) {
	    _prop.setBooleanProperty(RuntimeProperties.MESSAGE_CALLBACK_ON_REACTOR, value);
	}
	
	public void setNumberOfMessagesToPublishOnReceive(int value) {
	    _prop.setIntegerProperty(RuntimeProperties.NUMBER_OF_MSGS_TO_PUB_ON_RCV, value);
	}
	public void setPublishOnReceiveTopicList(String value) {
		_prop.setProperty(RuntimeProperties.POR_TOPIC_LIST, csv2List(value));
	}
	public void setPublishOnReceiveQueueList(String value) {
		_prop.setProperty(RuntimeProperties.POR_QUEUE_LIST, csv2List(value));
	}
	public void setPublishOnReceiveAttachmentSizeList(List<Integer> value) {
	    _prop.setProperty(RuntimeProperties.POR_ATTACHMENT_SIZE_LIST, value);
	}
	public void setPublishOnReceiveMessageType(String value) {
		_prop.setProperty(RuntimeProperties.POR_MESSAGE_TYPE, RuntimePropertiesBuilder.getMessageDeliveryMode(value));
	}
	public void setPublishOnReceiveReflectMessage(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.POR_REFLECT_MESSAGE, value);
	}

	public void setWantReplicationReconnect(boolean value) {
	    _prop.setBooleanProperty(RuntimeProperties.WANT_REPLICATION_RECONNECT, value);
	}
	
	public void setSkipFinalCommit(boolean value) {
	    _prop.setBooleanProperty(RuntimeProperties.SKIP_FINAL_COMMIT, value);
	}
	
	public void setSslProtocol(String value) {
		_prop.setProperty(RuntimeProperties.SSL_PROTOCOL, value);
	}
	
	public void setSslConnectionDowngradeTo(String value) {
		if (value == null) {
			throw new IllegalArgumentException("SSL_CONNECTION_DOWNGRADE_TO session property value cannot be null.");
		}
		if (value.equalsIgnoreCase("PLAIN_TEXT")) {
			_prop.setProperty(RuntimeProperties.SSL_CONNECTION_DOWNGRADE_TO, "PLAIN_TEXT");
		} else {
			_prop.setProperty(RuntimeProperties.SSL_CONNECTION_DOWNGRADE_TO, value);
		}
	}
	
	public void setSslExcludedProtocols(String value) {
		_prop.setProperty(RuntimeProperties.SSL_EXLCUDED_PROTOCOLS, value);
	}
	
	
	public void setSslCertificateFile(String value) {
		_prop.setProperty(RuntimeProperties.SSL_CLIENT_CERTIFICATE_FILE, value);
	}
	
	public void setSslClientPrivateKeyFile(String value) {
		_prop.setProperty(RuntimeProperties.SSL_CLIENT_PRIVATE_KEY_FILE, value);
	}
	public void setSslClientPrivateKeyFilePassword(String value) {
		_prop.setProperty(RuntimeProperties.SSL_CLIENT_PRIVATE_KEY_FILE_PASSWORD, value);
	}
	
	public void setSslValidateCertificate(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE, value);
	}
	
	public void setSslValidateCertificateDate(boolean value) {
		_prop.setBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE_DATE, value);
	}
	
	public void setSslCipherSuites(String value) {
		_prop.setProperty(RuntimeProperties.SSL_CIPHER_SUITES, value);
	}
	
	public void setSslTrustStore(String value) {
		_prop.setProperty(RuntimeProperties.SSL_TRUST_STORE, value);
	}
	
	public void setSslTrustStoreDir(String value) {
		_prop.setProperty(RuntimeProperties.SSL_TRUST_STORE_DIR, value);
	}
	
	public void setSslTrustStorePassword(String value) {
		_prop.setProperty(RuntimeProperties.SSL_TRUST_STORE_PASSWORD, value);
	}
	
	public void setSslTrustStoreFormat(String value) {
		_prop.setProperty(RuntimeProperties.SSL_TRUST_STORE_FORMAT, value);
	}
	
	public void setSslTrustedCommonNameList(String value) {
		_prop.setProperty(RuntimeProperties.SSL_TRUSTED_COMMON_NAME_LIST, value);
	}
    
    public void setSslKeyStore(String value) {
        _prop.setProperty(RuntimeProperties.SSL_KEY_STORE, value);
    }
    
    public void setSslKeyStorePassword(String value) {
        _prop.setProperty(RuntimeProperties.SSL_KEY_STORE_PASSWORD, value);
    }
    
    public void setSslKeyStoreFormat(String value) {
        _prop.setProperty(RuntimeProperties.SSL_KEY_STORE_FORMAT, value);
    }
    
    public void setSslPrivateKeyAlias(String value) {
        _prop.setProperty(RuntimeProperties.SSL_PRIVATE_KEY_ALIAS, value);
    }
    
    public void setSslPrivateKeyPassword(String value) {
        _prop.setProperty(RuntimeProperties.SSL_PRIVATE_KEY_PASSWORD, value);
    }
    
    public void setAuthenticationScheme(GenericAuthenticationScheme authenticationScheme) {
        _prop.setProperty(RuntimeProperties.AUTHENTICATION_SCHEME, authenticationScheme);
    }
    
    public void setAuthenticationScheme(String authenticationScheme) throws ParseException {
	    if (authenticationScheme.equalsIgnoreCase(GenericAuthenticationScheme.BASIC.toString()))
	    	setAuthenticationScheme(GenericAuthenticationScheme.BASIC);
	    else if (authenticationScheme.equalsIgnoreCase(GenericAuthenticationScheme.CLIENT_CERTIFICATE.toString()))
	    	setAuthenticationScheme(GenericAuthenticationScheme.CLIENT_CERTIFICATE);
	    else if (authenticationScheme.equalsIgnoreCase(GenericAuthenticationScheme.GSS_KRB.toString()))
	    	setAuthenticationScheme(GenericAuthenticationScheme.GSS_KRB);
	    else {
	        throw new ParseException("Invalid authentication scheme: \"" + authenticationScheme +"\"."
	        		+ " See help for valid authentication schemes.");
	    }
    }

    public void setWantApplicationServerCommand(String value) {
    	_prop.setProperty(RuntimeProperties.APPLICATION_SERVER_COMMAND, value);
    }
    
    public void setWantRATransaction(boolean value) {
    	_prop.setBooleanProperty(RuntimeProperties.APPLICATION_SERVER_RA_TRANSACTION, value);	
    }
    
    
    public void setNumPubThreads(int value) {
    	
    	if(value < 0) {
    		throw new IllegalArgumentException("Invalid number of publish thread requested ("+value+").");
    	}
    	
    	_prop.setIntegerProperty(RuntimeProperties.NUM_PUB_THREADS, value);
    }
    
	@SuppressWarnings("unchecked")
	public boolean validate(PrintStream errStream) {
		// Perform validity checks (add more to here as need comes up)
		StringBuffer errors = new StringBuffer();
		StringBuffer warnings = new StringBuffer();

		boolean bHaveTopics = (_prop.getProperty(RuntimeProperties.PUBLISH_TOPIC_LIST) != null) ? true : false;
		boolean bHaveQueues = (_prop.getProperty(RuntimeProperties.PUBLISH_QUEUE_LIST) != null) ? true : false;
			
		// xmlmeta, topics and queues are mutually exclusive.
		if ((bHaveTopics && bHaveQueues) ) {
			errors.append("E: Must specify only one of -ptl, -pql for publish.\n");
		}
			
		// All pub lists must be equal length if non-zero.
		int iListSize = 0;
		if (_prop.getProperty(RuntimeProperties.PUBLISH_FILE_LIST) != null) {
			iListSize = ((List<ByteBuffer>)_prop.getProperty(RuntimeProperties.PUBLISH_FILE_LIST)).size();
		}
		if (_prop.getProperty(RuntimeProperties.PUBLISH_ATTACH_LIST) != null) {
			int iTempListSize = ((List<ByteBuffer>)_prop.getProperty(RuntimeProperties.PUBLISH_ATTACH_LIST)).size();
			if (iListSize == 0) {
				iListSize = iTempListSize;
			} else if (iTempListSize != iListSize) {
				errors.append("E: All message part lists must be of equal length.\n");
			}
		}
		// Topics || queues list must be 1 or equal length to pub lists.
		if (_prop.getProperty(RuntimeProperties.PUBLISH_TOPIC_LIST) != null) {
			int iTempListSize = ((List<String>)_prop.getProperty(RuntimeProperties.PUBLISH_TOPIC_LIST)).size();
			if (iTempListSize != 1 && iTempListSize != iListSize && iListSize > 0) {
				errors.append("E: Topic list must len 1 or equal to message parts lists.\n");
			}
		}
		if (_prop.getProperty(RuntimeProperties.PUBLISH_QUEUE_LIST) != null) {
			int iTempListSize = ((List<String>)_prop.getProperty(RuntimeProperties.PUBLISH_QUEUE_LIST)).size();
			if (iTempListSize != 1 && iTempListSize != iListSize && iListSize > 0) {
				errors.append("E: Queue list must len 1 or equal to message parts lists.\n");
			}
		}
			
		if (_prop.getProperty(RuntimeProperties.CLIENT_IP_ADDR) == null) {
			if(_prop.getProperty(RuntimeProperties.SERVER_PORT_LIST) == null)
				errors.append("E: Must specify CLIENT_IP_ADDR (-cip).\n");
		}
		
		if(_prop.getIntegerProperty(RuntimeProperties.PUBLISH_END_DELAY_IN_SEC) != null &&
				_prop.getIntegerProperty(RuntimeProperties.PUBLISH_END_DELAY_IN_SEC).intValue() < 0 ){
			errors.append("E: Specified invalid value for PUBLISH_END_DELAY_IN_SEC  (-ped).\n");
		}
		
		
		if (errors.length() > 0)
			errStream.print(errors.toString());

		if (warnings.length() > 0)
			errStream.print(warnings.toString());
		
		return (errors.length() == 0); // true if validation passed (no errors)
	}

	public static GenericMessageDeliveryMode getMessageDeliveryMode(String type) {
		
		if (type.equalsIgnoreCase("direct") || type.equalsIgnoreCase("default"))
			return GenericMessageDeliveryMode.DIRECT;
		else if (type.equalsIgnoreCase("persistent"))
			return GenericMessageDeliveryMode.PERSISTENT;
		else if (type.equalsIgnoreCase("non-persistent")
				|| type.equalsIgnoreCase("non_persistent")
				|| type.equalsIgnoreCase("nonpersistent"))
			return GenericMessageDeliveryMode.NON_PERSISTENT;

		throw new IllegalArgumentException("Invalid value \"" + type + "\" for Message Delivery Mode.");
	}

	private static List<ByteBuffer> fileListToContentBuffers(String fileList) throws IOException
		 {
		// parse file list into individual paths
		// load each file into a byte array
		// store byte arrays into a List<ByteBuffer>

		// WARNING: this takes a huge amount of memory
		
		List<ByteBuffer> contentBufs = new LinkedList<ByteBuffer>();
		StringTokenizer tok = new StringTokenizer(fileList, ",");
		while (tok.hasMoreTokens()) {
			String s = tok.nextToken();
			byte[] curFileData = PerfIO.readFileAsBytes(s);
			contentBufs.add(ByteBuffer.wrap(curFileData));
		}
		return contentBufs;
	}

	private static List<List<String>> fileListToLineLists(String fileList)
		throws IOException {
		// parse file list into individual paths
		// load each file into a List<String>
		// store these lists into a List<List<String>>

		// WARNING: this takes a huge amount of memory

		List<List<String>> lineLists = new LinkedList<List<String>>();
		StringTokenizer tok = new StringTokenizer(fileList, ",");
		while (tok.hasMoreTokens()) {
			String s = tok.nextToken();
			lineLists.add(PerfIO.readFileAsLines(s, true));
		}
		return lineLists;
	}
	
	private static List<String> csv2List(String csv) {
		List<String> ls = new LinkedList<String>();
		StringTokenizer tok = new StringTokenizer(csv, ",");
		while (tok.hasMoreTokens()) {
			String s = tok.nextToken();
			ls.add(s);
		}
		return ls;
	}
	
	private static Set<Integer> csv2IntSet(String csv) {
		Set<Integer> ls = new HashSet<Integer>();
		StringTokenizer tok = new StringTokenizer(csv, ",");
		while (tok.hasMoreTokens()) {
			String s = tok.nextToken();
			ls.add(Integer.parseInt(s));
		}
		return ls;
	}
	
	
	private void loadDestListFromList(String propName, String topicsStr) {
		List<List<String>> topicLists = new LinkedList<List<String>>();

		// For some insight about that loop, observe that the variable i and
		// the current item are marching lockstep. At every iteration, we simply
		// drop the i-th item into the bucket i % N where N is the number of buckets.
		//
		// The if branches simply tests whether or not this is the first time that
		// we add a value for the corresponding client, in which case there is
		// some initialization to do. That gives us round robin.
		//
		// e.g. : If we distribute the values [1,2,3,4,5,6,7] among 3 clients,
		//        we wind up with [[1,4,7], [2,5], [3,6]].
		//
		//		  Bear in mind, though, that because of the way that the topics
		//		  are handled by the addSubscriptions() method in SDKPerf_java,
		//        if we have 3 topics and 10 clients, even though the resulting
		//        value of topicLists will look like [[1], [2], [3]], the final
		//        behavior will be such that it was as though we had that 
		//        topicLists was more like this :
		//           [[1], [2], [3], [1], [2], [3], [1], [2], [3], [1]]
		
		int i = 0;
		List<String> topics = csv2List(topicsStr);
		int numClients = _prop.getIntegerProperty(RuntimeProperties.NUM_CLIENTS);
		
		//for the case we want to set up topicstr to null and we have no client (restServer for example)
		if(numClients==0)
			numClients++;

		for (String item : topics) {
			if (i < numClients) {
				List<String> topic = new LinkedList<String>();
				topic.add(item);
				topicLists.add(topic);
			} else {
				List<String> topic = topicLists.get(i % numClients);
				topic.add(item);
			}
			i++;
		}
		_prop.setProperty(propName, topicLists);
	}
	public void printOptions(){
		Set<String> keys = _prop.propertyNames();
		Iterator<String> it = keys.iterator();
		while(it.hasNext()){
			String key = (String)it.next();
			System.out.print(key+"  :             ");
			System.out.println(_prop.getProperty(key));
		}
		
	}

	public void setRequestReplyWaitTime(int value) {
		_prop.setIntegerProperty(RuntimeProperties.REQUEST_REPLY_WAIT_TIME, value);
	}

	public void setMsgReflectDelayList(String optionValue) {

		List<String> delayListStr = csv2List(optionValue);
		List<Integer> delayListInt = new ArrayList<Integer>();

		for (String s : delayListStr) {
			Integer i;
			try {
				i = Integer.parseInt(s);
			} catch (NumberFormatException e) {
				throw new IllegalArgumentException("Could not parse reply/reflect delay value \"" + s + "\".", e);
			}

			if (i != null)
				delayListInt.add(i);
		}

		_prop.setProperty(RuntimeProperties.MESSAGE_REPLY_DELAY_LIST, delayListInt);
	}


	
}
