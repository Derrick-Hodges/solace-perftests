/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.common.util.CPUUsage;
import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;

/**
 * This class represents a collection of clients and presents
 * an interface so that actions can be performed on one or more
 * of these clients.  For example starting publishing.
 * 
 * This collection keeps the following internal lists:
 *      - CscsmpClient - For connection management, publishing,
 *                       subscribing, etc.
 *      - PubThread - 1 publishing threads.
 *      - CacheThread - Unsupported.
 *      - QueueBrowsing - Unsupported.
 */
public class RtrperfClientCollection extends AbstractClientCollection {
	private static final Log Trace = LogFactory.getLog(RtrperfClientCollection.class);

	private RtrperfPubThread _pubThread;

	
	public RtrperfClientCollection(RuntimeProperties prop, CPUUsage cpuMon) throws Exception {
		super(prop, cpuMon);
		
		_pubThread = new RtrperfPubThread(_clients);
		
		
		
		
		if (Trace.isDebugEnabled()) {
			Trace.debug(String.format("ClientCollection preparing %d clients...", _numClients));
		}
	}
	
	/////////////////////////////////////////////////////////////////
	// Cache Requesting Methods
	@Override
	public void startCacheRequesting(List<String> topics, RuntimeProperties reqProps) throws Exception {
		Trace.warn("Cache Requesting is unsupported in rtrperf.  Please use sdkperf.");
	}

	@Override
	public void stopCacheRequesting() throws PubSubException {
		Trace.warn("Cache Requesting is unsupported in rtrperf.  Please use sdkperf.");
	}

	@Override
	public boolean isCacheRequesting() {
		Trace.info("Cache Requesting is not a supported feature in rtrperf. Please use sdkperf for Cache Requesting");
		return false;
	}

	/////////////////////////////////////////////////////////////////
	// Publishing Methods
	@Override
	public void startPublishing(RuntimeProperties pubprops) throws Exception {
		if (isPublishing())
			throw new IllegalStateException(
				"Already publishing, must call stopPublishing before starting again.");
		
		if ((_rprops.getProperty(RuntimeProperties.STRUCT_DATA_MSGS_LIST) != null)
				&& (_rprops.getBooleanProperty(RuntimeProperties.WANT_ORDER_CHECK) ||
					_rprops.getBooleanProperty(RuntimeProperties.WANT_LATENCY) ||
					_rprops.getBooleanProperty(RuntimeProperties.WANT_PAYLOAD_CHECK) ||
					_rprops.getBooleanProperty(RuntimeProperties.WANT_LOSS_AND_DUPLICATE_DETECTION)))
		{
			throw new PubSubException("Cannot use order check, loss/duplicate detection, latency or payload check with structured messages");
	    }
		
		// Can't use multi threaded publishers per session as rtrperf is designed to 
	    // be single threaded.
	    if (_rprops.getIntegerProperty(RuntimeProperties.NUM_PUBS_PER_SESSION).intValue() > 1) {
	        throw new PubSubException("Cannot specify more than 1 pub per client with rtrperf.");
	    }
		
		// Cannot have msg rate is max with burst mode or smooth publishers.
		if (pubprops.getBooleanProperty(RuntimeProperties.MSG_RATE_IS_MAX) &&
			((pubprops.getDoubleProperty(RuntimeProperties.BURST_DURATION) > 0 && 
			  pubprops.getDoubleProperty(RuntimeProperties.INTER_BURST_DURATION) > 0) || 
			 pubprops.getBooleanProperty(RuntimeProperties.WANT_SMOOTH_PUB_CALC_LAT))) {
			throw new PubSubException("Unsupported publish combination.  Cannot use message rate target of max with smooth pubs or bursty pubs.");
		}
		
		// Msg Rate is max is only supported with normal publishing.  It's not supported with burst mode or smooth publishers
	    // Cannot have msg rate is max with burst mode or smooth publishers.
	    if (pubprops.getBooleanProperty(RuntimeProperties.MSG_RATE_IS_MAX)) {
	        throw new PubSubException("Unsupported publish combination.  Rtrperf does not support message rate target max.");
	    }
		
		// doclist is a not a list of immutable objects, it not shared with all pubs
		// each pub takes a copy of the list so that tool data can be updated
		// on message publish.
		// To save on memory, the call to create a doc list will also erase
		// loaded message buffers since they will then have been copied to the
		// MsgRep objects.
		List<BasicMsgRep> doclist;
		if (pubprops.getProperty(RuntimeProperties.STRUCT_DATA_MSGS_LIST) != null)
		{
			doclist = createDoclistForStructMsgs(pubprops);
		}
		else if (pubprops.getProperty(RuntimeProperties.SMF_BINARY_FILE_LIST) != null)
		{
			doclist = createDoclistFromBinarySmf(pubprops);
		}
		else
		{
			doclist = createDoclist(pubprops);
		}
		pubprops.setProperty(RuntimeProperties.PUBLISH_FILE_LIST, null);
		pubprops.setProperty(RuntimeProperties.PUBLISH_ATTACH_LIST, null);
		
	    if(pubprops.getStringProperty(RuntimeProperties.HTTP_CONTENT_ENCODING) != null) {
	    	for(BasicMsgRep m : doclist) {
	    		m.setHttpContentEncoding(pubprops.getStringProperty(RuntimeProperties.HTTP_CONTENT_ENCODING));
	    	}
	    }
	    if(pubprops.getStringProperty(RuntimeProperties.HTTP_CONTENT_TYPE) != null) {
	    	for(BasicMsgRep m : doclist) {
	    		m.setHttpContentType(pubprops.getStringProperty(RuntimeProperties.HTTP_CONTENT_TYPE));
	    	}
	    }
		
		final long numTotalMsgs = pubprops.getLongProperty(RuntimeProperties.NUM_MSGS_TO_PUBLISH).longValue();
		
		_pubThread.startPublish(doclist, numTotalMsgs, pubprops);
	}

	@Override
	public void stopPublishing() throws PubSubException {
		_pubThread.stopPublish();
	}

	@Override
	public boolean isPublishing() {
		return _pubThread.isPublishing();
	}

	
	///////////////////////////////////////////////////////////////////////
	// Queue Browsing Access
	@Override
	public void startQueueBrowsing(List<String> queues, String selector, RuntimeProperties props) throws Exception {
		throw new PubSubException("Feature unsupported in rtrperf.  Please use sdkperf for Queue Browsing");
	}

	@Override
	public void stopQueueBrowsing() throws PubSubException {
		throw new PubSubException("Feature unsupported in rtrperf.  Please use sdkperf for Queue Browsing");
	}

	@Override
	public boolean isQueueBrowsing() {
		Trace.error("Feature unsupported in rtrperf.  Please use sdkperf for Queue Browsing");
		return false;
	}

	
	///////////////////////////////////////////////////////////////////////
	// Stats Access
	@Override
	public void resetStats(final int clientidx) {
		super.resetStats(clientidx);
		_pubThread.resetStats();
	}

	@Override
	public double getTxThroughput() {
		
		long startTime = _pubThread.getStartTimeInNanos();
		
		if (startTime == 0) return 0;
		
		long endTime = _pubThread.getEndTimeInNanos();
		
		/*
		 * This lets us get up-to-date throughput stats while publishing, but
		 * uses the "REAL" start/end times when calling after publishing is
		 * finished.
		 */
		if (endTime == 0) {
			endTime = System.nanoTime();
		} 

		long msgsPublished;
		try {
			msgsPublished = this.getSdkStat(GenericStatType.TOTAL_MSGS_SENT, ALL_CLIENT_INDEX);
		} catch (PubSubException e) {
			Trace.error("Error while getting sdk stat.", e);
			return 0;
		}
		long timeDiffInNanos = endTime - startTime;

		if (timeDiffInNanos <= 0) {
			return 0;
		} else {
			return ((msgsPublished * 1000000000) / timeDiffInNanos);
		}
	}
	
	// No stats yet supported so return an empty PerfStats.
	@Override
	public PerfStats getTxStats(final int clientidx) {
		PerfStats ret_stats;
		
		int latBuckets = 0;
		int latGranularity = 0;
		double warmup = 0;
		ret_stats = new PerfStats(
				"aggregate", 
				latBuckets, 
				latGranularity, 
				warmup);
		
		return ret_stats;
	}
	
	/////////////////////////////////////////////////////////////
	// Other Methods

	@Override
	public String toString() {
		// Returns a huge per-client dump of names / SDK stats.
		StringBuffer buf = new StringBuffer();
		for (AbstractClient client : _clients) {
			buf.append(client.toString()).append("\n");
		}
		
		return buf.toString();
	}
	
	/////////////////////////////////////////////////////////////
	// Private methods
	
	@Override
	protected long getLastPubTimeInNanos()
	{
		// Last pub time is used for AD pub ack order checking.  This is not
		// supported in rtrperf.	    
	    return 0;
	}
	
	@Override
	protected void setLastPubTimeInNanos(long timeInNanos, int clientidx)
	{
		// Last pub time is used for AD pub ack order checking.  This is not
		// supported in rtrperf.
	}

}
