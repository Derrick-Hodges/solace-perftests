package com.solacesystems.pubsub.sdkperf.jms.solace;

import java.util.Hashtable;
import java.util.List;

import javax.jms.Connection;
import javax.jms.Session;
import javax.jms.XAConnection;
import javax.jms.XASession;
import javax.naming.InitialContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.jms.SupportedProperty;
import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.AbstractClient;
import com.solacesystems.pubsub.sdkperf.core.ClientFactory;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericAuthenticationScheme;
import com.solacesystems.pubsub.sdkperf.core.Constants.ReconnectFailAction;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsClientTransactedSession;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsClientXaSession;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsSdkperfFactory;

public class SolJmsSdkperfFactory implements JmsSdkperfFactory {

	private static final Log Trace = LogFactory.getLog(SolJmsSdkperfFactory.class);
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public InitialContext createInitialContext(RuntimeProperties rxProps, int clientIdInt) throws Exception {
		// Must build the provider URL string array.
		String hostList = rxProps.getStringProperty(RuntimeProperties.CLIENT_IP_ADDR);
		
		// check host
		StringBuilder bldr = new StringBuilder();
		String[] hostListArray = hostList.split(",");
		for(int i = 0; i < hostListArray.length; i++) {
			if (i > 0) {
				bldr.append(",");
			}
			if (hostListArray[i].indexOf("://") == -1) {
				bldr.append("smf://");
			}
			bldr.append(hostListArray[i]);
		}

		Hashtable<String,Object> 	env = new Hashtable<String,Object>();
		env.put(InitialContext.INITIAL_CONTEXT_FACTORY, JMSConstants.INITIAL_CONTEXT_FACTORY_NAME);
		env.put(InitialContext.PROVIDER_URL, bldr.toString());
		
		GenericAuthenticationScheme authScheme = (GenericAuthenticationScheme) rxProps.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME);
		
		if (!rxProps.getStringProperty(RuntimeProperties.CLIENT_USERNAME).equals("") ||
				(rxProps.getStringProperty(RuntimeProperties.CLIENT_USERNAME).equals("") &&
				 !authScheme.equals(GenericAuthenticationScheme.CLIENT_CERTIFICATE) &&
				 !authScheme.equals(GenericAuthenticationScheme.GSS_KRB))) {
			String jmsUsername = ClientFactory.generateClientUsername(rxProps, clientIdInt);
			env.put(javax.naming.Context.SECURITY_PRINCIPAL, jmsUsername);
		}
		
		String jmsPassword = rxProps.getStringProperty(RuntimeProperties.CLIENT_PASSWORD);
		env.put(javax.naming.Context.SECURITY_CREDENTIALS, jmsPassword);
		
		String jmsVPN = rxProps.getStringProperty(RuntimeProperties.CLIENT_VPN);
		env.put(SupportedProperty.SOLACE_JMS_VPN, jmsVPN);
		
		if (!rxProps.getProperty(RuntimeProperties.SSL_PROTOCOL).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_PROTOCOL, rxProps
					.getProperty(RuntimeProperties.SSL_PROTOCOL));
		}
		
		if (rxProps.getProperty(RuntimeProperties.RECONNECT_FAIL_ACTION) != null) {
			ReconnectFailAction rfa = (ReconnectFailAction) rxProps
					.getProperty(RuntimeProperties.RECONNECT_FAIL_ACTION);
			if (rfa == ReconnectFailAction.AUTO_RETRY) {
				env.put(SupportedProperty.SOLACE_JMS_GD_RECONNECT_FAIL_ACTION,
						SupportedProperty.GD_RECONNECT_FAIL_ACTION_AUTO_RETRY);
			} else if (rfa == ReconnectFailAction.DISCONNECT) {
				env.put(SupportedProperty.SOLACE_JMS_GD_RECONNECT_FAIL_ACTION,
						SupportedProperty.GD_RECONNECT_FAIL_ACTION_DISCONNECT);
			}
		}
		
		if (rxProps.getProperty(RuntimeProperties.SSL_CONNECTION_DOWNGRADE_TO) != null
				&& !rxProps.getProperty(RuntimeProperties.SSL_CONNECTION_DOWNGRADE_TO).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_CONNECTION_DOWNGRADE_TO,
					rxProps.getProperty(RuntimeProperties.SSL_CONNECTION_DOWNGRADE_TO));
		}
		
		if (!rxProps.getProperty(RuntimeProperties.SSL_EXLCUDED_PROTOCOLS).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_EXCLUDED_PROTOCOLS, rxProps
					.getProperty(RuntimeProperties.SSL_EXLCUDED_PROTOCOLS));
		}
		
		if (!rxProps.getBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE)) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_VALIDATE_CERTIFICATE, rxProps
					.getBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE));
		}
		
		if (!rxProps.getBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE_DATE)) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_VALIDATE_CERTIFICATE_DATE, rxProps
					.getBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE_DATE));
		}
		
		if (!rxProps.getProperty(RuntimeProperties.SSL_CIPHER_SUITES).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_CIPHER_SUITES, rxProps
					.getProperty(RuntimeProperties.SSL_CIPHER_SUITES));
		}
		
		if (!rxProps.getProperty(RuntimeProperties.SSL_TRUST_STORE).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_TRUST_STORE, rxProps
					.getProperty(RuntimeProperties.SSL_TRUST_STORE));
		}
		
		// Check for WANT_NON_BLOCKING_CONNECT
		Boolean value = rxProps.getBooleanProperty(RuntimeProperties.WANT_NON_BLOCKING_CONNECT);
		if (value != null && value) {
			Trace.warn("Cannot connect in a non-blocking way when using the JmsClient.");
		}
		
		if (!rxProps.getProperty(RuntimeProperties.SSL_TRUST_STORE_PASSWORD).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_TRUST_STORE_PASSWORD, rxProps
					.getProperty(RuntimeProperties.SSL_TRUST_STORE_PASSWORD));
		}
		
		if (!rxProps.getProperty(RuntimeProperties.SSL_TRUST_STORE_FORMAT).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_TRUST_STORE_FORMAT, rxProps
					.getProperty(RuntimeProperties.SSL_TRUST_STORE_FORMAT));
		}
		
		if (!rxProps.getProperty(RuntimeProperties.SSL_TRUSTED_COMMON_NAME_LIST).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_TRUSTED_COMMON_NAME_LIST, rxProps
					.getProperty(RuntimeProperties.SSL_TRUSTED_COMMON_NAME_LIST));
		}
		
		if (rxProps.getBooleanProperty(RuntimeProperties.SOLACE_JMS_OPTIMIZE_DIRECT) != null) {
			env.put(SupportedProperty.SOLACE_JMS_OPTIMIZE_DIRECT,
					rxProps.getBooleanProperty(RuntimeProperties.SOLACE_JMS_OPTIMIZE_DIRECT));
			Trace.info("Setting SOLACE_JMS_OPTIMIZE_DIRECT " 
					+ rxProps.getBooleanProperty(RuntimeProperties.SOLACE_JMS_OPTIMIZE_DIRECT));
		}
		
		if (!rxProps.getProperty(RuntimeProperties.SSL_KEY_STORE).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_KEY_STORE, rxProps
					.getProperty(RuntimeProperties.SSL_KEY_STORE));
		}
		
		if (!rxProps.getProperty(RuntimeProperties.SSL_KEY_STORE_PASSWORD).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_KEY_STORE_PASSWORD, rxProps
					.getProperty(RuntimeProperties.SSL_KEY_STORE_PASSWORD));
		}
		
		if (!rxProps.getProperty(RuntimeProperties.SSL_KEY_STORE_FORMAT).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_KEY_STORE_FORMAT, rxProps
					.getProperty(RuntimeProperties.SSL_KEY_STORE_FORMAT));
		}
		
		if (!rxProps.getProperty(RuntimeProperties.SSL_PRIVATE_KEY_ALIAS).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_PRIVATE_KEY_ALIAS, rxProps
					.getProperty(RuntimeProperties.SSL_PRIVATE_KEY_ALIAS));
		}
		
		if (!rxProps.getProperty(RuntimeProperties.SSL_PRIVATE_KEY_PASSWORD).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_SSL_PRIVATE_KEY_PASSWORD, rxProps
					.getProperty(RuntimeProperties.SSL_PRIVATE_KEY_PASSWORD));
		}
		
		if (!rxProps.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME).equals("")) {
			env.put(SupportedProperty.SOLACE_JMS_AUTHENTICATION_SCHEME, rxProps
					.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME));
			
			if (authScheme.equals(GenericAuthenticationScheme.BASIC)) {
				env.put(SupportedProperty.SOLACE_JMS_AUTHENTICATION_SCHEME, SupportedProperty.AUTHENTICATION_SCHEME_BASIC);
			} else if (authScheme.equals(GenericAuthenticationScheme.CLIENT_CERTIFICATE)) {
				env.put(SupportedProperty.SOLACE_JMS_AUTHENTICATION_SCHEME, SupportedProperty.AUTHENTICATION_SCHEME_CLIENT_CERTIFICATE);
			} else if (authScheme.equals(GenericAuthenticationScheme.GSS_KRB)) {
				env.put(SupportedProperty.SOLACE_JMS_AUTHENTICATION_SCHEME, SupportedProperty.AUTHENTICATION_SCHEME_GSS_KRB);
			} else {
				throw new IllegalArgumentException("Unknown authentication type \"" + authScheme + "\".");
			}
		}
		
		if (rxProps.getProperty(RuntimeProperties.EXTRA_PROP_LIST) != null) {
			List<String> extraProp = (List<String>) rxProps.getProperty(RuntimeProperties.EXTRA_PROP_LIST);
			
			for(int i = 0; i < (extraProp.size() - 1); i +=2) {
				env.put(extraProp.get(i), extraProp.get(i+1));
			}
		}
		
		if (rxProps.getIntegerProperty(RuntimeProperties.RECONNECT_INTERVAL_MSEC) != null) {
			Trace.error(String.format("Reconnect interval (msec) property (value=%d) was ignored.",
								rxProps.getIntegerProperty(RuntimeProperties.RECONNECT_INTERVAL_MSEC)));
		}
		if (rxProps.getIntegerProperty(RuntimeProperties.KEEPALIVE_INTERVAL_MSEC) != null) {
			Trace.error(String.format("Keep-alive interval (msec) property (value=%d) was ignored.",
								rxProps.getIntegerProperty(RuntimeProperties.KEEPALIVE_INTERVAL_MSEC)));
		}
		
		if (rxProps.getIntegerProperty(RuntimeProperties.CLIENT_COMPRESSION_LEVEL) != null) {
			Trace.error(String.format("Client compression level property (value=%d) was ignored, this value must be specified in the JMS Connection Factory.",
								rxProps.getIntegerProperty(RuntimeProperties.CLIENT_COMPRESSION_LEVEL)));
		}
		
		return new InitialContext(env);
	}
	
	public JmsClientTransactedSession createClientTransactedSession(AbstractClient client, Connection connection, Session transactedSession, RuntimeProperties rprops) {
		return new JmsClientTransactedSession(client, transactedSession, rprops);
	}

	public JmsClientXaSession createXaTransactedSession(AbstractClient client,
			XAConnection xaConnection, XASession xaSession, RuntimeProperties rprops) {
		return new JmsClientXaSession(client, xaSession, rprops);
	}
}