
package com.solacesystems.pubsub.sdkperf.core;

import java.util.Enumeration;
import java.util.Vector;
import com.solacesystems.common.SolEnum;


public final class GenericStatType extends SolEnum {
	
	
	private static final long serialVersionUID = 1L;
	private static int count=0;
	
	/**
	 * A count of messages sent.
	 */
	public static final GenericStatType TOTAL_MSGS_SENT;
	
	/**
	 * A count of messages sent with a QOS=0.
	 */
	public static final GenericStatType TOTAL_MSGS_SENT_QOS0;
	
	/**
	 * A count of messages sent with a QOS=1.
	 */
	public static final GenericStatType TOTAL_MSGS_SENT_QOS1;
	
	/**
	 *A count of messages sent with a QOS=2.
	 */
	public static final GenericStatType TOTAL_MSGS_SENT_QOS2;

	
	/**
	 * A count of bytes sent over the sockets owned by this session, including SMF
	 * protocol overhead.
	 */
	public static final GenericStatType TOTAL_SOCKET_BYTES_SENT;
	
	/**
	 * A count of bytes sent as part of published messages.
	 */
	public static final GenericStatType TOTAL_BYTES_SENT;

	/**
	 * A count of compressed bytes sent (after compression).
	 */
	public static final GenericStatType TOTAL_SOCKET_COMPRESSED_BYTES_SENT;

    /**
     * A count of ssl bytes sent (after encryption).
     */
    public static final GenericStatType TOTAL_SOCKET_SSL_BYTES_SENT;

	/**
	 * Total count of messages sent through TCP.
	 */
	public static final GenericStatType RELIABLE_MSGS_SENT;

	/**
	 * Total count of bytes sent through TCP.
	 */
	public static final GenericStatType RELIABLE_BYTES_SENT;

	/**
	 * Total count of messages sent through TCP acknowledged by
	 * the appliance.
	 */
	public static final GenericStatType RELIABLE_MSGS_SENT_CONFIRMED;

	/**
	 * A count of {@link DeliveryMode#PERSISTENT} messages sent.
	 */
	public static final GenericStatType RELIABLE_PERSISTENT_MSGS_SENT;

	/**
	 * A count of bytes sent as {@link DeliveryMode#PERSISTENT} messages.
	 */
	public static final GenericStatType RELIABLE_PERSISTENT_BYTES_SENT;

	/**
	 * A count of {@link DeliveryMode#NON_PERSISTENT} messages sent.
	 */
	public static final GenericStatType RELIABLE_NONPERSISTENT_MSGS_SENT;

	/**
	 * A count of bytes sent as {@link DeliveryMode#NON_PERSISTENT} messages.
	 */
	public static final GenericStatType RELIABLE_NONPERSISTENT_BYTES_SENT;

	/**
	 * A count of {@link DeliveryMode#DIRECT} messages sent.
	 */
	public static final GenericStatType RELIABLE_DIRECT_MSGS_SENT;

	/**
	 * A count of bytes sent as {@link DeliveryMode#DIRECT} messages.
	 */
	public static final GenericStatType RELIABLE_DIRECT_BYTES_SENT;

	/**
	 * A count of messages received.
	 */
	public static final GenericStatType TOTAL_MSGS_RECVED;

	/**
	 * A count of bytes received as part of subscriber messages, control messages,
	 * and protocol overhead.
	 */
	public static final GenericStatType TOTAL_SOCKET_BYTES_RECVED;
	
	/**
	 * A count of bytes received as part of subscriber messages.
	 */
	public static final GenericStatType TOTAL_BYTES_RECVED;
	
	/**
	 * A count of compressed bytes received (before decompression).
	 */
	public static final GenericStatType TOTAL_SOCKET_COMPRESSED_BYTES_RECVED;

    /**
     * A count of ssl bytes received (before decryption).
     */
    public static final GenericStatType TOTAL_SOCKET_SSL_BYTES_RECVED;

	/**
	 * A count of messages received through TCP.
	 */
	public static final GenericStatType RELIABLE_MSGS_RECVED;

	/**
	 * A count of bytes received through TCP.
	 */
	public static final GenericStatType RELIABLE_BYTES_RECVED;

	/**
	 * A count of messages received through TCP that were
	 * acknowledged, indicating successful delivery to the application.
	 */
	public static final GenericStatType RELIABLE_MSGS_RECVED_ACKED;

	/**
	 * A count of {@link DeliveryMode#PERSISTENT} messages received.
	 */
	public static final GenericStatType RELIABLE_PERSISTENT_MSGS_RECVED;

	/**
	 * A count of bytes received as {@link DeliveryMode#PERSISTENT} messages.
	 */
	public static final GenericStatType RELIABLE_PERSISTENT_BYTES_RECVED;

	/**
	 * A count of {@link DeliveryMode#PERSISTENT} messages received that were acknowledged, indicating
	 * successful delivery to the application.
	 */
	public static final GenericStatType RELIABLE_PERSISTENT_MSGS_RECVED_ACKED;

	/**
	 * A count of {@link DeliveryMode#NON_PERSISTENT} messages received.
	 */
	public static final GenericStatType RELIABLE_NONPERSISTENT_MSGS_RECVED;

	/**
	 * A count of bytes received as {@link DeliveryMode#NON_PERSISTENT} messages.
	 */
	public static final GenericStatType RELIABLE_NONPERSISTENT_BYTES_RECVED;

	/**
	 * A count of {@link DeliveryMode#NON_PERSISTENT} messages received that were acknowledged,
	 * indicating successful delivery to the application.
	 */
	public static final GenericStatType RELIABLE_NONPERSISTENT_MSGS_RECVED_ACKED;

	/**
	 * A count of {@link DeliveryMode#DIRECT} messages received.
	 */
	public static final GenericStatType RELIABLE_DIRECT_MSGS_RECVED;

	/**
	 * A count of bytes received as {@link DeliveryMode#DIRECT} messages.
	 */
	public static final GenericStatType RELIABLE_DIRECT_BYTES_RECVED;

	/**
	 * A count of messages received through TCP and dropped
	 * for being received out-of-order.
	 */
	public static final GenericStatType RELIABLE_MSGS_DISCARDED_OUTOFORDER;

	/**
	 * A count of messages received through TCP and dropped
	 * for being received as duplicate.
	 */
	public static final GenericStatType RELIABLE_MSGS_DISCARDED_DUPLICATES;

	/**
	 * Total number of TCP connections attempted by this session.
	 */
	public static final GenericStatType TOTAL_CONNECTION_ATTEMPTS;

	/**
	 * A count of {@link DeliveryMode#PERSISTENT} messages that were retransmitted to the appliance. 
	 */
	public static final GenericStatType RELIABLE_PERSISTENT_MSGS_RESENT;

	/**
	 * A count of bytes in {@link DeliveryMode#PERSISTENT} messages that were retransmitted to the appliance. 
	 */
	public static final GenericStatType RELIABLE_PERSISTENT_BYTES_RESENT;

	/**
	 * A count of {@link DeliveryMode#NON_PERSISTENT} messages that were retransmitted to the appliance. 
	 */
	public static final GenericStatType RELIABLE_NONPERSISTENT_MSGS_RESENT;

	/**
	 * A count of bytes in {@link DeliveryMode#NON_PERSISTENT} messages that were retransmitted to the appliance. 
	 */
	public static final GenericStatType RELIABLE_NONPERSISTENT_BYTES_RESENT;

	/**
	 * A count of reliable messages that were retransmitted to the appliance. 
	 */
	public static final GenericStatType RELIABLE_MSGS_RESENT;

	/**
	 * A count of bytes in reliable messages that were retransmitted to the appliance. 
	 */
	public static final GenericStatType RELIABLE_BYTES_RESENT;
	
	
	/**
	 * The number of messages received with the Discard Notification bit set.
	 * <p>
	 * Note that a message arriving with the Discard Notification bit set
	 * indicates that one or more messages prior to this message were
	 * dropped; therefore, this statistic is not indicative of the number of dropped
	 * messages.
	 * </p>
	 */
	public static final GenericStatType ROUTER_DISCARD_NOTIFICATIONS;
	
	/**
	 * The number of SMF messages discarded due to the presence of an unknown
	 * element in the SMF header.
	 * <p>
	 * Incoming protocol messages can be discarded due to the presence of
	 * unknown elements, such as an unknown protocol or parameter. Note that
	 * this statistic includes not only subscriber-bound routed messages, but
	 * all dropped SMF-encoded protocol messages received by the API.
	 * </p>
	 */
	public static final GenericStatType SMF_DISCARDS_UNKNOWN_ELEMENT;
	
	/**
	 * The number of times the subscriber was congested and suspended reads from the
	 * socket.
	 */
	public static final GenericStatType SUBSCRIBER_CONGESTED_EVENT;
	
	/**
	 * The number of messages discarded due to arriving on a message flow that did
	 * not match any local open message flows.
	 */
	public static final GenericStatType RELIABLE_MSGS_DISCARDED_NO_MATCHING_FLOW;
	
	/**
	 * The number of cache requests. This corresponds to the number of cache 
	 * request API calls that were made. A single cache request can involve
	 * many requests and replies.
	 */
	public static final GenericStatType CACHE_REQUESTS_SENT;

    /**
     * The number of cache requests that have been fulfilled with a live message.
     */
    public static final GenericStatType CACHE_REQUESTS_FULFILLED;

	/**
	 * The number of cache messages retrieved from caches.
	 */
	public static final GenericStatType CACHED_MSGS_RECVED;
	
	/**
	 * The number of cache replies discarded because a request has
	 * been fulfilled.
	 */
    public static final GenericStatType CACHE_FULFILL_REPLIES_DISCARDED;

	/**
	 * The number of requests that have been sent.
	 */
	public static final GenericStatType REQUESTS_SENT;

	/**
     * The number of requests that have timed out waiting for a reply.
     */
    public static final GenericStatType REQUESTS_TIMED_OUT;

	/**
	 * The number of replies to requests that have been received.
	 */
	public static final GenericStatType REPLIES_RECVED;

	/**
	 * The number of replies that have been discarded because
	 * there was no outstanding request. 
	 */
	public static final GenericStatType REPLIES_DISCARDED;

	/**
	 * Counts the number of times an application attempted to enqueue a
	 * Guaranteed Delivery message for publishing and found the publisher window
	 * full.
	 * <p>
	 * 
	 * High values for this statistic may indicate the publisher flow's window
	 * size is too low and is unable to keep up with the application's rate of
	 * message publishing.
	 */
	public static final GenericStatType PUBLISHER_WINDOW_CLOSED;
	/**
	 * Counts the number of times the subscriber window became closed, that is,
	 * the number of times a Guaranteed Delivery message was enqueued for a
	 * {@link Consumer} and that operation caused its local queue to be full.
	 * <p>
	 * High values for this statistic may indicate the application is not
	 * processing incoming messages fast enough to keep up with the flow from
	 * the appliance, or the flow's window size is too low.
	 */
	public static final GenericStatType SUBSCRIBER_FLOW_WINDOW_CLOSED;

	/**
	 * The number of incoming messages dropped by the API due to their
	 * {@link Consumer} being stopped. This statistic tracks both
	 * {@link DeliveryMode#DIRECT Direct} and Guaranteed Delivery messages
	 * dropped by stopped consumers; note that Guaranteed Delivery messages are
	 * not lost and will be received once the consumer is started.
	 */
	public static final GenericStatType MESSAGES_DISCARDED_INTERNAL;

	static {
		/*
		 * WARN: make sure the 'count' passed as the SolEnum id field is a valid
		 * array index [0 - n].
		 */

		TOTAL_MSGS_SENT = new GenericStatType(count++, "TOTAL_MSGS_SENT"); //$NON-NLS-1$
		TOTAL_SOCKET_BYTES_SENT = new GenericStatType(count++, "TOTAL_SOCKET_BYTES_SENT"); //$NON-NLS-1$
		TOTAL_BYTES_SENT = new GenericStatType(count++, "TOTAL_BYTES_SENT"); //$NON-NLS-1$
		TOTAL_SOCKET_COMPRESSED_BYTES_SENT = new GenericStatType(count++, "TOTAL_SOCKET_COMPRESSED_BYTES_SENT"); //$NON-NLS-1$
        TOTAL_SOCKET_SSL_BYTES_SENT = new GenericStatType(count++, "TOTAL_SOCKET_SSL_BYTES_SENT"); //$NON-NLS-1$
		RELIABLE_MSGS_SENT = new GenericStatType(count++, "RELIABLE_MSGS_SENT"); //$NON-NLS-1$
		RELIABLE_BYTES_SENT = new GenericStatType(count++, "RELIABLE_BYTES_SENT"); //$NON-NLS-1$
		RELIABLE_MSGS_SENT_CONFIRMED = new GenericStatType(count++, "RELIABLE_MSGS_SENT_CONFIRMED"); //$NON-NLS-1$
		RELIABLE_PERSISTENT_MSGS_SENT = new GenericStatType(count++, "RELIABLE_PERSISTENT_MSGS_SENT"); //$NON-NLS-1$
		RELIABLE_PERSISTENT_BYTES_SENT = new GenericStatType(count++, "RELIABLE_PERSISTENT_BYTES_SENT"); //$NON-NLS-1$
		RELIABLE_NONPERSISTENT_MSGS_SENT = new GenericStatType(count++, "RELIABLE_NONPERSISTENT_MSGS_SENT"); //$NON-NLS-1$
		RELIABLE_NONPERSISTENT_BYTES_SENT = new GenericStatType(count++, "RELIABLE_NONPERSISTENT_BYTES_SENT"); //$NON-NLS-1$
		RELIABLE_DIRECT_MSGS_SENT = new GenericStatType(count++, "RELIABLE_DIRECT_MSGS_SENT"); //$NON-NLS-1$
		RELIABLE_DIRECT_BYTES_SENT = new GenericStatType(count++, "RELIABLE_DIRECT_BYTES_SENT"); //$NON-NLS-1$
		
		TOTAL_MSGS_SENT_QOS0 = new GenericStatType(count++, "TOTAL_MSGS_SENT_QOS0");
		TOTAL_MSGS_SENT_QOS1 = new GenericStatType(count++, "TOTAL_MSGS_SENT_QOS1");
		TOTAL_MSGS_SENT_QOS2 = new GenericStatType(count++, "TOTAL_MSGS_SENT_QOS2");
	
		TOTAL_MSGS_RECVED = new GenericStatType(count++, "TOTAL_MSGS_RECVED"); //$NON-NLS-1$
		TOTAL_SOCKET_BYTES_RECVED = new GenericStatType(count++, "TOTAL_SOCKET_BYTES_RECVED"); //$NON-NLS-1$
		TOTAL_BYTES_RECVED = new GenericStatType(count++, "TOTAL_BYTES_RECVED"); //$NON-NLS-1$
		TOTAL_SOCKET_COMPRESSED_BYTES_RECVED = new GenericStatType(count++, "TOTAL_SOCKET_COMPRESSED_BYTES_RECVED"); //$NON-NLS-1$
        TOTAL_SOCKET_SSL_BYTES_RECVED = new GenericStatType(count++, "TOTAL_SOCKET_SSL_BYTES_RECVED"); //$NON-NLS-1$
		RELIABLE_MSGS_RECVED = new GenericStatType(count++, "RELIABLE_MSGS_RECVED"); //$NON-NLS-1$
		RELIABLE_BYTES_RECVED = new GenericStatType(count++, "RELIABLE_BYTES_RECVED"); //$NON-NLS-1$
		RELIABLE_MSGS_RECVED_ACKED = new GenericStatType(count++, "RELIABLE_MSGS_RECVED_ACKED"); //$NON-NLS-1$
		RELIABLE_PERSISTENT_MSGS_RECVED = new GenericStatType(count++, "RELIABLE_PERSISTENT_MSGS_RECVED"); //$NON-NLS-1$
		RELIABLE_PERSISTENT_BYTES_RECVED = new GenericStatType(count++, "RELIABLE_PERSISTENT_BYTES_RECVED"); //$NON-NLS-1$
		RELIABLE_PERSISTENT_MSGS_RECVED_ACKED = new GenericStatType(count++, "RELIABLE_PERSISTENT_MSGS_RECVED_ACKED"); //$NON-NLS-1$
		RELIABLE_NONPERSISTENT_MSGS_RECVED = new GenericStatType(count++, "RELIABLE_NONPERSISTENT_MSGS_RECVED"); //$NON-NLS-1$
		RELIABLE_NONPERSISTENT_BYTES_RECVED = new GenericStatType(count++, "RELIABLE_NONPERSISTENT_BYTES_RECVED"); //$NON-NLS-1$
		RELIABLE_NONPERSISTENT_MSGS_RECVED_ACKED = new GenericStatType(count++, "RELIABLE_NONPERSISTENT_MSGS_RECVED_ACKED"); //$NON-NLS-1$
		RELIABLE_DIRECT_MSGS_RECVED = new GenericStatType(count++, "RELIABLE_DIRECT_MSGS_RECVED"); //$NON-NLS-1$
		RELIABLE_DIRECT_BYTES_RECVED = new GenericStatType(count++, "RELIABLE_DIRECT_BYTES_RECVED"); //$NON-NLS-1$
	
		RELIABLE_MSGS_DISCARDED_OUTOFORDER = new GenericStatType(count++, "RELIABLE_MSGS_DISCARDED_OUTOFORDER"); //$NON-NLS-1$
		RELIABLE_MSGS_DISCARDED_DUPLICATES = new GenericStatType(count++, "RELIABLE_MSGS_DISCARDED_DUPLICATES"); //$NON-NLS-1$
		
		TOTAL_CONNECTION_ATTEMPTS = new GenericStatType(count++, "TOTAL_CONNECTION_ATTEMPTS"); //$NON-NLS-1$

		RELIABLE_PERSISTENT_MSGS_RESENT = new GenericStatType(count++, "RELIABLE_PERSISTENT_MSGS_RESENT"); //$NON-NLS-1$
		RELIABLE_PERSISTENT_BYTES_RESENT = new GenericStatType(count++, "RELIABLE_PERSISTENT_BYTES_RESENT"); //$NON-NLS-1$
		RELIABLE_NONPERSISTENT_MSGS_RESENT = new GenericStatType(count++, "RELIABLE_NONPERSISTENT_MSGS_RESENT"); //$NON-NLS-1$
		RELIABLE_NONPERSISTENT_BYTES_RESENT = new GenericStatType(count++, "RELIABLE_NONPERSISTENT_BYTES_RESENT"); //$NON-NLS-1$
		RELIABLE_MSGS_RESENT = new GenericStatType(count++, "RELIABLE_MSGS_RESENT"); //$NON-NLS-1$
		RELIABLE_BYTES_RESENT = new GenericStatType(count++, "RELIABLE_BYTES_RESENT"); //$NON-NLS-1$
		ROUTER_DISCARD_NOTIFICATIONS = new GenericStatType(count++, "ROUTER_DISCARD_NOTIFICATIONS"); //$NON-NLS-1$
		SMF_DISCARDS_UNKNOWN_ELEMENT = new GenericStatType(count++, "SMF_DISCARDS_UNKNOWN_ELEMENT"); //$NON-NLS-1$
		RELIABLE_MSGS_DISCARDED_NO_MATCHING_FLOW = new GenericStatType(count++, "RELIABLE_MSGS_DISCARDED_NO_MATCHING_FLOW"); //$NON-NLS-1$ 
		
		PUBLISHER_WINDOW_CLOSED = new GenericStatType(count++, "PUBLISHER_WINDOW_CLOSED"); //$NON-NLS-1$ 
		SUBSCRIBER_FLOW_WINDOW_CLOSED = new GenericStatType(count++, "SUBSCRIBER_FLOW_WINDOW_CLOSED"); //$NON-NLS-1$ 
		MESSAGES_DISCARDED_INTERNAL = new GenericStatType(count++, "MESSAGES_DISCARDED_INTERNAL"); //$NON-NLS-1$
		SUBSCRIBER_CONGESTED_EVENT = new GenericStatType(count++, "SUBSCRIBER_CONGESTED_EVENT"); //$NON-NLS-1$

		CACHE_REQUESTS_SENT = new GenericStatType(count++, "CACHE_REQUESTS_SENT"); //$NON-NLS-1$
        CACHE_REQUESTS_FULFILLED = new GenericStatType(count++, "CACHE_REQUESTS_FULFILLED"); //$NON-NLS-1$
		CACHED_MSGS_RECVED = new GenericStatType(count++, "CACHED_MESSAGES_RECVED"); //$NON-NLS-1$
        CACHE_FULFILL_REPLIES_DISCARDED = new GenericStatType(count++, "CACHE_FULFILL_REPLIES_DISCARDED"); //$NON-NLS-1$
        REQUESTS_SENT = new GenericStatType(count++, "REQUESTS_SENT"); //$NON-NLS-1$
        REQUESTS_TIMED_OUT = new GenericStatType(count++, "REQUESTS_TIMED_OUT"); //$NON-NLS-1$
        REPLIES_RECVED = new GenericStatType(count++, "RESPONSES_RECVED"); //$NON-NLS-1$
        REPLIES_DISCARDED = new GenericStatType(count++, "DISCARDED_RESPONSES"); //$NON-NLS-1$
	}
	
	private static Vector<GenericStatType> _types = new Vector<GenericStatType>();
	public static Enumeration<GenericStatType> elements()  {return _types.elements();}
	
	static {
		_types.add(TOTAL_MSGS_SENT);
		_types.add(TOTAL_MSGS_SENT_QOS0);
		_types.add(TOTAL_MSGS_SENT_QOS1);
		_types.add(TOTAL_MSGS_SENT_QOS2);
		_types.add(TOTAL_SOCKET_BYTES_SENT);
		_types.add(TOTAL_BYTES_SENT);
		_types.add(TOTAL_SOCKET_COMPRESSED_BYTES_SENT);
        _types.add(TOTAL_SOCKET_SSL_BYTES_SENT);
		_types.add(RELIABLE_MSGS_SENT);
		_types.add(RELIABLE_BYTES_SENT);
		_types.add(RELIABLE_MSGS_SENT_CONFIRMED);
		_types.add(RELIABLE_PERSISTENT_MSGS_SENT);
		_types.add(RELIABLE_PERSISTENT_BYTES_SENT);
		_types.add(RELIABLE_NONPERSISTENT_MSGS_SENT);
		_types.add(RELIABLE_NONPERSISTENT_BYTES_SENT);
		_types.add(RELIABLE_DIRECT_MSGS_SENT);
		_types.add(RELIABLE_DIRECT_BYTES_SENT);

		_types.add(TOTAL_MSGS_RECVED);
		_types.add(TOTAL_SOCKET_BYTES_RECVED);
		_types.add(TOTAL_BYTES_RECVED);
		_types.add(TOTAL_SOCKET_COMPRESSED_BYTES_RECVED);
        _types.add(TOTAL_SOCKET_SSL_BYTES_RECVED);
		_types.add(RELIABLE_MSGS_RECVED);
		_types.add(RELIABLE_BYTES_RECVED);
		_types.add(RELIABLE_MSGS_RECVED_ACKED);
		_types.add(RELIABLE_PERSISTENT_MSGS_RECVED);
		_types.add(RELIABLE_PERSISTENT_BYTES_RECVED);
		_types.add(RELIABLE_PERSISTENT_MSGS_RECVED_ACKED);
		_types.add(RELIABLE_NONPERSISTENT_MSGS_RECVED);
		_types.add(RELIABLE_NONPERSISTENT_BYTES_RECVED);
		_types.add(RELIABLE_NONPERSISTENT_MSGS_RECVED_ACKED);
		_types.add(RELIABLE_DIRECT_MSGS_RECVED);
		_types.add(RELIABLE_DIRECT_BYTES_RECVED);
		
		_types.add(RELIABLE_MSGS_DISCARDED_OUTOFORDER);
		_types.add(RELIABLE_MSGS_DISCARDED_DUPLICATES);
		_types.add(TOTAL_CONNECTION_ATTEMPTS);
		
		_types.add(RELIABLE_PERSISTENT_MSGS_RESENT);
		_types.add(RELIABLE_PERSISTENT_BYTES_RESENT);
		_types.add(RELIABLE_NONPERSISTENT_MSGS_RESENT);
		_types.add(RELIABLE_NONPERSISTENT_BYTES_RESENT);
		_types.add(RELIABLE_MSGS_RESENT);
		_types.add(RELIABLE_BYTES_RESENT);
		_types.add(ROUTER_DISCARD_NOTIFICATIONS);
		_types.add(SMF_DISCARDS_UNKNOWN_ELEMENT);
		_types.add(RELIABLE_MSGS_DISCARDED_NO_MATCHING_FLOW);
		_types.add(PUBLISHER_WINDOW_CLOSED);
		_types.add(SUBSCRIBER_FLOW_WINDOW_CLOSED);
		_types.add(MESSAGES_DISCARDED_INTERNAL);
		_types.add(SUBSCRIBER_CONGESTED_EVENT);

        _types.add(CACHE_REQUESTS_SENT);
        _types.add(CACHE_REQUESTS_FULFILLED);
        _types.add(CACHED_MSGS_RECVED);
        _types.add(CACHE_FULFILL_REPLIES_DISCARDED);
        _types.add(REQUESTS_SENT);
        _types.add(REQUESTS_TIMED_OUT);
        _types.add(REPLIES_RECVED);
        _types.add(REPLIES_DISCARDED);
	}

	/**
	 * Look up a <code>GStatType</code> instance from its label.
	 * 
	 * @param label
	 *            The label of the <code>GStatType</code> to look up.
	 * @return a GStatType instance corresponding to the label given, or
	 *         <code>null</code> if not found.
	 */
	public static GenericStatType fromString(String label) {
		for (GenericStatType t : _types) {
			if (t.getLabel().equals(label)) {
				return t;
			}
		}
		return null;
	}
	
	private GenericStatType(int id, String label) {
		super(id, label);
	}

	/**
	 * Test for equality
	 */
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof GenericStatType)) {
			return false;
		}
		else {
			return (_id == ((GenericStatType)obj)._id);
		}
	}

}
	
	
	
	
	
	
	
	

