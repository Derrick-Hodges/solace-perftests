/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import java.util.Timer;
import java.util.TimerTask;

import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;

public abstract class AbstractClientTransactedSession extends TimerTask {	
	
	protected AbstractClient _client;
	
	protected int transactionSize;
	protected boolean wantTransactionRollback;
	protected int rollbackInterval;
	protected int numMsgsRecv;
	protected int prevNumMsgsRecv;
	protected int numMsgsOnCommit;
	protected int numCommits;
	
	protected Timer timer;
	
	
	public abstract void close();
	
	public final void init(AbstractClient client, RuntimeProperties rprops) {
		this._client = client;
		
		this.transactionSize = rprops.getIntegerProperty(RuntimeProperties.AD_TRANSACTION_SIZE);
		this.rollbackInterval = rprops.getIntegerProperty(RuntimeProperties.AD_TRANSACTION_ROLLBACK_INTERVAL);
		this.numMsgsRecv = 0;
		this.prevNumMsgsRecv = 0;
		this.numMsgsOnCommit = 0;
		this.numCommits = 0;
		
		int transactionIdleTime = rprops.getIntegerProperty(RuntimeProperties.AD_TRANSACTION_IDLE_TIME);
		timer = new Timer();
		if (transactionIdleTime > 0 && this.transactionSize > 0) {
			timer.schedule((TimerTask)this, transactionIdleTime, transactionIdleTime);
		}
	}
	
	public void onMessage() throws Exception {
		
		numMsgsRecv++;
		
		if (transactionSize > 0 && 
				numMsgsRecv > 0 &&
				(numMsgsRecv % transactionSize) == 0) {
			
			// It's time to commit this transaction
			numCommits++;
			if (wantTransactionRollback ||
					((rollbackInterval > 0) &&
					(numCommits % rollbackInterval == 0))) {
				this.rollback();
			} else {
				this.commit();
			}
		}
	}
	
	public void onException(Exception e) {
		_client.updateLastErrorResponse(e);
		_client.logExceptionAsError(e);		
	}
	
	@Override
	public void run() {
		if ((numMsgsRecv == prevNumMsgsRecv) &&
				(numMsgsRecv != numMsgsOnCommit)) {
			
			try {
				this.commitOnDispatcher(false);
			} catch (Exception e) {
				onException(e);
			}	
		}
		prevNumMsgsRecv = numMsgsRecv;
	}
	
	public void commit() throws Exception {
		this.commit(false);
	}
	
	public void rollback() throws Exception {
		this.commit(true);
	}
	
	
	// In an actual application, commit/rollback is called from the message
	// callback (async) or from the thread on which the messages are being
	// received (sync).  However, this is not an actual application.  For
	// testing purposes, we will sometimes be triggering the commit/rollback
	// from outside of this application or based on a timer.  However, these
	// commits and/or rollbacks must still be executed on the thread on which
	// the messages are being received.  Since this application always uses 
	// async delivery on the dispatcher thread, we need to push the execution
	// of these operations onto the dispatcher thread.	
	
	
	public abstract void commitOnDispatcher(boolean wantRollback) throws Exception;

	protected abstract void commit(boolean wantRollback) throws Exception;
	
	public abstract Object getProducer() throws Exception;
	
}
