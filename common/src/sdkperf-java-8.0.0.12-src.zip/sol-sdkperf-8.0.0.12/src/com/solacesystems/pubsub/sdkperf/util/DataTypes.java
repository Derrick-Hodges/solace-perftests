/** 
*  Copyright 2004-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.util;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Data types values for SDKPERF.
 */
public class DataTypes {
	
	// Declare some supporting enum types.
	public enum ApiMode { JCSMP, JCSMP_TOPIC, JMS };
	public enum SubscriberDestinationsType { 
		NULL(0), XPE(1), TOPIC(2), QUEUE(3);
		
		private static final Map<Integer,SubscriberDestinationsType> lookup 
    		= new HashMap<Integer,SubscriberDestinationsType>();

		static {
			for(SubscriberDestinationsType s : EnumSet.allOf(SubscriberDestinationsType.class))
				lookup.put(s.getType(), s);
		}
		
		private int type;
		
		private SubscriberDestinationsType(int type) {
			this.type = type;
		}
		
		public int getType() {
			return type;
		}
		
		public static SubscriberDestinationsType get(int type) { 
	          return lookup.get(type); 
	     }		
	};	 
	public enum PublisherDestinationsType { NULL, QUEUE, TOPIC };
	
	public enum ClientModeType {SINK, REFLECT, REPLY };
	
	public enum ActiveFlowIndicationType { UNKNOWN, ACTIVE, INACTIVE };
}
