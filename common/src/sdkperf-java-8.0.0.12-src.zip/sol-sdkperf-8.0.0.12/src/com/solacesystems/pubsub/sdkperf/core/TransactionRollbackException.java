package com.solacesystems.pubsub.sdkperf.core;

public class TransactionRollbackException extends PubSubException {

	
	private static final long serialVersionUID = 6985416413565197495L;
	private int subCode_m = -1;
	
	public TransactionRollbackException(int subCode) {
		super();
		setSubCode(subCode);
	}

	public TransactionRollbackException(String message, int subCode, Throwable t) {
		super(message, t);
		setSubCode(subCode);
	}

	public TransactionRollbackException(int subCode, Throwable t) {
		super(t);
		setSubCode(subCode);
	}

	public TransactionRollbackException(String message, int subCode) {
		super(message);
		setSubCode(subCode);
	}

	public int getSubCode() {
		return subCode_m;
	}

	private void setSubCode(int subCode_m) {
		this.subCode_m = subCode_m;
	}
}