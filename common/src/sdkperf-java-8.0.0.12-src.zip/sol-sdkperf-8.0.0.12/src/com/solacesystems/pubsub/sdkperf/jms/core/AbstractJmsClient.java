/** 
 *  Copyright 2009-2017 Solace Corporation. All rights reserved.
 *  
 *  http://www.solacesystems.com
 *  
 *  This source is distributed WITHOUT ANY WARRANTY or support;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 *  A PARTICULAR PURPOSE.  All parts of this program are subject to
 *  change without notice including the program's CLI options.
 *
 *  Unlimited use and re-distribution of this unmodified source code is   
 *  authorized only with written permission.  Use of part or modified  
 *  source code must carry prominent notices stating that you modified it, 
 *  and give a relevant date.
 */
package com.solacesystems.pubsub.sdkperf.jms.core;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.ConnectionMetaData;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.Session;
import javax.jms.TemporaryQueue;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TransactionRolledBackException;
import javax.jms.XAConnection;
import javax.jms.XAConnectionFactory;
import javax.jms.XASession;
import javax.naming.InitialContext;
import javax.transaction.xa.XAResource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.jms.SolJmsUtility;
import com.solacesystems.pubsub.sdkperf.config.EpConfigProperties;
import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.AbstractCacheLiveDataAction;
import com.solacesystems.pubsub.sdkperf.core.AbstractClient;
import com.solacesystems.pubsub.sdkperf.core.AbstractClientTransactedSession;
import com.solacesystems.pubsub.sdkperf.core.AbstractMessageAckData;
import com.solacesystems.pubsub.sdkperf.core.AbstractWrappedMessage;
import com.solacesystems.pubsub.sdkperf.core.ChannelState;
import com.solacesystems.pubsub.sdkperf.core.BasicMsgRep;
import com.solacesystems.pubsub.sdkperf.core.FlowStatus;
import com.solacesystems.pubsub.sdkperf.core.GenericCapabilityType;
import com.solacesystems.pubsub.sdkperf.core.GenericMessageDeliveryMode;
import com.solacesystems.pubsub.sdkperf.core.GenericStatType;
import com.solacesystems.pubsub.sdkperf.core.PubSubException;
import com.solacesystems.pubsub.sdkperf.core.ToolData;
import com.solacesystems.pubsub.sdkperf.core.TransactionRollbackException;
import com.solacesystems.pubsub.sdkperf.util.Timing;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.ClientModeType;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.PublisherDestinationsType;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.SubscriberDestinationsType;

/**
 * Class for managing all activities of a single client. Handles all JMS sdk
 * interactions.
 */
public abstract class AbstractJmsClient extends AbstractClient implements ExceptionListener {

	private static final Log Trace = LogFactory.getLog(AbstractJmsClient.class);

	protected InitialContext _initialContext;
	protected ConnectionFactory _cf;
	protected XAConnectionFactory _xacf;
	protected Connection _jmsConnection;
	protected XAConnection _jmsXaConnection;
	protected List<JmsMessageReceiver> _consumersList;
	protected Session _jmsSession;
	protected boolean _wantJndi = false;
	
	// The current message received on the JMS Session (non-transacted)
	protected JmsWrappedMessage _currSessionMsg;

	protected MessageProducer[] _producers;
	protected long _msgsRx;
	protected long _cntPublished;
	protected List<QueueBrowser> _browserList;
	protected HashMap<String, JmsClientTransactedSession> _transactedSessions;
	protected HashMap<String, MessageProducer> _transactedProducers;
	protected HashMap<String, JmsClientXaSession> _xaSessions;
	protected HashMap<String, MessageProducer> _xaProducers;
	protected Session _currTransactedSession;
	protected JmsClientXaSession _currXaSession;
	
	
	// The JmsClient can specify a temporary queue as the reply-to
	// destination for messages sent. The JmsClient is responsible
	// of this queue object (must create it and bind to it).
	protected TemporaryQueue _tempQueueReplyTo = null;
	protected MessageConsumer _tempQueueMsgConsumer = null;
	
	//
	private int _numMsgPubOnReceive = 0;

	// Really need where in the pub props notify, we update this for based on
	// the index
	// and we trust that since transactions are only supported for 1 pub per
	// session
	// that we'll only every use the first index in practice. But make the code
	// generic
	// for simplicity.
	protected MessageProducer[] _currProducers;

	// The default message producer is used in message reflection.
	protected MessageProducer _defaultProducer;

	public AbstractJmsClient() {
	}

	// If the connection factory is from the application server's
	// resource adapter, we will not be able to use our own
	// exception listener.
	protected boolean _wantOnExceptionListener = true;
	private Map<String, Queue> _queueMap;
	private Map<String, Topic> _topicMap;

	// JMS Queues and Topics can be provided from the outside (e.g. from an
	// application server's
	// Resource Adapter). These endpoints will be used when possible.
	// For example, if the user wants to use a queue called "myQueue" and one is
	// present inside the
	// map, the JmsClient will use the existing queue rather than creating a new
	// one.
	public AbstractJmsClient(ConnectionFactory cf, Map<String, Queue> queueMap,
			Map<String, Topic> topicMap) {
		_cf = cf;
		_queueMap = queueMap;
		_topicMap = topicMap;
		_wantOnExceptionListener = false;
	}

	public void init(RuntimeProperties perfProps, int clientIdInt)
			throws Exception {
		
		_wantJndi = perfProps.getBooleanProperty(RuntimeProperties.WANT_JNDI_FOR_JMS);
		
		super.init(perfProps, clientIdInt);

		_jmsConnection = null;
		_jmsXaConnection = null;
		_clientIdInt = clientIdInt;
		_consumersList = new ArrayList<JmsMessageReceiver>();

		_msgsRx = 0;
		_cntPublished = 0;
		_browserList = new ArrayList<QueueBrowser>();
		_producers = new MessageProducer[_numPubPerSession];
		_currProducers = new MessageProducer[_numPubPerSession];

		_transactedSessions = new HashMap<String, JmsClientTransactedSession>();
		_transactedProducers = new HashMap<String, MessageProducer>();
		_xaSessions = new HashMap<String, JmsClientXaSession>();
		_xaProducers = new HashMap<String, MessageProducer>();
		_currTransactedSession = null;
		_currXaSession = null;

		// If the connection factory is null (empty constructor was used), set
		// it up.
		_initialContext = this.getJmsFactory().createInitialContext(_rxProps, _clientIdInt);
		if (_cf == null)
			_cf = this.setupConnectionFactory();

		if (_xacf == null
				&& perfProps
						.getBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION))
			_xacf = this.setupXAConnectionFactory();
		
		Integer numMsgPubOnRcv = _rxProps.getIntegerProperty(RuntimeProperties.NUMBER_OF_MSGS_TO_PUB_ON_RCV);
		_numMsgPubOnReceive = (numMsgPubOnRcv == null) ? 0 : numMsgPubOnRcv.intValue();
	}

	// Abstract JMS Client Interface
	protected abstract JmsSdkperfFactory getJmsFactory();

	protected abstract ConnectionFactory setupConnectionFactory()
			throws Exception;

	protected abstract XAConnectionFactory setupXAConnectionFactory()
			throws Exception;

	protected abstract String getSessionName(Session session);

	protected abstract String getMessageConsumerName(MessageConsumer msgConsumer);

	protected abstract BasicMessageListener createMessageListener(
			MessageConsumer msgConsumer, EpConfigProperties epProps,
			String destName, boolean isTopic) throws JMSException,
			PubSubException;

	protected abstract void modifyMsgForJmsExtendedProps(Message jmsMessage)
			throws JMSException;

	// Other interface methods worth overriding
	protected void publishBinarySmfMsg(BasicMsgRep msgRep, int pubSessionIndex)
			throws Exception {

		throw new PubSubException(
				"Publishing binary SMF unsupported in standard JMS.");
	}

	protected void updateLastErrorResponse(JMSException exception) {
		updateLastErrorResponse((Exception) exception);
	}

	// End of Abstract JMS Client interface

	@Override
	public long getLastAckedMsgId() {
		// not supported
		return -1;
	}

	@Override
	public void setLastAckedMsgId(long value) {
		// not supported by JMS clients.
		return;
	}

	@Override
	public String getClientName() throws JMSException, PubSubException {
		if (_rxProps
				.getBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION)) {
			if (_jmsXaConnection != null) {
				return _jmsXaConnection.getClientID();
			} else {
				throw new PubSubException("JMS Connection is null");
			}
		} else {
			if (_jmsConnection != null) {
				return _jmsConnection.getClientID();
			} else {
				throw new PubSubException("JMS Connection is null");
			}
		}
	}
	
	
	@Override
	public String getReplyToDestination() {
		String s = super.getReplyToDestination();
		
		if(s != null) {
			return s;
		}
		
		if(_rxProps.getBooleanProperty(RuntimeProperties.WANT_REPLY_TEMPORARY_QUEUE)) {
			if(_tempQueueReplyTo != null) {
				try {
					return _tempQueueReplyTo.getQueueName();
				} catch (JMSException e) {
					Trace.warn("Could not fetch reply-to destination from temporary queue.", e);
				}
			}
		}
		
		Trace.warn("Could not determine reply-to destination.");
		return null;
	}

	@Override
	public void setClientName(String value) throws PubSubException {
		throw new PubSubException(
				"Unsupported in JMS.  Client name cannot be changed after configuration.");
	}

	@Override
	public void resetStats() {
		super.resetStats();

		_cntPublished = 0;
		_msgsRx = 0;
	}

	@Override
	public void clearSubscriptionMemory() throws Exception {
		_consumersList.clear();
	}

	@Override
	public void connect() throws Exception {
		if (isConnected()) {
			return;
		}
		
		if(Trace.isDebugEnabled()) {
			Trace.debug("AbstractJmsClient -  connect() was called.");
		}
		
		boolean	isTransacted;
		if (_rxProps.getBooleanProperty(RuntimeProperties.APPLICATION_SERVER_RA_TRANSACTION) != null) {
			isTransacted = _rxProps.getBooleanProperty(RuntimeProperties.APPLICATION_SERVER_RA_TRANSACTION);
		} else {
			isTransacted = false;
		}
		
		
		try {
			if (_rxProps
					.getBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION)) {
				_jmsXaConnection = _xacf.createXAConnection();

				if (!_rxProps.getStringProperty(
						RuntimeProperties.CLIENT_NAME_PREFIX).equals(""))
					_jmsXaConnection.setClientID(_clientIdStr);

				if (_wantOnExceptionListener)
					_jmsXaConnection.setExceptionListener(this);

				_jmsSession = _jmsXaConnection.createSession(isTransacted,
						Session.AUTO_ACKNOWLEDGE);
			} else {
				_jmsConnection = _cf.createConnection();

				if (!_rxProps.getStringProperty(
						RuntimeProperties.CLIENT_NAME_PREFIX).equals(""))
					_jmsConnection.setClientID(_clientIdStr);

				if (_wantOnExceptionListener)
					_jmsConnection.setExceptionListener(this);

				_jmsSession = _jmsConnection.createSession(isTransacted,
						Session.AUTO_ACKNOWLEDGE);
			}

			for (int i = 0; i < _producers.length; ++i) {
				_producers[i] = _jmsSession.createProducer(null);
			}

			_defaultProducer = _producers[0];

			configureProducer(_defaultProducer, _rxProps);

			reconnectToFlows();
		} catch (JMSException ex) {
			updateLastErrorResponse(ex);
			throw ex;
		}
		
		
		if(_rxProps.getBooleanProperty(RuntimeProperties.WANT_REPLY_TEMPORARY_QUEUE)) {
			if(_tempQueueReplyTo == null) {
				_tempQueueReplyTo = _jmsSession.createTemporaryQueue();
				_tempQueueMsgConsumer = _jmsSession.createConsumer(_tempQueueReplyTo);
				_tempQueueMsgConsumer.setMessageListener(new BasicMessageListener(this,
								_tempQueueReplyTo.getQueueName(), false, null,
								true, null, _tempQueueMsgConsumer));
			}
		}
		
		_channelState = ChannelState.CLIENT_STATE_CONNECTED;
	}

	@Override
	public void disconnect() throws Exception {
		_channelState = ChannelState.CLIENT_STATE_DISCONNECTED;
		
		Trace.info("Closing client connection...");
		
		for (JmsMessageReceiver msgReceiver : _consumersList)
			msgReceiver.getJmsMessageConsumer().close();

		for (MessageProducer producer : _producers) {
			if (producer != null)
				producer.close();
		}

		if(_tempQueueMsgConsumer != null) {
			_tempQueueMsgConsumer.close();
			_tempQueueMsgConsumer = null;
		}
		if(_tempQueueReplyTo != null) {
			_tempQueueReplyTo.delete();
			_tempQueueReplyTo = null;
		}
		
		// Since all the objects will be invalid after a disconnect, clear the
		// lists as well.
		_transactedProducers.clear();
		_transactedSessions.clear();
		_xaProducers.clear();
		_xaSessions.clear();

		if (_jmsSession != null)
			_jmsSession.close();
		if (_jmsXaConnection != null)
			_jmsXaConnection.close();
		if (_jmsConnection != null)
			_jmsConnection.close();
		if (_initialContext != null)
			_initialContext.close();
	}

	@Override
	public void start() throws Exception {
		
		if (_rxProps.getBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION)) {
			_jmsXaConnection.start();
		} else {
			_jmsConnection.start();
		}
	}

	@Override
	public void stop() throws Exception {
		if (_rxProps.getBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION)) {
			_jmsXaConnection.stop();
		} else {
			_jmsConnection.stop();
		}
	}

	@Override
	public String openTransactedSession(RuntimeProperties rprops)
			throws Exception {
		Session transactedSession = null;
		JmsClientTransactedSession jmsWrappedSession = null;
		try {
			if (_rxProps
					.getBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION)) {
				transactedSession = _jmsXaConnection.createSession(true,
						Session.AUTO_ACKNOWLEDGE);
				jmsWrappedSession = this.getJmsFactory().createClientTransactedSession(
						(AbstractClient) this, (Connection)_jmsXaConnection, transactedSession, rprops);
			} else {
				transactedSession = _jmsConnection.createSession(true,
						Session.AUTO_ACKNOWLEDGE);
				jmsWrappedSession = this.getJmsFactory().createClientTransactedSession(
						(AbstractClient) this, _jmsConnection, transactedSession, rprops);
			}
		} catch (JMSException ex) {
			updateLastErrorResponse(ex);
			throw ex;
		}
		String name = this.getSessionName(transactedSession);

		_transactedSessions.put(
				name,
				jmsWrappedSession);

		return name;
	}

	@Override
	public void closeTransactedSession(String sessionName) throws Exception {
		AbstractClientTransactedSession transactedSession = _transactedSessions
				.remove(sessionName);
		if (transactedSession == null) {
			throw new PubSubException("CLIENT " + _clientIdStr
					+ ": Transacted Session not found (" + sessionName + ")");
		}

		MessageProducer producer = _transactedProducers.remove(sessionName);
		if (producer != null) {
			producer.close();
		}
		transactedSession.close();
	}

	@Override
	public void closeAllTransactedSessions() throws Exception {
		for (MessageProducer producer : _transactedProducers.values()) {
			producer.close();
		}
		_transactedProducers.clear();

		for (AbstractClientTransactedSession session : _transactedSessions
				.values()) {
			session.close();
		}
		_transactedSessions.clear();
	}

	@Override
	public void commitTransaction(String sessionName, boolean wantRollback)
			throws Exception {
		
		AbstractClientTransactedSession transactedSession = _transactedSessions
				.get(sessionName);

		try {
			transactedSession.commitOnDispatcher(wantRollback);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
	}

	@Override
	public void commitTransactionOnCurrPub(int producerIndex,
			boolean wantRollback) throws Exception {
		try {
			if (wantRollback) {
				_currTransactedSession.rollback();
			} else {
				_currTransactedSession.commit();
			}
		} catch (TransactionRolledBackException e) {
			updateLastErrorResponse(e);
			throw new TransactionRollbackException(-1, e);
		} catch (JMSException ex) {
			updateLastErrorResponse(ex);
			throw ex;
		}
	}

	@Override
	public String openXaSession(RuntimeProperties rprops) throws Exception {
		XASession xaSession = null;
		try {
			xaSession = _jmsXaConnection.createXASession();
		} catch (Exception ex) {
			updateLastErrorResponse(ex);
			throw ex;
		}
		String name = this.getSessionName(xaSession);

		JmsClientXaSession jmsClientXaSession = this.getJmsFactory().createXaTransactedSession(
				(AbstractClient) this, _jmsXaConnection, xaSession, rprops);
		_xaSessions.put(name, jmsClientXaSession);

		return name;
	}

	@Override
	public void closeXaSession(String sessionName) throws Exception {
		JmsClientXaSession xaSession = _xaSessions.remove(sessionName);
		if (xaSession == null) {
			throw new PubSubException("CLIENT " + _clientIdStr
					+ ": XA Session not found (" + sessionName + ")");
		}

		MessageProducer producer = _xaProducers.remove(sessionName);
		if (producer != null) {
			producer.close();
		}
		xaSession.close();
	}

	@Override
	public void closeAllXaSessions() throws Exception {
		for (MessageProducer producer : _xaProducers.values()) {
			producer.close();
		}
		_xaProducers.clear();

		for (JmsClientXaSession session : _xaSessions.values()) {
			session.close();
		}
		_xaSessions.clear();
	}

	@Override
	public String createXid(String sessionName) throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		String xid = "";
		try {
			xid = xaSession.createXid();
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
		return xid;
	}

	@Override
	public void commitXaSession(String sessionName, String xid, boolean onePhase)
			throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		try {
			xaSession.commitOnDispatcher(xid, onePhase);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
	}

	@Override
	public void endXaSession(String sessionName, String xid, int flags)
			throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		try {
			xaSession.endOnDispatcher(xid, flags);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
	}

	@Override
	public void forgetXaSession(String sessionName, String xid)
			throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		try {
			xaSession.forgetOnDispatcher(xid);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
	}

	@Override
	public void prepareXaSession(String sessionName, String xid)
			throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		try {
			xaSession.prepareOnDispatcher(xid);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
	}

	@Override
	public Vector<String> recoverXaSession(String sessionName, int flag) throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		Vector<String> retList = new Vector<String>();
		try {
			retList = xaSession.recover(flag);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
		return retList;
	}

	@Override
	public void rollbackXaSession(String sessionName, String xid)
			throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		try {
			xaSession.rollbackOnDispatcher(xid);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
	}

	@Override
	public void startXaSession(String sessionName, String xid, int flags)
			throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		try {
			xaSession.startOnDispatcher(xid, flags);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
	}

	@Override
	public void commitXaSessionOnCurrPub(int producerIndex,
			boolean wantRollback, boolean onePhase, boolean noStart) throws Exception {
		String startedXid = _currXaSession.getActiveXid();
		try {
			// End XA Session
			_currXaSession.end(startedXid, XAResource.TMSUCCESS);
			for (int i = 0; i < _currXaSession.getXids().size(); i++) {
				String xid = _currXaSession.getXids().get(0);
				if (!onePhase) {
					// Prepare XA Session
					_currXaSession.prepare(xid);
				}
				if (wantRollback) {
					// Rollback XA Session
					_currXaSession.rollback(xid);
				} else {
					// Commit XA Session
					_currXaSession.commit(xid, onePhase);
				}
				if (!noStart) {
					// Start XASession
					_currXaSession.start(xid, XAResource.TMNOFLAGS);
					if (_currXaSession.getXids().size() > 1) {
						// Suspend XA Session
						_currXaSession.end(xid, XAResource.TMSUSPEND);
					}
				}
			}
			if (_currXaSession.getXids().size() > 1) {
				// Resume XA Session
				_currXaSession.start(startedXid, XAResource.TMRESUME);
			}
		} catch (Exception ex) {
			updateLastErrorResponse(ex);
			String activeXid = _currXaSession.getActiveXid();
			if (activeXid != null) {
				try {
					_currXaSession.rollback(activeXid);
				} catch (Exception e1) {
					_currXaSession.start(startedXid, XAResource.TMNOFLAGS);
					throw e1;
				}
			}
			_currXaSession.start(startedXid, XAResource.TMNOFLAGS);
			throw ex;
		}

	}
	
	@Override
	public void suspendXaSessionOnCurrPub(int producerIndex) throws Exception {
		String suspendedXid = _currXaSession.getActiveXid();
		try {
			// Suspend XA Session
			_currXaSession.end(suspendedXid, XAResource.TMSUSPEND);
			Iterator<String> it = _currXaSession.getXids().iterator();
			String firstXid = "";
			String nextXid = "";
			while (it.hasNext()) {
				// Get Current XID
				String xid = it.next();
				if (firstXid.equals("")) {
					firstXid = xid;
				}
				if (xid.equals(suspendedXid)) {
					// Get Next XID
					if (!it.hasNext()) {
						nextXid = firstXid;
					} else {
						nextXid = it.next();
					}
					break;
				}
			}
			_currXaSession.start(nextXid, XAResource.TMRESUME);
		} catch (Exception ex) {
			updateLastErrorResponse(ex);
			throw ex;
		}
	}

	@Override
	public void setXaTransactionTimeout(String sessionName, int seconds) throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		try {
			xaSession.setTransactionTimeout(seconds);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
	}

	@Override
	public int getXaTransactionTimeout(String sessionName) throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		int timeout = -1;
		try {
			timeout = xaSession.getTransactionTimeout();
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
		return timeout;
	}

	@Override
	public String createXid(String sessionName, int formatId, String globalTransactionId, String branchQualifier) throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		String xid = "";
		try {
			xid = xaSession.createXid(formatId, globalTransactionId, branchQualifier);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
		return xid;
	}

	@Override
	public String getActiveXid(String sessionName)
			throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		String activeXid;
		try {
			activeXid = xaSession.getActiveXid();
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
		return activeXid;
	}

	@Override
	public Vector<String> getXids(String sessionName)
			throws Exception {
		JmsClientXaSession xaSession = _xaSessions.get(sessionName);

		Vector<String> xidList = new Vector<String>();
		try {
			xidList = xaSession.getXids();
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
		return xidList;
	}

	@Override
	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
		buf.append(String.format("Subscriber name: %s%n", _clientIdStr));
		buf.append("Number of Msgs received : " + _msgsRx);
		return buf.toString();
	}

	protected static Message copyMessageForReflect(Session session, Message m)
			throws Exception {
		Message msgCopy;

		if (m instanceof TextMessage) {
			TextMessage msgForReflection = session.createTextMessage();
			msgForReflection.setText(((TextMessage) m).getText());
			msgCopy = msgForReflection;
		} else if (m instanceof BytesMessage) {
			JmsWrappedMessage msg = new JmsWrappedMessage(m);
			BytesMessage msgForReflection = session.createBytesMessage();
			msgForReflection.writeBytes(msg.getAttachmentBytes());
			msgCopy = msgForReflection;
		} else {
			BytesMessage msgForReflection = session.createBytesMessage();
			msgCopy = msgForReflection;
		}

		return msgCopy;
	}

	protected void updateReplyToTopic(BasicMsgRep msgRep, Message msg)
			throws Exception {
		
		if(_tempQueueReplyTo != null) {
			msg.setJMSReplyTo(_tempQueueReplyTo);
			return;
		}

		String replyToDest = msgRep.getReplyToDestination();
		
		if(replyToDest == null || replyToDest.length() == 0) {
			// No reply-to destination!
			return;
		}

		if (msgRep.getReplyToDestType() == PublisherDestinationsType.TOPIC) {
			
			// Reply-To destination should be a topic
			if (_topicMap != null && _topicMap.containsKey(replyToDest)) {
				msg.setJMSReplyTo(_topicMap.get(replyToDest));
			} else {
				msg.setJMSReplyTo(_jmsSession.createTopic(replyToDest));
			}
		} else if (msgRep.getReplyToDestType() == PublisherDestinationsType.QUEUE) {
			// Reply-To destination should be a queue
			if (_queueMap != null && _queueMap.containsKey(replyToDest)) {
				msg.setJMSReplyTo(_queueMap.get(replyToDest));
			} else {
				msg.setJMSReplyTo(_jmsSession.createQueue(replyToDest));
			}
		}

	}

	protected void publishNormalMsg(BasicMsgRep msgRep, int pubSessionIndex)
			throws Exception {
		Message jmsMessage = null;

		// JMS does not support both xml payload and binary payload in the same
		// message.
		// If both are specified in the msgRep, we will ignored the binary
		// attachment.
		if (msgRep.getXmlBytes() != null) {
			jmsMessage = _jmsSession.createTextMessage();
			((TextMessage) jmsMessage)
					.setText(new String(msgRep.getXmlBytes()));
			if (_wantUserPropToolData && (_txToolDataProps.WANT_TOOL_DATA)) {
				setToolDataAsProperties(msgRep, jmsMessage);
			} else {
				// Do nothing. There is no binary attachment for the tool data.
			}
		} else {
			jmsMessage = _jmsSession.createBytesMessage();

			if (_txToolDataProps.WANT_TOOL_DATA) {
				if (_wantUserPropToolData) {
					setToolDataAsProperties(msgRep, jmsMessage);
					if (msgRep.getAttachmentBytes() != null) {
						((BytesMessage) (jmsMessage)).writeBytes(msgRep
								.getAttachmentBytes());
					}
				} else {
					int attachSize = setToolDataAsAttachment(msgRep);
					if (attachSize > 0) {
						((BytesMessage) (jmsMessage)).writeBytes(
								msgRep.getAttachmentBytes(), 0, attachSize);
					}
				}
			} else {
				if (msgRep.getAttachmentBytes() != null) {
					((BytesMessage) (jmsMessage)).writeBytes(msgRep
							.getAttachmentBytes());
				}
			}
		}
		
		
		// Set Custom Properties
		
		if(_txProps.getProperty(RuntimeProperties.CUSTOM_PROPERTIES_LIST) != null) {
			
			@SuppressWarnings("unchecked")
			List<String> customProps = (List<String>) _txProps.getProperty(RuntimeProperties.CUSTOM_PROPERTIES_LIST);
			
			
			int propIndex = 0;
			while(customProps.size() >= (propIndex+3)) {
				String type = customProps.get(propIndex++); 
				String name = customProps.get(propIndex++);
				String value = customProps.get(propIndex++);
				
				try {
					if(type.equalsIgnoreCase("Boolean")) {
						if(value.equalsIgnoreCase("true") || value.equals("1"))
							jmsMessage.setBooleanProperty(name, true);
						else if(value.equalsIgnoreCase("false") || value.equals("0")) {
							jmsMessage.setBooleanProperty(name, false);
						} else {
							Trace.warn("Could not parse Boolean property for custom JMS property \""
									+ type + "," + name + "," + value + "\"");
						}
					} else if(type.equalsIgnoreCase("String")) {
						jmsMessage.setStringProperty(name, value);
					} else if(type.equalsIgnoreCase("Float")) {
						jmsMessage.setFloatProperty(name, Float.parseFloat(value));
					} else if(type.equalsIgnoreCase("Int")) {
						jmsMessage.setIntProperty(name, Integer.parseInt(value));
					} else if(type.equalsIgnoreCase("Long")) {
						jmsMessage.setLongProperty(name, Long.parseLong(value));
					} else if(type.equalsIgnoreCase("Short")) {
						jmsMessage.setShortProperty(name, Short.parseShort(value));
					} else {
						Trace.warn("Invalid Type for custom JMS property \""
								+ type + "," + name + "," + value + "\"");
					}
				
				} catch (NumberFormatException e) {
					Trace.warn("Could not parse custom JMS property \"" + type
							+ "," + name + "," + value + "\"", e);
				}	
			}
			
		}
		
		this.modifyMsgForJmsExtendedProps(jmsMessage);

		if (_txProps.getBooleanProperty(RuntimeProperties.WANT_REPLY_TOPIC)	||
			_txProps.getBooleanProperty(RuntimeProperties.WANT_REPLY_TEMPORARY_QUEUE)) {			
			updateReplyToTopic(msgRep, jmsMessage);
		}

		Destination dest;
		switch (msgRep.getDestinationType()) {
		case QUEUE:
			if (_queueMap != null
					&& _queueMap.containsKey(msgRep.getDestinationString())) {
				dest = _queueMap.get(msgRep.getDestinationString());
			} else {
				if (_wantJndi) {
					dest = ((JmsMsgRep) msgRep).getJmsDestination(_initialContext);
				} else {
					dest = ((JmsMsgRep) msgRep).getJmsDestination(_jmsSession);
				}
			}
			break;
		case TOPIC:
			if (_topicMap != null
					&& _topicMap.containsKey(msgRep.getDestinationString())) {
				dest = _topicMap.get(msgRep.getDestinationString());
			} else {
				if (_wantJndi) {
					dest = ((JmsMsgRep) msgRep).getJmsDestination(_initialContext);
				} else {
					dest = ((JmsMsgRep) msgRep).getJmsDestination(_jmsSession);
				}
			}
			break;
		default:
			throw new PubSubException("Unkown destination type \""
					+ msgRep.getDestinationType() + "\".");
		}

		try {
		    _currProducers[pubSessionIndex].send(dest, jmsMessage);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
	}

	@Override
	public void publishMsg(BasicMsgRep msgRep, int pubSessionIndex)
			throws Exception {
		if (_wantStopOnError && _asyncExceptionOccured) {
			throw new PubSubException(
					"CLIENT "
							+ _clientIdStr
							+ ": Async exception occured.  Aborting publish of message.");
		}

		if (Trace.isDebugEnabled())
			Trace.debug("CLIENT " + _clientIdStr + ": sendMessage() called");

		if (msgRep.getSmfBytes() == null) {
			this.publishNormalMsg(msgRep, pubSessionIndex);
		} else {
			this.publishBinarySmfMsg(msgRep, pubSessionIndex);
		}

		_cntPublished++;
	}

	@Override
	public void publishSendMultiple(List<BasicMsgRep> msgReps,
			int pubSessionIndex) throws Exception {
		// Send multiple unsupported in java so fake it out.
		for (BasicMsgRep msgRep : msgReps) {
			publishMsg(msgRep, pubSessionIndex);
		}
	}

	@Override
	public void queueUpdate(EpConfigProperties epProps) throws Exception {
		List<String> queues = epProps.getEpNames();
		List<String> selectors = epProps.getSelectors();

		int iQueueSize = (queues == null) ? 0 : queues.size();
		int iSelectorsSize = (selectors == null) ? 0 : selectors.size();
		int i = 0;

		if (iQueueSize == 0) {
			Trace.error("CLIENT " + _clientIdStr
					+ ": Empty queue list provided. Aborting queue update");
			return;
		}
		if ((iQueueSize != iSelectorsSize) && (iSelectorsSize != 0)) {
			Trace.error("CLIENT " + _clientIdStr
					+ ": Queue list must be the same size as selector list");
			return;
		}

		Session currSession = _jmsSession;

		Queue queue;
		try {
			if (epProps.getIsAdding()) {

				if (!epProps.getTransactedSessionName().equals("")) {
					if (_xaSessions.containsKey(epProps.getTransactedSessionName())) {
						currSession = _xaSessions.get(
								epProps.getTransactedSessionName())
								.getXaSession();
					} else {
						currSession = (Session) _transactedSessions.get(
								epProps.getTransactedSessionName())
								.getTransactedSession();
					}
				}

				for (String queueName : queues) {
					if (_queueMap != null && _queueMap.containsKey(queueName)) {
						queue = _queueMap.get(queueName);
					} else if (_wantJndi) {
						queue = (Queue) _initialContext.lookup(queueName);
					} else {
						queue = currSession.createQueue(queueName);
					}

					String selector = null;
					if (iSelectorsSize > 0) {
						selector = selectors.get(i % selectors.size());
					}

					MessageConsumer consumer = currSession.createConsumer(
							queue, selector, epProps.getNoLocal());

					boolean isTopic = false;
					BasicMessageListener myConsumer = this
							.createMessageListener(consumer, epProps,
									queueName, isTopic);
					_consumersList.add(myConsumer);
					i++;
				}
			} else {
				// Removing.

				// For each topic, must find matching consumer. For now do it
				// this slow way
				// we can look at speeding this up if required.
				boolean matchfound = false;
				for (String queueName : queues) {
					// Find matching consumer and close it.
					for (JmsMessageReceiver msgReceiver : _consumersList) {
						if (msgReceiver.getDestinationString()
								.equals(queueName)) {
							// We've found the matching queue.
							matchfound = true;
							msgReceiver.getJmsMessageConsumer().close();
							_consumersList.remove(msgReceiver);
							break;
						}
					}
				}
				if (!matchfound) {
					Trace.error("CLIENT " + _clientIdStr
							+ ": Did not find matching in topic remove.");
				}
			}
		} catch (JMSException ex) {
			updateLastErrorResponse(ex);
			throw ex;
		}
	}

	@Override
	public void topicUpdate(EpConfigProperties epProps) throws Exception {
		List<String> topics = epProps.getSubscriptions();
		List<String> endpointNames = epProps.getEpNames();
		List<String> selectors = epProps.getSelectors();

		int iTopicsSize = (topics == null) ? 0 : topics.size();
		int iDTESize = (endpointNames == null) ? 0 : endpointNames.size();
		int iSelectorsSize = (selectors == null) ? 0 : selectors.size();
		Topic topic;

		if (iDTESize == 0) {
			Trace.error("CLIENT "
					+ _clientIdStr
					+ ": Empty durable topic endpoint list provided. Aborting topic update");
			return;
		}

		Session currSession = _jmsSession;

		try {
			if (epProps.getIsAdding()) {
				if (!epProps.getTransactedSessionName().equals("")) {
					if (_xaSessions.containsKey(epProps.getTransactedSessionName())) {
						currSession = _xaSessions.get(
								epProps.getTransactedSessionName())
								.getXaSession();
					} else {
						currSession = _transactedSessions.get(
								epProps.getTransactedSessionName())
								.getTransactedSession();
					}
				}

				if (iTopicsSize > 0 && iTopicsSize != iDTESize) {
					Trace.error("CLIENT "
							+ _clientIdStr
							+ ": Topics specified for DTEs but not of same length.  Aborting topic update");
					return;
				}
				if (iSelectorsSize > 0
						&& iTopicsSize > 0
						&& ((iTopicsSize != iDTESize) || (iTopicsSize != iSelectorsSize))
						&& (iSelectorsSize != 1)) {
					Trace.error("CLIENT "
							+ _clientIdStr
							+ ": Topics and Selectors specified for DTEs but not of same length.  Aborting topic update");
					return;
				}

				for (int i = 0; i < iDTESize; i++) {
					String dteName = endpointNames.get(i);
					String topicName = topics.get(i);

					String selector = null;
					if (iSelectorsSize > 0) {
						if (iSelectorsSize > 1) {
							selector = selectors.get(i);
						} else {
							selector = selectors.get(0);
						}
					}

					if (_topicMap != null && _topicMap.containsKey(topicName)) {
						topic = _topicMap.get(topicName);
					} else if (_wantJndi) {
						topic = (Topic) _initialContext.lookup(topicName);
					} else {
						topic = currSession.createTopic(topicName);
					}

					MessageConsumer consumer = currSession
							.createDurableSubscriber(topic, dteName, selector,
									epProps.getNoLocal());

					boolean isTopic = true;
					BasicMessageListener myConsumer = this
							.createMessageListener(consumer, epProps, dteName,
									isTopic);
					_consumersList.add(myConsumer);
				}
			} else {
				// Removing.

				// For each topic, must find matching consumer. For now do it
				// this slow way
				// we can look at speeding this up if required.
				boolean matchfound = false;
				for (String dteStr : endpointNames) {
					// Find matching consumer and close it.
					for (JmsMessageReceiver msgReceiver : _consumersList) {
						if (msgReceiver.getDestinationString().equals(dteStr)) {
							// We've found the matching dte.
							matchfound = true;
							msgReceiver.getJmsMessageConsumer().close();

							if (epProps.getTopicUnsubscribe()) {
								// Always use the jms session here as the
								// transacted session will likley have been
								// closed at this point.
								_jmsSession.unsubscribe(msgReceiver
										.getDestinationString());
							}

							_consumersList.remove(msgReceiver);
							break;
						}
					}
				}
				if (!matchfound) {
					Trace.error("CLIENT " + _clientIdStr
							+ ": Did not find matching in topic remove.");
				}
			}
		} catch (JMSException ex) {
			updateLastErrorResponse(ex);
			throw ex;
		}
	}

	@Override
	public Vector<String> tempEndpointUpdate(EpConfigProperties epProps)
			throws Exception {
		Vector<String> retList = new Vector<String>();
		List<String> topics = epProps.getSubscriptions();
		List<String> selectors = epProps.getSelectors();
		int iSelectorsSize = (selectors == null) ? 0 : selectors.size();
		Topic topic;

		if (epProps.getNumTempEndpoints() > 0 && iSelectorsSize > 0
				&& epProps.getNumTempEndpoints() != iSelectorsSize
				&& iSelectorsSize != 1) {
			Trace.error("CLIENT "
					+ _clientIdStr
					+ ": Size of selector list and number of temporary endpoints are not equal");
			return null;
		}

		Session currSession = _jmsSession;

		if (!epProps.getTransactedSessionName().equals("")) {
			if (_xaSessions.containsKey(epProps.getTransactedSessionName())) {
				currSession = _xaSessions.get(
						epProps.getTransactedSessionName()).getXaSession();
			} else {
				currSession = (Session) _transactedSessions.get(
						epProps.getTransactedSessionName())
						.getTransactedSession();
			}
		}

		// Respect TTL is done via JNDI, so can't do anything with it here.

		try {
			if (epProps.getType() == SubscriberDestinationsType.TOPIC) {
				if (topics == null || topics.isEmpty()) {
					Trace.error("CLIENT "
							+ _clientIdStr
							+ ": Empty topics list provided. Aborting temp endpoint update");
					return null;
				}

				Iterator<String> topicsIter = null;
				for (int i = 0; i < epProps.getNumTempEndpoints(); i++) {
					if (topicsIter == null || !topicsIter.hasNext()) {
						topicsIter = topics.iterator();
					}
					String topicName = topicsIter.next();

					String selector = null;
					if (iSelectorsSize > 0) {
						if (iSelectorsSize > 1) {
							selector = selectors.get(i);
						} else {
							selector = selectors.get(0);
						}
					}

					if (_topicMap != null && _topicMap.containsKey(topicName)) {
						topic = _topicMap.get(topicName);
					} else if (_wantJndi) {
						topic = (Topic) _initialContext.lookup(topicName);
					} else {
						topic = currSession.createTopic(topicName);
					}

					MessageConsumer consumer = currSession.createConsumer(
							topic, selector, epProps.getNoLocal());

					String tteName = this.getMessageConsumerName(consumer);
					boolean isTopic = true;

					BasicMessageListener myConsumer = this
							.createMessageListener(consumer, epProps, tteName,
									isTopic);
					_consumersList.add(myConsumer);
					retList.add(tteName);
				}
			} else {
				for (int i = 0; i < epProps.getNumTempEndpoints(); i++) {
					Queue queue = currSession.createTemporaryQueue();

					String selector = null;
					if (iSelectorsSize > 0) {
						if (iSelectorsSize > 1) {
							selector = selectors.get(i);
						} else {
							selector = selectors.get(0);
						}
					}

					MessageConsumer consumer = currSession.createConsumer(
							queue, selector, epProps.getNoLocal());

					boolean isTopic = false;
					BasicMessageListener myConsumer = this
							.createMessageListener(consumer, epProps,
									queue.getQueueName(), isTopic);
					_consumersList.add(myConsumer);
					retList.add(queue.getQueueName());
				}
			}
		} catch (JMSException ex) {
			updateLastErrorResponse(ex);
			throw ex;
		}
		return retList;
	}

	@Override
	public void unbindAllTempEndpoints() throws Exception {
		// Find matching non-durable consumers and close them.
		for (JmsMessageReceiver msgReceiver : _consumersList) {
			if (msgReceiver.isNonDurable()) {
				msgReceiver.getJmsMessageConsumer().close();
				_consumersList.remove(msgReceiver);
				break;
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean browseMsg(Integer browserIndex) throws Exception {
		if (browserIndex >= _browserList.size()) {
			throw new PubSubException(String.format(
					"CLIENT %s: browserIndex out of range.  Index is %d, Browser List Size is %d", _clientIdStr,
					browserIndex, _browserList.size()));
		}

		QueueBrowser qb = _browserList.get(browserIndex);
		Enumeration<Message> enumer = (Enumeration<Message>) qb
				.getEnumeration();

		boolean foundMsg = false;

		if (enumer.hasMoreElements()) {
			Message msg = enumer.nextElement();

			foundMsg = true;

			JmsWrappedMessage wMsg = new JmsWrappedMessage(msg);

			synchronized (this) {
				_msgsRx++;
			}

			processMessage(wMsg);
		}

		return foundMsg;
	}

	@Override
	public void createBrowsers(List<String> queues, String selector,
			int deleteFrequency, int msgBufSize) throws Exception {
		if (deleteFrequency > 0 || msgBufSize > 0) {
			StringBuffer buf = new StringBuffer();
			buf.append(String
					.format("CLIENT %s: Use of unsupported parameters in JMS.  QB delete frequency and msg buf size are unspported",
							_clientIdStr));
			throw new PubSubException(buf.toString());
		}

		// Should always start with a clean list.
		deleteBrowsers();

		for (String queueName : queues) {
			Queue queue = null;

			if (_queueMap != null && _queueMap.containsKey(queueName)) {
				queue = _queueMap.get(queueName);
			} else if (_wantJndi) {
				queue = (Queue) _initialContext.lookup(queueName);
			} else {
				queue = _jmsSession.createQueue(queueName);
			}

			QueueBrowser qb = _jmsSession.createBrowser(queue, selector);
			_browserList.add(qb);
		}
	}

	@Override
	public void deleteBrowsers() throws Exception {
		for (QueueBrowser browser : _browserList) {
			browser.close();
		}
		_browserList.clear();
	}

	@Override
	public void endpointProvisioning(EpConfigProperties epProps)
			throws Exception {
		Trace.error("CLIENT " + _clientIdStr
				+ ": Unsupported method - endpointProvisioning");
	}

	@Override
	public void subscriptionUpdate(EpConfigProperties epProps) throws Exception {
		List<String> lst = epProps.getSubscriptions();
		int iTopicsSize = (lst == null) ? 0 : lst.size();
		Topic topic;

		// Since in other SDKs subscriptions can never be part of a transaction,
		// we will not fake out support here in JMS either.

		try {
			if (epProps.getIsAdding()) {

				for (int i = 0; i < iTopicsSize; i++) {
					String topicName = lst.get(i);

					if (_topicMap != null && _topicMap.containsKey(topicName)) {
						topic = _topicMap.get(topicName);
					} else if (_wantJndi) {
						topic = (Topic) _initialContext.lookup(topicName);
					} else {
						topic = _jmsSession.createTopic(topicName);
					}
					MessageConsumer consumer = _jmsSession
							.createConsumer(topic);

					BasicMessageListener myMsgListener = new BasicMessageListener(
							this, topicName, true, topic, true, null, consumer);
					myMsgListener.startMessageListener();
					_consumersList.add(myMsgListener);
				}

			} else {
				// Removing.

				// For each topic, must find matching consumer. For now do it
				// this slow way
				// we can look at speeding this up if required.
				boolean matchfound = false;
				for (String topicStr : lst) {
					// Find matching consumer and close it.
					for (JmsMessageReceiver msgReceiver : _consumersList) {
						if (msgReceiver.getDestinationString().equals(topicStr)) {
							// We've found the matching topic.
							matchfound = true;
							msgReceiver.getJmsMessageConsumer().close();
							_consumersList.remove(msgReceiver);
							break;
						}
					}
				}
				if (!matchfound) {
					Trace.error("CLIENT " + _clientIdStr
							+ ": Did not find matching in topic remove.");
				}

			}
		} catch (JMSException ex) {
			updateLastErrorResponse(ex);
			throw ex;
		}
	}

	@Override
	public FlowStatus getFlowStatus(String epName) {
		FlowStatus flowStatus = new FlowStatus();

		for (JmsMessageReceiver msgReceiver : _consumersList) {
			if (msgReceiver.getDestinationString().equals(epName)) {
				flowStatus = msgReceiver.getFlowStatus();
				break;
			}
		}

		return flowStatus;
	}

	@Override
	public void cacheRequest(List<String> destinations, boolean subscribe,
			long minSeq, long maxSeq,
			AbstractCacheLiveDataAction liveDataAction, boolean waitForConfirm)
			throws Exception {
		Trace.error("CLIENT " + _clientIdStr
				+ ": Unsupported method - cacheRequest");
	}

	@Override
	public void cancelCacheRequests() throws Exception {
		Trace.error("CLIENT " + _clientIdStr
				+ ": Unsupported method - cancelCacheRequests");
	}

	@Override
	public String requestReply(String topic, String request) throws Exception {
		Trace.error("CLIENT " + _clientIdStr
				+ ": Unsupported method - requestReply");
		return "JMS Unsupported method - requestReply";
	}

	@Override
	public void mapTopics(String queue, List<String> topics, boolean isAdding)
			throws Exception {
		Trace.error("CLIENT " + _clientIdStr
				+ ": Unsupported method - mapTopics");
	}

	@Override
	protected void keepMsg(AbstractMessageAckData messageAckData) {
		Trace.error("CLIENT " + _clientIdStr + ": Unsupported method - keepMsg");
	}

	@Override
	public void clearKeptMsgs() throws Exception {
		Trace.error("CLIENT " + _clientIdStr
				+ ": Unsupported method - clearKeptMsgs");
	}

	@Override
	public void clearKeptMsgs(String destination, boolean isTopic)
			throws Exception {
		Trace.error("CLIENT " + _clientIdStr
				+ ": Unsupported method - clearKeptMsgs");
	}

	@Override
	public BasicMsgRep[] cloneToApiSpecificMsgRep(BasicMsgRep[] inputMsgReps)
			throws PubSubException {
		BasicMsgRep[] retArray = new BasicMsgRep[inputMsgReps.length];

		for (int i = 0; i < inputMsgReps.length; i++) {
			JmsMsgRep outputMsgRep = new JmsMsgRep(inputMsgReps[i]);
			try {
				if (_wantJndi) {
					if (_initialContext != null)
						outputMsgRep.cacheDestinationFromJNDI(_initialContext);
				} else {
					if (_jmsSession != null)
						outputMsgRep.cacheDestinationFromSession(_jmsSession);
				}
			} catch (Exception e) {
				throw new PubSubException(e);
			}
			retArray[i] = outputMsgRep;
		}

		return retArray;
	}

	@Override
	public void publishPropsUpdateNotify(int producerIndex, String transactedSessionName) throws Exception {
		// Must also determine and set the current message producer.
		if (transactedSessionName != null && !transactedSessionName.equals("")) {

			if (_txProps
					.getBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION) == true) {
				_currXaSession = _xaSessions.get(transactedSessionName);
				if (_currXaSession == null) {
					throw new PubSubException("CLIENT " + _clientIdStr
							+ ": Transacted Session session not found ("
							+ transactedSessionName + ")");
				}

				_currProducers[producerIndex] = _xaProducers
						.get(transactedSessionName);

				if (_currProducers[producerIndex] == null) {
					_currProducers[producerIndex] = _currXaSession
							.getXaSession().createProducer(null);
					_xaProducers.put(transactedSessionName,
							_currProducers[producerIndex]);
				}

				_currTransactedSession = null;
			} else {
				
				if (_transactedSessions != null) {
					JmsClientTransactedSession jmsTranSession = _transactedSessions.get(transactedSessionName);
					if (jmsTranSession != null) {
						_currTransactedSession = jmsTranSession.getTransactedSession();
					}
				}
				
				if (_currTransactedSession == null) {
					throw new PubSubException("CLIENT " + _clientIdStr + ": Transacted Session session not found ("
							+ transactedSessionName + ")");
				}

				_currProducers[producerIndex] = _transactedProducers
						.get(transactedSessionName);

				if (_currProducers[producerIndex] == null) {
					_currProducers[producerIndex] = _currTransactedSession
							.createProducer(null);
					_transactedProducers.put(transactedSessionName,
							_currProducers[producerIndex]);
				}

				_currXaSession = null;
			}
		} else {
			_currProducers[producerIndex] = _producers[producerIndex];
			_currTransactedSession = null;
			_currXaSession = null;
		}

		MessageProducer producer = _currProducers[producerIndex];

		configureProducer(producer, _txProps);

		// Clear producer of any ttl
		producer.setTimeToLive(0);
		if (_txProps.getLongProperty(RuntimeProperties.MSG_TTL) != null) {
			producer.setTimeToLive(_txProps
					.getLongProperty(RuntimeProperties.MSG_TTL));
		}
	}

	protected void configureProducer(MessageProducer producer,
			RuntimeProperties props) throws Exception {
		producer.setDisableMessageID(true);
		producer.setDisableMessageTimestamp(true);

		GenericMessageDeliveryMode msgtype = (GenericMessageDeliveryMode) props
				.getProperty(RuntimeProperties.PUB_MESSAGE_TYPE);

		if (msgtype == GenericMessageDeliveryMode.NON_PERSISTENT
				|| msgtype == GenericMessageDeliveryMode.DIRECT) {

			producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
		} else {
			producer.setDeliveryMode(DeliveryMode.PERSISTENT);
		}
	}

	@Override
	public Hashtable<GenericCapabilityType, String> getRtrCapabilities() {
		
		Hashtable<GenericCapabilityType, String> cap = new Hashtable<GenericCapabilityType, String>();
		
		try {
			ConnectionMetaData meta = _jmsConnection.getMetaData();
			cap.put(GenericCapabilityType.API_VERSION, meta.getProviderVersion());
		} catch (JMSException e) {
			Trace.warn("Could not fetch JMS API version.");
		}
		
		return cap;
	}

	protected void reconnectToFlows() throws Exception {
		for (int i = 0; i < _consumersList.size(); i++) {
			// Remove any non-durable flows.
			if (_consumersList.get(i).isNonDurable()) {
				// Don't reconnect any nonDurable flows.
				_consumersList.remove(i);
			}
		}

		// Must bind to any flows we were previously bound to.
		for (JmsMessageReceiver msgReceiver : _consumersList) {
			MessageConsumer consumer = null;

			if (msgReceiver.isTopic()) {
				Topic topic;

				if (_topicMap != null
						&& _topicMap.containsKey(msgReceiver
								.getDestinationString())) {
					topic = _topicMap.get(msgReceiver.getDestinationString());
				} else {
					topic = msgReceiver.getTopic();
				}

				consumer = _jmsSession.createDurableSubscriber(topic,
						msgReceiver.getDestinationString());
			} else {
				// Must be a queue
				Queue queue;

				if (_queueMap != null
						&& _queueMap.containsKey(msgReceiver
								.getDestinationString())) {
					queue = _queueMap.get(msgReceiver.getDestinationString());
				} else {
					queue = _jmsSession.createQueue(msgReceiver
							.getDestinationString());
				}
				consumer = _jmsSession.createConsumer(queue);
			}
			msgReceiver.setJmsMessageConsumer(consumer);

			msgReceiver.restartMessageListener();
		}
	}

	private void setToolDataAsProperties(BasicMsgRep msgRep, Message message)
			throws JMSException {
		ToolData txToolData = msgRep.getToolData();

		if (_txToolDataProps.WANT_PAYLOAD_CHECK) {
			// In JMS we cannot have both an xml payload and a binary
			// attachment. In the case where both
			// are defined, the binary attachment is ignored.
			if (txToolData.hasXmlPayloadHash()) {
				message.setIntProperty(ToolData.PROP_XML_PAYLOAD_HASH,
						(int) txToolData.getXmlPayloadHash());
			} else if (txToolData.hasBinAttachHash()) {
				message.setIntProperty(ToolData.PROP_BIN_PAYLOAD_HASH,
						(int) txToolData.getBinAttachHash());
			}
		}

		if (txToolData.hasStreamId()) {
			message.setIntProperty(ToolData.PROP_STREAM_ID,
					txToolData.getStreamId());
		}

		if (txToolData.hasMessageIdentifier()) {
			message.setLongProperty(ToolData.PROP_MESSAGE_ID,
					txToolData.getMessageIdentifier());
		}

		if (_txToolDataProps.WANT_LATENCY) {
			long latencyTime = txToolData.getLatency();
			if (latencyTime == 0) {
				latencyTime = Timing.getClockValue();
			}
			message.setLongProperty(ToolData.PROP_LATENCY, latencyTime);
		}
	}

	protected void readToolDataFromProperties(AbstractWrappedMessage message,
			ToolData toolData) {
		// Validate message input
		if (!(message instanceof JmsWrappedMessage)) {
			throw new IllegalArgumentException("Message must be of type "
					+ JmsWrappedMessage.class.toString());
		}

		Message jmsMsg = ((JmsWrappedMessage) message).getMessage();

		toolData.reset();
		try {
			if (jmsMsg.propertyExists(ToolData.PROP_XML_PAYLOAD_HASH)) {
				toolData.setXmlPayloadHash(0xffffffffL & jmsMsg
						.getIntProperty(ToolData.PROP_XML_PAYLOAD_HASH));
			}

			if (jmsMsg.propertyExists(ToolData.PROP_BIN_PAYLOAD_HASH)) {
				toolData.setBinAttachHash(0xffffffffL & jmsMsg
						.getIntProperty(ToolData.PROP_BIN_PAYLOAD_HASH));
			}

			if (jmsMsg.propertyExists(ToolData.PROP_MESSAGE_ID)) {
				toolData.setMessageIdentifier(jmsMsg
						.getLongProperty(ToolData.PROP_MESSAGE_ID));
			}

			if (jmsMsg.propertyExists(ToolData.PROP_STREAM_ID)) {
				toolData.setStreamId(jmsMsg
						.getIntProperty(ToolData.PROP_STREAM_ID));
			}

			if (jmsMsg.propertyExists(ToolData.PROP_LATENCY)) {
				toolData.setLatency(jmsMsg
						.getLongProperty(ToolData.PROP_LATENCY));
			}
		} catch (JMSException e) {
			Trace.error("CLIENT " + _clientIdStr + ": " + e.getMessage(), e);
		}
	}

	@Override
	public void reflectMsg(AbstractWrappedMessage message) {

		// The fact that this method was called implies that we were in a
		// situation where _rxToolDataProps.WANT_MSG_REFLECT was true.

		// Validate message input
		if (!(message instanceof JmsWrappedMessage)) {
			throw new IllegalArgumentException("Message must be of type "
					+ JmsWrappedMessage.class.toString());
		}

		if (_rxToolDataProps.CLIENT_MODE == ClientModeType.SINK) {
			throw new IllegalStateException(
					"Error in the logic. This method shouldn't be called in mode ClientModeType.SINK.");
		}
		if (_rxToolDataProps.CLIENT_MODE == ClientModeType.REFLECT) {
			throw new IllegalStateException(
					"Error in the logic. This method shouldn't be called in mode ClientModeType.REFLECT.");
		}

		Message m = ((JmsWrappedMessage) message).getMessage();
		Destination dest = null;
		try {
			dest = m.getJMSReplyTo();
		} catch (JMSException e) {
			Trace.error(
					"Exception received when trying to retrieve the ReplyTo field of the message.",
					e);
		}

		if (dest == null) {
			// don't reflect anything if the replyTo address isn't set up.
			return;
		}

		try {
			_defaultProducer.send(dest, copyMessageForReflect(_jmsSession, m));
		} catch (JMSException e) {
			Trace.error(
					"The JMS provider was unable to send the message. The message was not successfully reflected.",
					e);
		} catch (Exception e) {
			Trace.error("Exception received when trying to reflect message.", e);
		}
	}

	public synchronized void incrMsgRecvStat() {
		_msgsRx++;
	}

	@Override
	public long getSdkStat(GenericStatType statName) throws Exception {
		if (statName.equals(GenericStatType.TOTAL_MSGS_SENT)) {
			return _cntPublished;
		} else if (statName.equals(GenericStatType.TOTAL_MSGS_RECVED)) {
			return _msgsRx;
		} else {
			// Else unfortunately, we can't get and expose the JCSMP stats
			// so return 0;
			return 0;
		}
	}

	
	public void onException(JMSException exception) {
		Trace.warn("CLIENT " + _clientIdStr + ": Exception listener error.", exception);
		updateLastErrorResponse(exception);
		_asyncExceptionOccured = true;
	}

	public void updateLastErrorResponse(Exception exception) {
		Trace.debug("Last Error Response unsupported in standard JMS");
		_lastErrorResponse = null;
	}

	@Override
	public void processKeptMsgs(int desiredQueueSize, boolean enableAcking) {
		Trace.error("CLIENT " + _clientIdStr
				+ ": Unsupported method - processKeptMsgs");
	}

	@Override
	protected void publishOnReceive(Object producer, BasicMsgRep msgRep) throws Exception {

		MessageProducer prod = (MessageProducer) producer;
		
		Message jmsMsg;
		if (msgRep.getXmlBytes() != null && msgRep.getXmlBytes().length > 0) {
			jmsMsg = _jmsSession.createTextMessage();			
			((TextMessage) jmsMsg).setText(new String(msgRep.getXmlBytes()));
		} else if(msgRep.getAttachmentBytes() != null && msgRep.getAttachmentBytes().length > 0) {
			jmsMsg = _jmsSession.createBytesMessage();
			((BytesMessage) (jmsMsg)).writeBytes(msgRep.getAttachmentBytes());
		} else if (msgRep.getSmfBytes() != null && msgRep.getSmfBytes().length > 0) {
			jmsMsg = SolJmsUtility.fromByteArray(msgRep.getSmfBytes());
		} else {
			jmsMsg = _jmsSession.createMessage();
		}
		
		if (msgRep.getMessageDeliveryMode() == GenericMessageDeliveryMode.NON_PERSISTENT)
			jmsMsg.setJMSDeliveryMode(DeliveryMode.NON_PERSISTENT);
		else
			jmsMsg.setJMSDeliveryMode(DeliveryMode.PERSISTENT);		

		// Set reply-to destination if necessary
		updateReplyToTopic(msgRep, jmsMsg);
		
		if(msgRep.getDestinationString() == null || msgRep.getDestinationString().length() == 0 ||
				msgRep.getDestinationType() == null) {
			throw new IllegalArgumentException(
					"Cannot publish on receive, null destination name or destination type provided.");
		}
		
		Destination dest;
		if (msgRep.getDestinationType() == PublisherDestinationsType.QUEUE)
			dest = _jmsSession.createQueue(msgRep.getDestinationString());
		else
			dest = _jmsSession.createTopic(msgRep.getDestinationString());

		prod.send(dest, jmsMsg);
	}
	
	protected int getNumMsgPubOnReceive() {
		return _numMsgPubOnReceive;
	}

}
