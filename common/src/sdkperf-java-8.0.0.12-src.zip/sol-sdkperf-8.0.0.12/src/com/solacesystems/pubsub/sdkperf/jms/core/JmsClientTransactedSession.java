/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.jms.core;

import java.util.concurrent.ArrayBlockingQueue;

import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;

import com.solacesystems.jcsmp.protocol.nio.impl.ConsumerNotificationDispatcher;
import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.AbstractClient;
import com.solacesystems.pubsub.sdkperf.core.AbstractClientTransactedSession;
import com.solacesystems.pubsub.sdkperf.jms.solace.ClientCommitNotification;

public class JmsClientTransactedSession extends AbstractClientTransactedSession {

	private Session transactedSession;
	private MessageProducer _msgProducer = null;
	
	ConsumerNotificationDispatcher dispatcher;

	
	public JmsClientTransactedSession(AbstractClient client, Session transactedSession, RuntimeProperties rprops) {		
		this.init(client, rprops);
		this.transactedSession = transactedSession;
	}
	
	public Session getTransactedSession() {
		return transactedSession;
	}
	
	@Override
	public void close() {
		timer.cancel();
		try {
			transactedSession.close();
		} catch (JMSException e) {
			onException(e);
		}
	}

	@Override
	protected void commit(boolean wantRollback) throws Exception {
		numMsgsOnCommit = numMsgsRecv;
		
		if (wantRollback) {
			transactedSession.rollback();
			_client.getRxStats().rollback();
		} else {
			transactedSession.commit();
			_client.getRxStats().commit();
		}
	}
	
	public void setDispatcher(ConsumerNotificationDispatcher dispatcher) {
		this.dispatcher = dispatcher;
	}
	
	@Override
	public void commitOnDispatcher(boolean wantRollback) throws Exception {
		numMsgsOnCommit = numMsgsRecv;
		
		if (dispatcher != null) {
				ArrayBlockingQueue<Object> responseQueue = new ArrayBlockingQueue<Object>(1);
			dispatcher.enqueueNonBlockingNotification( new ClientCommitNotification(this, responseQueue, wantRollback) );
			Object response = responseQueue.take();
			if (response instanceof Exception) {
				throw (Exception)response;
			}
		} else {
			this.commit(wantRollback);
		}
	}

	@Override
	public Object getProducer() throws Exception {
		if (_msgProducer == null)
			_msgProducer = transactedSession.createProducer(null);
		return _msgProducer;
	}

}
