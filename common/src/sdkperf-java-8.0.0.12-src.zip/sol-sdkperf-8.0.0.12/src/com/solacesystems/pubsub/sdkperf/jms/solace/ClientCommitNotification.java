/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.jms.solace;

import java.util.concurrent.ArrayBlockingQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.jcsmp.JCSMPStreamingPublishEventHandler;
import com.solacesystems.jcsmp.XMLMessageListener;
import com.solacesystems.jcsmp.protocol.nio.impl.AbstractNotification;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsClientTransactedSession;


// In an actual application, commit/rollback is called from the message
// callback (async) or from the thread on which the messages are being
// received (sync).  However, this is not an actual application.  For
// testing purposes, we will sometimes be triggering the commit/rollback
// from outside of this application or based on a timer.  However, these
// commits and/or rollbacks must still be executed on the thread on which
// the messages are being received.  Since this application always uses 
// async delivery on the dispatcher thread, we need to push the execution
// of these operations onto the dispatcher thread.

public class ClientCommitNotification extends AbstractNotification {

	private static final Log Trace = LogFactory.getLog(ClientCommitNotification.class);
	
	private final JmsClientTransactedSession transactedSession;
	private final ArrayBlockingQueue<Object> responseQueue;
	private final boolean wantRollback;
	
	public ClientCommitNotification(JmsClientTransactedSession transactedSession, ArrayBlockingQueue<Object> responseQueue, boolean wantRollback) {
		this.transactedSession = transactedSession;
		this.responseQueue = responseQueue;
		this.wantRollback = wantRollback;
	}
	
	public boolean usesListener(XMLMessageListener listener) {
		return false;
	}

	public boolean usesHandler(JCSMPStreamingPublishEventHandler handler) {
		return false;
	}

	public int handleNotification() {

		try {
			if (wantRollback) {
				transactedSession.rollback();
			} else {
				transactedSession.commit();
			}
		} catch (Exception e) {
			if (!responseQueue.offer(e)) {
				Trace.warn("Failed to add element to response queue.");
			}
			return 0;
		}
		if (!responseQueue.offer(new Object())) {
			Trace.warn("Failed to add object to response queue.");
		}
		return 0;
	}

}
