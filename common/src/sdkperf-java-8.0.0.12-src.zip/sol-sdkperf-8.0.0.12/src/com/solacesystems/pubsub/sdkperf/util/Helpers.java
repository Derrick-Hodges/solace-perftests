/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.lang.mutable.MutableLong;

import com.solacesystems.pubsub.sdkperf.core.PubSubException;

/**
 * Simple utility methods for sdkperf.
 */
public class Helpers {
	
	public static String createGeneratedXmlDoc(final int sz) {
		final String XMLSTART = "<x>", XMLEND = "</x>";
		Formatter ft = null;
		try {
			StringBuffer buf = new StringBuffer();
			buf.append(XMLSTART);
			
			int bytesRemaining = sz - XMLSTART.length() - XMLEND.length();
			
			ft = new Formatter(buf);
			// Fill with unique string.
	        for (int i = 0; i < bytesRemaining / 8; i++) {
	        	ft.format(":%07x", i);
	        }
	        
	        bytesRemaining = sz - buf.length() - XMLEND.length();
	        
	        // Top up with any left over.
	        for (int i = 0; i < bytesRemaining; i++) {
	            buf.append("x");
	        }
			
			buf.append(XMLEND);
			return buf.toString();
		} finally {
			if (ft != null) {
				ft.close();
			}
		}
	}
	
	public static String createGeneratedDoc(final int sz) {
		Formatter ft = null;
		try {
			StringBuffer buf = new StringBuffer();
			ft = new Formatter(buf);
			// Fill with unique string.
	        for (int i = 0; i < sz / 8; i++) {
	        	ft.format(":%07x", i);
	        }
	        
	        int bytesRemaining = sz - buf.length();
	        
	        // Top up with any left over.
	        for (int i = 0; i < bytesRemaining; i++) {
	            buf.append("A");
	        }
	        
			return buf.toString();
		} finally {
			if (ft != null) {
				ft.close();
			}
		}
	}
	
	public static List<MutableLong>  cloneMutableLongArrayList(List<MutableLong> input) {
		List<MutableLong> retArray = new ArrayList<MutableLong>();
		
		for (MutableLong value : input) {
			retArray.add(new MutableLong(value));
		}
		
		return retArray;
	}
	
	public static HashMap<MutableLong, MutableLong>  cloneMutableLongHashMap(HashMap<MutableLong, MutableLong> input) {
		HashMap<MutableLong, MutableLong> retMap = new HashMap<MutableLong, MutableLong>();
		
		for (Map.Entry<MutableLong, MutableLong> entry : input.entrySet()) {
			retMap.put(new MutableLong(entry.getKey()), new MutableLong(entry.getValue()));
		}
		
		return retMap;
	}
	
	public static Vector<String> readFileAsVector(String filename) throws IOException, PubSubException {
		Vector<String> stringArray = new Vector<String>();
		
		if (filename == null || filename.equals("")) {
			throw new PubSubException("Cannot open file since its absolute path is empty or null");
		}
		File fileHandle = new File(filename);
		if (!fileHandle.exists()) {
			throw new PubSubException("Cannot open XPE file '" + filename + "' because it does not exist");
		}			
		BufferedReader buffReader = null;
		boolean eof = false;		
		buffReader = new BufferedReader(new FileReader(fileHandle));
		String nextLine;
		while (!eof) {
		    nextLine = buffReader.readLine();
			if (nextLine == null) {
			    eof = true;
			    break;
			}
			nextLine = nextLine.trim();
			stringArray.add(nextLine);
		}
		buffReader.close();	
		
		return stringArray;
	}
	
	/**
	  * Write contents of file, overwriting any existing text.
	  *
	  * @param filename is a file which can be written to.
	  * @param contents string to be written
	  * @throws IllegalArgumentException if param does not comply.
	  * @throws FileNotFoundException if the file does not exist.
	  * @throws IOException if problem encountered during write.
	  */
	  static public void writeFile(String filename, String contents)
	                                 throws FileNotFoundException, IOException {
	    if (filename == null) {
	      throw new IllegalArgumentException("File should not be null.");
	    }
	    
	    FileWriter fstream = new FileWriter(filename, false);
        BufferedWriter out = new BufferedWriter(fstream);
        
	    try {
	    	//FileWriter always assumes default encoding is OK!
	    	out.write( contents );
	    }
	    finally {
	      out.close();
	    }
	  }
}
