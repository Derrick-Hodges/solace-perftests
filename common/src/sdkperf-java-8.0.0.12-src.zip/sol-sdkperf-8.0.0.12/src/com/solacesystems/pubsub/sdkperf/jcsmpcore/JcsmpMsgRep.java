/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.jcsmpcore;



import com.solacesystems.jcsmp.DeliveryMode;
import com.solacesystems.jcsmp.Destination;
import com.solacesystems.jcsmp.DestinationUtils;
import com.solacesystems.jcsmp.XMLMessage;
import com.solacesystems.pubsub.sdkperf.core.BasicMsgRep;
import com.solacesystems.pubsub.sdkperf.core.ToolData;

/**
 * Contains properties of the message that will be published.
 * This includes all data for the message such as topic or queue,
 * byte arrays of message parts or the structured data message ID, etc.
*/
public class JcsmpMsgRep extends BasicMsgRep implements Cloneable {

	Destination jcsmpDestination = null;
	
	public JcsmpMsgRep() {
		
	}
			
	public JcsmpMsgRep(BasicMsgRep basicMsgRep) {

		if (basicMsgRep.getXmlBytes() != null) {
			this.xml = new byte[basicMsgRep.getXmlBytes().length];
			System.arraycopy(basicMsgRep.getXmlBytes(), 0, this.getXmlBytes(), 0, basicMsgRep.getXmlBytes().length);
		}

		if (basicMsgRep.getSmfBytes() != null) {
			this.smf = new byte[basicMsgRep.getSmfBytes().length];
			System.arraycopy(basicMsgRep.getSmfBytes(), 0, this.smf, 0, basicMsgRep.getSmfBytes().length);
		}

		if (basicMsgRep.getAttachmentBytes() != null) {
			this.attach = new byte[basicMsgRep.getAttachmentBytes().length];
			System.arraycopy(basicMsgRep.getAttachmentBytes(), 0, this.attach, 0, basicMsgRep.getAttachmentBytes().length);
		}

		// Don't copy the tool data because it is regenerated on every publish.
		this.toolData = new ToolData();

		this.destination = basicMsgRep.getDestinationString();
		this.structDataMsgId = basicMsgRep.getStructDataMsgId();
		this.ackImmediately = basicMsgRep.getAckImmediately();
		this.destType = basicMsgRep.getDestinationType();
		this.msgtype = basicMsgRep.getMessageDeliveryMode();
		
		// Don't copy this as it should be set by the client.
		this.jcsmpDestination = null;
		
		this._replyToDestination = basicMsgRep.getReplyToDestination();
		this._replyToDestType = basicMsgRep.getReplyToDestType();
		
		this._httpContentEncoding = basicMsgRep.getHttpContentEncoding();
		this._httpContentType = basicMsgRep.getHttpContentType();
		
		cacheDestination();
	}

	public JcsmpMsgRep clone() {
		JcsmpMsgRep mr = (JcsmpMsgRep) super.clone();
		
		// JCSMP destinations are not cloneable. So during a clone, this will be set to null.
		mr.jcsmpDestination = null;
		
		return mr;
	}
	

	public Destination getJcsmpDestination() {
		return jcsmpDestination;
	}
	
	public void cacheDestination() {
		
		if(destType == null) return;
		
		switch (destType) {
		case QUEUE:
			jcsmpDestination = DestinationUtils.onlyInstance().queueFromNetworkName(destination);
			break;
		case TOPIC:
			jcsmpDestination = DestinationUtils.onlyInstance().topicFromNetworkName(destination);
			break;
		default:
			throw new RuntimeException("Unkown destination type \"" + destType + "\".");
		}
	}
	
	//
	public static void setDeliveryModeOnXMLMessage(BasicMsgRep msgRep, XMLMessage jcsmpMsg) {

		if (jcsmpMsg == null)
			throw new NullPointerException("Cannot set delivery mode on null XMLMessage message.");
		if (msgRep == null)
			throw new NullPointerException("Cannot get delivery mode from null JcsmpMsgRep message.");

		switch (msgRep.getMessageDeliveryMode()) {

		case DIRECT:
			jcsmpMsg.setDeliveryMode(DeliveryMode.DIRECT);
			break;
		case NON_PERSISTENT:
			jcsmpMsg.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
			break;
		case PERSISTENT:
			jcsmpMsg.setDeliveryMode(DeliveryMode.PERSISTENT);
			break;
		default:
			throw new UnsupportedOperationException("Cannot set delivery mode, \"" + msgRep.getMessageDeliveryMode()
					+ "\" is unsupported.");
		}

	}
}
