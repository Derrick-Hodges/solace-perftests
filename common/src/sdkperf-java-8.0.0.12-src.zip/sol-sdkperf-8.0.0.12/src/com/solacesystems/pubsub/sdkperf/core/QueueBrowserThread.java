/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;

/**
 * Cache thread.  When sending cache requests at a specific
 * rate each client will contain a cache request thread that
 * will execute the cache request task. This thread runs to
 * completion and in general aborts when encountering errors.
 */
public class QueueBrowserThread {
	private static final Log Trace = LogFactory.getLog(QueueBrowserThread.class);
	
	protected AbstractClient _client;
	
	protected volatile boolean _isRequesting;
	protected volatile boolean _isDoneRequesting; 
	protected volatile boolean _shutdown; 
	protected volatile long _startTime;
	protected volatile long _endTime;
	protected QueueBrowserThreadObj _browserThread;
	protected RuntimeProperties _props;
	
	List<String> _queues;
	String _selector;
	
	public QueueBrowserThread(
			AbstractClient client) {
		_client = client;
	}

	public void start(
			final List<String> queueslist,
			final String selector,
			final RuntimeProperties props) throws Exception
	{
		_isDoneRequesting = false;
		_queues = new ArrayList<String>(queueslist);
		_selector = selector;
		_props = (RuntimeProperties)props.clone();
		
		if (_browserThread != null) {
			// previous thread object
			if (_browserThread.isAlive())
				throw new IllegalStateException("Attempted to start a queue browser thread when one was already running.");
		}
		_browserThread = new QueueBrowserThreadObj();
		_browserThread.start();
	}
	
	public void stop() throws Exception
	{
		_shutdown = true;
	}
	
	public boolean isReceiving() { return _isRequesting; }
	public boolean isDoneReceiving() { return _isDoneRequesting; }
	
	public long getStartTimeInNanos() { return _startTime; }
	public long getEndTimeInNanos() { return _endTime; }
	
	public void resetTimes() 
	{
		if (isReceiving())
		{
			_startTime = System.nanoTime();
			_endTime = 0;
		}
		else 
		{
			_startTime = 0;
			_endTime = 0;
		}
	}
	
	class QueueBrowserThreadObj extends Thread {
		@Override
		public void run() {
			
			_shutdown = false; //reset shutdown request
			
			try {
				if (Trace.isDebugEnabled()) {
					Trace.debug("CLIENT " + _client.getIdStr() + ":QueueBrowser about to connect.");
				}
				_client.connect();
				if (Trace.isDebugEnabled()) {
					Trace.debug("CLIENT " + _client.getIdStr() + ":QueueBrowser connected successfully.");
				}
			} catch (Exception e) {
				Trace.error("CLIENT " + _client.getIdStr() + ":QueueBrowser unable to open connection, shutdown", e);			
				_shutdown = true;
			}
		
			if (Trace.isDebugEnabled()) {
				Trace.debug(String.format("CLIENT " + _client.getIdStr() + ":About to enter receive loop"));
			}
			
			_startTime = System.nanoTime();
			
			_isRequesting = true;
			
			int deleteFrequency = _props.getIntegerProperty(RuntimeProperties.QB_DELETE_FREQUENCY);
			int msgBufSize = _props.getIntegerProperty(RuntimeProperties.QB_DELETE_BUFFER);
			
			// For simplicity, if desiring msg buffering, then make sure we are only using 1 browser so 
            // we don't have to save the browser and the message.
            if (msgBufSize > 0 && _queues.size() > 1)
            {
                Trace.error("CLIENT " + _client.getIdStr() + ":Must use single queue browser when buffering messages");			
				_shutdown = true;
            }
			
			try {
				_client.createBrowsers(_queues, _selector, deleteFrequency, msgBufSize);
			} catch (Exception e1) {
				Trace.error("CLIENT " + _client.getIdStr() + ":Error creating queue browsers", e1);
				_client.updateLastErrorResponse(e1);
				_shutdown = true;
			}
			
			while( !_shutdown) {
				
				try {
					boolean foundMsgsToBrowse = false;
					for (int i = 0; i<_queues.size(); i++)
					{
						if (_client.browseMsg(i))
						{
							foundMsgsToBrowse = true;
						}
					}
					
					if (!foundMsgsToBrowse) 
					{
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					Trace.error("CLIENT " + _client.getIdStr() + ":Error browsing messages: " + e.getMessage(), e);
					_shutdown = true;
				}
			}
			if (Trace.isDebugEnabled()) {
				Trace.debug(String.format("Exited queue browsing loop"));
			}
		 
			try {
				_client.deleteBrowsers();
			} catch (Exception e) {
				Trace.error("CLIENT " + _client.getIdStr() + ":Error browsing messages: " + e.getMessage(), e);
			}

			_endTime = System.nanoTime();

			_isRequesting = false;
			_isDoneRequesting = true;
		}
	}
}
