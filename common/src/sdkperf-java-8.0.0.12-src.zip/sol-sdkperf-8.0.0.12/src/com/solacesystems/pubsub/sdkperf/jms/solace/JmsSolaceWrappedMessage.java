package com.solacesystems.pubsub.sdkperf.jms.solace;

import javax.jms.JMSException;
import javax.jms.Message;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.jms.SolJmsUtility;
import com.solacesystems.jms.SupportedProperty;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsWrappedMessage;


public class JmsSolaceWrappedMessage extends JmsWrappedMessage {

	private static final Log Trace = LogFactory.getLog(JmsSolaceWrappedMessage.class);


	public JmsSolaceWrappedMessage(Message msg) {
		super(msg);
	}


	@Override
	public String dump() {
		if (_jmsMsg == null) {
			Trace.error("Unable to print null message.");
			return null;
		}

		return SolJmsUtility.dumpMessage(_jmsMsg);
	}

	@Override
	public byte[] getMessageAsBytes() throws Exception {
		if (_jmsMsg == null) {
			Trace.error("Unable to print null message.");
			return new byte[0];
		}
		byte[] retArray;
		try {
			retArray = SolJmsUtility.toByteArray(_jmsMsg);
		} catch (JMSException e) {
			return new byte[0];
		}
		
		return retArray;
	}
	
	@Override
	public boolean hasDiscardIndication() {
		if (_jmsMsg == null) {
			Trace.error("Unable to check DI of null message.");
			return false;
		}
		
		try {
			if (_jmsMsg.propertyExists(SupportedProperty.SOLACE_JMS_PROP_MSG_DISCARD_INDICATION) &&
					_jmsMsg.getBooleanProperty(SupportedProperty.SOLACE_JMS_PROP_MSG_DISCARD_INDICATION)) {
				return true;
			} 

			return false;
		} catch (JMSException e) {
			Trace.error("Exception during check of DI:" + e.getMessage(), e);
			return false;
		}
	}

	@Override
	public Long getTopicSequence() {
		
		if (_jmsMsg == null) {
			Trace.error("Unable to get topic sequence with null message.");
			return null;
		}

		try {
			if (_jmsMsg.propertyExists(SupportedProperty.SOLACE_JMS_PROP_TOPIC_SEQUENCE_NUMBER)) {
				return _jmsMsg.getLongProperty(SupportedProperty.SOLACE_JMS_PROP_TOPIC_SEQUENCE_NUMBER);
			} else {
				return null;
			}
		} catch (JMSException e) {
			Trace.error("Exception during check topic sequence:" + e.getMessage(), e);
			return null;
		}
	}


}
