package com.solacesystems.pubsub.sdkperf.core;

public abstract class AbstractMessageAckData {

	public abstract AbstractWrappedMessage getMessage();
	
}
