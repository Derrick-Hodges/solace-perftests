/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.util;

/**
 * Rate data point for display of rate on cli.
 */
public class RateDataPoint {
	long _messageCount = 0, _time = 0;
	
	public RateDataPoint(long messageCount, long time) {
		_messageCount = messageCount;
		_time = time;
	}

	public long getMessageCount() {
		return _messageCount;
	}

	public long getTime() {
		return _time;
	}
	
}
