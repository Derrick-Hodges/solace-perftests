package com.solacesystems.pubsub.sdkperf.core;

import java.util.List;

import com.solacesystems.pubsub.sdkperf.util.DataTypes.PublisherDestinationsType;

public abstract class AbstractWrappedMessage {

	// Returns the original message
	public abstract Object getMessage();
	
	public abstract boolean hasXml();

	public abstract boolean hasAttachment();	
	
	public abstract boolean hasTopic();
	public abstract String getDestinationName();
	public abstract PublisherDestinationsType getDestinationType();
	public abstract String getReplyToDestinationName();
	public abstract PublisherDestinationsType getReplyToDestinationType();
	
	public abstract GenericMessageDeliveryMode getDeliveryMode();
	
	public abstract boolean hasReplyToDestination();

	public abstract byte[] getXmlBytes();
	
	public abstract byte[] getAttachmentBytes();
	
	public abstract byte[] getUserdata();
	
	public abstract List<Long> getCids();
	
	// Return true if a message has been redelivered, false otherwise
	public abstract boolean getRedelivered();
	
	public abstract boolean validateStructDataMsg();
	
	// Returns true is the message is a cache message, false otherwise
	public abstract boolean isCacheMessage();
	
	// Returns true is the message is suspect, false otherwise
	public abstract boolean isSuspect();
	
	// Returns a string dump of the content of the message
	public abstract String dump();
	
	//
	public abstract byte[] getMessageAsBytes() throws Exception;
	
	// Returns true if a message prior to this message was discarded.
	public abstract boolean hasDiscardIndication();
		
	// 
	public abstract Long getTopicSequence();

	// If messages need to be sent upon reception of a message, the client may set the following producer
	protected Object _prodOnReceive = null;
	
	public Object getProducerOnReceive() {
		return _prodOnReceive;
	}
	public void setProducerOnReceive(Object prod) {
		_prodOnReceive = prod;	
	}
	
}
