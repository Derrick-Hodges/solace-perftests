/** 
*  Copyright 2004-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.util;

import java.nio.ByteBuffer;


/**
 * Constant values for the SDKPERF.
 */
public class SdkperfConstants {
	
	//custom stats filters
	public static final byte[] magicWord = { (byte) 0x50, (byte) 0x1A,
			(byte) 0xCE, (byte) 0x01};
	public static final long magicWordLong = NetworkByteOrderNumberUtil.fourByteToUInt(magicWord);
	
	public static final String userData = "abcdefghijklmnopqrstuvwxyz0123456789";
	public static final byte[] userDataBytes = userData.getBytes();
	public static final ByteBuffer userDataByteBuffer = ByteBuffer.wrap(userDataBytes);
	
	
	public static final int presenceDataOffset  = 4;
	
	public static final int xmlPayloadSize = 4;
	public static final int binAttachSize = 4;
	public static final int streamIdSize = 4;
	public static final int messageIdentifierSize = 8;
	public static final int latencySize = 8;  
	public static final int transactionIdentifierSize = 8;
	public static final int transactionMessageIdentifierSize = 4;
	public static final int transactionSizeBytes = 4;
	
	public static final int xmlPayloadBit = 0;
	public static final int streamIdBit = 1;
	public static final int rffuBit2 = 2;
	public static final int binAttachBit = 3;
	public static final int messageIdentifierBit = 4;
	public static final int latencyBit = 5;
	public static final int republishedBit = 6;
	public static final int transactionIdentifierBit = 7;

	public static final int SDM_ID_NULL = -1;
	public static final int SDM_ID_ALL = 0;
	public static final int SDM_ID_USER_DEF_BASE = 50;
	
	public static final String SOLACE_SDKPERF_USE_NATIVE_TIMER = "SOLACE_SDKPERF_USE_NATIVE_TIMER";
	public static final String SOLACE_SDKPERF_MTR_CATCHUP_NS = "SOLACE_SDKPERF_MTR_CATCHUP_NS";
}
