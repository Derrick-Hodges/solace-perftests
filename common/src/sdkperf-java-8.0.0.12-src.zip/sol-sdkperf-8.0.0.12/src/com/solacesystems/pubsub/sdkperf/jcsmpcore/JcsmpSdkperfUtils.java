package com.solacesystems.pubsub.sdkperf.jcsmpcore;

import java.util.HashMap;

import com.solacesystems.jcsmp.statistics.StatType;
import com.solacesystems.pubsub.sdkperf.core.GenericStatType;
import com.solacesystems.pubsub.sdkperf.core.PubSubException;



public class JcsmpSdkperfUtils {

	private JcsmpSdkperfUtils() {}
	
	/*
	 * 
	 */
	private static HashMap<GenericStatType, StatType> StatTypeTranslator = new HashMap<GenericStatType, StatType>();
	static {
		// Builds the StatType Translator
		StatTypeTranslator.put(GenericStatType.CACHE_FULFILL_REPLIES_DISCARDED, StatType.CACHE_FULFILL_REPLIES_DISCARDED);
		StatTypeTranslator.put(GenericStatType.CACHE_REQUESTS_FULFILLED, StatType.CACHE_REQUESTS_FULFILLED);
		StatTypeTranslator.put(GenericStatType.CACHE_REQUESTS_SENT, StatType.CACHE_REQUESTS_SENT);
		StatTypeTranslator.put(GenericStatType.CACHED_MSGS_RECVED, StatType.CACHED_MSGS_RECVED);
		StatTypeTranslator.put(GenericStatType.MESSAGES_DISCARDED_INTERNAL, StatType.MESSAGES_DISCARDED_INTERNAL);
		StatTypeTranslator.put(GenericStatType.PUBLISHER_WINDOW_CLOSED, StatType.PUBLISHER_WINDOW_CLOSED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_BYTES_RECVED, StatType.RELIABLE_BYTES_RECVED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_BYTES_RESENT, StatType.RELIABLE_BYTES_RESENT);
		StatTypeTranslator.put(GenericStatType.RELIABLE_BYTES_SENT, StatType.RELIABLE_BYTES_SENT);
		StatTypeTranslator.put(GenericStatType.RELIABLE_DIRECT_BYTES_RECVED, StatType.RELIABLE_DIRECT_BYTES_RECVED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_DIRECT_MSGS_RECVED, StatType.RELIABLE_DIRECT_MSGS_RECVED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_DIRECT_MSGS_SENT, StatType.RELIABLE_DIRECT_MSGS_SENT);
		StatTypeTranslator.put(GenericStatType.RELIABLE_MSGS_DISCARDED_DUPLICATES, StatType.RELIABLE_MSGS_DISCARDED_DUPLICATES);
		StatTypeTranslator.put(GenericStatType.RELIABLE_MSGS_DISCARDED_NO_MATCHING_FLOW, StatType.RELIABLE_MSGS_DISCARDED_NO_MATCHING_FLOW);
		StatTypeTranslator.put(GenericStatType.RELIABLE_MSGS_DISCARDED_OUTOFORDER, StatType.RELIABLE_MSGS_DISCARDED_OUTOFORDER);
		StatTypeTranslator.put(GenericStatType.RELIABLE_MSGS_RECVED, StatType.RELIABLE_MSGS_RECVED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_MSGS_RECVED_ACKED, StatType.RELIABLE_MSGS_RECVED_ACKED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_MSGS_RESENT, StatType.RELIABLE_MSGS_RESENT);
		StatTypeTranslator.put(GenericStatType.RELIABLE_MSGS_SENT, StatType.RELIABLE_MSGS_SENT);
		StatTypeTranslator.put(GenericStatType.RELIABLE_MSGS_SENT_CONFIRMED, StatType.RELIABLE_MSGS_SENT_CONFIRMED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_NONPERSISTENT_BYTES_RECVED, StatType.RELIABLE_NONPERSISTENT_BYTES_RECVED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_NONPERSISTENT_BYTES_RESENT, StatType.RELIABLE_NONPERSISTENT_BYTES_RESENT);
		StatTypeTranslator.put(GenericStatType.RELIABLE_NONPERSISTENT_MSGS_RECVED, StatType.RELIABLE_NONPERSISTENT_MSGS_RECVED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_NONPERSISTENT_MSGS_RECVED_ACKED, StatType.RELIABLE_NONPERSISTENT_MSGS_RECVED_ACKED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_NONPERSISTENT_MSGS_RESENT, StatType.RELIABLE_NONPERSISTENT_MSGS_RESENT);
		StatTypeTranslator.put(GenericStatType.RELIABLE_NONPERSISTENT_MSGS_SENT, StatType.RELIABLE_NONPERSISTENT_MSGS_SENT);
		StatTypeTranslator.put(GenericStatType.RELIABLE_PERSISTENT_BYTES_RECVED, StatType.RELIABLE_PERSISTENT_BYTES_RECVED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_PERSISTENT_BYTES_RESENT, StatType.RELIABLE_PERSISTENT_BYTES_RESENT);
		StatTypeTranslator.put(GenericStatType.RELIABLE_PERSISTENT_MSGS_SENT, StatType.RELIABLE_PERSISTENT_MSGS_SENT);
		StatTypeTranslator.put(GenericStatType.RELIABLE_PERSISTENT_MSGS_RECVED, StatType.RELIABLE_PERSISTENT_MSGS_RECVED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_PERSISTENT_MSGS_RECVED_ACKED, StatType.RELIABLE_PERSISTENT_MSGS_RECVED_ACKED);
		StatTypeTranslator.put(GenericStatType.RELIABLE_PERSISTENT_MSGS_RESENT, StatType.RELIABLE_PERSISTENT_MSGS_RESENT);
		StatTypeTranslator.put(GenericStatType.REPLIES_DISCARDED, StatType.REPLIES_DISCARDED);
		StatTypeTranslator.put(GenericStatType.REPLIES_RECVED, StatType.REPLIES_RECVED);
		StatTypeTranslator.put(GenericStatType.REQUESTS_SENT, StatType.REQUESTS_SENT);
		StatTypeTranslator.put(GenericStatType.REQUESTS_TIMED_OUT, StatType.REQUESTS_TIMED_OUT);
		StatTypeTranslator.put(GenericStatType.ROUTER_DISCARD_NOTIFICATIONS, StatType.ROUTER_DISCARD_NOTIFICATIONS);
		StatTypeTranslator.put(GenericStatType.SMF_DISCARDS_UNKNOWN_ELEMENT, StatType.SMF_DISCARDS_UNKNOWN_ELEMENT);
		StatTypeTranslator.put(GenericStatType.SUBSCRIBER_CONGESTED_EVENT, StatType.SUBSCRIBER_CONGESTED_EVENT);
		StatTypeTranslator.put(GenericStatType.SUBSCRIBER_FLOW_WINDOW_CLOSED, StatType.SUBSCRIBER_FLOW_WINDOW_CLOSED);
		StatTypeTranslator.put(GenericStatType.TOTAL_BYTES_RECVED, StatType.TOTAL_BYTES_RECVED);
		StatTypeTranslator.put(GenericStatType.TOTAL_BYTES_SENT, StatType.TOTAL_BYTES_SENT);
		StatTypeTranslator.put(GenericStatType.TOTAL_SOCKET_BYTES_RECVED, StatType.TOTAL_SOCKET_BYTES_RECVED);
		StatTypeTranslator.put(GenericStatType.TOTAL_SOCKET_BYTES_SENT, StatType.TOTAL_SOCKET_BYTES_SENT);
		StatTypeTranslator.put(GenericStatType.TOTAL_SOCKET_COMPRESSED_BYTES_RECVED, StatType.TOTAL_SOCKET_COMPRESSED_BYTES_RECVED);
		StatTypeTranslator.put(GenericStatType.TOTAL_SOCKET_COMPRESSED_BYTES_SENT, StatType.TOTAL_SOCKET_COMPRESSED_BYTES_SENT);
		StatTypeTranslator.put(GenericStatType.TOTAL_SOCKET_SSL_BYTES_RECVED, StatType.TOTAL_SOCKET_SSL_BYTES_RECVED);
		StatTypeTranslator.put(GenericStatType.TOTAL_SOCKET_SSL_BYTES_SENT, StatType.TOTAL_SOCKET_SSL_BYTES_SENT);
		StatTypeTranslator.put(GenericStatType.TOTAL_MSGS_SENT, StatType.TOTAL_MSGS_SENT);
		StatTypeTranslator.put(GenericStatType.TOTAL_MSGS_RECVED, StatType.TOTAL_MSGS_RECVED);
	}
	
	
	public static StatType convertGStatTypeToStatType(GenericStatType gst) throws Exception
	{

		StatType st = StatTypeTranslator.get(gst);
		
		if(st != null)
			return st;

		// Throw an exception in the event it cannot be converted to a StatType
		throw new PubSubException("GenericStatType \"" + gst.getLabel() + "\" cannot be converted to Jcsmp's StatType."); 

	}
}		
		
	
	
	
