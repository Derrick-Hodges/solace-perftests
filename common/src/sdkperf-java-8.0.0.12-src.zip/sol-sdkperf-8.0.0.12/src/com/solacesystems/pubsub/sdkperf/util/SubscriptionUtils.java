package com.solacesystems.pubsub.sdkperf.util;

public class SubscriptionUtils {

    private static final String TOPIC_END = "<TOPIC_END/>";
    private static final String DELIVER_TO_ALL_FLAG = "DA=1";
    private static final String DELIVER_TO_ALL_REGEX = "DA=[0-1]";

    
	public static final String DEMUXID_END = "<DEMUX_ID/>";
	public static final String DEMUX_LOCAL_ONLY_FLAG = "DLO=1";
	private static final String DEMUX_LOCAL_REGEX = "DLO=[0-1]";
    

    public static SubscriptionBean buildSubscriptionBeanFromExpression(String expression) {
    	
    	SubscriptionBean sb = new SubscriptionBean();
    	
		sb.setDeliverAlways(expression.contains(DELIVER_TO_ALL_FLAG));
		expression = expression.replaceAll(DELIVER_TO_ALL_REGEX, "");

		sb.setIsLocalDelivery(expression.contains(DEMUX_LOCAL_ONLY_FLAG));
		expression = expression.replaceAll(DEMUX_LOCAL_REGEX, "");
		
		int demuxIdEnd = expression.indexOf(DEMUXID_END);
		
		if(demuxIdEnd != -1) {
			String dispatcherName = expression.substring(0, demuxIdEnd);
			sb.setDispatcherName(dispatcherName);
			expression = expression.substring(demuxIdEnd);
			expression = expression.replace(DEMUXID_END, "");
		}
		
		// Remove tags
		
		int topicEnd = expression.indexOf(TOPIC_END);
		
		if(topicEnd != -1) {
			String topic = expression.substring(0, topicEnd);
			sb.setTopic(topic);
		} else {
			sb.setTopic(expression);
		}
		
		
		
		return sb;
    }
    
    
    public static class SubscriptionBean {
    	private boolean _deliverAlways = false;
    	private boolean _isLocalDelivery = false;
    	private String _dispatcherName;
    	private String _topic;

    	public boolean getDeliverAlways() {
    		return _deliverAlways;
    	}

    	public void setDeliverAlways(boolean deliverAlways) {
    		_deliverAlways = deliverAlways;
    	}

    	public boolean getIsLocalDelivery() {
    		return _isLocalDelivery;
    	}

    	public void setIsLocalDelivery(boolean isLocalDelivery) {
    		_isLocalDelivery = isLocalDelivery;
    	}

    	public String getDispatcherName() {
    		return _dispatcherName;
    	}

    	public void setDispatcherName(String dispatcherName) {
    		_dispatcherName = dispatcherName;
    	}

    	public String getTopic() {
    		return _topic;
    	}

    	public void setTopic(String topic) {
    		_topic = topic;

    	}
    }
    
}
