/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import java.util.List;

import javax.transaction.xa.XAResource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericRestMode;
import com.solacesystems.pubsub.sdkperf.core.Constants.InternalApiMode;
import com.solacesystems.pubsub.sdkperf.util.Timing;

/**
 * Publisher thread.  When publishing, each client will contain
 * a publisher thread that will execute the publish task.
 * This thread runs to completion and in general aborts when
 * encountering errors.
 */
public class RtrperfPubThread {
	private static final Log Trace = LogFactory.getLog(RtrperfPubThread.class);
	
	protected List<AbstractClient> _clients;
	protected RuntimeProperties _perfProps;
	protected BasicMsgRep[] _doclist;
	
	
	private long _numTotalMsgs;
	
	protected volatile boolean _isPublishing;
	protected volatile boolean _shutdown; 
	protected volatile long _startTime;
	protected volatile long _endTime;
	protected PubThreadObj _pubThread;
	
		
	public RtrperfPubThread(
			List<AbstractClient> clients) throws Exception {
		_clients = clients;
	
	}

	@SuppressWarnings("unchecked")
	public void startPublish(
			final List<BasicMsgRep> doclist,
			final long numTotalMsgs,
			final RuntimeProperties props) throws Exception
	{
		_numTotalMsgs = numTotalMsgs;
		_perfProps = (RuntimeProperties)props.clone();
		
		if(props.getProperty(RuntimeProperties.API_MODE).equals(InternalApiMode.REST) &&props.getProperty(RuntimeProperties.RESTCLIENT_MODE).equals(GenericRestMode.SOCKET)){
			for(AbstractClient client :_clients){
				client._numMsgPub=numTotalMsgs;
				client._isStartPub=true;
				client._numMsgsPubOffset=1;
			}
		}
		
		// Must create an API specific version of the message list to allow the APIs to cache some things like destinations.
		// Also keep it as an array for faster access in the pub loop.
		// Use the first client for the conversion.
		_doclist = _clients.get(0).cloneToApiSpecificMsgRep(doclist.toArray(new BasicMsgRep[doclist.size()]));
		
		List<String> transactedSessionNameList = (List<String>)_perfProps.getProperty(RuntimeProperties.TRANSACTED_SESSION_NAME_LIST);

		// If trying to publish with transactions then we need to make sure that the session names list is the same length as the clients list.
		if (transactedSessionNameList != null &&
				transactedSessionNameList.size() > 0 &&
				transactedSessionNameList.size() != _clients.size()) {
			throw new PubSubException("Error trying to publishing using transacted sessions.  Session names list not equal to num clients");
		}
		
		int _producerIndex = 0;
		String transactedSessionName = "";
		for (int i = 0; i < _clients.size(); i++) {
			AbstractClient client = _clients.get(i);
			if (transactedSessionNameList != null &&
					transactedSessionNameList.size() > 0) {
				transactedSessionName = transactedSessionNameList.get(i);
			}
			
			if ((_perfProps.getBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION)) && 
				(_perfProps.getIntegerProperty(RuntimeProperties.AD_TRANSACTION_SIZE) > 0)) {
				this.initXaTransactions(transactedSessionName, client);
			}
			
			client.setPublishProps(_perfProps, _producerIndex, transactedSessionName);
		//Duplicate connect()??	
		//client.connect();
		}
		
		//Here we are going to connect all Consumers if Any
	
		
		if (_pubThread != null) {
			// previous thread object
			if (_pubThread.isAlive())
				throw new IllegalStateException("Attempted to start a publisher thread when one was already running.");
		}		
		_pubThread = new PubThreadObj();
		_pubThread.start();
	}
	
	public void stopPublish() 
	{
		_shutdown = true;
	}
	
	public boolean isPublishing() { return _isPublishing; }
	
	public long getStartTimeInNanos() { return _startTime; }
	public long getEndTimeInNanos() { return _endTime; }
	
	public void resetStats() 
	{
		if (isPublishing())
		{
			_startTime = System.nanoTime();
			_endTime = 0;
		}
		else 
		{
			_startTime = 0;
			_endTime = 0;
		}
	}

	public String initXaTransactions(String sessionName, AbstractClient client) throws Exception {
		// Create XID
		String clientXid = client.createXid(sessionName);
		//Trace.error("Created XID " + clientXid + " for Consumer XASession " + sessionName);
		String firstClientXid = clientXid;
		
		// Start XA Session
		client.startXaSession(sessionName, clientXid, XAResource.TMNOFLAGS);
		//Trace.error("Started XID " + clientXid + " for Consumer XASession " + sessionName);
		
		if ((_perfProps.getIntegerProperty(RuntimeProperties.XA_NUM_SUSPENDED_TRANSACTIONS) > 0)) {
			// Suspend XA Session
			client.endXaSession(sessionName, clientXid, XAResource.TMSUSPEND);
			//Trace.error("Suspend XID " + clientXid + " for Consumer XASession " + sessionName);
			
			for (int j = 1; j < _perfProps.getIntegerProperty(RuntimeProperties.XA_NUM_SUSPENDED_TRANSACTIONS); j++) {
				// Create XID
				clientXid = client.createXid(sessionName);
				//Trace.error("Created XID " + clientXid + " for Consumer XASession " + sessionName);
				
				// Start XA Session
				client.startXaSession(sessionName, clientXid, XAResource.TMNOFLAGS);
				//Trace.error("Started XID " + clientXid + " for Consumer XASession " + sessionName);
				
				// Suspend XA Session
				client.endXaSession(sessionName, clientXid, XAResource.TMSUSPEND);
				//Trace.error("Suspend XID " + clientXid + " for Consumer XASession " + sessionName);
			}
			
			// Resume XA Session
			client.startXaSession(sessionName, firstClientXid, XAResource.TMRESUME);
			//Trace.error("Resume XID " + firstClientXid + " for Consumer XASession " + sessionName);
		}
		
		return firstClientXid;
	}
	
	class PubThreadObj extends Thread {
		@Override
		public void run() {
			_shutdown = false;
		    _isPublishing = true;
		    
		    if (Trace.isDebugEnabled())
		    	Trace.debug("Rtrperf: Main loop start.");

		    int pubSendVectSize = _perfProps.getIntegerProperty(RuntimeProperties.PUB_SEND_VECT_SIZE);
			
			/* Check to see if the burst duration and inter-burst duration  have been
			 * set. If either one of them have not been set, we do not set the burst mode flag. 
			 */
			if (_perfProps.getDoubleProperty(RuntimeProperties.BURST_DURATION) > 0 && 
				_perfProps.getDoubleProperty(RuntimeProperties.INTER_BURST_DURATION) > 0) {
				Trace.error("Feature unsupported in rtrperf.  Please raise bug to request support for Burst Mode");
				_shutdown = true;
			} 
		    
		    long msgsSent = 0;
		    long startTimeInTicks = Timing.getClockValue();
		    int numClients = _clients.size();
		    double msgRate = _perfProps.getDoubleProperty(RuntimeProperties.PUBLISH_RATE_PER_PUB) * numClients;
		    long txMsgRateInTicksPerMsg = 1L;
		    if(msgRate > 0.0) {
		    	txMsgRateInTicksPerMsg = (long)((double)Timing.clockSpeedInHz() / msgRate);
		    }
		    int msgListSize = _doclist.length;
		    final int producerIndex = 0;
		    int transactionSize = _perfProps.getIntegerProperty(RuntimeProperties.AD_TRANSACTION_SIZE);
			boolean wantXa = _perfProps.getBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION);
			boolean wantOnePhaseCommit = _perfProps.getBooleanProperty(RuntimeProperties.XA_WANT_ONE_PHASE_COMMIT_TRANSACTION);
			int numMsgsPerTransactionSegment = _perfProps.getIntegerProperty(RuntimeProperties.XA_NUM_MSGS_PER_TRANSACTION_SEGMENT);
			int numSuspendedTransactions = _perfProps.getIntegerProperty(RuntimeProperties.XA_NUM_SUSPENDED_TRANSACTIONS);
		    boolean wantTransactionRollback = (_perfProps.getIntegerProperty(RuntimeProperties.AD_TRANSACTION_ROLLBACK_INTERVAL) == 1);
		    int ackImmediatelyInterval = _perfProps.getIntegerProperty(RuntimeProperties.AD_ACK_IMMEDIATELY_INTERVAL);
		    boolean skipFinalCommit = _perfProps.getBooleanProperty(RuntimeProperties.SKIP_FINAL_COMMIT);
		    
			if (msgRate < 1 && numClients > 1) {
			    _isPublishing = false;
				_shutdown = true;
				// To support this feature, rtrperf will need to publish
				// messages using all clients (it currently publishes all
				// messages using a single client)
				throw new UnsupportedOperationException(
						"It is currently impossible for rtrperf to publish at an unlimited rate when using more than a single client.");
		    }
		    
		    long[] xaMsgIdOffset = new long[numClients];
		    
			
		    // Update publisher start time.
		    _startTime = System.nanoTime();

		    while (!_shutdown && (msgsSent < _numTotalMsgs))
		    {
		        long curTick = Timing.getClockValue();
		        long msgsToSendNow = ((curTick - startTimeInTicks) / txMsgRateInTicksPerMsg) - msgsSent;
		        
		        if (msgsToSendNow > 0) {   
		            if (msgsSent + msgsToSendNow > _numTotalMsgs)
		            {
		                msgsToSendNow = _numTotalMsgs - msgsSent;
		            }

		            int msgsSentNow = 0;
		            do
		            {
		                // Determine client ID
		            	int clientId = (int)((msgsSent + 1) % numClients);
		            	
		                long clientMsgNum = msgsSent / numClients + 1 + xaMsgIdOffset[clientId];		                

		                // msgId array is 0 based.  So subtract 1.
		                int msgId    = (int)((clientMsgNum - 1)  % msgListSize);

						// If we have an ack immediately interval, we set the flag explicitly
			            // because we reuse message properties.
						if (ackImmediatelyInterval > 0) {
							if ((clientMsgNum % ackImmediatelyInterval) == 0) {
								_doclist[msgId].setAckImmediately(true);
							} else {
								_doclist[msgId].setAckImmediately(false);
							}
						}
		                
		                try {
		                    if (pubSendVectSize > 0) {
		                    	Trace.error("Burst-mode feature unsupported in rtrperf.");
		        				_shutdown = true;
		                    } else {

		                    	// First check of this method is whether tool data is required.
		                    	_clients.get(clientId).populateToolData(
		                    			_doclist[msgId],
		                    			clientMsgNum,
		                    			-1, -1, -1);

		                    	_clients.get(clientId).publishMsg(_doclist[msgId], producerIndex);
		                    }
		                    
			                // If doing transactions then at this point check to see if we should do a commit.
							if (transactionSize > 0 && 
								(clientMsgNum % transactionSize) == 0) {

								// It's time to commit this transaction.  In case a roll back exception, we
								// will keep track of a msgId offset based on the size of this transaction.
								// This has the effect of trying to re-send and re-commit the set of messages.
								try {
									if (wantXa) {
										_clients.get(clientId).commitXaSessionOnCurrPub(producerIndex, wantTransactionRollback, wantOnePhaseCommit, false);
									} else {
										_clients.get(clientId).commitTransactionOnCurrPub(producerIndex, wantTransactionRollback);
									}
								} catch ( Exception e) {
									xaMsgIdOffset[clientId] -= transactionSize;
								}
							} else if (wantXa &&
										transactionSize > 0 &&
										numMsgsPerTransactionSegment > 0 &&
										numSuspendedTransactions > 0 &&
										(clientMsgNum % numMsgsPerTransactionSegment) == 0) {
								_clients.get(clientId).suspendXaSessionOnCurrPub(producerIndex);
							}
		                } 
		                catch (Exception e) {
							Trace.error("RtrperfThread sendMessage, shutdown due to: " + e.getMessage(), e);
							_shutdown = true;
						}
		                
		                msgsSent+=_clients.get(clientId)._numMsgsPubOffset;
		                msgsSentNow+=_clients.get(clientId)._numMsgsPubOffset;		                
		            }
		            while (msgsSentNow < msgsToSendNow && !_shutdown);
		        }
		    }
		    
		    if (transactionSize > 0 && !skipFinalCommit) {
				// One last commit at the end
				try {
					for (AbstractClient client : _clients) 
					{
						if (wantXa) {
							client.commitXaSessionOnCurrPub(producerIndex, wantTransactionRollback, wantOnePhaseCommit, true);
						} else {
							client.commitTransactionOnCurrPub(producerIndex, wantTransactionRollback);
						}
					}
				} catch (Exception e) {
					Trace.error("RtrperfPubThread : Exception - " + e.getMessage(), e);
				}
			}

		    // Update publish end time.
		    _endTime = System.nanoTime();

		    Trace.error("Rtrperf: Main loop done");
		    _isPublishing = false;
		}
	}
}
