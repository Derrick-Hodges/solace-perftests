/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.jcsmpcore;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.jcsmp.JCSMPException;
import com.solacesystems.pubsub.sdkperf.core.AbstractClient;

/**
 * Client Ack thread.  When operating in Client Ack Mode and requesting
 * that client acks are performed in a new thread, this thread will do
 * the work.
 */
public class ClientAckThread extends Thread {
	private static final Log Trace = LogFactory.getLog(ClientAckThread.class);
	
	protected AbstractClient _client;
	protected ConcurrentLinkedQueue<?> _keptMsgQueue;
	protected Semaphore _clientAckSemaphore;
	
	protected volatile boolean _shutdown;	
		
	protected int _desiredQueueSize;
	protected boolean _enableAcking;
		
	public ClientAckThread(
			AbstractClient client, 
			ConcurrentLinkedQueue<?> keptMsgQueue) throws JCSMPException {
		_client = client;
		_keptMsgQueue = keptMsgQueue;
		_desiredQueueSize = 0;
		_enableAcking = false;
	}
	
	public void shutdown()
	{
		_shutdown = true;
	}
	
	public void setDesiredQueueSize(int value) {
		_desiredQueueSize = value;
	}
	
	public void setEnableAcking(boolean value) {
		_enableAcking = value;
	}
	
	public void run() {
		
		_shutdown = false;
	    
	    if (Trace.isDebugEnabled()) {
	    	Trace.debug("Client Ack Thread: Main loop start.");
	    }

	    try {
	    	
    		while (!_shutdown) {
    			synchronized(_keptMsgQueue) {
		    		_keptMsgQueue.wait();
		    	}
		        if (!_shutdown) {
		        	_client.processKeptMsgs(_desiredQueueSize, _enableAcking);
		        }
		    }
	    } catch (Exception e) {
			Trace.error("ClienAckThread encountered an error, shutdown", e);			
			_shutdown = true;
	    }
	}
}
