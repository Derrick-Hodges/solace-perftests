/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import com.solacesystems.pubsub.sdkperf.util.DataTypes.ActiveFlowIndicationType;

public class FlowStatus {
	
	private volatile boolean _isUp;
	private ActiveFlowIndicationType _afiState;
	
	public FlowStatus() {
		_isUp = false;
		_afiState = ActiveFlowIndicationType.UNKNOWN;
	}
	
	public ActiveFlowIndicationType getAfiState() {
		return _afiState;
	}
	
	public void setAfiState(ActiveFlowIndicationType value) {
		_afiState = value;
	}
	
	public String getAfiStateString() {
		return _afiState.name();
	}
	
	public boolean isUp() {
		return _isUp;
	}
	
	public void setIsUp(boolean value) {
		_isUp = value;
	}
	
}
