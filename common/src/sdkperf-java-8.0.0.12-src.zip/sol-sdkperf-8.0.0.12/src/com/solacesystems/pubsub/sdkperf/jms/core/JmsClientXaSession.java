/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.jms.core;

import java.net.Inet4Address;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Vector;
import java.util.Random;

import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.XASession;
import javax.transaction.xa.XAResource;
import javax.transaction.xa.Xid;

import com.solacesystems.common.xa.SolXid;
import com.solacesystems.jcsmp.protocol.nio.impl.ConsumerNotificationDispatcher;
import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.AbstractClient;
import com.solacesystems.pubsub.sdkperf.core.AbstractClientTransactedSession;
import com.solacesystems.pubsub.sdkperf.core.Constants.XaTransactionAction;
import com.solacesystems.pubsub.sdkperf.jms.solace.ClientXaNotification;

public class JmsClientXaSession extends AbstractClientTransactedSession {

	protected XASession xaSession;
	protected XAResource xaResource;
	protected boolean wantOnePhase;
	protected int numMsgsPerTransactionSegment;
	protected int numSuspendedTransactions;
	protected LinkedHashMap<String, SolXid> _xidMap;
	protected Vector<String> _xids;
	protected String _activeXid;
	private static int _xidCounter = (new Random(System.currentTimeMillis())).nextInt(1000000);
	ConsumerNotificationDispatcher dispatcher;
	private MessageProducer _msgProd = null;
	
	public JmsClientXaSession(AbstractClient client, XASession xaSession, RuntimeProperties rprops) {
		this.init(client, rprops);
		this.xaSession = xaSession;
		this.xaResource = xaSession.getXAResource();
		this.wantOnePhase = rprops.getBooleanProperty(RuntimeProperties.XA_WANT_ONE_PHASE_COMMIT_TRANSACTION);
		this.numMsgsPerTransactionSegment = rprops.getIntegerProperty(RuntimeProperties.XA_NUM_MSGS_PER_TRANSACTION_SEGMENT);
		this.numSuspendedTransactions = rprops.getIntegerProperty(RuntimeProperties.XA_NUM_SUSPENDED_TRANSACTIONS);
		_xidMap = new LinkedHashMap<String, SolXid>();
		_xids = new Vector<String>();
		_activeXid = null;
	}
	
	public String createXid(int formatIdInt, String globalTransactionIDString, String branchQualifierString) {
		byte[] globalTransactionIDByteArray = globalTransactionIDString.getBytes();
		byte[] branchQualifierByteArray = branchQualifierString.getBytes();
		
		SolXid xid = new SolXid(formatIdInt, globalTransactionIDByteArray, branchQualifierByteArray);
		String xidString = this.xidToString(xid);
		_xidMap.put(xidString, xid);
		
		return xidString;
	}
	
	public String createXid() {
		String globalTransactionIDString;
		String branchQualifierString;
		int formatIdInt = _xidCounter;

		try {
			globalTransactionIDString = Inet4Address.getLocalHost().getHostAddress() + "globalTransactionID" + _xidCounter;
		} catch (Exception ex) {
			globalTransactionIDString = "globalTransactionID" + _xidCounter;
		}
		_xidCounter++;
		try {
			branchQualifierString = Inet4Address.getLocalHost().getHostAddress() + "branchQualifier" + _xidCounter;
		} catch (Exception ex) {
			branchQualifierString = "branchQualifier" + _xidCounter;
		}
		_xidCounter++;
		
		String xidString = this.createXid(formatIdInt, globalTransactionIDString, branchQualifierString);
		
		return xidString;
	}
	
	public String xidToString(Xid xid) {
		return xid.toString();
	}
	
	public XASession getXaSession() {
		return xaSession;
	}
	
	public Vector<String> getXids() {
		return _xids;
	}

	public String getActiveXid() {
		return _activeXid;
	}
	
	public void commit(String xid, boolean onePhase) throws Exception {
		numMsgsOnCommit = numMsgsRecv;
		xaResource.commit(_xidMap.get(xid), onePhase);
		if (_xids.contains(xid)) {
			_xids.remove(xid);
		}
	}
	
	public void end(String xid, int flags) throws Exception {
		xaResource.end(_xidMap.get(xid), flags);
		_activeXid = null;
	}
	
	public void forget(String xid) throws Exception {
		xaResource.forget(_xidMap.get(xid));
		if (_xids.contains(xid)) {
			_xids.remove(xid);
		}
	}
	
	public void prepare(String xid) throws Exception {
		xaResource.prepare(_xidMap.get(xid));
	}
	
	public Vector<String> recover(int flag) throws Exception {
		Vector<String> retList = new Vector<String>();
		for (Xid xid : xaResource.recover(flag)) {
			retList.add(this.xidToString(xid));
		}
		return retList;
	}
	
	public void rollback(String xid) throws Exception {
		numMsgsOnCommit = numMsgsRecv;
		xaResource.rollback(_xidMap.get(xid));
		if (_xids.contains(xid)) {
			_xids.remove(xid);
		}
	}
	
	public void start(String xid, int flags) throws Exception {
		xaResource.start(_xidMap.get(xid), flags);
		if (!_xids.contains(xid)) {
			_xids.add(xid);
		}
		_activeXid = xid;
	}
	
	public void setTransactionTimeout(int seconds) throws Exception {
		xaResource.setTransactionTimeout(seconds);
	}
	
	public int getTransactionTimeout() throws Exception {
		return xaResource.getTransactionTimeout();
	}
	
	@Override
	public void close() {
		timer.cancel();
		try {
			xaSession.close();
		} catch (JMSException e) {
			onException(e);
		}
	}
	
	@Override
	public void commit(boolean wantRollback) throws Exception {
		numMsgsOnCommit = numMsgsRecv;
		if (wantRollback) {
			xaSession.rollback();
			_client.getRxStats().rollback();
		} else {
			xaSession.commit();
			_client.getRxStats().commit();
		}
	}
	
	public void setDispatcher(ConsumerNotificationDispatcher dispatcher) {
		this.dispatcher = dispatcher;
	}
	
	@Override
	public void commitOnDispatcher(boolean wantRollback) throws Exception {
		numMsgsOnCommit = numMsgsRecv;
		if (dispatcher != null) {
				ArrayBlockingQueue<Object> responseQueue = new ArrayBlockingQueue<Object>(1);
			dispatcher.enqueueNonBlockingNotification( new ClientXaNotification(this, responseQueue, wantRollback) );
			Object response = responseQueue.take();
			if (response instanceof Exception) {
				throw (Exception)response;
			}
		} else {
			this.commit(wantRollback);
		}
	}
	
	public void commitOnDispatcher(String xid, boolean onePhase) throws Exception {
		numMsgsOnCommit = numMsgsRecv;
		if (dispatcher != null) {
				ArrayBlockingQueue<Object> responseQueue = new ArrayBlockingQueue<Object>(1);
			dispatcher.enqueueNonBlockingNotification( new ClientXaNotification(this, responseQueue, XaTransactionAction.COMMIT, xid, onePhase) );
			Object response = responseQueue.take();
			if (response instanceof Exception) {
				throw (Exception)response;
			}
		} else {
			this.commit(xid, onePhase);
		}
	}
	
	public void endOnDispatcher(String xid, int flags) throws Exception {
		if (dispatcher != null) {
				ArrayBlockingQueue<Object> responseQueue = new ArrayBlockingQueue<Object>(1);
			dispatcher.enqueueNonBlockingNotification( new ClientXaNotification(this, responseQueue, XaTransactionAction.END, xid, flags) );
			Object response = responseQueue.take();
			if (response instanceof Exception) {
				throw (Exception)response;
			}
		} else {
			this.end(xid, flags);
		}
	}
	
	public void forgetOnDispatcher(String xid) throws Exception {
		if (dispatcher != null) {
				ArrayBlockingQueue<Object> responseQueue = new ArrayBlockingQueue<Object>(1);
			dispatcher.enqueueNonBlockingNotification( new ClientXaNotification(this, responseQueue, XaTransactionAction.FORGET, xid) );
			Object response = responseQueue.take();
			if (response instanceof Exception) {
				throw (Exception)response;
			}
		} else {
			this.forget(xid);
		}
	}
	
	public void prepareOnDispatcher(String xid) throws Exception {
		if (dispatcher != null) {
				ArrayBlockingQueue<Object> responseQueue = new ArrayBlockingQueue<Object>(1);
			dispatcher.enqueueNonBlockingNotification( new ClientXaNotification(this, responseQueue, XaTransactionAction.PREPARE, xid) );
			Object response = responseQueue.take();
			if (response instanceof Exception) {
				throw (Exception)response;
			}
		} else {
			this.prepare(xid);
		}
	}
	
	public void recoverOnDispatcher(int flag) throws Exception {
		if (dispatcher != null) {
				ArrayBlockingQueue<Object> responseQueue = new ArrayBlockingQueue<Object>(1);
			dispatcher.enqueueNonBlockingNotification( new ClientXaNotification(this, responseQueue, XaTransactionAction.RECOVER, flag) );
			Object response = responseQueue.take();
			if (response instanceof Exception) {
				throw (Exception)response;
			}
		} else {
			this.recover(flag);
		}
	}
	
	public void rollbackOnDispatcher(String xid) throws Exception {
		numMsgsOnCommit = numMsgsRecv;
		if (dispatcher != null) {
				ArrayBlockingQueue<Object> responseQueue = new ArrayBlockingQueue<Object>(1);
			dispatcher.enqueueNonBlockingNotification( new ClientXaNotification(this, responseQueue, XaTransactionAction.ROLLBACK, xid) );
			Object response = responseQueue.take();
			if (response instanceof Exception) {
				throw (Exception)response;
			}
		} else {
			this.rollback(xid);
		}
	}
	
	public void startOnDispatcher(String xid, int flags) throws Exception {
		if (dispatcher != null) {
				ArrayBlockingQueue<Object> responseQueue = new ArrayBlockingQueue<Object>(1);
			dispatcher.enqueueNonBlockingNotification( new ClientXaNotification(this, responseQueue, XaTransactionAction.START, xid, flags) );
			Object response = responseQueue.take();
			if (response instanceof Exception) {
				throw (Exception)response;
			}
		} else {
			this.start(xid, flags);
		}
	}
	
	public void runOnDispatcher(boolean onePhase) throws Exception {
		numMsgsOnCommit = numMsgsRecv;
		if (dispatcher != null) {
				ArrayBlockingQueue<Object> responseQueue = new ArrayBlockingQueue<Object>(1);
			dispatcher.enqueueNonBlockingNotification( new ClientXaNotification(this, responseQueue, XaTransactionAction.ALL, onePhase) );
			Object response = responseQueue.take();
			if (response instanceof Exception) {
				throw (Exception)response;
			}
		} else {
			String xid = _activeXid;
			try {
				this.end(xid, XAResource.TMSUCCESS);
				if (!onePhase) {
					this.prepare(xid);
				}
				this.commit(xid, onePhase);
				this.start(xid, XAResource.TMNOFLAGS);
			} catch (Exception e) {
				if (_activeXid != null) {
					try {
						this.rollback(_activeXid);
					} catch (Exception e1) {
						this.start(xid, XAResource.TMNOFLAGS);
						throw e1;
					}
				}
				this.start(xid, XAResource.TMNOFLAGS);
				throw e;
			}
		}
	}
	
	@Override
	public void onMessage() throws Exception {
		numMsgsRecv++;

		if (transactionSize > 0 &&
				numMsgsRecv > 0 &&
				(numMsgsRecv % transactionSize) == 0) {
			numCommits++;
			String startedXid = _activeXid;
			try {
				this.end(startedXid, XAResource.TMSUCCESS);
				for (int i = 0; i < _xids.size(); i++) {
					String xid = _xids.get(0);
					if (!wantOnePhase) {
						this.prepare(xid);
					}
					if (wantTransactionRollback ||
							((rollbackInterval > 0) &&
							(numCommits % rollbackInterval == 0))) {
						this.rollback(xid);
					} else {
						this.commit(xid, wantOnePhase);
					}
					this.start(xid, XAResource.TMNOFLAGS);
					if (_xids.size() > 1) {
						this.end(xid, XAResource.TMSUSPEND);
					}
				}
				if (_xids.size() > 1) {
					this.start(startedXid, XAResource.TMRESUME);
				}
			} catch (Exception e) {
				if (_activeXid != null) {
					try {
						this.rollback(_activeXid);
					} catch (Exception e1) {
						this.start(startedXid, XAResource.TMNOFLAGS);
						throw e1;
					}
				}
				this.start(startedXid, XAResource.TMNOFLAGS);
				throw e;
			}
		} else if (transactionSize > 0 &&
						numMsgsPerTransactionSegment > 0 &&
						numSuspendedTransactions > 0 &&
						numMsgsRecv > 0 &&
						(numMsgsRecv % numMsgsPerTransactionSegment) == 0) {
			String suspendedXid = _activeXid;
			this.end(suspendedXid, XAResource.TMSUSPEND);
			Iterator<String> it = _xids.iterator();
			String firstXid = "";
			String nextXid = "";
			while (it.hasNext()) {
				String xid = it.next();
				if (firstXid.equals("")) {
					firstXid = xid;
				}
				if (xid.equals(suspendedXid)) {
					if (!it.hasNext()) {
						nextXid = firstXid;
					} else {
						nextXid = it.next();
					}
				 	break;
				}
			}
			this.start(nextXid, XAResource.TMRESUME);
		}

	}
	
	@Override
	public void run() {
		if ((numMsgsRecv == prevNumMsgsRecv) &&
				(numMsgsRecv != numMsgsOnCommit)) {
			try {
				this.runOnDispatcher(wantOnePhase);
			} catch (Exception e) {
				onException(e);
			}
		}
		prevNumMsgsRecv = numMsgsRecv;
	}

	@Override
	public Object getProducer() throws Exception {
		if(_msgProd == null)
			_msgProd = xaSession.createProducer(null);
		return _msgProd;
	}

}
