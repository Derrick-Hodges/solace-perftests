package com.solacesystems.pubsub.sdkperf.core;

public class TransactionResultUnknownException extends PubSubException {

	private static final long serialVersionUID = -7161425489006369822L;
	
	public TransactionResultUnknownException() {
		super();
	}

	public TransactionResultUnknownException(String message, Throwable t) {
		super(message, t);
	}

	public TransactionResultUnknownException(Throwable t) {
		super(t);
	}

	public TransactionResultUnknownException(String message) {
		super(message);
	}
}

