package com.solacesystems.pubsub.sdkperf.jms.core;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;

import javax.jms.BytesMessage;
import javax.jms.TextMessage;
import javax.jms.MapMessage;
import javax.jms.StreamMessage;
import javax.jms.ObjectMessage;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Topic;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.pubsub.sdkperf.core.AbstractWrappedMessage;
import com.solacesystems.pubsub.sdkperf.core.GenericMessageDeliveryMode;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.PublisherDestinationsType;

public class JmsWrappedMessage extends AbstractWrappedMessage {

	protected Message _jmsMsg = null;
	private static final Log Trace = LogFactory.getLog(JmsWrappedMessage.class);

	public JmsWrappedMessage(Message msg) {
		_jmsMsg = msg;
	}

	@Override
	public Message getMessage() {
		return _jmsMsg;
	}

	@Override
	public boolean hasXml() {
		if (_jmsMsg == null)
			return false;
		if (_jmsMsg instanceof TextMessage) {
			return true;
		}
		return false;
	}

	@Override
	public boolean hasAttachment() {
		if (_jmsMsg == null)
			return false;
		if (_jmsMsg instanceof BytesMessage) {
			return true;
		}
		return false;
	}

	@Override
	public boolean hasTopic() {
		// All messages are received on a topic.
		return true;
	}

	@Override
	public boolean hasReplyToDestination() {
		if (_jmsMsg == null) {
			return false;
		}
		Destination dest = null;
		try {
			dest = _jmsMsg.getJMSReplyTo();
		} catch (JMSException e) {
			Trace.warn("Could not get JMS ReplyTo destination.", e);
		}

		if (dest != null) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public byte[] getXmlBytes() {
		if (_jmsMsg == null)
			return null;
		if (_jmsMsg instanceof TextMessage) {
			TextMessage message = (TextMessage) _jmsMsg;
			byte[] dataBytes = null;
			try {
				dataBytes = message.getText().getBytes();
			} catch (JMSException e) {
				Trace.error(e.getMessage(), e);
			}
			return dataBytes;
		} else {
			return null;
		}

	}

	@Override
	public byte[] getAttachmentBytes() {
		if (_jmsMsg == null)
			return null;

		if (_jmsMsg instanceof javax.jms.BytesMessage) {
			javax.jms.BytesMessage message = (javax.jms.BytesMessage) _jmsMsg;
			byte[] attachmentBytes = null;
			try {
				message.reset();
				attachmentBytes = new byte[(int) message.getBodyLength()];
				message.readBytes(attachmentBytes);
			} catch (JMSException e) {
				Trace.error(e.getMessage(), e);
			}
			return attachmentBytes;
		} else {
			return null;
		}
	}

	@Override
	public byte[] getUserdata() {
		// Methods unsupported in JMS so stubbed out.
		return null;
	}

	@Override
	public List<Long> getCids() {
		// Methods unsupported in JMS so stubbed out.
		return null;
	}

	@Override
	public boolean getRedelivered() {
		if (_jmsMsg == null)
			return false;

		try {
			return _jmsMsg.getJMSRedelivered();
		} catch (JMSException e) {
			Trace.error(e.getMessage(), e);
		}
		return false;
	}

	@Override
	public boolean validateStructDataMsg() {
		// Unsupported at this point.
		return false;
	}

	@Override
	public boolean isCacheMessage() {
		// Currently unsupported.
		return false;
	}

	@Override
	public boolean isSuspect() {
		// Currently unsupported.
		return false;
	}

	@Override
	public String dump() {
		if (_jmsMsg == null) {
			Trace.error("Unable to print null message.");
			return null;
		}
		
		StringBuilder sb = new StringBuilder();
		
		String deliveryMode = "";
		try {
			deliveryMode = Integer.toString(_jmsMsg.getJMSDeliveryMode());
			if (_jmsMsg.getJMSDeliveryMode() == DeliveryMode.NON_PERSISTENT) {
				deliveryMode = "NON_PERSISTENT";
			} else if (_jmsMsg.getJMSDeliveryMode() == DeliveryMode.PERSISTENT) {
				deliveryMode = "PERSISTENT";
			}
		} catch (JMSException e) {
			deliveryMode = "Failed to get JMSDeliveryMode - " + e.getMessage();
		}
		
		String ls = System.getProperty("line.separator");
		
		sb.append("JMSDeliveryMode:                        " + deliveryMode + ls);
		try {
			sb.append("JMSDestination:                         " + _jmsMsg.getJMSDestination() + ls);
		} catch (JMSException e) {
			sb.append("JMSDestination:                         Failed to get JMSDestination - " + e.getMessage() + ls);
		}
		try {
			sb.append("JMSExpiration:                          " + _jmsMsg.getJMSExpiration() + ls);
		} catch (JMSException e) {
			sb.append("JMSExpiration:                          Failed to get JMSExpiration - " + e.getMessage() + ls);
		}
		try {
			sb.append("JMSPriority:                            " + _jmsMsg.getJMSPriority() + ls);
		} catch (JMSException e) {
			sb.append("JMSPriority:                            Failed to get JMSPriority - " + e.getMessage() + ls);
		}
		try {
			sb.append("JMSTimestamp:                           " + _jmsMsg.getJMSTimestamp() + ls);
		} catch (JMSException e) {
			sb.append("JMSTimestamp:                           Failed to get JMSTimestamp - " + e.getMessage() + ls);
		}
		try {
			sb.append("JMSRedelivered:                         " + _jmsMsg.getJMSRedelivered() + ls);
		} catch (JMSException e) {
			sb.append("JMSRedelivered:                         Failed to get JMSRedelivered - " + e.getMessage() + ls);
		}		
		try {
			sb.append("JMSCorrelationID:                       " + _jmsMsg.getJMSCorrelationID() + ls);
		} catch (JMSException e) {
			sb.append("JMSCorrelationID:                       Failed to get JMSCorrelationID - " + e.getMessage() + ls);
		}
		try {
			sb.append("JMSMessageID:                           " + _jmsMsg.getJMSMessageID() + ls);
		} catch (JMSException e) {
			sb.append("JMSMessageID:                           Failed to get JMSMessageID - " + e.getMessage() + ls);
		}
		try {
			sb.append("JMSReplyTo:                             " + _jmsMsg.getJMSReplyTo() + ls);
		} catch (JMSException e) {
			sb.append("JMSReplyTo:                             Failed to get JMSReplyTo - " + e.getMessage() + ls);
		}
		try {
			sb.append("JMSType:                                " + _jmsMsg.getJMSType() + ls);
		} catch (JMSException e) {
			sb.append("JMSType:                                Failed to get JMSType - " + e.getMessage() + ls);
		}
		
		sb.append("JMSProperties:                          {");
		try {
			Enumeration<?> jmsPropertyNames = _jmsMsg.getPropertyNames();
			
			while (jmsPropertyNames.hasMoreElements()) {
				Object o = jmsPropertyNames.nextElement();
				sb.append(o.toString());
				sb.append(":"+ _jmsMsg.getObjectProperty(o.toString()).toString() + ";");
			}
		} catch (JMSException e) {
			sb.append("failed to fetch properties - " + e.getMessage());
		}
		sb.append("}" + System.getProperty("line.separator"));
		
		sb.append("Object Type:                            ");
		if (_jmsMsg instanceof BytesMessage) {
			sb.append("BytesMessage ");
		}
		if (_jmsMsg instanceof TextMessage) {
			sb.append("TextMessage ");
		}
		if (_jmsMsg instanceof StreamMessage) {
			sb.append("StreamMessage ");
		}
		if (_jmsMsg instanceof MapMessage) {
			sb.append("MapMessage ");
		}
		if (_jmsMsg instanceof ObjectMessage) {
			sb.append("ObjectMessage ");
		}
		sb.append(ls);
		
		if (_jmsMsg instanceof BytesMessage) {
			try {
				BytesMessage bm = (BytesMessage) _jmsMsg;
				int bodyLen = (int) bm.getBodyLength();
				sb.append("Binary Attachment:                      len=" + bodyLen + ls);
				
				byte[] body = new byte[bodyLen];
				bm.reset();
				System.out.println("Bytes read: " + bm.readBytes(body));
				
				for(int i=0; i<bodyLen; ++i) {
				
					if (i % 16 == 0) {
						sb.append("  ");
					}
					
					sb.append(String.format("%02x", body[i]) + " ");
					
					if (i > 0) {
						if ((i+1) % 16 == 0) {
							try {
								sb.append("    " + new String(Arrays.copyOfRange(body, i - 15, i + 1), "UTF-8") + ls);
							} catch (Exception e) {
								sb.append(ls);
							}
						} else if ((i+1) % 8 == 0) {
							sb.append("   ");
						}
					}
				}
				
				int numCharToPrint = bodyLen % 16;
				if (numCharToPrint > 0) {
					for (int i = 0; i < 16-numCharToPrint; ++i) {
						sb.append("   ");
					}

					if (numCharToPrint <= 8) {
						sb.append("   ");
					}
					
					sb.append("    ");

					try {
						sb.append(new String(Arrays.copyOfRange(body, bodyLen - numCharToPrint, bodyLen), "UTF-8") + ls);
					} catch (Exception e) {
						sb.append(ls);
					}
				}
				
			} catch (JMSException e) {
				sb.append("Failed to print binary attachment - " + e.getMessage() + ls);
			}
		}
		if (_jmsMsg instanceof TextMessage) {
			TextMessage tm = (TextMessage) _jmsMsg;
			int textLength = 0;
			String s = null;
			try {
				textLength = tm.getText().length();
				s = tm.getText();
			} catch (Exception e) {}
			sb.append("Text:                                   len=" + textLength + ls);
			
			if (s != null && s.length() > 0) {
				for (int i = 0; i < textLength; i += 60) {
					try {
					sb.append("  " + s.substring(i, i + Math.min(60, textLength - i)) + ls);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		if (_jmsMsg instanceof StreamMessage) {
			StreamMessage sm = (StreamMessage) _jmsMsg;
			sb.append("  StreamMessage " + sm.toString());
		}
		if (_jmsMsg instanceof MapMessage) {
			MapMessage mm = (MapMessage) _jmsMsg;
			sb.append("  MapMessage " + mm.toString());
		}
		if (_jmsMsg instanceof ObjectMessage) {
			ObjectMessage om = (ObjectMessage) _jmsMsg;
			sb.append("ObjectMessage " + om.toString());
		}
		sb.append(ls);

		return sb.toString();
	}

	@Override
	public byte[] getMessageAsBytes() throws Exception {
		if (_jmsMsg == null) {
			Trace.error("Unable to print null message.");
			return new byte[0];
		}
		byte[] retArray;
		try {
			try {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(baos);
				oos.writeObject(_jmsMsg);
				retArray = baos.toByteArray();
			} catch (Exception e) {
				JMSException jmsEx = new JMSException(e.getMessage(), "serialization error");
				jmsEx.setLinkedException(e);
				throw jmsEx;
			}
		} catch (JMSException e) {
			Trace.warn("Could not get JMS Message as bytes.", e);
			return new byte[0];
		}

		return retArray;
	}

	@Override
	public boolean hasDiscardIndication() {
		// Discard Indication is not a JMS feature
		return false;
	}

	@Override
	public Long getTopicSequence() {
		// Topic Sequence is not a JMS feature
		return null;
	}

	@Override
	public String getDestinationName() {
		if (_jmsMsg == null)
			return null;
		try {
			return getDestName(_jmsMsg.getJMSDestination(), getDestinationType());
		} catch (JMSException e) {
			throw new RuntimeException("Failed to retrieve JMS destination from message.", e);
		}
	}

	@Override
	public PublisherDestinationsType getDestinationType() {
		if (_jmsMsg == null)
			return null;
		Destination dest = null;
		try {
			dest = _jmsMsg.getJMSDestination();
		} catch (JMSException e) {
			throw new RuntimeException("Failed to retrieve JMS destination from message.", e);
		}
		return getDestType(dest);
	}

	@Override
	public String getReplyToDestinationName() {
		if (_jmsMsg == null)
			return null;
		try {
			return getDestName(_jmsMsg.getJMSReplyTo(), getDestinationType());
		} catch (JMSException e) {
			throw new RuntimeException("Failed to retrieve JMS reply-to destination from message.", e);
		}
	}

	@Override
	public PublisherDestinationsType getReplyToDestinationType() {
		if (_jmsMsg == null)
			return null;
		Destination dest = null;
		try {
			dest = _jmsMsg.getJMSReplyTo();
		} catch (JMSException e) {
			throw new RuntimeException("Failed to retrieve JMS reply-to destination from message.", e);
		}
		return getDestType(dest);
	}

	private static PublisherDestinationsType getDestType(Destination d) {
		if (d == null)
			return null;
		if (d instanceof Queue)
			return PublisherDestinationsType.QUEUE;
		else if (d instanceof Topic)
			return PublisherDestinationsType.TOPIC;
		throw new RuntimeException("Could not retrieve type from JMS destination. Destination class: " + d.getClass());
	}

	private static String getDestName(Destination d, PublisherDestinationsType destType) {
		if (destType == null || d == null)
			return null;

		String destName = null;

		if (destType == PublisherDestinationsType.QUEUE) {
			try {
				destName = ((Queue) d).getQueueName();
			} catch (JMSException e) {
				throw new RuntimeException("Failed to retrieve JMS queue name.", e);
			}
		} else if (destType == PublisherDestinationsType.TOPIC) {
			try {
				destName = ((Topic) d).getTopicName();
			} catch (JMSException e) {
				throw new RuntimeException("Failed to retrieve JMS topic name.", e);
			}
		}
		return destName;
	}

	@Override
	public GenericMessageDeliveryMode getDeliveryMode() {
		if (_jmsMsg == null)
			return null;

		int delivMode;
		try {
			delivMode = _jmsMsg.getJMSDeliveryMode();
		} catch (JMSException e) {
			Trace.warn("Failed to retrieve delivery mode from JMS message.", e);
			return null;
		}

		if (delivMode == DeliveryMode.PERSISTENT)
			return GenericMessageDeliveryMode.PERSISTENT;
		else if (delivMode == DeliveryMode.NON_PERSISTENT)
			return GenericMessageDeliveryMode.NON_PERSISTENT;

		return null;
	}

}
