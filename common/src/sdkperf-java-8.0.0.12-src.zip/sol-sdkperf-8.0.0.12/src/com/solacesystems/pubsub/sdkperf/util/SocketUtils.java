package com.solacesystems.pubsub.sdkperf.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericAuthenticationScheme;

public class SocketUtils {

	private SocketUtils() {}

	public static SSLContext configSSLSocket(RuntimeProperties props,
			boolean wantSSL) throws NoSuchAlgorithmException,
			KeyStoreException, KeyManagementException, CertificateException,
			IOException, UnrecoverableKeyException {

		SSLContext scb = SSLContext.getInstance("TLS");

		if (props.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME).equals(
				GenericAuthenticationScheme.CLIENT_CERTIFICATE)) {

			boolean passKey = false;
			boolean isProvided = false;
			String keyStorePass = props.getStringProperty(RuntimeProperties.SSL_KEY_STORE_PASSWORD);
			String privKeyPass = props.getStringProperty(RuntimeProperties.SSL_PRIVATE_KEY_PASSWORD);
			String trustStorePass = props.getStringProperty(RuntimeProperties.SSL_TRUST_STORE_PASSWORD);
			String sslKeyStore = props.getStringProperty(RuntimeProperties.SSL_KEY_STORE);
					
			TrustManagerFactory tmf = null;
			KeyManagerFactory kmf = null;

			if (sslKeyStore != null && !sslKeyStore.equals("")) {

				KeyStore keys = KeyStore.getInstance(KeyStore.getDefaultType());
				FileInputStream instream = new FileInputStream(new File(sslKeyStore));
				kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());

				try {
					if (keyStorePass != null && !keyStorePass.equals("")) {
						keys.load(instream, keyStorePass.toCharArray());
						isProvided = true;
						passKey = true;
					} else {
						// from java doc keystore pass and truststore
						// pass cannot be both null, since if one of
						// them is null, java will try to use the other
						// one.
						if (trustStorePass != null && trustStorePass.length() > 0) {
							keys.load(instream, trustStorePass.toCharArray());
							isProvided = true;
						} else {
							throw new IllegalArgumentException(
									"KeyStore password and TrustStore password cannot be both null/empty");
						}
					}

					kmf.init(keys, privKeyPass.toCharArray());
				} finally {
					instream.close();
				}

			}

			if (props.getStringProperty(RuntimeProperties.SSL_TRUST_STORE) != null
					&& props.getStringProperty(RuntimeProperties.SSL_TRUST_STORE).length() > 0) {

				tmf = TrustManagerFactory.getInstance(TrustManagerFactory
						.getDefaultAlgorithm());
				KeyStore trustStore = KeyStore.getInstance(KeyStore
						.getDefaultType());
				FileInputStream instream2 = new FileInputStream(
						new File(
								props.getStringProperty(RuntimeProperties.SSL_TRUST_STORE)));

				try {
					if (trustStorePass != null && trustStorePass.length() > 0) {
						isProvided = true;
						trustStore
								.load(instream2, trustStorePass.toCharArray());
					} else if (passKey) {
						isProvided = true;
						trustStore.load(instream2, keyStorePass.toCharArray());

					} else {
						throw new IllegalArgumentException(
								"KeyStore password and TrustStore password cannot be both null/empty");
					}

					tmf = TrustManagerFactory.getInstance(TrustManagerFactory
							.getDefaultAlgorithm());
					tmf.init(trustStore);

				} finally {
					instream2.close();
				}
			}

			if (isProvided == true) {
				scb.init((kmf != null ? kmf.getKeyManagers() : null),
						(tmf != null ? tmf.getTrustManagers() : null), null);
			} else {
				throw new IllegalArgumentException(
						"Both keyStore and trustStore are not provided correctly, cannot set up SSL connection");

			}

		} else {

			X509TrustManager tm = new X509TrustManager() {

				public void checkClientTrusted(X509Certificate[] arg0,
						String arg1) throws CertificateException {
				}

				public void checkServerTrusted(X509Certificate[] arg0,
						String arg1) throws CertificateException {
				}

				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}

			};

			scb.init(null, new TrustManager[] { tm }, null);

		}

		return scb;

	}

}
