/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.config;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Pattern;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.pubsub.sdkperf.core.Constants.EndpointAccessType;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericAuthenticationScheme;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericServerConnectionType;
import com.solacesystems.pubsub.sdkperf.core.Constants.ReconnectFailAction;
import com.solacesystems.pubsub.sdkperf.core.PubSubException;
import com.solacesystems.pubsub.sdkperf.core.Constants.InternalApiMode;
import com.solacesystems.pubsub.sdkperf.core.Constants.ToolMode;
import com.solacesystems.pubsub.sdkperf.util.Helpers;
import com.solacesystems.pubsub.sdkperf.core.GenericMessageDeliveryMode;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.ClientModeType;

/**
 * All cli options for sdkperf
 * 
 */
public final class CliPropertiesParser {

	private static final Log Trace = LogFactory.getLog(CliPropertiesParser.class);

	private CliPropertiesParser() {}
	
	private static Options _opts;
	static {
		init();
	}
	
	private static void addOption(Options opts, String optionName, String argName) {
		
		if(argName != null && argName.length() > 0) {
			OptionBuilder.withArgName(argName);
			OptionBuilder.hasArg();
		}
		opts.addOption(OptionBuilder.create(optionName));
	}
	
	private static void init() {
		_opts = new Options();
		
		addOption(_opts, "cpc", null);
		addOption(_opts, "cnl", null);
		addOption(_opts, "cc", "num");
		addOption(_opts, "cpt", "num");
		addOption(_opts, "cptt", "num");
		addOption(_opts, "ca", null);
		addOption(_opts, "cat", null);
		addOption(_opts, "caf", null);
		addOption(_opts, "cafr", null);
		addOption(_opts, "car", "int");
		addOption(_opts, "ptc", "int");
		addOption(_opts, "stc", "int");
		addOption(_opts, "cask", "int");
		addOption(_opts, "ped", "secs");
		addOption(_opts, "mr", "rate");
		addOption(_opts, "mrt", "string");
		addOption(_opts, "mn", "num");
		addOption(_opts, "msx", "list");
		addOption(_opts, "msa", "list");
		addOption(_opts, "msxs", "val");
		addOption(_opts, "msas", "val");
		addOption(_opts, "mdq", null);
		addOption(_opts, "mtl", "millis");
		addOption(_opts, "mee", null);
		addOption(_opts, "md", null);
		addOption(_opts, "mdd", "dir");
		addOption(_opts, "cm", "sink/reflect/reply");
		addOption(_opts, "prt", null);
		addOption(_opts, "prq", null);
		addOption(_opts, "prp", "string");
		addOption(_opts, "prs", "string");
		addOption(_opts, "cip", "ip:port");
		addOption(_opts, "ptp", "string");
		addOption(_opts, "stp", "string");
		addOption(_opts, "cu", "user[@vpn]");
		addOption(_opts, "cn", "name");
		addOption(_opts, "cp", "pass");
		addOption(_opts, "cdp", "L[:N]");
		addOption(_opts, "ccn", null);
		addOption(_opts, "tnd", null);
		addOption(_opts, "nagle", null);
		addOption(_opts, "pfl", "file");
		addOption(_opts, "pal", "file");
		addOption(_opts, "psl", "file");
		addOption(_opts, "mt", "type");
		addOption(_opts, "ptl", "dest-list");
		addOption(_opts, "rsrco", "dest-list");
		addOption(_opts, "ripl", "dest-list");
		addOption(_opts, "pql", "dest-list");
		addOption(_opts, "ptf", "files");
		addOption(_opts, "pqf", "files");
		addOption(_opts, "psv", "int");
		addOption(_opts, "nsr", null);
		addOption(_opts, "nsm", null);
		addOption(_opts, "caq", "int");
		addOption(_opts, "qb", null);
		addOption(_opts, "qbd", "F[,B]");
		addOption(_opts, "sd", "ms");
		addOption(_opts, "sdc", "int");
		addOption(_opts, "sri", "ms");
		addOption(_opts, "tps", null);
		addOption(_opts, "srs", null);
		addOption(_opts, "pedn", "string");
		addOption(_opts, "apw", "ws");
		addOption(_opts, "apa", "ms");
		addOption(_opts, "amr", "maxr");
		addOption(_opts, "ats", "int");
		addOption(_opts, "atxa", null);
		addOption(_opts, "atop", null);
		addOption(_opts, "atts", "int");
		addOption(_opts, "atst", "int");
		addOption(_opts, "atpc", null);
		addOption(_opts, "atxatt", "int");
		addOption(_opts, "atdbs", "int");
		addOption(_opts, "atdbe", "int");
		addOption(_opts, "atdbp", "int");
		addOption(_opts, "atdbc", "int");
		addOption(_opts, "afi", null);
		addOption(_opts, "aii", "int");
		addOption(_opts, "aem", "int");
		addOption(_opts, "atr", null);
		addOption(_opts, "atri", "int");
		addOption(_opts, "att", "int");
		addOption(_opts, "asw", "ws");
		addOption(_opts, "asa", "ms");
		addOption(_opts, "snq", "snqsz");
		addOption(_opts, "awt", "perc");
		addOption(_opts, "cid", null);
		addOption(_opts, "di", null);
		addOption(_opts, "ka", "int");
		addOption(_opts, "z", "int");
		addOption(_opts, "cos", "int");
		addOption(_opts, "pto", null);
		addOption(_opts, "pso", "int");
		addOption(_opts, "poo", "int");
		addOption(_opts, "d", null);
		addOption(_opts, "q", null);
		addOption(_opts, "v", null);
		addOption(_opts, "mec", null);
		addOption(_opts, "cor", null);
		addOption(_opts, "crr", null);

        // REST Server SSL Parameters
		addOption(_opts, "rssslks", "string");
		addOption(_opts, "rssslts", "string");
		addOption(_opts, "rssslksp", "string");
		addOption(_opts, "rsssltsp", "string");
		addOption(_opts, "rssslpkp", "string");
		
        // SSL Parameters
		addOption(_opts, "sslp", "string");
		addOption(_opts, "sslcd", "string");
		addOption(_opts, "sslep", "string");
		addOption(_opts, "sslvc", null);
		addOption(_opts, "sslvcd", null);
		addOption(_opts, "sslcs", "string");
		addOption(_opts, "sslts", "string");
		addOption(_opts, "ssltsd", "string");
		addOption(_opts, "ssltsp", "string");
		addOption(_opts, "ssltsf", "string");
		addOption(_opts, "sslks", "string");
		addOption(_opts, "sslksp", "string");
		addOption(_opts, "sslksf", "string");
		addOption(_opts, "sslpka", "string");
		addOption(_opts, "sslcf", "string");
		addOption(_opts, "sslpk", "string");
		addOption(_opts, "sslpkp", "string");
		
		addOption(_opts, "ctp", "string");
		addOption(_opts, "cwtpl", "string");
		addOption(_opts, "ctpdt", "string");
		addOption(_opts, "as", "string");
		addOption(_opts, "api", "api");
		addOption(_opts, "rcm", "string");
		addOption(_opts, "rte", "rte");
		addOption(_opts, "ecc", "string");
        
		
		// MQTT specific arguments
		
		// Deprecated argument, replaced by mpq and msq
		addOption(_opts, "mqttqos", "int");
		addOption(_opts, "mpq", "int");
		addOption(_opts, "msq", "int");
		// Deprecated, replaced by -mcs
		addOption(_opts, "mqttClean", "bool");
		addOption(_opts, "mcs", "bool");
		// Deprecated argument, replaced by -mwmt
		addOption(_opts, "willMsgTopic", "string");
		addOption(_opts, "mwmt", "string");
		// Deprecated, replaced by -mwmq
		addOption(_opts, "willMsgQos", "int");
		addOption(_opts, "mwmq", "int");
		// Deprecated, replaced by -mwmr
		addOption(_opts, "willMsgRetained", null);
		addOption(_opts, "mwmr", null);
		// Deprecated, replaced by -mwms
		addOption(_opts, "willMsgSize", "int");
		addOption(_opts, "mwms", "int");
		
		//JMS Specific Parameters
		addOption(_opts, "jod", null);
		addOption(_opts, "jcf", "string");
		// Subscriber destination lists...
		addOption(_opts, "sxl", "destlist");
		addOption(_opts, "sxf", "files");
		addOption(_opts, "stl", "destlist");
		addOption(_opts, "stf", "file");
		addOption(_opts, "sdl", "destlist");
		addOption(_opts, "sdf", "files");
		addOption(_opts, "sql", "destlist");
		addOption(_opts, "sqf", "files");
		addOption(_opts, "tte", "int");
		addOption(_opts, "tqe", "int");
		
		// Cache Params (-ch...)
		addOption(_opts, "chpn", "string");
		addOption(_opts, "chpm", "int");
		addOption(_opts, "chpa", "int");
		addOption(_opts, "chpt", "int");
		addOption(_opts, "chrs", null);
		addOption(_opts, "chrr", "double");
		addOption(_opts, "chrn", "int");
		addOption(_opts, "chrt", "min:max");
		addOption(_opts, "chld", "string");
		
		// Latency params
		addOption(_opts, "l", null);
		addOption(_opts, "lat", null);
		addOption(_opts, "lb", "num");
		addOption(_opts, "lg", "num");
		addOption(_opts, "lwu", "num");

		addOption(_opts, "rc", "int");
		addOption(_opts, "rfa", "string");		
		addOption(_opts, "brt", "int");
		addOption(_opts, "oc", null);
		addOption(_opts, "ldd", null);
		addOption(_opts, "om", null);
		addOption(_opts, "crc", null);
		addOption(_opts, "psm", null);
		addOption(_opts, "psm2", null);
		addOption(_opts, "sdm", null);
		addOption(_opts, "jndi", null);
		addOption(_opts, "epl", "string");
		addOption(_opts, "cjpl", "string");
		addOption(_opts, "cpl", "string");
		addOption(_opts, "bd", "bd");
		addOption(_opts, "ibd", "ibd");
		addOption(_opts, "pe", null);
		addOption(_opts, "pep", "char");
		addOption(_opts, "pea", "int");
		addOption(_opts, "peq", "int");
		addOption(_opts, "pem", "int");
		addOption(_opts, "per", null);
		addOption(_opts, "pemr", "int");
		addOption(_opts, "scn", "string");
		addOption(_opts, "fct", null); // cut-through
		addOption(_opts, "ssl", "selector-list");
		addOption(_opts, "ssf", "files");
		addOption(_opts, "soe", null);
		addOption(_opts, "upt", null);
		addOption(_opts, "tm", "string");
		addOption(_opts, "ud", null);
		addOption(_opts, "csr", null);
		addOption(_opts, "spl", "string");
		addOption(_opts, "mrdl", "string");
		addOption(_opts, "rrwt", "int");
		addOption(_opts, "q", null);
		addOption(_opts, "h", null);
		addOption(_opts, "hm", null);
		addOption(_opts, "he", null);
		addOption(_opts, "eep", "string");
		addOption(_opts, "istx", null);
		addOption(_opts, "nmp", "int");
		
		// Publish on receive feature
		addOption(_opts, "nmpr", "int");
		addOption(_opts, "portl", "list");
		addOption(_opts, "porql", "list");
		addOption(_opts, "pormt", "string");
		addOption(_opts, "pormsa", "list");
		addOption(_opts, "porrm", null);
		
		addOption(_opts, "sfc", null);
	}

	public static RuntimeProperties parseCli(String[] args, PrintStream errorStr) {
		
		/* convert any params with '=' to spaces */
		ArrayList<String> newArgs = new ArrayList<String>();
		newArgs.clear();
		
		for (String arg : args) {
			// Only split if param matches the "-param=value" regexp.
			if (Pattern.matches("-[\\w]+=.*", arg)) {
				String[] tokens = arg.split("=", 2);
				for (String token : tokens) {
					newArgs.add(token);
				}
			} else {
				newArgs.add(arg);
			}
		}

		args = new String[newArgs.size()]; 
		newArgs.toArray(args);
        	
		CommandLineParser parser = new GnuParser();
		RuntimeProperties props = null;
		try {
			CommandLine line = parser.parse(_opts, args);
			
			// If the user accidentally supplied unrecognized options, we want to
			// fail immediately and inform the user about it.
			if (line.getArgs().length > 0 ) {
				String exceptionMsg = "Extra unrecognized options present : ";
				for (String leftover : line.getArgs() ) {
					exceptionMsg += "    " + leftover;			
				}
				throw new ParseException(exceptionMsg);
			}
			
			RuntimePropertiesBuilder pb = new RuntimePropertiesBuilder();
			
			// First load the default options.
			loadDefaultOptions(pb);
			
			// Do this first so it's set for other options to use.
			if (line.hasOption("cip")) {
				
				if(line.hasOption("cc")){
					pb.setNumClients(intval(line, "cc"));
				}else if(!line.hasOption("cc")){
					pb.setNumClients(1);
				}
				pb.setClientHost(line.getOptionValue("cip"));
			}else if(line.hasOption("cc")){
				throw new IllegalArgumentException("-cc argument can be used if only -cip argument is set up.");
			}
			

			if(line.hasOption("mec")){
				pb.setWantMessageContentExamined(true);
			}
			
			if(line.hasOption("api")){
				if(line.getOptionValue("api").equalsIgnoreCase("rest") ){
				
					if ((line.hasOption("cu") && line.hasOption("cp"))) {
						pb.setAuthenticationScheme("basic");
					}
					if (line.hasOption("msa") && line.hasOption("msx")) {
						throw new IllegalArgumentException("-msx & -msa cannot be used simultaneously when using REST API.");
					}
				}
				
				pb.setToolApi(line.getOptionValue("api"));
			}
			
			if (line.hasOption("rcm")) {
				if (line.hasOption("api") && line.getOptionValue("api").equalsIgnoreCase("REST")) {
					pb.setRestMode(line.getOptionValue("rcm"));
				} else {
					throw new ParseException("-rcm argument is supported only by the REST API.");
				}
			}
			
			if(line.hasOption("rte")){
				if(line.hasOption("api") && line.getOptionValue("api").equalsIgnoreCase("REST")){
					pb.setTransferEncoding(line.getOptionValue("rte"));
				}else{
					throw new ParseException("-rte argument is supported only by the REST API.");
				}	
			}
			
			String mqttWillMsgTopic = null;
			
			// Deprecated, use mwmt instead
			if (line.hasOption("willMsgTopic")) {
				if (!line.hasOption("api") || !line.getOptionValue("api").equalsIgnoreCase("mqtt"))
					throw new IllegalArgumentException("Argument -willMsgTopic is only supported in sdkperf_mqtt.");

				mqttWillMsgTopic = line.getOptionValue("willMsgTopic");
				pb.setMQTTWillMsgTopic(mqttWillMsgTopic);
			}
			// MQTT Will Message Topic
			if (line.hasOption("mwmt")) {
				if (line.hasOption("willMsgTopic"))
					throw new IllegalArgumentException("Can only set one of -mwmt and -willMsgTopic");
				if (!line.hasOption("api") || !line.getOptionValue("api").equalsIgnoreCase("mqtt"))
					throw new IllegalArgumentException("Argument -mwmt is only supported in sdkperf_mqtt.");

				mqttWillMsgTopic = line.getOptionValue("mwmt");
				pb.setMQTTWillMsgTopic(mqttWillMsgTopic);
			}
			
			if (line.hasOption("willMsgSize")) {
				if (!line.hasOption("api") || !line.getOptionValue("api").equalsIgnoreCase("mqtt"))
					throw new IllegalArgumentException("Argument -willMsgSize is only supported in sdkperf_mqtt.");
				if (mqttWillMsgTopic == null)
					throw new IllegalArgumentException("Argument -mwmt is required when using argument '-willMsgSize'.");

				pb.setMQTTWillMsgSize(Integer.parseInt(line.getOptionValue("willMsgSize")));
			}
			// MQTT Will Message Size
			if (line.hasOption("mwms")) {
				if (line.hasOption("willMsgSize"))
					throw new IllegalArgumentException("Can only set one of -mwms and -willMsgSize");
				if (!line.hasOption("api") || !line.getOptionValue("api").equalsIgnoreCase("mqtt"))
					throw new IllegalArgumentException("Argument -mwms is only supported in sdkperf_mqtt.");
				if (mqttWillMsgTopic == null)
					throw new IllegalArgumentException("Argument -mwmt is required when using argument -mwms");

				pb.setMQTTWillMsgSize(Integer.parseInt(line.getOptionValue("mwms")));
			}
			
			if(line.hasOption("willMsgQos")){
				if(!line.hasOption("api") || !line.getOptionValue("api").equalsIgnoreCase("mqtt"))
					throw new IllegalArgumentException("Argument -willMsgQos is only supported in sdkperf_mqtt.");
				if(mqttWillMsgTopic == null)
					throw new IllegalArgumentException("Argument -mwmt is required when using argument '-willMsgQos'.");
				
				pb.setMQTTWillMsgQos(Integer.parseInt(line.getOptionValue("willMsgQos")));
			}
			// MQTT Will Message QoS
			if(line.hasOption("mwmq")){
				if (line.hasOption("willMsgQos"))
					throw new IllegalArgumentException("Can only set one of -mwmq and -willMsgQos");
				if(!line.hasOption("api") || !line.getOptionValue("api").equalsIgnoreCase("mqtt"))
					throw new IllegalArgumentException("Argument -willMsgQos is only supported in sdkperf_mqtt.");
				if(mqttWillMsgTopic == null)
					throw new IllegalArgumentException("Argument -mwmt is required when using argument '-mwmq'.");
				
				pb.setMQTTWillMsgQos(Integer.parseInt(line.getOptionValue("mwmq")));
			}
			
			// MQTT Will Message Retain
			if (line.hasOption("willMsgRetained") || line.hasOption("mwmr")) {
				if (!line.hasOption("api") || !line.getOptionValue("api").equalsIgnoreCase("mqtt"))
					throw new IllegalArgumentException("Setting MQTT Will Message Retain flag is only supported in sdkperf_mqtt.");
				if (mqttWillMsgTopic == null)
					throw new IllegalArgumentException("Setting MQTT Will Message Topic (-mwmt) is required when setting MQTT Will Message Retain flag.");

				pb.setMQTTWillMsgRetained(true);
			}
			
			if(line.hasOption("mqttClean")) {
				if(!line.hasOption("api") || (line.hasOption("api") && !line.getOptionValue("api").equalsIgnoreCase("mqtt")))
					throw new IllegalArgumentException("Argument -mqttClean can only be used when the API mode is set to MQTT.");
				if(line.getOptionValue("mqttClean").equals("1") || line.getOptionValue("mqttClean").equalsIgnoreCase("true")) {
					pb.setMqttWantCleanConnect(true);
				} else if(line.getOptionValue("mqttClean").equals("0")|| line.getOptionValue("mqttClean").equalsIgnoreCase("false")) {
					pb.setMqttWantCleanConnect(false);
				} else {
					throw new IllegalArgumentException("Invalid value '"+line.getOptionValue("mqttClean")+"' provided for -mqttClean argument. Accepted values are: 0 (false), 1 (true)");
				}
			}
			// MQTT Clean Session flag
			if(line.hasOption("mcs")) {
				if (line.hasOption("mqttClean"))
					throw new IllegalArgumentException("Can only set one of -mcs and -mqttClean, please use only -mcs");
				if(!line.hasOption("api") || (line.hasOption("api") && !line.getOptionValue("api").equalsIgnoreCase("mqtt")))
					throw new IllegalArgumentException("Argument -mcs can only be used when the API mode is set to MQTT.");
				
				if(line.getOptionValue("mcs").equals("1") || line.getOptionValue("mcs").equalsIgnoreCase("true")) {
					pb.setMqttWantCleanConnect(true);
				} else if(line.getOptionValue("mcs").equals("0")|| line.getOptionValue("mcs").equalsIgnoreCase("false")) {
					pb.setMqttWantCleanConnect(false);
				} else {
					throw new IllegalArgumentException("Invalid value '"+line.getOptionValue("mcs")+"' provided for -mcs argument. Accepted values are: 0 (false), 1 (true)");
				}
			}
			
			
			if(line.hasOption("mqttqos")){
			    throw new IllegalArgumentException("Argument -mqttqos has been deprecated, please use -mpq (MQTT Publisher QoS) or -msq (MQTT Subscription QoS) instead.");	
			}
			
			if(line.hasOption("mpq")){
				
				if (line.hasOption("api") && line.getOptionValue("api").equalsIgnoreCase("mqtt")) {

					int qos;
					try {
						qos = intval(line, "mpq");
					} catch (Exception e) {
						throw new IllegalArgumentException(
								"Invalid value provided for the -mpq argument, valid values are: 0, 1 or 2.");
					}

					pb.setMqttPublishQos(qos);
				}
				else {
					throw new IllegalArgumentException("Argument -mpq should only be used when the API mode has been set to MQTT.");
				}
			}
			
			if(line.hasOption("msq")){
				
				if (line.hasOption("api") && line.getOptionValue("api").equalsIgnoreCase("mqtt")) {
					
					int qos;
					try {
						qos = intval(line, "msq");
					} catch (Exception e) {
						throw new IllegalArgumentException(
								"Invalid value provided for the -msq argument, valid values are: 0, 1 or 2.");
					}

					pb.setMqttSubscribeQos(qos);

				}
				else {
					throw new IllegalArgumentException("Argument -msq should only be used when the API mode has been set to MQTT.");
				}
			}
			
			if(line.hasOption("ecc")){
				pb.setToolExternalClientClassString(line.getOptionValue("ecc"));
			}
			
			if(line.hasOption("stp")){
				if(line.hasOption("stl"))
					throw new IllegalArgumentException("Arguments -stl and -stp cannot be used at the same time");
				if(!line.hasOption("stc")){
					
				}else if(longval(line, "stc")==0){
					throw new IllegalArgumentException("-stc must be greater than 0");
				}
				
				pb.setSubscriberTopicPrefixedList(line.getOptionValue("stp"),longval(line,"stc"));
				
				
			}
		
			
			if(line.hasOption("ptp") || line.hasOption("ptc")){
				if(line.hasOption("ptl") ){
					throw new IllegalArgumentException("Cannot use -ptp and -ptl at the same time.");
				}
				if(line.getOptionValue("ptp")==null || line.getOptionValue("ptp")==""){
					throw new IllegalArgumentException("-ptp must be not null and must be different from \"\"");
				}
				if(!line.hasOption("ptc")){
					throw new IllegalArgumentException("Argument -ptp must be used with -ptc");
				}else if(longval(line, "ptc")==0){
					throw new IllegalArgumentException("-ptc value must be greater than 0");
				}
				pb.setPublisherTopicPrefixedList(line.getOptionValue("ptp"),longval(line, "ptc"));
			}
			
			if(line.hasOption("jcf")){
				pb.setJMSCF(line.getOptionValue("jcf"));
			}
						
			if (line.hasOption("ctp")) {
				pb.setClientTransportProtocol(line.getOptionValue("ctp"));
			}
			
			if (line.hasOption("sfc")) {
				pb.setSkipFinalCommit(true);
			}
			
			if (line.hasOption("cwtpl")) {
				pb.setWebTransportProtocolList(line.getOptionValue("cwtpl"));
			}
			
			if (line.hasOption("ctpdt")) {
				pb.setClientTransportProtocolDowngradeTimeout(line.getOptionValue("ctpdt"));
			}
			
			if (line.hasOption("cpc")) {
				pb.setWantContextPerClient(true);
			}
			
			
			if (line.hasOption("cnl")) {
				pb.setWantNoLocal(true);
			}

			// Both are mutually exclusive
			if (line.hasOption("cpt") && line.hasOption("cptt")) {
				throw new IllegalArgumentException("Cannot set -cpt and -cptt flags simultaneously, they are mutually exclusive.");
			}
			
			if (line.hasOption("cpt")) {
				pb.setNumPubsPerSession(intval(line, "cpt"));
			}
			
			if (line.hasOption("cptt")) {
				pb.setNumPubThreads(intval(line, "cptt"));
			}
			
			if (line.hasOption("ca")) {
				pb.setWantClientAck(true);
			}
			
			if (line.hasOption("cat")) {
				pb.setWantClientAck(true);
				pb.setWantClientAckThread(true);
			}
			
			if (line.hasOption("caf")) {
				pb.setWantClientAck(true);
				pb.setClientAckFlushQueue(true);
			}
			
			if (line.hasOption("cafr")) {
				pb.setWantClientAck(true);
				pb.setClientAckQueueReverse(true);
			}

			if (line.hasOption("car")) {
				pb.setWantClientAck(true);
				pb.setClientAckRandomDepth(intval(line, "car"));
			}
			
			if (line.hasOption("cask")) {
				pb.setWantClientAck(true);
				pb.setClientAckSkipNum(intval(line, "cask"));
			}

			if (line.hasOption("ped")) {
				pb.setPubEndDelay(intval(line, "ped"));
			}

			if (line.hasOption("mr")) {
				pb.setRatePerPub(doubleval(line, "mr"));
			}
			
			if (line.hasOption("mrt")) {
				String mrtValue = line.getOptionValue("mrt");
				if (mrtValue.equalsIgnoreCase("avg"))
					pb.setMsgRateIsMax(false);
				else if (mrtValue.equalsIgnoreCase("max"))
					pb.setMsgRateIsMax(true);
				else
					throw new ParseException("ERROR: Invalid message rate target: " + mrtValue + ". See help for valid values.");
			}
			
			if (line.hasOption("mn")) {
				try {
					pb.setNumMsgsToPublish(longval(line, "mn"));
				} catch (NumberFormatException e) {
					throw new IllegalArgumentException("Could not parse -mn parameter. Value '"+line.getOptionValue("mn")+"' is not a valid number.", e);
				}
			}

			if (line.hasOption("msx")) {
				List<Integer> sizes = RuntimePropertiesBuilder.tokenizeIntegers(line.getOptionValue("msx"), ",");
				pb.setXmlPayloadSize(sizes);
			}
			
			if (line.hasOption("msa")) {
				List<Integer> sizes = RuntimePropertiesBuilder.tokenizeIntegers(line.getOptionValue("msa"), ",");
				pb.setAttachmentSize(sizes);
			}
			
			if (line.hasOption("msxs")) {
				try {
					pb.setXmlPayloadSweep(line.getOptionValue("msxs"));
				} catch (PubSubException e) {
					throw new ParseException(e.getMessage());
				}
			}
			
			if (line.hasOption("msas")) {
				try {
					pb.setAttachmentSweep(line.getOptionValue("msas"));
				} catch (PubSubException e) {
					throw new ParseException(e.getMessage());
				}
			}
			
			if (line.hasOption("mdq")) {
				pb.setMsgDMQEligible(true);
			}
			
			if (line.hasOption("mtl")) {
				pb.setMsgTTL(longval(line, "mtl"));
			}
			
			if (line.hasOption("mee")) {
				pb.setElidingEligible(true);
			}
			
			if (line.hasOption("md")) {
				pb.setWantMsgDump(true);
			}
			
			if (line.hasOption("mdd")) {
				pb.setWantMsgDump(true);
				pb.setMsgDumpDirectory(line.getOptionValue("mdd"));
			}
			
			if (line.hasOption("cm")) {
				
				String value = line.getOptionValue("cm");
				
				if(value.equals("sink") || value.equals("reply")){
					pb.setWantMsgReflect(false);
					pb.setClientMode(value);
				}else if(value.equals("reflect")){
					throw new ParseException("Client Mode 'reflect' is not supported yet.");
				}else{
					throw new ParseException("Error parsing client mode argument. Should be one of : 'sink', 'reflect', 'reply' but it was '" + value + "'.");

				}

			}
			
			
			// Reply-to topic/queue validation:
			// Can use at most one of: prt, prq, prp, prs
			int totalReplyToParameters = 0;
			if(line.hasOption("prt"))
				totalReplyToParameters++;
			if(line.hasOption("prq"))
				totalReplyToParameters++;
			if(line.hasOption("prp"))
				totalReplyToParameters++;
			if(line.hasOption("prs"))
				totalReplyToParameters++;
			
			if(totalReplyToParameters>1) {
				throw new IllegalArgumentException("Can use at most one of the following parameters simultaneously: prt, prq, prp, prs.");
			}
			
			
			if (line.hasOption("prt")) {
				if(line.hasOption("api") && line.getOptionValue("api").equalsIgnoreCase("JMS")){
					throw new IllegalArgumentException("-prt parameter is not supported when using the JMS API. The -prt parameter can be simulated by using a combination of the -stl and -prs parameters.");
				}	
				
				pb.setWantReplyTopic(true);
			}
			
			if (line.hasOption("prq")) {
				
				if(line.hasOption("api") && !(line.getOptionValue("api").equalsIgnoreCase("JMS") || line.getOptionValue("api").equalsIgnoreCase("JNI"))){
					throw new IllegalArgumentException("The -prq parameter is currently only supported when using the JMS client.");
				}
				
				pb.setWantReplyTemporaryQueue(true);
			}

			if (line.hasOption("prp")) {
				pb.setReplyToPostfix(line.getOptionValue("prp"));
				// it also implies that we want -prt
				pb.setWantReplyTopic(true);
			}

			if (line.hasOption("prs")) {
				pb.setReplyToString(line.getOptionValue("prs"));
				// it also implies that we want -prt
				pb.setWantReplyTopic(true);
			}
			
			
			
			if (line.hasOption("cu")) {
				UserVpnDef parsedUserVpn = getParsedUserVpn(line.getOptionValue("cu"));
				pb.setClientUsername(parsedUserVpn.user);
				pb.setClientVpn(parsedUserVpn.vpn);
			}
			
			if (line.hasOption("cn")) {
				pb.setClientNamePrefix(line.getOptionValue("cn"));
			}
			
			if (line.hasOption("cp")) {
				pb.setClientPassword(line.getOptionValue("cp"));
			}
			
			if (line.hasOption("cdp")) {
				
				StringTokenizer tok = new StringTokenizer(line.getOptionValue("cdp"), ":");
			
				String localStr = "", networkStr = "";
				localStr = tok.nextToken();
				try {
					Integer iLocal = Integer.parseInt(localStr);
					pb.setClientDtoLocalPri(iLocal);
				} catch (NumberFormatException nfe) {
					throw new ParseException("Error parsing dto priority format.");
				}
				
				if (tok.hasMoreTokens()) 
				{
					networkStr = tok.nextToken();
					try {
						Integer iNetwork = Integer.parseInt(networkStr);
						pb.setClientDtoNetworkPri(iNetwork);
					} catch (NumberFormatException nfe) {
						throw new ParseException("Error parsing dto priority format.");
					}
				}
			}
			
			if (line.hasOption("ccn")) {
				pb.setChangeClientNameFlag(true);
			}
			
			if (line.hasOption("tnd")) {
				pb.setWantTcpNoDelay(false); //DO NOT set the nodelay option
			}
			
			if (line.hasOption("nagle")) {
				pb.setWantTcpNoDelay(false); //DO NOT set the nodelay option
			}
			
			if (line.hasOption("pfl")) {
				pb.setXmlDocs(line.getOptionValue("pfl"));
			}
			
			if (line.hasOption("pal")) {
				pb.setAttachmentDocs(line.getOptionValue("pal"));
			}
			
			if (line.hasOption("psl")) {
				pb.setSmfBinaryFiles(line.getOptionValue("psl"));
			}
						
			if(line.hasOption("mt")){
				if(line.hasOption("api") && line.getOptionValue("api").equalsIgnoreCase("mqtt")){
					throw new IllegalArgumentException("The -mt argument is not supported (and cannot be used) when the -api parameter is specified as \"mqtt\". Please use the -mpq parameter instead to change the Quality of Service.");
				}
				pb.setMessageType(line.getOptionValue("mt"));
			}
			
			if (line.hasOption("ptl")) {
				if(!line.hasOption("cip"))
					throw new IllegalArgumentException("Cannot publish to topic '"+line.getOptionValue("ptl")+"'; Reason: Missing -cip argument.");
				pb.setPublisherTopicLists(line.getOptionValue("ptl"));
			}
			
			if (line.hasOption("nmp")) {
				
				try {
				    int value = Integer.parseInt(line.getOptionValue("nmp"));
				    pb.setNumMessageProducer(value);
				} catch (NumberFormatException e) {
					throw new IllegalArgumentException(
							"Invalid value '" + line.getOptionValue("nmp") + "' provided for -nmp argument; must provide a valid integer.");
				}
			}
			
			
			if(line.hasOption("rsrco")){
				if(line.hasOption("api") && line.getOptionValue("api").equalsIgnoreCase("rest")){
					pb.setRestServerResponseLogic(line.getOptionValue("rsrco"));
				}else{
					throw new IllegalArgumentException("-rsrco argument can be used only with REST API");
				}
				
			}
			
			if (line.hasOption("ripl")) {
				if(!line.getOptionValue("api").equalsIgnoreCase("rest"))
					throw new IllegalArgumentException("-ripl argument can be used only with REST API"); 
				pb.setRestIpList(line.getOptionValue("ripl"));
			}

			if (line.hasOption("pql")) {
				if(!line.hasOption("cip"))
					throw new IllegalArgumentException("Cannot publish to queue '"+line.getOptionValue("pql")+"'; Reason: Missing -cip argument.");
				
				if(line.hasOption("api") && line.getOptionValue("api").equalsIgnoreCase("mqtt"))
					throw new IllegalArgumentException("Unsupported argument '-pql' when using MQTT API mode. Please use -ptl and -mpq instead.");

				pb.setPublisherQueueLists(line.getOptionValue("pql"));
			}

			if (line.hasOption("ptf")) {
				try {
					Vector<String> topicsArray = Helpers.readFileAsVector(line.getOptionValue("ptf"));
					pb.setPubTopics(topicsArray);
				} catch (PubSubException pse) {
					throw new ParseException("Error parsing topic file format.");
				}
			}

			if (line.hasOption("pqf")) {
				try {
					Vector<String> topicsArray = Helpers.readFileAsVector(line.getOptionValue("pqf"));
					pb.setPubQueues(topicsArray);
				} catch (PubSubException pse) {
					throw new ParseException("Error parsing pqf file.");
				}
			}

			if (line.hasOption("psv")) {
				pb.setPubSendVectSize(intval(line, "psv"));
			}
			
			if (line.hasOption("sd")) {
				pb.setSubDelay(intval(line, "sd"));
			} 
			
			if (line.hasOption("sdc")) {
				pb.setSubDelayCount(intval(line, "sdc"));
			} 
			
			if (line.hasOption("sri")) {
				pb.setSubRateInterval(intval(line, "sri"));
			}

			if (line.hasOption("nsr")) {
				pb.setSubscriberRemove(false);
			}
			
			if (line.hasOption("nsm")) {
				pb.setWantSubscriptionMemory(false);
			}
			
			if (line.hasOption("caq")) {
				pb.setWantClientAck(true);
				pb.setSubMsgQueueDepth(intval(line, "caq"));
			}
			
			if (line.hasOption("qb")) {
				pb.setWantQueueBrowsing(true);
			}
			
			if (line.hasOption("qbd")) {
				pb.setWantQueueBrowsing(true);
				pb.setQueueBrowseDelete(line.getOptionValue("qbd"));
			}
			
			if (line.hasOption("tps")) {
				pb.setSubscriberPerSubThruStats(true);
			}
			
			if (line.hasOption("srs")) {
				pb.setWantSubscriptionRateStats(true);
			}
			
			if (line.hasOption("pedn")) {
				pb.setDiscardNotifySender(line.getOptionValue("pedn"));
			} else {
				pb.setDiscardNotifySender(null);
			}
			
			if (line.hasOption("apw")) {
				pb.setAdPubWindowSize(intval(line, "apw"));
			}
			
			if (line.hasOption("apa")) {
				pb.setAdPubAckTimeout(intval(line, "apa"));
			}
			
			if (line.hasOption("amr")) {
				pb.setAdPubMaxResends(intval(line, "amr"));
			}
			
			if (line.hasOption("ats")) {
				pb.setAdTransactionSize(intval(line, "ats"));
			}
			
			if (line.hasOption("atxa")) {
				pb.setWantXaTransaction(true);
			}
			
			if (line.hasOption("atop")) {
				pb.setWantOnePhaseCommitTransaction(true);
			}
			
			if (line.hasOption("atts")) {
				pb.setNumMsgsPerTransactionSegment(intval(line, "atts"));
			}
			
			if (line.hasOption("atst")) {
				pb.setNumSuspendedTransactions(intval(line, "atst"));
			}
			
			if (line.hasOption("atpc")) {
				pb.setWantProducerConsumersTransaction(true);
			}
			
			if (line.hasOption("atxatt")) {
				pb.setXaTransactionIdleTimeout(intval(line, "atxatt"));
			}
			
			if (line.hasOption("atdbs")) {
				pb.setTransactionPhaseDelayBeforeSuspending(intval(line, "atdbs"));
			}
			
			if (line.hasOption("atdbe")) {
				pb.setTransactionPhaseDelayBeforeEnding(intval(line, "atdbe"));
			}
			
			if (line.hasOption("atdbp")) {
				pb.setTransactionPhaseDelayBeforePreparing(intval(line, "atdbp"));
			}
			
			if (line.hasOption("atdbc")) {
				pb.setTransactionPhaseDelayBeforeCommitting(intval(line, "atdbc"));
			}
			
			if (line.hasOption("afi")) {
				pb.setWantActiveFlowIndication(true);
			}

			if (line.hasOption("aii")) {
				pb.setAckImmediatelyInterval(intval(line, "aii"));
			}
			
			if (line.hasOption("atr")) {
				pb.setAdTransactionRollbackInterval(1);
			}
			
			if (line.hasOption("atri")) {
				pb.setAdTransactionRollbackInterval(intval(line, "atri"));
			}
			
			if (line.hasOption("att")) {
				pb.setAdTransactionIdleTime(intval(line, "att"));
			}
			
			if (line.hasOption("asw")) {
				pb.setAdSubWindowSize(intval(line, "asw"));
			}
			if (line.hasOption("asa")) {
				pb.setAdSubAckTimeout(intval(line, "asa"));
			}
			if (line.hasOption("awt")) {
				pb.setAdSubThreshold(intval(line, "awt"));
			}
			if (line.hasOption("cid")) {
				pb.setWantCidStat(true);
			}

			if (line.hasOption("di")) {
				pb.setWantDIStat(true);
			}

			if (line.hasOption("d")) {
				pb.setWantVerbose(true);
			}
			
			if (line.hasOption("q")) {
				pb.setWantQuiet(true);
			}
			
			// Subscriptions options
			if (line.hasOption("sql")) {
				pb.setSubscriberQueueLists(line.getOptionValue("sql"));
			} 
			
			if (line.hasOption("sqf")) {
				pb.setSubscriberQueuesFileList(line.getOptionValue("sqf"));
			} 

			if (line.hasOption("stl")) {
				pb.setSubscriberTopicLists(line.getOptionValue("stl"));
			} 
			
			if (line.hasOption("stf")) {
				pb.setSubscriberTopicsFileList(line.getOptionValue("stf"));
			} 

			if (line.hasOption("sdl")) {
				pb.setSubscriberDTELists(line.getOptionValue("sdl"));
			} 
			
			if (line.hasOption("sdf")) {
				pb.setSubscriberDTEFileList(line.getOptionValue("sdf"));
			} 
			
			if (line.hasOption("tte")) {
				pb.setNumTempTopicEndpoints(intval(line, "tte"));
			} 

			if (line.hasOption("tqe")) {
				pb.setNumTempQueueEndpoints(intval(line, "tqe"));
			} 
			
			if (line.hasOption("ssl")) {
				pb.setSelectorLists(line.getOptionValue("ssl"));
			}		
			
			if (line.hasOption("ssf")) {
				pb.setSelectorFileList(line.getOptionValue("ssf"));
			}

			
			// Cache params
			if (line.hasOption("chpn")) {
				pb.setCachePropName(line.getOptionValue("chpn"));
			}
			
			if (line.hasOption("chpm")) {
				pb.setCachePropMaxMsgsPerTopic(intval(line, "chpm"));
			}
			
			if (line.hasOption("chpa")) {
				pb.setCachePropMaxAge(intval(line, "chpa"));
			}
			
			if (line.hasOption("chpt")) {
				pb.setCachePropTimeoutInMsec(intval(line, "chpt"));
			}

			if (line.hasOption("chrs")) {
				pb.setCacheWantRequestsOnSubscribe(true);
			}
			
			if (line.hasOption("chrr")) {
				pb.setCacheReqMsgRate(intval(line, "chrr"));
			}
			
			if (line.hasOption("chrn")) {
				pb.setCacheNumReq(intval(line, "chrn"));
			}
		
			if (line.hasOption("chrt")) {
				
				StringTokenizer tok = new StringTokenizer(line.getOptionValue("chrt"), ":");
			
				String minStr = "", maxStr = "";
				minStr = tok.nextToken();
				try {
					Long iMinSeq = Long.parseLong(minStr);
					pb.setCacheReqMinSequence(iMinSeq);
				} catch (NumberFormatException nfe) {
					throw new ParseException("Error parsing Cache Request Topic Sequence. Could not parse min value");
				}
				
				if (tok.hasMoreTokens()) 
				{
					maxStr = tok.nextToken();
					try {
						Long iMaxSeq = Long.parseLong(maxStr);
						pb.setCacheReqMaxSequence(iMaxSeq);
					} catch (NumberFormatException nfe) {
						throw new ParseException("Error parsing Cache Request Topic Sequence. Could not parse max value");
					}
				} else {
					throw new ParseException("Error parsing Cache Request Topic Sequence. Did not find max value");
				}
			}
				
			if (line.hasOption("chld")) {
				try {
					pb.setCacheLiveDataAction(line.getOptionValue("chld"));
				} catch (PubSubException e) {
					throw new ParseException("Error parsing live data action.");
				}
			}
			
			if (line.hasOption("aem")) {
				pb.setAckEventMode(line.getOptionValue("aem"));
			}
			
			if (line.hasOption("rc")) {
				if (line.hasOption("api") && line.getOptionValue("api").equalsIgnoreCase("jms")) {
					Trace.warn(String
							.format("Reconnect Retries property (-rc=%d) was ignored, this value must be specified in the JMS Connection Factory.",
									intval(line, "rc")));
				}
				pb.setReconnectAttempts(intval(line, "rc"));
			}
			
			if (line.hasOption("rfa")) {
				
				String rfa = line.getOptionValue("rfa");
				
				if (rfa.equalsIgnoreCase("disconnect") || rfa.equalsIgnoreCase("gd_reconnect_fail_action_disconnect")) {
					pb.setReconnectFailAction(ReconnectFailAction.DISCONNECT);
				} else if (rfa.equalsIgnoreCase("auto_retry") || rfa.equalsIgnoreCase("auto-retry")
						|| rfa.equalsIgnoreCase("gd_reconnect_fail_action_auto_retry")) {
					pb.setReconnectFailAction(ReconnectFailAction.AUTO_RETRY);
				} else {
					throw new ParseException("Invalid value provided for argument 'Reconnect Fail Action' (-rfa).");
				}
			}
		
			if (line.hasOption("brt")) {
				pb.setReadTimeoutInMsec(intval(line, "brt"));
			}
			
			
			// Latency options
			if (line.hasOption("l")) {
				pb.setWantLatency(true);
				pb.setWantSmoothPubCalcLat(true);
			}
			if (line.hasOption("lat")) {
				pb.setWantLatency(true);
				pb.setWantFullLatencyStats(false);
				pb.setWantSmoothPubCalcLat(true);
			}
			
			
			if (line.hasOption("lb")) {
				pb.setLatencyBuckets(intval(line, "lb"));
			} 
			
			if (line.hasOption("lg")) {
				pb.setLatencyGranularity(intval(line, "lg"));
			} 
			
			if (line.hasOption("lwu")) {
				pb.setLatencyWarmupInSec(doubleval(line, "lwu"));
			}
			
			if (line.hasOption("oc")) {
				pb.setWantOrderCheck(true);
			}

			if (line.hasOption("ldd")) {
				pb.setWantLossAndDuplicateDetection(true);
			}

			if (line.hasOption("om")) {
				pb.setWantOrderMemory(true);
			}
			
			if (line.hasOption("crc")) {
				pb.setWantPayloadCheck(true);
			}
			
			if (line.hasOption("psm")) {
				pb.setWantSmoothPubCalcLat(true);
			}
			
			if (line.hasOption("sdm")) {
				pb.setDefaultStructuredDataList();
			}
			
			if (line.hasOption("snq")) {
				pb.setSubscriberNotificationQueueDepth(intval(line, "snq"));
			}
			
			if (line.hasOption("ka")) {
				pb.setKeepaliveIntervalInMsec(intval(line, "ka"));
			}
			
			if (line.hasOption("z")) {
				try {
					pb.setClientCompressionLevel(intval(line, "z"));
				} catch (NumberFormatException e) {
					throw new IllegalArgumentException("Could not parse -z (compression) parameter. Value '"+line.getOptionValue("z")+"' is not a valid number.", e);
				}
				
			}
			
			if (line.hasOption("cos")) {
				try {
					pb.setPublishCos(intval(line, "cos"));
				} catch (PubSubException e) {
					errorStr.println("Error.  Reason: " + e.getMessage());
				}
			}
			
			if (line.hasOption("pto")) {
				pb.setPublishToOne(true);
			}
			
			if (line.hasOption("pso")) {
				pb.setPublishStreamOffset(intval(line, "pso"));
			}
			
			if (line.hasOption("poo")) {
				pb.setPublishOrderOffset(intval(line, "poo"));
			}
			
			if (line.hasOption("spl")) {
				pb.setServerPortList(line.getOptionValue("spl"));
				if(!line.hasOption("ptl") && !line.hasOption("pql")){
					pb.setNumPubThreads(0);
					pb.setSubscriberTopicLists("null");
				}
			}
			
			if(line.hasOption("mrdl")){
				if(!line.hasOption("cm") || (!line.getOptionValue("cm").equalsIgnoreCase("reply") && !line.getOptionValue("cm").equalsIgnoreCase("reflect"))){
					throw new IllegalArgumentException("-mrdl can only be used with -cm=reflect or -cm=reply  ");
				}
				pb.setMsgReflectDelayList(line.getOptionValue("mrdl"));
			}
			
			if(line.hasOption("rrwt")){
				int tmp;
				try{
					tmp=Integer.parseInt(line.getOptionValue("rrwt"));
				}catch(NumberFormatException e){
					throw new IllegalArgumentException("Argument -rrwt must be passed with an int value.");
				}
				pb.setRequestReplyWaitTime(tmp);
				pb.setWantReplyTopic(true);
			}
			
			
			
            if (line.hasOption("cor")) {
                pb.setCallbackOnReactorThread(true);
            }
            
            // Publish on Receive feature arguments
            if(line.hasOption("nmpr")) {
            	pb.setNumberOfMessagesToPublishOnReceive(Integer.parseInt(line.getOptionValue("nmpr")));
            }
            if(line.hasOption("portl")) {
            	pb.setPublishOnReceiveTopicList(line.getOptionValue("portl"));
            }
            if(line.hasOption("porql")) {
            	pb.setPublishOnReceiveQueueList(line.getOptionValue("porql"));
            }
            if(line.hasOption("pormt")) {
            	pb.setPublishOnReceiveMessageType(line.getOptionValue("pormt"));
            }
			if (line.hasOption("pormsa")) {
				List<Integer> list = RuntimePropertiesBuilder.tokenizeIntegers(line.getOptionValue("pormsa"), ",");
				pb.setPublishOnReceiveAttachmentSizeList(list);
			}
			if (line.hasOption("porrm")) {
				pb.setPublishOnReceiveReflectMessage(true);
			}
            // end POR feature arguments

            if (line.hasOption("crr")) {
            	pb.setWantReplicationReconnect(true);
            }
            
            if(line.hasOption("rssslks")){
            	pb.setRestServerConnectionType(GenericServerConnectionType.SSL);
            	pb.setRestServerKeyStore(line.getOptionValue("rssslks"));
            	
            	if(line.hasOption("rssslksp")){
             		pb.setRestServerKeyStorePass(line.getOptionValue("rssslksp"));
            	}
            	
            	if(line.hasOption("rssslpkp")){
            		pb.setRestServerPrivatekeyStorePassword(line.getOptionValue("rssslpkp"));
            	}
            }
            
           
            
            if(line.hasOption("rssslts")){
            	pb.setRestServerConnectionType(GenericServerConnectionType.SSL);
            	pb.setRestServerTrustStore(line.getOptionValue("rssslts"));	
            	if(line.hasOption("rsssltsp")){
                	pb.setRestServerTrustStorePass(line.getOptionValue("rsssltsp"));	
                }
            }
            
            
            
            if (line.hasOption("sslp")) {
            	pb.setSslProtocol(line.getOptionValue("sslp"));
            }

            if (line.hasOption("sslcd")) {
            	pb.setSslConnectionDowngradeTo(line.getOptionValue("sslcd"));
            }
            
            if (line.hasOption("sslep")) {
            	pb.setSslExcludedProtocols(line.getOptionValue("sslep"));
            }
            
            if (line.hasOption("sslvc")) {
            	pb.setSslValidateCertificate(true);
            }
            
            if (line.hasOption("sslvcd")) {
            	pb.setSslValidateCertificateDate(true);
            }
            
            if (line.hasOption("sslcs")) {
            	pb.setSslCipherSuites(line.getOptionValue("sslcs"));
            }
            
            if (line.hasOption("sslts")) {
            	pb.setSslTrustStore(line.getOptionValue("sslts"));
            }
            
            if (line.hasOption("ssltsd")) {
            	pb.setSslTrustStoreDir(line.getOptionValue("ssltsd"));
            }
            
            if (line.hasOption("ssltsp")) {
            	pb.setSslTrustStorePassword(line.getOptionValue("ssltsp"));
            }
            
            if (line.hasOption("ssltsf")) {
            	pb.setSslTrustStoreFormat(line.getOptionValue("ssltsf"));
            }
            
            if (line.hasOption("ssltcn")) {
            	pb.setSslTrustedCommonNameList(line.getOptionValue("ssltcn"));
            }
            
            if (line.hasOption("sslks")) {
                pb.setAuthenticationScheme(GenericAuthenticationScheme.CLIENT_CERTIFICATE);
                pb.setSslKeyStore(line.getOptionValue("sslks"));
            }
            
            if (line.hasOption("sslksp")) {
                pb.setAuthenticationScheme(GenericAuthenticationScheme.CLIENT_CERTIFICATE);
                pb.setSslKeyStorePassword(line.getOptionValue("sslksp"));
            }
            
            if (line.hasOption("sslksf")) {
                pb.setAuthenticationScheme(GenericAuthenticationScheme.CLIENT_CERTIFICATE);
                pb.setSslKeyStoreFormat(line.getOptionValue("sslksf"));
            }
            
            if (line.hasOption("sslpka")) {
                pb.setAuthenticationScheme(GenericAuthenticationScheme.CLIENT_CERTIFICATE);
                pb.setSslPrivateKeyAlias(line.getOptionValue("sslpka"));
            }
            
            if (line.hasOption("sslcf")) {
                pb.setAuthenticationScheme(GenericAuthenticationScheme.CLIENT_CERTIFICATE);
                // Used for JNI
                pb.setSslCertificateFile(line.getOptionValue("sslcf"));
            }
            
            if (line.hasOption("sslpk")) {
                pb.setAuthenticationScheme(GenericAuthenticationScheme.CLIENT_CERTIFICATE);
                // Used for JNI
                pb.setSslClientPrivateKeyFile(line.getOptionValue("sslpk"));
            }
            
            if (line.hasOption("sslpkp")) {
                pb.setAuthenticationScheme(GenericAuthenticationScheme.CLIENT_CERTIFICATE);
                
                pb.setSslPrivateKeyPassword(line.getOptionValue("sslpkp"));
                // Used for JNI (reuse argument)
                pb.setSslClientPrivateKeyFilePassword(line.getOptionValue("sslpkp"));
            }
            
            if (line.hasOption("as")) {
            	pb.setAuthenticationScheme(line.getOptionValue("as"));
            }
            
			if (line.hasOption("jndi")) {
				pb.setJNDIforJMS(true);
			}
			if (line.hasOption("jod")) {
			    pb.setOptimizeJMSForDirectDelivery(true);
			}
			if (line.hasOption("epl")) {
				try {
					pb.setExtraProps(line.getOptionValue("epl"));
					}
			    catch (Exception e) {
			    	throw new ParseException("Error parsing extra property list.");
				}
			}
			
			if (line.hasOption("cpl") && line.hasOption("cjpl")) {
				throw new IllegalArgumentException("Can only use one of -cjpl and -cpl arguments.");
			}
			
			if (line.hasOption("cpl")) {
				if(line.hasOption("api")){
					String a = line.getOptionValue("api");
					
					if(!a.equalsIgnoreCase("jms") && !a.equalsIgnoreCase("jcsmp")){
						throw new IllegalArgumentException("-cpl parameter is only supported for the JMS & JCSMP API modes.");
					}
				}
				
				pb.setCustomPropertyList(line.getOptionValue("cpl"));
			}
			
			if (line.hasOption("cjpl")) {
				pb.setCustomPropertyList(line.getOptionValue("cjpl"));
			}			

			if (line.hasOption("bd")) {
				pb.setBurstDuration(doubleval(line, "bd"));
			}

			if (line.hasOption("ibd")) {
				pb.setInterBurstDuration(doubleval(line, "ibd"));
			}
			
			if (line.hasOption("pe")) {
				pb.setProvisionEndpoints(true);
			}
			
			if (line.hasOption("pep")) {
				pb.setProvisionEndpoints(true);
				pb.setPEPremision(line.getOptionValue("pep"));
			}
			
			if (line.hasOption("pea")) {
				pb.setProvisionEndpoints(true);
				
				int endpointAccessType = intval(line, "pea");
				
				if(endpointAccessType == 0)
					pb.setPEAccessType(EndpointAccessType.ACCESSTYPE_NONEXCLUSIVE);
				else if(endpointAccessType == 1)
					pb.setPEAccessType(EndpointAccessType.ACCESSTYPE_EXCLUSIVE);
				else {
					throw new IllegalArgumentException("Invalid Endpoint Access Type provided (-pea): "
							+ endpointAccessType);
				}
			}
			
			if (line.hasOption("peq")) {
				pb.setProvisionEndpoints(true);
				pb.setPEQuota(intval(line, "peq"));
			}
			
			if (line.hasOption("pem")) {
				pb.setProvisionEndpoints(true);
				pb.setPEMAxMsgSize(intval(line, "pem"));
			}
			
			if (line.hasOption("per")) {
				pb.setProvisionEndpoints(true);
				pb.setPERespectTTL(true);
			}
			
			if (line.hasOption("pemr")) {
				pb.setProvisionEndpoints(true);
				pb.setPEMaxMsgRedelivery(intval(line, "pemr"));
			}
			
			if (line.hasOption("scn")) {
				pb.setSubscriptionClientName(line.getOptionValue("scn"));
			}
			
			if (line.hasOption("fct")) {
				pb.setWantCutThroughPersistence(true);
			}
			
			if (line.hasOption("soe")) {
				pb.setStopOnError(true);
			}
			
			if (line.hasOption("upt")) {
				pb.setWantUserPropToolData(true);
			}
			
			if(line.hasOption("tm")){
				pb.setToolMode(line.getOptionValue("tm"));
			}
			
			if(line.hasOption("ud")){
				pb.setWantUD(true);
			}
			
			if(line.hasOption("csr")){
				pb.setWantClientSynchronousReceive(true);
			}
			
			if(line.hasOption("q")){
				pb.setWantQuiet(true);
			}
			
			boolean wantVersion = false;
			if (line.hasOption("v")) {
				// print version and exit
				pb.setWantVersion(true);
				wantVersion = true;
			}

			if (line.hasOption("h")) {
				printUsage();
				return null;
			}
			if (line.hasOption("hm")) {
				printMoreUsage();
				return null;
			}
			if (line.hasOption("he")) {
				printExampleUsage();
				return null;
			}
			
			if(line.hasOption("eep")) {
				pb.setWantApplicationServerCommand(line.getOptionValue("eep"));
			}
			
			if(line.hasOption("istx")) {
				pb.setWantRATransaction(true);
			}
			
			if (!wantVersion) {
				boolean isValid = pb.validate(System.out);
				if (!isValid) {
					printUsage();
				} else {
					pb.loadXmlDocs();
					pb.loadAttachmentDocs();
					pb.loadSmfBinaryFiles();
					props = pb.getRuntimeProperties();
				}
			} else {
				// do not validate if getting version info
				props = pb.getRuntimeProperties();
			}
			
		} catch (ParseException exp) {
			errorStr.println("Parsing failed.  Reason: " + exp.getMessage());
			errorStr.println("use -h or -hm for the list of accepted arguments.");
			props = null;
		} catch (IOException exp) {
			errorStr.println("I/O Error.  Reason: " + exp.toString());
			props = null;
		}
		
		if (props != null &&
			props.getIntegerProperty(RuntimeProperties.CACHE_NUM_REQ) > 0 &&
			props.getLongProperty(RuntimeProperties.NUM_MSGS_TO_PUBLISH) > 0	) {
			errorStr.println("Cli Options Conflict.  Cannot use -mn and -chrn together.");
			props = null;
		}
		
		return props;
	}
	
	
	/**
	 * load tool's run time properties from option file. 
	 * @param pb
	 * 					RuntimePropertiesBuilder object
	 * @param optionFile
	 * 					option file name
	 */
	public static void loadDefaultOptions(RuntimePropertiesBuilder pb) {
		// Leave as null where no default is required.
		
		pb.setMQTTWillMsgSize(0);
		pb.setMQTTWillMsgQos(0);
		pb.setMQTTWillMsgRetained(false);
		pb.setMqttWantCleanConnect(true);
		pb.setReconnectAttempts(3);
		pb.setRestServerConnectionType(GenericServerConnectionType.PLAIN_TEXT);
		pb.setMqttPublishQos(0);
		pb.setMqttSubscribeQos(0);
		pb.setNumClients(0);
		pb.setToolMode(ToolMode.SDKPERF);
		pb.setToolApi(InternalApiMode.JCSMP.toString());
		pb.setToolExternalClientClassString("com.solacesystems.pubsub.sdkperf.thirdparty.ExtClient");
		pb.setWebMessagingBrowserType("firefox");
		pb.setWebMessagingGotoURL("http://localhost:8080/missing_value_for_goto_url_argument.html");
		pb.setWantPayloadCheck(false);
		pb.setWantUD(false);
		pb.setWantOrderCheck(false);
		pb.setWantLossAndDuplicateDetection(false);
		pb.setWantOrderMemory(false);		
		pb.setWantMessageContentExamined(false);
		pb.setJMSCF("/jms/cf/default");
		pb.setNumPubsPerSession(1);
		pb.setNumMsgsToPublish(0);
		pb.setPubEndDelay(2);
		pb.setClientUsername("");
		pb.setClientVpn(""); 
		pb.setClientNamePrefix(""); 
		pb.setClientPassword("");
		pb.setClientDescription(""); // Not accessible via cli.
		pb.setChangeClientNameFlag(false);
		pb.setWantTcpNoDelay(true); //DO NOT set the nodelay option
		pb.setMessageType(GenericMessageDeliveryMode.DIRECT);
		pb.setSubDelay(0); 
		pb.setSubDelayCount(-1);
		pb.setSubRateInterval(1);
		pb.setSubscriberRemove(true);
		pb.setWantSubscriptionMemory(true);
		pb.setSubscriberPerSubThruStats(false);
		pb.setWantSubscriptionRateStats(false); 
		pb.setSubscriberNotificationQueueDepth(-1);
		pb.setWantCidStat(false);
		pb.setWantDIStat(false);
		pb.setWantVerbose(false);
		pb.setWantQuiet(false);
		pb.setWantVersion(false);
		pb.setWantLatency(false);
		pb.setWantFullLatencyStats(true);
		pb.setLatencyBuckets(1024);
		pb.setLatencyGranularity(0);
		pb.setLatencyWarmupInSec(30.0);
		pb.setWantSmoothPubCalcLat(false);
		pb.setWantStructMsgCheck(false);
		pb.setRatePerPub(1);
		pb.setCacheWantStats(false);
		pb.setCacheNumReq(0);
		pb.setCacheReqMinSequence(-1);
		pb.setCacheReqMaxSequence(-1);
		pb.setCacheReqWaitForConfirm(false);
		pb.setNumTempQueueEndpoints(0);
		pb.setNumTempTopicEndpoints(0);
		pb.setWantContextPerClient(false);
		pb.setJNDIforJMS(false);
		pb.setBurstDuration(0);
		pb.setInterBurstDuration(0);
		pb.setProvisionEndpoints(false);
		pb.setPEAccessType(EndpointAccessType.ACCESSTYPE_API_DEFAULT);
		pb.setPEMAxMsgSize(-1);
		pb.setPEQuota(-1);
		pb.setPEMaxMsgRedelivery(-1);
		pb.setPEPremision("");
		pb.setPERespectTTL(false);
		pb.setStopOnError(false);
		pb.setWantQueueBrowsing(false);
		pb.setQBDeleteFrequency(-1);
		pb.setQBDeleteBuf(-1);
		pb.setPubSendVectSize(0);
		pb.setAdPubWindowSize(50);
		pb.setWantMsgDump(false);
		pb.setMsgDumpDirectory("");
		pb.setClientMode(ClientModeType.SINK);
		pb.setWantMsgReflect(false);
		pb.setWantReplyTopic(false);
		pb.setWantReplyTemporaryQueue(false);
		pb.setReplyToPostfix("");
		pb.setReplyToString("");
		pb.setPublishStreamOffset(-1);
		pb.setPublishOrderOffset(0);
		pb.setSubscriptionClientName("");
		pb.setWantCutThroughPersistence(false);
		pb.setWantUserPropToolData(false);
		pb.setMsgRateIsMax(false);
		pb.setIgnoreExistsErrors(true);
		pb.setWantClientAck(false);
		pb.setWantClientAckThread(false);
		pb.setClientAckSkipNum(0);
		pb.setClientAckFlushQueue(false);
		pb.setClientAckQueueReverse(false);
        pb.setClientAckRandomDepth(0);
		pb.setSubMsgQueueDepth(0);
		pb.setWantClientSynchronousReceive(false);
		pb.setWantNoLocal(false);
		pb.setAdTransactionSize(0);
		pb.setWantXaTransaction(false);
		pb.setTransactedSessionNameList(new Vector<String>());
		pb.setWantOnePhaseCommitTransaction(false);
		pb.setNumMsgsPerTransactionSegment(1);
		pb.setNumSuspendedTransactions(0);
		pb.setWantProducerConsumersTransaction(false);
		pb.setXaTransactionIdleTimeout(0);
		pb.setTransactionPhaseDelayBeforeSuspending(0);
		pb.setTransactionPhaseDelayBeforeEnding(0);
		pb.setTransactionPhaseDelayBeforePreparing(0);
		pb.setTransactionPhaseDelayBeforeCommitting(0);
		pb.setAdTransactionRollbackInterval(-1);
		pb.setAdTransactionIdleTime(0);
		pb.setWantQuiet(false);
		pb.setAckImmediatelyInterval(0);
		pb.setSslProtocol("");
		pb.setSslConnectionDowngradeTo("");
		pb.setSslExcludedProtocols("");
		pb.setSslValidateCertificate(false);
		pb.setSslValidateCertificateDate(false);
		pb.setSslCipherSuites("");
		pb.setSslTrustStore("");
		pb.setSslTrustStoreDir("");
		pb.setSslTrustStorePassword("");
		pb.setSslTrustStoreFormat("");
		pb.setSslTrustedCommonNameList("");
		pb.setSslKeyStore("");
		pb.setSslKeyStorePassword("");
		pb.setSslKeyStoreFormat("");
		pb.setSslPrivateKeyAlias("");
		pb.setSslPrivateKeyPassword("");
		pb.setSslCertificateFile("");
		pb.setSslClientPrivateKeyFile("");
		pb.setSslClientPrivateKeyFilePassword("");
		pb.setAuthenticationScheme(GenericAuthenticationScheme.BASIC);
		pb.setWantActiveFlowIndication(false);
		pb.setWantPubAckOrderCheck(true);
		pb.setWantReplicationReconnect(false);
		pb.setWantApplicationServerCommand("");
		pb.setWantRATransaction(false);
		pb.setNumPubThreads(1);	
		pb.setClientTransportProtocol("");		
		pb.setWebTransportProtocolList("");
		pb.setClientTransportProtocolDowngradeTimeout("");
		pb.setWantPerMessageDetails(false);
		pb.setNumMessageProducer(1);
		pb.setNumberOfMessagesToPublishOnReceive(0);
    	pb.setPublishOnReceiveTopicList("");
    	pb.setPublishOnReceiveQueueList("");
    	pb.setPublishOnReceiveMessageType("direct");
		pb.setPublishOnReceiveAttachmentSizeList(new ArrayList<Integer>());
		pb.setPublishOnReceiveReflectMessage(false);
		pb.setSkipFinalCommit(false);
	}
	
	public static void printUsage() {
		//HelpFormatter hf = new HelpFormatter();
		//hf.printHelp("SDKPerf_java", _opts);
		
		StringBuffer buf = new StringBuffer();
		buf.append("sdkperf_java [options]\n");
		buf.append("\n");
		buf.append("  Client control:\n");
		buf.append("    -cip ip[:port]  IP and port of the client appliance. (e.g. -cip=192.168.160.101)\n");
		buf.append("    -cu user[@vpn]  Client username and optionally VPN name.  Used only with TRB appliances.\n");
		buf.append("                    (default is 'perf_client' if client-certificate authentication is not used)\n");
		buf.append("    -cn string      Root name for clients, index appended (default in pubsub mode is '')\n");
		buf.append("                    First client by default is 'perf_client0001', second is\n");
		buf.append("                    'perf_client0002', etc.) (default in client mode is API specified)\n");
		buf.append("\n");
		buf.append("  Message Control:\n");
		buf.append("    -mr number      Publishing rate (msg/sec per client) (default 1)\n");
		buf.append("    -mn number      Total # messages to publish (across ALL clients). (default is 0)\n");
		buf.append("    -msx list       Comma sep size list in bytes for auto-generated xml payload portion.\n");
		buf.append("    -msa list       Comma sep size list in bytes for auto-generated binary attachment portion.\n");
		buf.append("    -mt string      Message type, one of {direct|nonpersistent|persistent}.\n");
		buf.append("                    Default is direct\n");
		buf.append("    -md             Dump all received messages to the screen as text\n");
		buf.append("\n");
		buf.append("  Publishing options (All files lists are comma separated, full paths): \n");
		buf.append("    Note: All lists of message parts specified must be of equal length.\n");
		buf.append("    -pfl list       Xml data file list\n");
		buf.append("    -pal list       Binary attachment list.\n");
		buf.append("    -ptl list       List of topics for publishing. Note: This list must be \n");
		buf.append("                    either of size 1 (same topic used for all msgs) or \n");
		buf.append("                    of equal length to message parts specified (topics uniquely specified). \n");
		buf.append("    -pql list       List of queues for publishing. Note: This list must be \n");
		buf.append("                    either of size 1 (same queue used for all msgs) or \n");
		buf.append("                    of equal length to message parts specified (queues uniquely specified). \n");
		buf.append("    -ptp string     Publish topic prefix. Use with -ptc to generate a large topic list. \n");
		buf.append("    -ptc int        Publish topic count. Use with -ptp to generate a large topic list. \n");
		buf.append("    -psv number     Configure pub send vector.  Default is 0, meaning disabled.  Max is 50\n");
		buf.append("    -psm            Enable smooth publishers.  Enabled by default for latency testing. \n");
		buf.append("\n");
		buf.append("  Subscribing options (All lists are comma separated) \n");
		buf.append("    Note: Elements of the given lists are applied round robin to clients.  Ie if you have \n");
		buf.append("          2 clients and 2 topics, then each client will get 1 topic.\n");
		buf.append("    -sxl list       Comma sep list of XPEs applied round robin to clients\n");
		buf.append("                    Note: Escape quotes with \\\n");
		buf.append("    -sql list       List of queues for subscribing applied round robin to clients\n");
		buf.append("    -sdl list       List of durable topic endpoints (DTE) for subscribing.  If using DTEs \n");
		buf.append("                    and this param is omitted, topic names will be used as DTE names.\n");
		buf.append("    -stl list       List of topics for subscribing applied round robin to clients\n");
		buf.append("    -stp string     Subscription topic prefix. Use with -stc to generate a large list of topics.\n");
		buf.append("    -stc int        Subscription topic count. Use with -stp to generate a large list of topics.\n");
		buf.append("    -ssl list       List of selector strings applied to filter messages from flows\n");
		buf.append("    -tte int        Number of temporary topic endpoints to create per client.\n");
		buf.append("    -tqe int        Number of temporary queue endpoints to create per client.\n");
		buf.append("    -nsr            No subscription remove. Flag to indicate that sdkperf should\n");
		buf.append("                    not remove subscriptions on exit.\n");
		buf.append("\n");
		buf.append("  Performance measurement options.  Runtime must be > 1 second:\n");
		buf.append("    -l  flag        Enable latency measurements (default is no latency). \n");
		buf.append("    -lb int         Enable latency measurement with # buckets (default 1024 buckets) \n");
		buf.append("    -lg int         Latency granularity factor (default 0)\n");
		buf.append("    -nagle          Enable Nagle's algorithm (RFC 896) to allow higher tcp throughput. (replaces -tnd)\n");
		buf.append("\n");
		buf.append("  Tool Specific Options: \n");
		buf.append("    -ka number      Keepalive interval in milliseconds.  (Default -1)\n");
		buf.append("    -z number       Enable compression. (1..9) 1 is fastest, 9 max compression.\n");
		buf.append("    -epl list       Comma sep list of extra Props passed blindly to the API\n");
        buf.append("\n");
        buf.append("  General Parameters:\n");
		buf.append("\n");
		buf.append("  General Flags:\n");
		buf.append("    -soe            Stop client connections or publishing on errors.\n");
		buf.append("    -v              Show version\n");
		buf.append("    -h | -?         Show this short help\n");
		buf.append("    -hm             Show more help.  Ie all other options not shown in basic help\n");
		buf.append("    -he             Show cli examples help\n");
   
		System.out.println(buf.toString());
	}
	
	public static void printMoreUsage() {
		printUsage();
		
		StringBuffer buf = new StringBuffer();
		buf.append("  -------------------------------------------\n");
		buf.append("  Advanced Options \n");
		buf.append("  -------------------------------------------\n");
		buf.append("\n");
		buf.append("  Client control:\n");
		buf.append("    -cc number      Number of client connections (default 1)\n");
		buf.append("    -cp password    Client password (default '')\n");
		buf.append("    -cdp L[:N]      Client DeliverToOne Priority. L for Local priority. N for Network Priority. \n");
		buf.append("                    (Priorities are integers 1..4)\n");
		buf.append("    -ccn            Flag to change client names following reconnect. Rather than correctly setting them on connect. \n");
		buf.append("    -cm=string      Client mode.  One of 'reply' or 'sink'.  Default is 'sink'.  \n");
		buf.append("                    In reply, all messages are reflected by the replyTo topic is used as the destination when sending.\n");
        buf.append("    -mrdl list      Message Reply Delay list. Determine the amount of time the consumer should wait before responding. Must be used with with the -cm option in 'reply' mode.\n");
		buf.append("    -cpc            Context per client.  Enable 1 context for each client.\n");
		buf.append("    -cpt number     Number of publish threads per client (default 1)\n");
		buf.append("    -cptt number    Total number of publish threads (default 1). Clients will be evenly spread out on all available threads.\n");
		buf.append("                    Mutually exclusive with -cpt parameter.\n");
		buf.append("    -crr            Client Replication Reconnect. (default false)\n");
		buf.append("    -cnl            Client No Local on session and all endpoints.  (default false)\n");
		buf.append("\n");

		buf.append("  Message Control:\n");
		buf.append("    -mrt=string     Publishing rate targets one of 'avg' or 'max'. (default avg)\n");
		buf.append("    -msxs val       Where val=start,step,end in bytes for a list of xml payload sizes.\n");
		buf.append("    -msas val       Where val=start,step,end in bytes for a list of binary attachment sizes.\n");
		buf.append("    -sdm            Used to send canned messages to test structured data messaging.  \n");
		buf.append("                    Also enables checking on recv.\n");
		buf.append("    -mdq            Messages should be flagged eligible for the dead message queue\n");
		buf.append("    -mtl int        Messages will be tagged with time to live (millis) of this value\n");
		buf.append("    -mee            Messages should be flagged eligible for message eliding\n");
                buf.append("    -mdd dir        Output all messages received to individual files in this directory.  Only available in sdkperf_jms.\n");
		buf.append("\n");
		buf.append("  Publishing options: \n");
		buf.append("    -psl list       Binary SMF Serialized Message list.\n");
		buf.append("    -ptf list       List of files containing topics for publishing.  Note all publishers \n");
		buf.append("                    publish to all topics.\n");
		buf.append("    -pqf list       List of files containing queues for publishing.  Note all publishers \n");
		buf.append("                    publish to all queues.\n");
		buf.append("    -ped int        Publish end delay, The time in seconds\n");
		buf.append("                    to wait following publishing the final message before\n");
		buf.append("                    bringing down subscriber data channels.\n");
		buf.append("                    (Default 2 (seconds))\n");
		buf.append("    -cos int        The cos value to use in publishing.  Valid range (1..3) or\n");
		buf.append("                    0 to leave unspecified in API.\n");
		buf.append("                    Default is 1\n");
		buf.append("    -pto            Publish to one.  Flag to have publisher set deliver to one field \n");
		buf.append("                    transmitted messages.\n");
		buf.append("    -pso int        Publish stream offset.  Add stream Ids to outgoing messages using this offset\n");
		buf.append("    -poo int        Publish order offset.  Add this offset to order Ids of outgoing messages\n");
		buf.append("    -bd int         Duration of burst (double value in seconds), enables bursty publishing. \n");
		buf.append("                    Use with inter-burst duration.\n");
		buf.append("    -ibd int        Optional Inter-burst duration (double value in seconds), specifies duration of inter\n");
		buf.append("                    burst gaps. Use with burst duration\n");
		buf.append("    -prt            Publish reply topic flag. Pubs will add reply to topic in each send.  P2P by default.\n");
		buf.append("    -prq            Publish reply temporary queue flag. The client will create and bind to a temporary queue\n");
		buf.append("                    which will be used as the reply-to destination for every message published.\n");
		buf.append("    -prp=string     Publish reply postfix.  Similar to -prt except pub will add publish topic + this\n");
		buf.append("                    postfix as reply to.\n");
		buf.append("    -prs=string     Publish reply string.  Similar to -prt except pub will use this string as reply to.\n");
		buf.append("                    By default, the destination type will be a topic. It is possible to change the destination type\n");
		buf.append("                    by using the \"/QUEUE/\" or \"/TOPIC/\" suffix. For example, -prs=/QUEUE/myQueue would set the\n");
		buf.append("                    reply-to destination as queue \"myQueue\".\n");
		buf.append("    -cpl            Custom Property List. This argument can be used to add custom Properties on messages being published.\n");
		buf.append("                    Usage: -cpl=type,name,value (e.g. -cpl=Boolean,PropName,true or -cpl=Int,prop1,1,Long,prop2,92).\n");
		buf.append("                    Accepted types are: String, Boolean {true, false}, Double, Float, Int, Long, Short\n");	
		buf.append("    -nmp=int        Number of message producers per client. Default: 1; Accepted Values: >= 1\n");
		buf.append("                    The first producer will always be the default producer. When publishing, the client will round-robin\n");
		buf.append("                    over all available producers.\n");	
		buf.append("\n");
		buf.append("  Subscribing options (All lists are comma separated) \n");
		buf.append("    -sxf list       List of files of the form:\n");
		buf.append("                    file1[:number],file2[:number],...\n");
		buf.append("                    the number specifies how many XPEs are used from each file\n");
		buf.append("    -sqf list       List of files containing queues for subscribing.\n");
		buf.append("    -sdf list       List of files containing DTEs for subscribing.\n");
		buf.append("                    If using DTEs and DTE param is omitted, topic names will be used as DTE names.\n");
		buf.append("    -stf list       List of files containing topics for subscribing.\n");
		buf.append("    -ssf list       List of files containing selector strings\n");
		buf.append("    -sd int         Per subscriber per msg delay in milliseconds. Ie slow subscribers.\n");
		buf.append("                    Use -1 to stop the subscriber from responding to messages.\n");
		buf.append("                    (default 0)\n");
		buf.append("    -sdc int        Slow subscriber count.  Number of msgs a subscriber will be slow \n");
		buf.append("                    before returning to normal.(default -1, slow forever)\n");
		buf.append("    -sri int        Subscriber rate interval.  A method of controlling how\n");
		buf.append("                    often the subscriber calculates throughput.  The subscriber\n");
		buf.append("                    will calculate rate every sri messages.  (default 1)\n");
		buf.append("                    Use -1 to disable rate checking.\n");
		buf.append("    -nsm            No subscription memory.  Flag to disable re-add of subscriptions on \n");
		buf.append("                    channel reconnects. \n");
		buf.append("    -qb             Enables queue browsing. Option must be used with '-sql' \n");
		buf.append("    -qbd F,B        Queue browsing delete instructions.  F is for frequency of delete.  B is \n");
		buf.append("                    for number of messages to buffer before deleting\n");
		buf.append("    -pe             Enables provisioning and cleanup of queues and topic endpoints\n");
		buf.append("    -pep char       Provisioned Endpoints Permissions. One of (n)one, (r)eadonly, \n");
		buf.append("                    (c)onsume, (m)odify, (d)elete\n");
		buf.append("    -pea int        Provisioned Endpoints Access Type. 0 for Non Exclusive, 1 for Exclusive\n");
		buf.append("    -peq int        Provisioned Endpoints Quota in MB\n");
		buf.append("    -pem int        Provisioned Endpoints Max Message Size in bytes\n");
		buf.append("    -pemr int       Provisioned Endpoints Max Message Redelivery. 0 means retry forever.\n");
		buf.append("    -per            Provisioned Endpoints Respect TTL flag\n");
		buf.append("    -pedn string    Provisioned Endpoints Discard Notify Sender flag.\n");
		buf.append("                    Takes one of the values 'default', 'on', 'off'  as argument.\n");
		buf.append("    -scn string     Subscription client name.  All subscriptions will be entered on behalf of this client.\n");
		buf.append("    -fct            Use cut-through persistence for subscriber flows.\n");
		buf.append("    -cor            Callback on reactor. Message delivery will be on the reactor thread.\n");
        buf.append("\n");
		buf.append("  Publish On Receive\n");
		buf.append("   As the name suggests, the Publish On Receive feature will cause the client to send message(s)\n");
		buf.append("   upon reception of a message using the calling thread and independently of the publisher thread.\n");
		buf.append("   The user must specify the number of message its client(s) must send upon reception of a message using\n");
		buf.append("   the -nmpr flag. By default, if no destination is provided, the message will be sent back to the\n");
		buf.append("   destination from which the message was received. It is possible to specify multiple types of\n");
		buf.append("   destinations in the same query (i.e. both -porql and -portl can be used simultaneously).\n");
		buf.append("   It is also possible to vary the message size of each message sent using the -pormsa argument.\n");
		buf.append("   The Publish on Receive feature is compatible with the -ats argument. The client will use the\n");
		buf.append("   transacted session to publish if a message was received from a transacted session. It is important\n");
		buf.append("   to note that the client will only commit or rollback upon reception of the defined number of messages.\n");
		buf.append("   In other words, specifying the arguments \"-ats=2 -nmpr=2\" would result in transactions \n");
		buf.append("   containing 6 messages (2 received + 4 published).\n");
        buf.append("\n");
		buf.append("   -nmpr int        Number of messages to publish on receive. Specifies the number of messages\n");
		buf.append("                     to publish upon reception of a message. Default: 0\n");
		buf.append("   -portl list      List of topics (comma separated) to be used for publishing upon message reception.\n");
		buf.append("   -porql list      List of queues (comma separated) to be used for publishing upon message reception.\n");
		buf.append("   -pormt string    Message type, one of {direct|nonpersistent|persistent}. Default: direct\n");
		buf.append("   -pormsa list     Comma separated size list in bytes for auto-generated binary attachment portion.\n");
		buf.append("   -porrm           If flag is set, the first message published on receive will be the message received\n");
		buf.append("                    but only if it has a reply-to destination set. The message destination will be set\n");
		buf.append("                    as the reply-to destination and the reply-to destination will be cleared before the\n");
		buf.append("                    message is published.\n");
		
		
		
        buf.append("\n");
        buf.append("  Client Ack Options (applies only to GD msgs)\n");
        buf.append("    -ca             Enable client ack for all GD msgs. (default auto ack)\n");
        buf.append("    -caq int        Queue size for buffering of msgs before processing them for client acks\n");
        buf.append("    -caf            When queue is full ack all messages in the queue. (Ie burst acks)\n");
        buf.append("    -cafr           Same as -caf but process the queue in reverse order.\n");
        buf.append("    -car int        When processing ack queue, choose a message at random\n");
        buf.append("                    up to this value.  The larger this value the larger the\n");
        buf.append("                    perf impact of using this option\n");
        buf.append("    -cask int       Skip this many messages during client ack\n");
        buf.append("    -cat            Perform client acks in a new thread\n");
		buf.append("\n");
		buf.append("  Performance measurement options.  Runtime must be > 1 second:\n");
		buf.append("    -lat            Enable latency average and 99th stats printout\n");
		buf.append("    -lfl int        Enable first to last latency stats with specified fanout\n");
		buf.append("    -lp             Set the latency precision in significant digits after the decimal.\n");
		buf.append("    -lwu sec        Set latency warmup in seconds.  (default 30.0)\n");
		buf.append("    -tps            Enable per-subscriber throughput stats \n");
		buf.append("    -crc            Enable CRC-32 check of message payload (default off)\n");
		buf.append("    -oc             Enable out-of-order checking and loss/duplicate detection on clients.\n");
		buf.append("    -ldd            Enable loss and duplicate detection on clients. This is a subset of the -oc argument, no out-of-order checking will be executed.\n");
	    buf.append("    -om             Enable order memory on clients.\n");
		buf.append("    -ud             Send userdata in msgs.  Userdata will be the alphabet then\n");
		buf.append("                    the digits to fill the space\n");
		buf.append("    -mec            Msg Examine Content - A flag used to tell sdkperf\n");
		buf.append("                    to check each part of the message and keep stats on msgs \n");
		buf.append("                    received.  Ex: num messages with xml payload, etc\n");
		buf.append("    -cid            Enable stats per consumer id.\n");
		buf.append("    -di             Enable Discard indication statistics.\n");
		buf.append("\n");
		buf.append("  Assured Delivery:\n");
		buf.append("    Note: For all AD properties the default behavior is to leave the\n");
		buf.append("          particular CSMP property unmodified\n");
		buf.append("    -apw int        Set the publisher ack window size.  Valid range is 1 - 255; Default: 50\n");
		buf.append("                    Please note that Sdkperf's default differs from JCSMP's default of 1.\n");
		buf.append("    -apa int        Set the publisher ack timeout in milliseconds.  Valid\n");
		buf.append("                    range is 0 - 5000  \n");
		buf.append("    -asw int        Set the subscriber ack window size.  Valid range is 1 - 255\n");
		buf.append("    -asa int        Set the subscriber ack timeout in milliseconds.  Valid\n");
		buf.append("                    range is 0 - 1500  \n");
		buf.append("    -awt int        Set the subscriber ack window threshold in percent.  Valid\n");
		buf.append("                    range is 1-75\n");
		buf.append("    -amr int        Set the maximum number of resend when a message ack is\n");
		buf.append("                    missing.  Valid range is >= 0\n");
		buf.append("    -ats int        AD transaction size.  Valid range is 0..256, default is 0 (disabled)\n");
		buf.append("    -atxa           Enable XA transaction semantics. Default is disabled.\n");
		buf.append("    -atop           Enable one-phase commit. Default is two-phase commit.\n");
		buf.append("    -atts=int       Number of messages per transaction segment. Default is 1.\n");
		buf.append("    -atst=int       Number of suspended transactions. Default is 0.\n");
		buf.append("    -atpc           Producer and consumers on the same transaction. Default is on separate transactions.\n");
		buf.append("    -atxatt         XA transaction idle timeout in seconds for XAResource. Default value is 0 (which is 180 s).\n");
		buf.append("    -atr            Flag to enable mode where every transaction is rolled back (default is to commit)\n");
		buf.append("    -atri=int       AD transaction rollback interval.  Used in combination with -ats to\n");
		buf.append("                    rollback rather than commit at the specified frequency (default is disabled)\n");
		buf.append("    -att=int        AD transaction idle time.  Used in combination with -ats.  If a partial\n");
		buf.append("                    uncommitted transaction does not receive a message within <int> ms, a commit\n");
		buf.append("                    is triggered.  Default is 0 ms (disabled)\n");
		buf.append("    -afi            Enable active flow indication on each flow\n");
		buf.append("    -aem=string     Set the ack event mode.  Valid values are: 'per-message' or 'windowed'\n");
		buf.append("    -aii=int        ACK immediately interval.  Valid range is >= 0, default is 0 (disabled)\n");
		buf.append("\n");
		buf.append("  Authentication and SSL Options:\n");
		buf.append("    Note: For all omitted SSL options, the API defaults are used unless\n");
		buf.append("          otherwise mentioned.\n");
		buf.append("    -as=string      Client authentication scheme. Accepted values: "
				+ GenericAuthenticationScheme.BASIC.toString()
				+ ", "
				+ GenericAuthenticationScheme.CLIENT_CERTIFICATE.toString()
				+ ", " + GenericAuthenticationScheme.GSS_KRB + "\n");
		buf.append("    -sslp=string    Comma seperated list of the encryption protocol(s) to use.\n");
		buf.append("    -sslvc          Enable validation of server certificates. (default is false)\n");
		buf.append("    -sslvcd         Enable validation of certificate date.    (default is false)\n");
		buf.append("    -sslcs=string   Comma seperated list of cipher suites to enable.\n");
		buf.append("    -sslcd=string   SSL Connection Downgrade. Session property specifying a transport protocol that\n");
		buf.append("                    the connection will be downgraded to after client authentication.\n");
		buf.append("                    Default: API default (do not downgrade); Accepted Value: PLAIN_TEXT\n");
		buf.append("   JCSMP, JMS and REST specific arguments.\n");
		buf.append("    -sslts=string   Path to trust store file.\n");
		buf.append("    -ssltsp=string  The trust store password.\n");
		buf.append("    -ssltsf=string  The trust store format.\n");
		buf.append("    -sslks=string   Path to key store file.\n");
		buf.append("    -sslksp=string  The key store password.\n");
		buf.append("    -sslksf=string  The key store format.\n");
		buf.append("    -sslpka=string  The private key alias.\n");
		buf.append("    -sslpkp=string  The private key password.\n");
		buf.append("    -sslep=string   Comma separated list of excluded SSL protocol(s).\n");
		buf.append("   JNI specific arguments.\n");
		buf.append("    -sslcf=string   The client certificate file.\n");
		buf.append("    -sslpk=string   The client private key file.\n");
		buf.append("    -sslpkp=string  The client private key file password.\n");
		buf.append("    -ssltsd=string  Path to trust store directory.\n");
		buf.append("\n");
		buf.append("  Web Transport Options:\n");
		buf.append("    -ctp            Client (Web) Transport Protocol. (default is to let API decide)\n");
		buf.append("    -cwtpl          Client Web Transport Protocol List. (default is to let API decide)\n");
		buf.append("    -ctpdt          Client Transport Protocol Downgrade Timeout (ms). (default is to let API decide)\n");
		buf.append("\n");
		buf.append("  Cache Options (-ch..):\n");
		buf.append("    -chpn string    Property - Name of cache for requests\n");
		buf.append("    -chpm int       Property - Max Msgs Per Topic\n");
		buf.append("    -chpa int       Property - Max age for cached messages in secs\n");
		buf.append("    -chpt int       Property - Timeout in msec for a given cache request\n");
		buf.append("    -chrs           Want Request on Subscribe - Tool will perform cache request\n");
		buf.append("                    on every subscribe performed\n");
		buf.append("    -chrr double    Request rate (msgs/sec)\n");
		buf.append("    -chrn int       Request number.  How many requests to send at the rate specified.\n");
		buf.append("    -chrt int:int   Topic Sequence number range <begin:end> for the cache request. \n");
		buf.append("                    Values are passed to API unchanged.\n");
		buf.append("    -chld string    Live Data Action.  One of QUEUE, FULFILL, FLOW_THRU\n");
		buf.append("\n");
		buf.append("  Tool Specific Options: \n");
		buf.append("    -rc int         Retry Count.  Number of times API will try to re-establish a failed connection. (Default 3)\n");
		buf.append("    -rfa string     Reconnect Fail Action. Specify the behavior that the API should take if it is unable to recover guaranteed delivery state after reconnecting the session.\n");
		buf.append("                    Possible values: DISCONNECT, AUTO_RETRY. (Default: API default)\n");
		buf.append("    -jndi           Enable JNDI topic and queue lookups.\n");
		buf.append("    -jod            Optimizes the JMS in direct mode (assumes one\n");
		buf.append("                    producer/consumer per connection)\n");
		buf.append("    -jcf string     JMS Connection Factory (default /jms/cf/default)\n");
		buf.append("    -upt            Tool data is contained in the user property map rather than the binary attachment.\n");
		buf.append("    -snq int        Modify the subscriber notification queue size (Dispatcher Queue).  (Default is API default)\n");
		buf.append("    -tm string      Tool mode.  One of 'sdkperf' or 'rtrperf'.  Default is 'sdkperf'.");
		buf.append("    -api string     Customizes which Solace API is used by sdkperf. Valid values are: JCSMP, JMS, JNI, REST, MQTT \n");
		buf.append("                    JAVASCRIPT, ACTIONSCRIPT, SILVERLIGHT. It's also possible to integrate with thirdparty \n");
		buf.append("                    by using a value of THIRDPARTY.\n");
		buf.append("                    (Default is JCSMP.)\n");
		buf.append("    -ecc string     Used with -api. It specifies a path to an external client class to load which implements the AbstractClient or AbstractJmsClient interface.\n");
		buf.append("                    (Default is 'com.solacesystems.pubsub.sdkperf.thirdparty.ExtClient'\n");		
		buf.append("\n");
		buf.append("  Enterprise Java Options: \n");
		buf.append("    NOTE: Use these options to interact with the sdkperf-ee application running inside a J2EE application server.\n");
		buf.append("    -eep string     Specifies sdkperf-ee options (UTF-8 encoded string) embedded as a binary attachment of message.  The message's destination should be one bound to by an sdkperf-ee Message-Driven-Bean. Cannot be used with -msa and -msx parameters.\n");
		buf.append("                    (e.g.: -eep=\"-cip 192.168.160.150 -cu default@default -ptl DurTopicBMTMDB -mr 1 -mn 1 -jcf XATCF \") \n");
		buf.append("    -istx           Flag: Specifies that the initial session to the Solace router be an XASession.  Use this option if you know the outbound message should be transacted\n");		

		buf.append("\n");

		// Feature needs to be cleaned up before it is made available
//		buf.append("  JCSMP Client specific Flags:\n");
//		buf.append("    -csr            Client synchronous receive. The application thread will be used to synchronously received messages.\n");
//		buf.append("                    Cannot be used with -ptl or -pql parameters.\n");
//		buf.append("\n");
		
		buf.append("  REST Client specific flags:\n");
		buf.append("    -spl list         Server Port List. Define a comma-separated list of ports for REST consumers to connect to.\n");
		buf.append("    -rcm string       REST Client Mode. Accepted values are: socket or httpclient.\n");
		buf.append("                      \"Socket\" uses no third-party libraries and sends REST messages directly on a socket while \"HttpClient\" sends messages using Apache's HttpClient library.\n");
		buf.append("                      The REST Client Mode, if not specified with this parameter, will vary depending on which tool mode is used.\n");
		buf.append("                      When RouterPerf mode is used, the default becomes the Socket Client, when Sdkperf mode is used, the default becomes HttpClient.\n");
		buf.append("    -rsrco list       REST Server Response Override. Example usage: -rsrco=200,70,204,10,400,10,500,10\n");
		buf.append("                      Given the example usage, the REST server will return response code 200 70% of the time, 204 10% of the time, 400 10% of the time and 500 10% of the time.\n");
		buf.append("    -rte string       REST Transfer Encoding. Currently only Chunked Encoding is supported.\n");
		buf.append("    -rrwt int         Request Reply Wait Time. Can be used for setting the \"Solace-Reply-Wait-Time\" header on outgoing message.\n");
		buf.append("    -ripl list        REST (local) IP list. This flag can be used to specify a list of local IPs that will be used in a round-robin fashion for opening outgoing connections to a REST server.\n");
		buf.append("\n");
		buf.append("  REST Server specific flags:\n");
		buf.append("    -rssslks  string   REST Server SSL key Store Path.\n");
		buf.append("    -rssslksp string   REST Server SSL Key Store Password \n");
		buf.append("    -rssslpkp string   REST Server SSL Private Key Password \n");
		buf.append("    -rssslts  string   REST Server SSL Trusted Store Path \n");
		buf.append("    -rsssltsp string   REST Server SSL Trusted Store Password\n");
		
		buf.append("\n");
		buf.append("  MQTT Client specific flags:\n");
		
		buf.append("  -mpq int           MQTT Publisher QoS. Sets the Quality of Service (QoS) of MQTT messages published.\n");
		buf.append("                     Default: 0; Accepted Values: 0, 1 and 2.\n");

		buf.append("  -msq int           MQTT Subscription QoS. Sets the Quality of Service (QoS) of subscriptions requested.\n");
		buf.append("                     Default: 0, Accepted Values: 0, 1 and 2.\n");
		buf.append("                     It is also possible to overload the default subscription QoS on a per subscription basis\n");
		buf.append("                     by appending '<TOPIC_END/>qos=<value>' to your topic (e.g.'-stl=test_topic<TOPIC_END/>qos=1')\n");
		buf.append("  -mcs bool          MQTT flag indicating whether the session should be cleaned.\n");
		buf.append("                     Default: 1 (true); Accepted values: 1 (true), 0 (false)\n");

		buf.append("  -mwmt string       MQTT Will Message Topic. MQTT topic on which the will message will be sent.\n");
		buf.append("  -mwms int          MQTT Will Message Size. Default: 0 \n");
		buf.append("  -mwmq int          MQTT Will Message Quality of Service (QoS). Default: 0 \n");
		
		//Bug 65828: sdkperf_mqtt: hide -mwmr (mqtt will message retain) parameter from help output
//		buf.append("  -mwmr              MQTT Will Message Retained. MQTT flag indicating whether the will message should be retained.\n");
		buf.append("\n");
		buf.append("  General Flags:\n");
		buf.append("    -d              Enable debug information.\n");
		buf.append("    -q              Enable quiet mode.  No command line output during\n");
		buf.append("                    publishing or subscribing.\n");

		System.out.println(buf.toString());
	}

	public static void printExampleUsage() {
				
		String TOOL_BASIC_START = "      sdkperf_java -cip 192.168.160.xx ";
		String TOOL_TCPS_START = "      sdkperf_java -cip tcps://192.168.160.xx ";
		String TOOL_SMFS_START = "      sdkperf_jms -cip smfs://192.168.160.xx ";
		StringBuffer buf = new StringBuffer();
		buf.append("  -------------------------------------------\n");
		buf.append("  CLI Examples (for basic options see -h | -?) \n");
		buf.append("  -------------------------------------------\n");
		buf.append("\n");
		buf.append("  - Publish and receive 5 100 byte messages on a topic at 1 msg/sec:\n");
		buf.append(TOOL_BASIC_START + "-ptl a -stl a -msa 100 -mn 5 -mr 1\n");
		buf.append("\n");
		buf.append("  - Provision a queue, map 4 topics to this queue and publish to the topics:\n");
		buf.append(TOOL_BASIC_START + "-pe -sql queue -stl a,b,c,d -ptl a,b,c,d -mn 100 -mr 100 -msa 100\n");
		buf.append("\n");
		buf.append("  - Publish to queue with time to live of 1 millisecond and mark the message as DMQ eligible: \n");
		buf.append(TOOL_BASIC_START + "-pql queue -mt persistent -mn 100 -mr 100 -msa 100 -mtl 1 -mdq\n");
		buf.append("\n");
		buf.append("  - Subscribe to topic 'a' with deliver always.  Useful in testing publish to one (-pto): \n");
		buf.append(TOOL_BASIC_START + "-stl \"a<TOPIC_END/>DA=1\"\n");
		buf.append("\n");
		buf.append("  - Enter subscriptions on behalf of another client: \n");
		buf.append(TOOL_BASIC_START + "-stl a -scn c0001\n");
		buf.append("\n");
		buf.append("  - Example of tuning API params with epl lists: \n");
		buf.append(TOOL_BASIC_START + "-stl a -epl \"jcsmp.MESSAGE_CALLBACK_ON_REACTOR,true\"\n");
		buf.append("\n");
		buf.append("  - Connect a JCSMP client using SSL.  (For a complete list of SSL options see -hm)\n");
        buf.append(TOOL_TCPS_START + "\n");
        buf.append("\n");
        buf.append("  - Connect a JMS client using SSL.  (For a complete list of SSL options see -hm)\n");
        buf.append(TOOL_SMFS_START + "\n");
        buf.append("\n");
		System.out.println(buf.toString());
	}
	
	private static long longval(CommandLine line, String optName) {
		return Long.parseLong(line.getOptionValue(optName));
	}
	
	private static int intval(CommandLine line, String optName) {
		return Integer.parseInt(line.getOptionValue(optName));
	}
	
	private static double doubleval(CommandLine line, String optName) {
		return Double.parseDouble(line.getOptionValue(optName));
	}
		
	private final static class UserVpnDef {
		public final String user;
		public final String vpn;

		public UserVpnDef(final String user, final String vpn) {
			this.user = user;
			this.vpn = vpn;
		}
	}
	
	private static UserVpnDef getParsedUserVpn(String user_vpn) throws ParseException {
		String user = "", vpn = "";
		String[] parts = user_vpn.split("@");
		if (parts.length > 0) {
			user = parts[0];
			if (parts.length > 1) {
				vpn = parts[1];
			}
		}
		return new UserVpnDef(user, vpn);
	}
}

