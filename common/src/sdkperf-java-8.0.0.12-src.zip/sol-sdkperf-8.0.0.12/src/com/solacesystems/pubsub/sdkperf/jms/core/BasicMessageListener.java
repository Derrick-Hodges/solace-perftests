package com.solacesystems.pubsub.sdkperf.jms.core;

import java.lang.reflect.Constructor;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Topic;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.pubsub.sdkperf.core.AbstractClientTransactedSession;
import com.solacesystems.pubsub.sdkperf.core.FlowStatus;

/**
 * Class to receive JMS messages asynchronously
 * 
 */
public class BasicMessageListener implements MessageListener, JmsMessageReceiver {
	
	private static final Log Trace = LogFactory.getLog(BasicMessageListener.class);

	protected final String _destination;
	protected MessageConsumer _consumer;
	protected final boolean _isNonDurable;
	protected final boolean _isTopic;
	protected final Topic _topic;
	protected final AbstractJmsClient _jmsClient;
	protected final AbstractClientTransactedSession _transactedSession;
	protected Class<?> _wrappedMessageClass = null; 
	protected Constructor<?> _wrappedMessageConstructor = null;
	
	public BasicMessageListener(AbstractJmsClient client, String destination, boolean isTopic, Topic topic,
			boolean isNonDurable, AbstractClientTransactedSession transactedSession, MessageConsumer consumer) {
		this._destination = destination;
		this._isTopic = isTopic;
		this._consumer = null;
		this._topic = topic;
		this._isNonDurable = isNonDurable;
		this._jmsClient = client;
		this._transactedSession = transactedSession;
		this._consumer = consumer;
		
		setWrappedMessageClass(JmsWrappedMessage.class);
	}
	
	public void setWrappedMessageClass(Class<?> wrappedMessageClass) {
		_wrappedMessageClass = wrappedMessageClass;
		
		try {
			_wrappedMessageConstructor = _wrappedMessageClass.getConstructor(Message.class);
		} catch (Exception e) {
			Trace.warn("Failed to set JmsWrappedMessage constructor.", e);
		}
	}
	
	public void onMessage(Message message) {

		_jmsClient.incrMsgRecvStat();

		JmsWrappedMessage wMsg = null;
		try {
			wMsg = (JmsWrappedMessage) _wrappedMessageConstructor.newInstance(new Object[] { message });
		} catch (Exception e) {
			Trace.warn(
					"Failed to instantiate "
							+ ((_wrappedMessageClass == null) ? "null" : _wrappedMessageClass.getName()) + " object.",
					e);
			wMsg = new JmsWrappedMessage(message);
		}
		
				
		if (_jmsClient.getNumMsgPubOnReceive() > 0) {
			Object prod = null;
			if (_transactedSession != null) {
				try {
					prod = _transactedSession.getProducer();
				} catch (Exception e) {
					Trace.warn("Failed to get producer from transacted session", e);
				}
			} else {
				prod = _jmsClient._defaultProducer;
			}

			wMsg.setProducerOnReceive(prod);
		}
		
		_jmsClient.processMessage(wMsg);

		if (_transactedSession != null) {
			try {
				_transactedSession.onMessage();
			} catch (Exception exception) {
				_jmsClient.handleMessageProcessingError(exception);
			}
		}
	}

	public MessageConsumer getJmsMessageConsumer() {
		return _consumer;
	}
	public void setJmsMessageConsumer(MessageConsumer value) {
		_consumer = value;
	}

	// It is expected that Solace specific clients will be able
	// to override this with a more intelligent implementation.
	public FlowStatus getFlowStatus() {
		return new FlowStatus();
	}

	public void startMessageListener() throws JMSException {
		// instantiate a new async listener for this sub
		_consumer.setMessageListener(this);
	}
	
	public void restartMessageListener() throws JMSException {
		// no different than starting fresh.
		this.startMessageListener();
	}

	public String getDestinationString() {
		return _destination;
	}

    public boolean isNonDurable() {
		return _isNonDurable;
	}

	public boolean isTopic() {
		return _isTopic;
	}

	public Topic getTopic() {
		return _topic;
	}

}
