/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import java.util.LinkedList;
import java.util.List;

import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.PerfStats.PerfStatType;
import com.solacesystems.pubsub.sdkperf.core.TransactionResultUnknownException;
import com.solacesystems.pubsub.sdkperf.core.TransactionRollbackException;
import com.solacesystems.pubsub.sdkperf.util.SdkperfConstants;
import com.solacesystems.pubsub.sdkperf.util.Timing;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Publisher thread.  When publishing, each client will contain
 * a publisher thread that will execute the publish task.
 * This thread runs to completion and in general aborts when
 * encountering errors.
 */
public class SdkperfPubThread {
	private static final Log Trace = LogFactory.getLog(SdkperfPubThread.class);
	
	//wait threshold at which we switch to the special waiting algorithm.
	private static final int RATE_CHK_THRESH = 1000000000/500;
	private static final int RATE_CHK_INTERV = 10;
	private static final long CATCHUP_THRESHOLD_IN_NS = 100; //100ns

	protected AbstractClient _client;
	protected int _pubPerSessionIndex;
	protected RuntimeProperties _perfProps;
	protected BasicMsgRep[] _doclist;
	
	
	private long _numMsgsPub;
	
	protected volatile boolean _isPublishing;
	protected volatile boolean _isDonePublishing; 
	protected volatile boolean _shutdown; 
	protected volatile long _startTime;
	protected volatile long _endTime;
	protected volatile long _lastPubTime;
	protected PubThreadObj _pubThread;
	protected PerfStats _txStats;

	protected boolean _wantStopOnError;
		
	public SdkperfPubThread(
			AbstractClient client,
			int pubIndex) throws Exception {
		_client = client;
		_pubPerSessionIndex = pubIndex;
		
		int latBuckets = 0;
		int latGranularity = 0;
		double warmup = 0;
		_txStats = new PerfStats(
				_client.getIdStr(), 
				latBuckets, 
				latGranularity,
				warmup);
	}

	public void startPublish(
			final List<BasicMsgRep> doclist,
			final long numMsgs,
			final RuntimeProperties props,
			final String transactedSessionName) throws Exception
	{
		_numMsgsPub = numMsgs;
		_perfProps = (RuntimeProperties)props.clone();
		
		_isDonePublishing = false;
		_wantStopOnError = _client.getWantStopOnError();
		
		// Must create an API specific version of the message list to allow the APIs to cache some things like destinations.
		// Also keep it as an array for faster access in the pub loop.
		_doclist = _client.cloneToApiSpecificMsgRep(doclist.toArray(new BasicMsgRep[doclist.size()]));
				
		_client.setPublishProps(_perfProps, _pubPerSessionIndex, transactedSessionName);
		
		if (_pubThread != null) {
			// previous thread object
			if (_pubThread.isAlive())
				throw new IllegalStateException("Attempted to start a publisher thread when one was already running.");
		}		
		_pubThread = new PubThreadObj();
		_pubThread.start();
	}
	
	public void stopPublish() throws Exception
	{
		_shutdown = true;
	}
	
	public boolean isPublishing() { return _isPublishing; }
	public boolean isDonePublishing() { return _isDonePublishing; }
	
	public long getStartTimeInNanos() { return _startTime; }
	public long getEndTimeInNanos() { return _endTime; }
	public long getLastPubTimeInNanos() { return _lastPubTime; }
	public PerfStats getTxStats() { return _txStats; }
	
    // The pub thread keeps track of lastPubTime.  However, it's
    // possible to publish from outside the pub thread using the
    // method publishMsg.  We will allow publishMsg to set the
    // last pub time.
	public void setLastPubTimeInNanos(long value)
	{
		_lastPubTime = value;
	}
	
	public String getClientName() 
	{ 
		String clientName = "";
		try {
			clientName = _client.getClientName();
		} catch (Exception e) {
			Trace.error("PubThread unable to open publisher, shutdown", e);
		}
		return clientName;
	}
	
	
	public void resetStats() 
	{
		if (isPublishing())
		{
			_startTime = System.nanoTime();
			_endTime = 0;
		}
		else 
		{
			_startTime = 0;
			_endTime = 0;
		}
		
		_txStats.resetStats();
	}
	
	class PubThreadObj extends Thread {
		@Override
		public void run() {
			
			long interDocDelayNs;
			
			double burstDuration = 0, interBurstDuration = 0;
			
			boolean burstMode = false;
			int pubSendVectSize = _perfProps.getIntegerProperty(RuntimeProperties.PUB_SEND_VECT_SIZE);
			
			/* Check to see if the burst duration and inter-burst duration  have been
			 * set. If either one of them have not been set, we do not set the burst mode flag. 
			 */
			if (_perfProps.getDoubleProperty(RuntimeProperties.BURST_DURATION) > 0 && 
				_perfProps.getDoubleProperty(RuntimeProperties.INTER_BURST_DURATION) > 0) {
				burstDuration = _perfProps.getDoubleProperty(RuntimeProperties.BURST_DURATION);
				interBurstDuration = _perfProps.getDoubleProperty(RuntimeProperties.INTER_BURST_DURATION);
				burstMode = true;
			} else if ((_perfProps.getDoubleProperty(RuntimeProperties.BURST_DURATION) > 0 && 
				_perfProps.getDoubleProperty(RuntimeProperties.INTER_BURST_DURATION) <= 0) ||
			   (_perfProps.getDoubleProperty(RuntimeProperties.BURST_DURATION) <=0  && 
				_perfProps.getDoubleProperty(RuntimeProperties.INTER_BURST_DURATION) > 0)) {
				throw new IllegalArgumentException("Burst duration and Inter-burst duration must be set together.");
			}
			
			// calculate inter-doc delay from publish rate
			double pubrate = _perfProps.getDoubleProperty(RuntimeProperties.PUBLISH_RATE_PER_PUB);
			boolean msgRateIsMax = _perfProps.getBooleanProperty(RuntimeProperties.MSG_RATE_IS_MAX);
			boolean wantSmoothPubCalcLat = _perfProps.getBooleanProperty(RuntimeProperties.WANT_SMOOTH_PUB_CALC_LAT);
			int transactionSize = _perfProps.getIntegerProperty(RuntimeProperties.AD_TRANSACTION_SIZE);
			boolean wantXa = _perfProps.getBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION);
			boolean wantOnePhaseCommit = _perfProps.getBooleanProperty(RuntimeProperties.XA_WANT_ONE_PHASE_COMMIT_TRANSACTION);
			int numMsgsPerTransactionSegment = _perfProps.getIntegerProperty(RuntimeProperties.XA_NUM_MSGS_PER_TRANSACTION_SEGMENT);
			int numSuspendedTransactions = _perfProps.getIntegerProperty(RuntimeProperties.XA_NUM_SUSPENDED_TRANSACTIONS);
			int rollbackInterval = _perfProps.getIntegerProperty(RuntimeProperties.AD_TRANSACTION_ROLLBACK_INTERVAL);
			int ackImmediatelyInterval = _perfProps.getIntegerProperty(RuntimeProperties.AD_ACK_IMMEDIATELY_INTERVAL);
			long orderOffset = _perfProps.getIntegerProperty(RuntimeProperties.PUB_ORDER_OFFSET);
			boolean wantReplicationReconnect = _perfProps.getBooleanProperty(RuntimeProperties.WANT_REPLICATION_RECONNECT);
			boolean skipFinalCommit = _perfProps.getBooleanProperty(RuntimeProperties.SKIP_FINAL_COMMIT);
			
			long numCommits = 0;
			
			long _MAX_CATCHUP = CATCHUP_THRESHOLD_IN_NS;
			if (System.getProperty(SdkperfConstants.SOLACE_SDKPERF_MTR_CATCHUP_NS) != null) {
				_MAX_CATCHUP = Long.parseLong(System.getProperty(SdkperfConstants.SOLACE_SDKPERF_MTR_CATCHUP_NS));
			}

			if (pubrate == 0) {
				// 0 is a magic number, it means "as fast as you can go"
				interDocDelayNs = 0;
			} else {
				interDocDelayNs = (long)(1000000000 / pubrate);
			}
			
			_shutdown = false; //reset shutdown request
			try {
				if (Trace.isDebugEnabled()) {
					Trace.debug("PubThread about to connect publisher.");
				}
				_client.connect();
				if (Trace.isDebugEnabled()) {
					Trace.debug("PubThread connected publisher successfully.");
				}
			} catch (Exception e) {
				Trace.error("PubThread unable to open publisher, shutdown", e);			
				_shutdown = true;
			}
			
			
			try {
				long cntPublished = 0;
				long maxCntPublished = -1;

				
				if (Trace.isDebugEnabled()) {
					Trace.debug(String.format("CLIENT " + _client.getIdStr() + ":About to enter publish loop (%s) messages", _numMsgsPub));
				}
				
				_startTime = System.nanoTime();
				
				// Need a local variable for rate calculation because,
			    // don't want to reset this when stats are reset (ie resetTimes() is called).
			    // but set it equal to the startTime_m.
			    long adjustedStartTime, burstStartTime;
			    adjustedStartTime = _startTime;
			    
			    /* 
			     * Need burst start time as it provides a reference for determining whether 
			     * the thread should sleep for the inter-burst duration. 
			     */
			    burstStartTime = _startTime;
			    List<BasicMsgRep> psvMsgs = new LinkedList<BasicMsgRep>();
				
			    // Calculate cyclesPerMsg only if pubrate is not zero
			    long cyclesPerMsg = 0;
			    if (pubrate != 0) {
			    	cyclesPerMsg = (long)((double)Timing.clockSpeedInHz() / (double)pubrate);
			    }
			    long currentTimeInCycles = Timing.getClockValue();
			    long nextPubTimeInCycles = currentTimeInCycles;
			    
				_isPublishing = true;
				boolean firstSample = false;
				
				while( !_shutdown && (cntPublished < _numMsgsPub)) {
				    
					if (wantSmoothPubCalcLat && pubrate != 0) {
						nextPubTimeInCycles += cyclesPerMsg;
		                
		                currentTimeInCycles = Timing.getClockValue();
		                if (nextPubTimeInCycles < currentTimeInCycles) {
		                	_txStats.incStat(PerfStatType.PSM_NUM_TIMES_BEHIND, 1);
		                
		                    if ((currentTimeInCycles - nextPubTimeInCycles) > _txStats.getStat(PerfStatType.PSM_MAX_CYCLES_BEHIND)) {
		                    	_txStats.setStat(PerfStatType.PSM_MAX_CYCLES_BEHIND, currentTimeInCycles - nextPubTimeInCycles);
		                    }
		                }
		                
		                while (nextPubTimeInCycles > currentTimeInCycles) {
		                    currentTimeInCycles = Timing.getClockValue();
		                }

					} else {
					
						/* If the estimated run time is greater than the burst duration then the 
						 * thread should sleep. After the thread resumes the loopStartTime is updated
						 * to account for the inter-burst duration. Local variable firstSample is set to
						 * true at this point. 
						 */
						if (burstMode) {
							if ((System.nanoTime() - burstStartTime) / 1000000000.0 >= burstDuration) {
								Thread.sleep((int)(interBurstDuration*1000));
								adjustedStartTime = System.nanoTime() - interDocDelayNs * cntPublished;
								firstSample = true;
							}
						}
						
						long timeWaited = docPubDelay(adjustedStartTime, interDocDelayNs, cntPublished);
						if (msgRateIsMax && (timeWaited <  -1 * _MAX_CATCHUP)) {
							// If we fell behind by more than the threshold then adjust the start time
							// so that we don't burst over the max rate.
							adjustedStartTime = System.nanoTime() - interDocDelayNs * cntPublished;
						}
					}
				
					try {
						/* If we are in burst mode and if this is the first message being published 
						 * in a burst then we sample the current time and update the burstStartTime to 
						 * this value. Meanwhile, the flag firstSample is set to false as further messages
						 * in the burst will not be the first.  
						 */
						
						if(burstMode) {
							if (firstSample) {
								firstSample = false;
								burstStartTime = System.nanoTime();
							}
						}
						
						int idx = (int)(cntPublished % _doclist.length); 
						BasicMsgRep msgRep = _doclist[idx];
						
						// Checking if we want tool data is done in the populate method as the first step.
						// Want 1 based msg order numbers. The effects of this method call is to
						// mutate its first 'msgRep' parameter. It does not affect the _client otherwise
						// or update its information, but it does rely on the settings found on that _client.
						long tranId = -1;
						int tranMsgId = -1;
						int tranSize = -1;
						if (transactionSize > 0) {
							tranId = numCommits + 1;
							tranMsgId = (int) ((cntPublished % transactionSize) + 1);
							tranSize = transactionSize;
						}
						//Populate tool data with the current time stamp
						_client.populateToolData(msgRep, cntPublished + 1, tranId, tranMsgId, tranSize);
						
						if (cntPublished <= maxCntPublished) {
						    msgRep.setRepublished(true);
						}
						
						// If we have an ack immediately interval, we set the flag explicitly
			            // because we reuse message properties.
						if (ackImmediatelyInterval > 0) {
							if (((cntPublished + 1) % ackImmediatelyInterval) == 0) {
								msgRep.setAckImmediately(true);
							} else {
								msgRep.setAckImmediately(false);
							}
						}
						
						
						if (pubSendVectSize > 0) {
							psvMsgs.add(msgRep);
							
							if (psvMsgs.size() > pubSendVectSize) {
								if(Trace.isErrorEnabled())
									Trace.error("CLIENT " + _client.getIdStr() + ":Send vector too large: " + psvMsgs.size());
								_shutdown = true;
	                        } else if ((psvMsgs.size() == pubSendVectSize) || _numMsgsPub == cntPublished+1) {
	                            // If we've reached the max vector size or the end of the publish
	                            // then send off the messages. 
	                        	_client.publishSendMultiple(psvMsgs, _pubPerSessionIndex);
	                        	psvMsgs = new LinkedList<BasicMsgRep>();
	                        }
						} else {
						    // mutates the 'msgRep' and not the _client

							_client.publishMsg(msgRep, _pubPerSessionIndex);
						}
					} catch (Exception e) {					
					    
						if (_wantStopOnError) {
							Trace.error("CLIENT " + _client.getIdStr() + ":PubThread sendMessage, shutdown due to: " + e.getMessage(), e);
							_shutdown = true;							
						} else if (wantReplicationReconnect) {
							//TODO: add check for shutdown hook
						    while (!_client.isConnected()) {
						        Thread.sleep(1000);
						    }
						    cntPublished = _client.getLastAckedMsgId() - 1 - orderOffset;
						    
						    Trace.info("CLIENT " + _client.getIdStr() + 
						            ":StaleSessionException while publishing.  Republishing msgIds: " + 
						            (cntPublished + 2 + orderOffset) + " - " + (maxCntPublished + orderOffset));							
						} else {
							Trace.warn("CLIENT " + _client.getIdStr() + ":PubThread sendMessage, send error: " + e.getMessage(), e);
							
							while(_client.getChannelState() != ChannelState.CLIENT_STATE_CONNECTED && !_shutdown) {
								
								// Handle the case where the API will never
								// attempt to reconnect
								if (_client.getChannelState() == ChannelState.CLIENT_STATE_DISCONNECTED) {
									_shutdown = true;
								}
								Thread.sleep(100);
							}
							
							if (!_shutdown) {
								Trace.warn("CLIENT " + _client.getClientName()
										+ ": Publishing resuming following publish error.");
							}
							
						}

					}
					
                    if (cntPublished > maxCntPublished) {
                        maxCntPublished = cntPublished;
                    }
                    
                    /*
                     * All Client Except RestSocket have a _numMsgPubOffset of 1
                     */
					cntPublished+=_client._numMsgsPubOffset;
					
					// If doing transactions then at this point check to see if we should do a commit.
					if (transactionSize > 0 && 
						(cntPublished % transactionSize) == 0) {
						
						numCommits++;
						boolean rollbackOnTransaction = false;
						if (rollbackInterval > 0 && numCommits % rollbackInterval == 0) {
							rollbackOnTransaction = true;
						}
                        
						try {
							// It's time to commit this transaction.  In case a roll back exception,
							// we will decrement cntPublished by the size of this transaction.  This
							// has the effect of trying to re-send and re-commit the set of messages.
							if (wantXa) {
								_client.commitXaSessionOnCurrPub(_pubPerSessionIndex, rollbackOnTransaction, wantOnePhaseCommit, false);
							} else {
								_client.commitTransactionOnCurrPub(_pubPerSessionIndex, rollbackOnTransaction);
							}
						} catch (TransactionRollbackException e) {
							numCommits--;
							cntPublished -= transactionSize;
							if(Trace.isInfoEnabled())
                                Trace.info("Received TransactionRollbackException on commit.", e);
						} catch (TransactionResultUnknownException e) {
							numCommits--;
							cntPublished -= transactionSize;
                            Trace.warn("Received TransactionResultUnknownException on commit. Resending messages, "
											+ transactionSize + " duplicates possible.", e);
						}
					} else if (wantXa &&
								transactionSize > 0 &&
								numMsgsPerTransactionSegment > 0 &&
								numSuspendedTransactions > 0 &&
								(cntPublished % numMsgsPerTransactionSegment) == 0) {
						_client.suspendXaSessionOnCurrPub(_pubPerSessionIndex);
					}
				}
				if (Trace.isDebugEnabled()) {
					Trace.debug(String.format("CLIENT " + _client.getIdStr() + ":Exited publish loop (numpublished=%s)",
						cntPublished));
				}
			} catch (Exception e) {
				Trace.error("CLIENT " + _client.getIdStr() + ":Error during send loop: " + e.getMessage(), e);
				_shutdown = true;
			} 
			// If doing transactions then at this point check to see if we should do a commit.
			if (transactionSize > 0 && !skipFinalCommit) {
				numCommits++;
				boolean wantRollback = false;
				if (rollbackInterval > 0 && numCommits % rollbackInterval == 0) {
					wantRollback = true;
				}
				// One last commit at the end
				try {
					if (wantXa) {
						_client.commitXaSessionOnCurrPub(_pubPerSessionIndex, wantRollback, wantOnePhaseCommit, true);
					} else {
						_client.commitTransactionOnCurrPub(_pubPerSessionIndex, wantRollback);
					}
				} catch (Exception e) {
					Trace.error("CLIENT " + _client.getIdStr() + ": " + e.getMessage(), e);
				}
			}
			
			_endTime = System.nanoTime();
			_lastPubTime = _endTime;

			_isPublishing = false;
			_isDonePublishing = true;
		}
	}
	
	/**
	 * Performs the inter-doc delay. If operating at low rate, delay is applied
	 * between each doc. If operating at high rate (> 500 msgs/sec), delay is
	 * applied only once per 10 docs.
	 * 
	 * @param cntPublished
	 *            Count of messages published
	 */
	private final long docPubDelay(
			final long pubStartTimeNs,
			final long interDocDelayNs,
			final long cntPublished) 
	{
		long timeWaited = 0;
		long nextPubTimeNs;
		if (interDocDelayNs > 0) {
			if (interDocDelayNs < RATE_CHK_THRESH) {
				if (cntPublished % RATE_CHK_INTERV == 0) {
					long timeSinceStartInNs = interDocDelayNs * cntPublished;
					/*
					 * The pause runs only every RATE_CHK_INTERV docs.
					 */
					nextPubTimeNs = pubStartTimeNs + timeSinceStartInNs;
					timeWaited = waitUntil(nextPubTimeNs);
				}
			} else {
				long timeSinceStartInNs = interDocDelayNs * cntPublished;
				/*
				 * The pause runs only every RATE_CHK_INTERV docs.
				 */
				nextPubTimeNs = pubStartTimeNs + timeSinceStartInNs;
				timeWaited = waitUntil(nextPubTimeNs);
			}
		}
		return timeWaited;
	}
	
	private static final long waitUntil(long targetNanoTime) {
		long curtime = System.nanoTime();
		long waittimeInMs = (targetNanoTime - curtime) / 1000000;
		if (waittimeInMs > 0) {
			try {
				Thread.sleep(waittimeInMs);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return waittimeInMs;
	}
}
