/** 
*  Copyright 2004-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Message Reply thread. This thread can be used by clients to send a reply
 * after a certain specified time period.
 * 
 */
public class MessageReplyTask implements Runnable {
	
	private static ScheduledExecutorService _executor = Executors.newSingleThreadScheduledExecutor();
	
	AbstractClient _client;
	AbstractWrappedMessage _message;

	private static final Log Trace = LogFactory.getLog(MessageReplyTask.class);
	
	private MessageReplyTask(AbstractClient client, AbstractWrappedMessage message, int sendDelayMS) {
		_client = client;
		_message = message;
		
		_executor.schedule(this, sendDelayMS, TimeUnit.MILLISECONDS);
	}
	
	public void run() {
		validateAndReflectMsg(_client, _message);
	}
	
	private static void validateAndReflectMsg(AbstractClient client, AbstractWrappedMessage message) {
		if(client == null) {
			Trace.error("MessageReplyTask - Could not publish message with 'null' client.");
			return;
		}
		if(message == null || message.getMessage() == null) {
			Trace.error("MessageReplyTask - Could not publish 'null' message.");
			return;
		}
		
		try {
			client.reflectMsg(message);
		} catch (Exception e) {
			Trace.warn("Caught exception attempting to reflect message.", e);
		}
	}

	
	public static void scheduleMessageReplyTask(AbstractClient client, AbstractWrappedMessage message, int sendDelayMS) {
		if(sendDelayMS>0) {
			new MessageReplyTask(client, message, sendDelayMS);
		} else {
			validateAndReflectMsg(client, message);
		}
	}
	
}
