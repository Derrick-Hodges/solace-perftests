/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import javax.transaction.xa.XAResource;

/**
 * Constant values for the SDKPERF interface.
 */
public class Constants {
	
	public static final int DISCARD_NOTIFY_SENDER_OFF = 1;
	public static final int DISCARD_NOTIFY_SENDER_ON = 2;
	
	public enum EndpointAccessType {
		ACCESSTYPE_API_DEFAULT(-1, "API_DEFAULT"),
		ACCESSTYPE_EXCLUSIVE(1, "EXCLUSIVE"),
		ACCESSTYPE_NONEXCLUSIVE(0, "NON-EXCLUSIVE");
		
		private final int value;
		private final String strValue;
		private EndpointAccessType(int value, String strValue) {
			this.value = value;
			this.strValue = strValue;
		}
		public int getValue() {
			return value;
		}
		public String toString() {
			return strValue;
		}
	}
	
	public enum ReconnectFailAction {

		AUTO_RETRY("AUTO_RETRY"), DISCONNECT("DISCONNECT");

		private final String strValue;

		private ReconnectFailAction(String strValue) {
			this.strValue = strValue;
		}

		public String toString() {
			return strValue;
		}
	}

	public static final int SOL_CLIENT_ACKNOWLEDGE = 4;
	public static final String SUB_DEFAULT_QUEUE_NAME = "#sol.subscribername";
	
	public enum ToolMode {
		SDKPERF,
		RTRPERF
	}
	
	public enum InternalApiMode {
		JCSMP,
		JMS,
		JNI,
		REST,
		MQTT,
		THIRDPARTY,
		JAVASCRIPT,
		ACTIONSCRIPT,
		SILVERLIGHT
	}
	
	public enum GenericServerConnectionType {
		SSL,
		PLAIN_TEXT;
	}
	
	public enum GenericAuthenticationScheme {
		// Username/Password based Authentication Scheme.
		BASIC ("basic"),
		// Kerberos based Authentication Scheme.
		GSS_KRB ("kerberos"),
		// Client Certificate based Authentication Scheme.
		CLIENT_CERTIFICATE ("client-certificate");
		
		private final String _name;
		private GenericAuthenticationScheme(String s) { _name = s; }
		
		public boolean equals(String otherName){
	        return (otherName == null) ? false: _name.equals(otherName);
	    }
	    
	    public boolean equalsIgnoreCase(String otherName){
	        return (otherName == null) ? false: _name.equalsIgnoreCase(otherName);
	    }

	    public String toString() {
	       return _name;
	    }
	}
	
	public enum XaTransactionAction {
		COMMIT,
		END,
		FORGET,
		PREPARE,
		RECOVER,
		ROLLBACK,
		START,
		ALL
	}

	public enum XaTransactionFlag {
		TMENDRSCAN(XAResource.TMENDRSCAN),
		TMFAIL(XAResource.TMFAIL),
		TMJOIN(XAResource.TMJOIN),
		TMNOFLAGS(XAResource.TMNOFLAGS),
		TMONEPHASE(XAResource.TMONEPHASE),
		TMRESUME(XAResource.TMRESUME),
		TMSTARTRSCAN(XAResource.TMSTARTRSCAN),
		TMSUCCESS(XAResource.TMSUCCESS),
		TMSUSPEND(XAResource.TMSUSPEND),
		XA_OK(XAResource.XA_OK),
		XA_RDONLY(XAResource.XA_RDONLY);

	    private final int intValue;

	    private XaTransactionFlag (int intValue) {
	      this.intValue = intValue;
	    }

	    public int intValue() {
	      return intValue;
	    }
	}
	
	public enum GenericTransferEncoding {
		CHUNKED,
		COMPRESS,
		DEFLATE,
		GZIP,
		IDENTITY
	}
	
	public enum GenericRestMode {
		SOCKET,
		HTTPCLIENT
		
	}
	
	public enum GenericClientVersion {
		SOCKET,
		HTTPCLIENT,
		PAHO
	}
	
	public enum GenericSupportedAckEvent {
		// API sends out message acknowledgment event for a single Guaranteed message published.
		PER_MSG ("SUPPORTED_ACK_EVENT_MODE_PER_MSG"),
		// API sends out message acknowledgment event for a range of Guaranteed messages published.
		WINDOWED ("SUPPORTED_ACK_EVENT_MODE_WINDOWED");
		
		private final String _name;
		
		private GenericSupportedAckEvent(String s) { _name = s; }
		
		public boolean equals(String otherName){
	        return (otherName == null) ? false: _name.equals(otherName);
	    }
	    
	    public boolean equalsIgnoreCase(String otherName){
	        return (otherName == null) ? false: _name.equalsIgnoreCase(otherName);
	    }
	    
	    public String toString() {
	       return _name;
	    }
	}
	
	public enum GenericSessionSupportedModes{
		AUTO_ACKNOWLEDGE(""),
		
		CLIENT_ACKNOWLEDGE(""),
		
		DUPS_OK_ACKNOWLEDGE(""),
		
		SOL_CLIENT_ACKNOWLEDGE("");
		
		private final String _name;
		
		private GenericSessionSupportedModes(String s) { _name = s; }
		
		public boolean equals(String otherName){
	        return (otherName == null) ? false: _name.equals(otherName);
	    }
	    
	    public boolean equalsIgnoreCase(String otherName){
	        return (otherName == null) ? false: _name.equalsIgnoreCase(otherName);
	    }
	    
	    public String toString() {
	       return _name;
	    }
	}

}
