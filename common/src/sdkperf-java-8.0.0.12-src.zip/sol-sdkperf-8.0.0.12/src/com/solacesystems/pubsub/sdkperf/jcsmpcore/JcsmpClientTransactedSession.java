/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.jcsmpcore;

import com.solacesystems.jcsmp.JCSMPException;
import com.solacesystems.jcsmp.JCSMPProducerEventHandler;
import com.solacesystems.jcsmp.JCSMPStreamingPublishEventHandler;
import com.solacesystems.jcsmp.ProducerEventArgs;
import com.solacesystems.jcsmp.XMLMessageProducer;
import com.solacesystems.jcsmp.transaction.TransactedSession;
import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.AbstractClient;
import com.solacesystems.pubsub.sdkperf.core.AbstractClientTransactedSession;
import com.solacesystems.jcsmp.protocol.nio.impl.ConsumerNotificationDispatcher;










import java.util.concurrent.ArrayBlockingQueue;

public class JcsmpClientTransactedSession extends AbstractClientTransactedSession {

	private TransactedSession transactedSession;
	private XMLMessageProducer _prod = null;
	ConsumerNotificationDispatcher dispatcher;
	
	public JcsmpClientTransactedSession(AbstractClient client, TransactedSession transactedSession, RuntimeProperties rprops) {		
		this.init(client, rprops);
		this.transactedSession = transactedSession;
		this.dispatcher=null;
	}
	
	public TransactedSession getTransactedSession() {
		return transactedSession;
	}
	
	@Override
	public void close() {
		timer.cancel();
		transactedSession.close();
	}

	@Override
	protected void commit(boolean wantRollback) throws Exception {
		numMsgsOnCommit = numMsgsRecv;
		
		if (wantRollback) {
			transactedSession.rollback();
			_client.getRxStats().rollback();
		} else {
			transactedSession.commit();
			_client.getRxStats().commit();
		}
	}

	public void setDispatcher(ConsumerNotificationDispatcher dispatcher) {
		this.dispatcher = dispatcher;
	}
	
	

 public void commitOnDispatcher(boolean wantRollback) throws Exception {
		
		numMsgsOnCommit = numMsgsRecv;
			
		if (dispatcher != null) {
			ArrayBlockingQueue<Object> responseQueue = new ArrayBlockingQueue<Object>(1);
			
			dispatcher.enqueueNonBlockingNotification( new ClientCommitNotification(this, responseQueue, wantRollback) );
			
			Object response = responseQueue.take();
			if (response instanceof Exception) {
				throw (Exception)response;
			}
		} else {
			this.commit(wantRollback);
		}
	}

@Override
public Object getProducer() throws JCSMPException {

	if(_prod == null) {
		_prod = transactedSession.createProducer(null, new JCSMPStreamingPublishEventHandler() {

			public void responseReceived(String arg) {
			}

			public void handleError(String arg0, JCSMPException arg1, long arg2) {
				System.out.println("Received error trying to publish from transacted session.");
			}
		}
		, new JCSMPProducerEventHandler() {

			public void handleEvent(ProducerEventArgs pea) {
				System.out.println(pea);
			}
		});
	}

	return _prod;
}

}
