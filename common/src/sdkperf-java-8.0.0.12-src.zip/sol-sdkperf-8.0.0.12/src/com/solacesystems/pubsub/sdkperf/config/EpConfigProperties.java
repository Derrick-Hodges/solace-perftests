/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.config;

import java.util.List;
import java.util.Vector;

import com.solacesystems.pubsub.sdkperf.core.Constants.EndpointAccessType;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.SubscriberDestinationsType;

/**
 * Contains properties related to endpoint management.
*/
public class EpConfigProperties {

	private List<String> _epNames;
	private List<String> _subscriptions;
	private List<String> _selectors;
	private boolean _isAdding;
	private boolean _wantTopicUnsubscribe;
	private boolean _noLocal;
	private boolean _wantActiveFlowIndication;
	private String _clientName;
	private SubscriberDestinationsType _type;
	private int _numTempEndpoints;
	private boolean _respectTTL;
	private String _transactedSessionName;
	private int _transactionSize;
	private int _discardNotifySender;
	private boolean _isTopic;
	private EndpointAccessType _accessType;
	private int _maxMsgSize;
	private int _quota;
	private String _permission;
	private int _maxMsgRedelivery;
	private boolean _wantCutThroughPersistence;
	private boolean _distributeTopics;
	
	public static EpConfigProperties CreateDefault() {
		return new EpConfigProperties();
	}
	
	public static EpConfigProperties CreateForSubscriptionAdd(
			List<String> subscriptions,
			String clientName,
			SubscriberDestinationsType type
			) {
		EpConfigProperties ret = new EpConfigProperties();
		
		ret.setSubscriptions(subscriptions);
		ret.setIsAdding(true);
	    ret.setClientName(clientName);
	    ret.setType(type);
	    
	    return ret;
	}
	
	public static EpConfigProperties CreateForTopicEpAdd(
			List<String> epNames, 
			List<String> subscriptions,
			List<String> selectors, 
			boolean noLocal,
			String transactedSessionName,
			int transactionSize,
			int discardNotifySender,
			boolean wantCutThroughPersistence
			) {
		
		EpConfigProperties ret = new EpConfigProperties();
		
		ret.setEpNames(epNames);
		ret.setSubscriptions(subscriptions);
		ret.setSelectors(selectors);
		ret.setIsAdding(true);
		ret.setNoLocal(noLocal);
		ret.setType(SubscriberDestinationsType.TOPIC);
		ret.setTransactedSessionName(transactedSessionName);
		ret.setTransactionSize(transactionSize);
		ret.setDiscardNotifySender(discardNotifySender);
		ret.setWantCutThroughPersistence(wantCutThroughPersistence);

	    return ret;
	}
	
	public static EpConfigProperties CreateForQueueEpAdd(
			List<String> epNames, 
			List<String> selectors,
			boolean noLocal,
			String transactedSessionName,
			int transactionSize,
			int discardNotifySender,
			boolean wantActiveFlowIndication,
			boolean wantCutThroughPersistence
			) {
		
		EpConfigProperties ret = new EpConfigProperties();
		
		ret.setEpNames(epNames);
		ret.setSelectors(selectors);
		ret.setIsAdding(true);
		ret.setNoLocal(noLocal);
		ret.setType(SubscriberDestinationsType.QUEUE);
		ret.setTransactedSessionName(transactedSessionName);
		ret.setTransactionSize(transactionSize);
		ret.setDiscardNotifySender(discardNotifySender);
		ret.setWantActiveFlowIndication(wantActiveFlowIndication);
		ret.setWantCutThroughPersistence(wantCutThroughPersistence);
		
	    return ret;
	}
	
	public static EpConfigProperties CreateForTempEpAdd(
			SubscriberDestinationsType type, 
			int numTempEndpoints,
			List<String> subscriptions,
			List<String> selectors,
			int maxMsgSize,
			int quota,
			String permission, 
			boolean respectTTL,
			boolean noLocal,
			String transactedSessionName,
			int transactionSize,
			int discardNotifySender,
			int maxMsgRedelivery,
			boolean wantActiveFlowIndication,
			boolean wantCutThroughPersistence
			
			) {
		
		EpConfigProperties ret = new EpConfigProperties();
		
		ret.setSubscriptions(subscriptions);
		ret.setSelectors(selectors);
		ret.setIsAdding(true);
		ret.setNumTempEndpoints(numTempEndpoints);
		ret.setType(type);
		ret.setMaxMsgSize(maxMsgSize);
		ret.setQuota(quota);
		ret.setPermission(permission);
		ret.setRespectTTL(respectTTL);
		ret.setNoLocal(noLocal);
		ret.setTransactedSessionName(transactedSessionName);
		ret.setTransactionSize(transactionSize);
		ret.setDiscardNotifySender(discardNotifySender);
		ret.setMaxMsgRedelivery(maxMsgRedelivery);
		ret.setWantActiveFlowIndication(wantActiveFlowIndication);
		ret.setWantCutThroughPersistence(wantCutThroughPersistence);
		
	    return ret;
	}
	
	public static EpConfigProperties CreateForSubscriptionRemove(
			List<String> subscriptions,
			String clientName,
			SubscriberDestinationsType type
			) {
		
		EpConfigProperties ret = new EpConfigProperties();
		
		ret.setSubscriptions(subscriptions);
		ret.setIsAdding(false);
		ret.setClientName(clientName);
	    ret.setType(type);
	    
	    return ret;
	}
	
	public static EpConfigProperties CreateForEpRemove(List<String> epNames) {
		
		EpConfigProperties ret = new EpConfigProperties();
		
		ret.setEpNames(epNames);
		ret.setIsAdding(false);
	    
	    return ret;
	}
	
	public static EpConfigProperties CreateForEpProvision(
			List<String> epNames,
			boolean isTopic,
	        boolean isAdding,
	        EndpointAccessType accessType,
	        int maxMsgSize,
	        int quota,
	        String permission, 
	        boolean respectTTL,
	        int discardNotifySender,
	        int maxMsgRedelivery,
	        boolean wantActiveFlowIndication,
	        boolean wantCutThroughPersistence) {
		
		EpConfigProperties ret = new EpConfigProperties();
		
		ret.setEpNames(epNames);
		ret.setIsTopic(isTopic);
		ret.setIsAdding(isAdding);
		ret.setAccessType(accessType);
		ret.setMaxMsgSize(maxMsgSize);
		ret.setQuota(quota);
		ret.setPermission(permission);
		ret.setRespectTTL(respectTTL);
		ret.setDiscardNotifySender(discardNotifySender);
		ret.setMaxMsgRedelivery(maxMsgRedelivery);
		ret.setWantActiveFlowIndication(wantActiveFlowIndication);
		ret.setWantCutThroughPersistence(wantCutThroughPersistence);
	    
	    return ret;
	}	
	
	protected EpConfigProperties() {
		_epNames = new Vector<String>();
		_subscriptions = new Vector<String>();
		_selectors = new Vector<String>();
		_isAdding = false;
		_wantTopicUnsubscribe = false;
		_noLocal = false;
		_clientName = "";
		_type = SubscriberDestinationsType.NULL;
		_numTempEndpoints = 0;
		_respectTTL = false;
		_transactedSessionName = "";
		_transactionSize = 0;
		_discardNotifySender = -1;
		_isTopic = false;
        _accessType = EndpointAccessType.ACCESSTYPE_API_DEFAULT;
        _maxMsgSize = -1;
        _quota = -1;
        _permission = "";
        _maxMsgRedelivery = -1;
        _distributeTopics = false;
	}
	
	
	public EpConfigProperties ( EpConfigProperties input) {
		
		this._epNames = new Vector<String>();
		this._epNames.addAll(input._epNames);
		this._subscriptions = new Vector<String>();
		this._subscriptions.addAll(input._subscriptions);
		this._selectors = new Vector<String>();
		this._selectors.addAll(input._selectors);
		this._isAdding = input._isAdding;
		this._wantTopicUnsubscribe = input._wantTopicUnsubscribe;
		this._noLocal = input._noLocal;
		this._clientName = input._clientName;
		this._type = input._type;
		this._numTempEndpoints = input._numTempEndpoints;
		this._respectTTL = input._respectTTL;
		this._transactedSessionName = input._transactedSessionName;
		this._transactionSize = input._transactionSize;
		this._discardNotifySender = input._discardNotifySender;
		this._isTopic = input._isTopic;
		this._accessType = input._accessType;
        this._maxMsgSize = input._maxMsgSize;
        this._quota = input._quota;
        this._permission = input._permission;
        this._maxMsgRedelivery = input._maxMsgRedelivery;
        this._distributeTopics = input._distributeTopics;
	}


	@Override
	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("EP Names Size         : ").append(_epNames.size()).append("\n");
		buf.append("Subscriptions Size    : ").append(_subscriptions.size()).append("\n");
		buf.append("Selectors Size        : ").append(_selectors.size()).append("\n");
		buf.append("Is Adding             : ").append(_isAdding).append("\n");
		buf.append("Want Topic Unsub      : ").append(_wantTopicUnsubscribe).append("\n");
		buf.append("No Local              : ").append(_noLocal).append("\n");
		buf.append("Client Name           : ").append(_clientName).append("\n");
		buf.append("Type                  : ").append(_type).append("\n");
		buf.append("Num Temp EPs          : ").append(_numTempEndpoints).append("\n");
		buf.append("Respect TTL           : ").append(_respectTTL).append("\n");
		buf.append("Trans Sess Name       : ").append(_transactedSessionName).append("\n");
		buf.append("Trans Size            : ").append(_transactionSize).append("\n");
		buf.append("Discard Notify Sender : ").append(_discardNotifySender).append("\n");
		buf.append("Is Topic              : ").append(_isTopic).append("\n");
		buf.append("Access Type           : ").append(_accessType.toString()).append("\n");
		buf.append("Max Message Size      : ").append(_maxMsgSize).append("\n");
		buf.append("Quota                 : ").append(_quota).append("\n");
		buf.append("Permission            : ").append(_permission).append("\n");
		buf.append("Max Msg Redelivery    : ").append(_maxMsgRedelivery).append("\n");
		buf.append("Cut-through           : ").append(_wantCutThroughPersistence).append("\n");
		buf.append("Distribute Topics     : ").append(_distributeTopics).append("\n");
		
		return buf.toString();
	}

	public List<String> getEpNames() { return _epNames; }
	public void setEpNames(List<String> values) {
		_epNames.clear();
		if (values != null) _epNames.addAll(values);
	}
	
	public List<String> getSubscriptions() { return _subscriptions; }
	public void setSubscriptions(List<String> values) {
		_subscriptions.clear();
		if (values != null) _subscriptions.addAll(values);
	}
	
	public List<String> getSelectors() { return _selectors; }
	public void setSelectors(List<String> values) {
		_selectors.clear();
		if (values != null)  _selectors.addAll(values);
	}
	
	public boolean getIsAdding() { return _isAdding; }
	public void setIsAdding(boolean value) { _isAdding = value; }
	
	public boolean getTopicUnsubscribe() { return _wantTopicUnsubscribe; }
	public void setTopicUnsubscribe(boolean value) { _wantTopicUnsubscribe = value; }
	
	public boolean getNoLocal() { return _noLocal; }
	public void setNoLocal(boolean value) { _noLocal = value; }
	
	public boolean getWantActiveFlowIndication() { return _wantActiveFlowIndication; }
	public void setWantActiveFlowIndication(boolean value) { _wantActiveFlowIndication = value; }
	
	public boolean getWantCutThroughPersistence() { return _wantCutThroughPersistence; }
	public void setWantCutThroughPersistence(boolean value) { _wantCutThroughPersistence = value; }
	
	public String getClientName() { return _clientName; }
	public void setClientName(String value) { _clientName = value; }
	
	public SubscriberDestinationsType getType() { return _type; } 
	public void setType(SubscriberDestinationsType value) { _type = value; }

	public int getNumTempEndpoints() { return _numTempEndpoints; }
	public void setNumTempEndpoints(int value) { _numTempEndpoints = value; }
	
	public boolean getRespectTTL() { return _respectTTL; }
	public void setRespectTTL(boolean value) { _respectTTL = value; }
	
	public String getTransactedSessionName() { return _transactedSessionName; }
	public void setTransactedSessionName(String value) { _transactedSessionName = value; }
	
	public int getTransactionSize() { return _transactionSize; }
	public void setTransactionSize(int value) { _transactionSize = value; }
	
	public int getDiscardNotifySender() { return _discardNotifySender; }
	public void setDiscardNotifySender(int value) { _discardNotifySender = value; }
	
	public boolean getIsTopic() { return _isTopic; }
	public void setIsTopic(boolean value) { _isTopic = value; }
	
	public EndpointAccessType getAccessType() { return _accessType; }
	public void setAccessType(EndpointAccessType value) { _accessType = value; }	
	
	public int getMaxMsgSize() { return _maxMsgSize; }
	public void setMaxMsgSize(int value) { _maxMsgSize = value; }		
	
	public String getPermission() { return _permission; }
	public void setPermission(String value) { _permission = value; }
	
	public int getQuota() { return _quota; }
	public void setQuota(int value) { _quota = value; }	

	public int getMaxMsgRedelivery() { return _maxMsgRedelivery; }
	public void setMaxMsgRedelivery(int value) { _maxMsgRedelivery = value; }
	
	public boolean getDistributeTopics() { return _distributeTopics; }
	public void setDistributeTopics(boolean value) { _distributeTopics = value; }
	
}
