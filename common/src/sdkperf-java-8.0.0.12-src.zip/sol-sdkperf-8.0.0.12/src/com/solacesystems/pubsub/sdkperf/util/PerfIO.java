/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for reading and writing files from disk.
 */
public class PerfIO {

	public static byte[] readFileAsBytes(String fPath) throws IOException {
		File f = new File(fPath);
		if (!f.exists())
			throw new FileNotFoundException(fPath);

		FileInputStream fis = null;
		try {
			fis = new FileInputStream(f);
			int sz = (int) f.length(), read = 0;
			byte[] buf = new byte[sz];
			read = fis.read(buf);
			assert (read == sz);
			return buf;
		} finally {
			if (fis != null)
				fis.close();
		}
	}

	public static List<String> readFileAsLines(
		String fPath, 
		boolean skipComments)
		throws IOException {
		File f = new File(fPath);
		if (!f.exists())
			throw new FileNotFoundException(fPath);

		List<String> ls = new ArrayList<String>();
		BufferedReader r = null;
		try {
			r = new BufferedReader(new FileReader(f));
			String line = null;
			while (true) {
				line = r.readLine();
				if (line == null)
					break;
				if (line.equals("")) // skip empty
					continue;
				if (skipComments && line.charAt(0) == '#')
					continue;
				ls.add(line);
			}
			return ls;
		} finally {
			r.close();
		}
	}
	
	/**
	 * Saves an array of bytes to the specified location
	 * @param location <code>String</code> that holds the file path
	 * @param name <code>String</code> that holds the file name
	 * @param data <code>byte[]</code> that holds the bytes to write
	 * @throws IOException
	 */
    public static synchronized long writeFile(String location, byte[] data) throws IOException {
    	File file = new File(location);
    	FileOutputStream stream = new FileOutputStream(file);
        stream.write(data);
        stream.close();
        return data.length;
    }
}
