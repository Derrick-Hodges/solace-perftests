package com.solacesystems.pubsub.sdkperf.jms.core;

import javax.jms.Connection;
import javax.jms.Session;
import javax.jms.XAConnection;
import javax.jms.XASession;
import javax.naming.InitialContext;

import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.AbstractClient;

public interface JmsSdkperfFactory {

	public InitialContext createInitialContext(RuntimeProperties rxProps,
			int clientIdInt) throws Exception;

	public JmsClientTransactedSession createClientTransactedSession(
			AbstractClient client, Connection connection, Session transactedSession,
			RuntimeProperties rprops);
	
	public JmsClientXaSession createXaTransactedSession(
			AbstractClient client, XAConnection xaConnection, XASession xaSession,
			RuntimeProperties rprops);
}