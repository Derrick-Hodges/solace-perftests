package com.solacesystems.pubsub.sdkperf.jcsmpcore;

import com.solacesystems.pubsub.sdkperf.core.AbstractWrappedMessage;
import com.solacesystems.pubsub.sdkperf.core.GenericMessageDeliveryMode;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.PublisherDestinationsType;
import com.solacesystems.pubsub.sdkperf.util.SdkperfConstants;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.jcsmp.BytesXMLMessage;
import com.solacesystems.jcsmp.DeliveryMode;
import com.solacesystems.jcsmp.Destination;
import com.solacesystems.jcsmp.Queue;
import com.solacesystems.jcsmp.impl.sdt.InteropTest;

public class JcsmpWrappedMessage extends AbstractWrappedMessage {

	BytesXMLMessage _jcsmpMsg;
	private static final Log Trace = LogFactory.getLog(JcsmpWrappedMessage.class);

	
	public JcsmpWrappedMessage(BytesXMLMessage msg) {
		this._jcsmpMsg = msg;
	}

	@Override
	public BytesXMLMessage getMessage() {
		return _jcsmpMsg;
	}
	
	@Override
	public boolean hasXml() {
		if (_jcsmpMsg == null) return false;
		return (_jcsmpMsg.getContentLength() > 0);
	}

	@Override
	public boolean hasAttachment() {
		if (_jcsmpMsg == null) return false;
		return _jcsmpMsg.hasAttachment();
	}

	@Override
	public boolean hasTopic() {
		if (_jcsmpMsg == null) return false;
		// TODO: I suspect this might be a bug, only the destination is checked
		// and we do not verify that the destination is a topic (could be a queue)
		Destination dest = _jcsmpMsg.getDestination();
		return (dest != null);
	}
	

	@Override
	public String getDestinationName() {
		if (_jcsmpMsg == null || _jcsmpMsg.getDestination() == null) return null;
		return _jcsmpMsg.getDestination().getName();
	}

	@Override
	public PublisherDestinationsType getDestinationType() {
		if (_jcsmpMsg == null || _jcsmpMsg.getDestination() == null) return null;

		if (_jcsmpMsg.getDestination() instanceof Queue)
			return PublisherDestinationsType.QUEUE;
		else
			return PublisherDestinationsType.TOPIC;
	}
	
	@Override
	public String getReplyToDestinationName() {
		if (_jcsmpMsg == null || _jcsmpMsg.getReplyTo() == null) return null;
		return _jcsmpMsg.getReplyTo().getName();
	}

	@Override
	public PublisherDestinationsType getReplyToDestinationType() {
		if (_jcsmpMsg == null || _jcsmpMsg.getReplyTo() == null) return null;

		if (_jcsmpMsg.getReplyTo() instanceof Queue)
			return PublisherDestinationsType.QUEUE;
		else
			return PublisherDestinationsType.TOPIC;

	}

	@Override
	public GenericMessageDeliveryMode getDeliveryMode() {
		if (_jcsmpMsg == null || _jcsmpMsg.getDeliveryMode() == null) return null;
		
		if(_jcsmpMsg.getDeliveryMode() == DeliveryMode.PERSISTENT)
		    return GenericMessageDeliveryMode.PERSISTENT;
		else if(_jcsmpMsg.getDeliveryMode() == DeliveryMode.NON_PERSISTENT)
			return GenericMessageDeliveryMode.NON_PERSISTENT;
		else if(_jcsmpMsg.getDeliveryMode() == DeliveryMode.DIRECT)
			return GenericMessageDeliveryMode.DIRECT;
		else
			throw new RuntimeException("Unknown Delivery Mode set on JCSMP message: " + _jcsmpMsg.getDeliveryMode());
	}

	@Override
	public boolean hasReplyToDestination() {
		if (_jcsmpMsg == null) return false;
		Destination dest = _jcsmpMsg.getReplyTo();
		return (dest != null);
	}

	@Override
	public byte[] getXmlBytes() {
		if (_jcsmpMsg == null) return null;
		byte[] bytes = new byte[_jcsmpMsg.getContentLength()]; 
		_jcsmpMsg.readContentBytes(bytes);
		return bytes;
	}

	@Override
	public byte[] getAttachmentBytes() {
		if (_jcsmpMsg == null) return null;
		byte[] attachmentBytes = new byte[_jcsmpMsg.getAttachmentContentLength()]; 
		_jcsmpMsg.readAttachmentBytes(attachmentBytes);
		return attachmentBytes;
	}

	@Override
	public byte[] getUserdata() {
		if (_jcsmpMsg == null) return null;
		return _jcsmpMsg.getUserData();
	}

	@Override
	public List<Long> getCids() {
		if (_jcsmpMsg == null) return null;
		return _jcsmpMsg.getConsumerIdList();
	}

	@Override
	public boolean getRedelivered() {
		if (_jcsmpMsg == null) return false;
		return _jcsmpMsg.getRedelivered();
	}

	@Override
	public boolean validateStructDataMsg() {
		boolean rc = false;
		try {
			byte[] userData = _jcsmpMsg.getUserData();
			if ((userData == null) || (userData.length == 0)) {
	            Trace.error("No test number specified in Message user data");
	        }
	        
			if (userData != null && (int)userData[0] < SdkperfConstants.SDM_ID_USER_DEF_BASE) {
				
	            InteropTest.validateRecvMsg(_jcsmpMsg);
	            rc = true;
			} else {
		        // As a future feature we will be able to parse and check
				// messages based on a structured input file.  These
				// messages will have ID's starting at USER_DEF_BASE.
				Trace.debug("Ignoring messages >= " +  SdkperfConstants.SDM_ID_USER_DEF_BASE + 
						" as we can not yet parse these.");
				rc = true;
			}
        } catch(IllegalArgumentException e) {
        	Trace.error(e.getMessage(), e);
        }
        return rc;
	}

	@Override
	public boolean isCacheMessage() {
		if (_jcsmpMsg == null) return false;
		
		if (_jcsmpMsg.isCacheMessage()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean isSuspect() {
		if (_jcsmpMsg == null) return false;
		
		if (_jcsmpMsg.isSuspect()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public String dump() {
		if (_jcsmpMsg == null) {
			Trace.error("Unable to print null message.");
			return null;
		}
		
		return _jcsmpMsg.dump();
	}

	@Override
	public byte[] getMessageAsBytes() throws Exception {
		Trace.error("Method getMessageAsBytes() not supported for this message type.");
		return new byte[0];
	}

	@Override
	public boolean hasDiscardIndication() {
		if (_jcsmpMsg == null) {
			Trace.error("Unable to check DI on null message.");
			return false;
		}
		
		return _jcsmpMsg.getDiscardIndication();
	}

	@Override
	public Long getTopicSequence() {
		if (_jcsmpMsg == null) {
			Trace.error("Unable to get topic sequence with null message.");
			return null;
		}
		
		return _jcsmpMsg.getTopicSequenceNumber();
	}


}
