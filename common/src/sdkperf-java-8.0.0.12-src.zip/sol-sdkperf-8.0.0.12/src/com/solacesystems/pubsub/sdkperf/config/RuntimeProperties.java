/** 
 *  Copyright 2009-2017 Solace Corporation. All rights reserved.
 *  
 *  http://www.solacesystems.com
 *  
 *  This source is distributed WITHOUT ANY WARRANTY or support;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 *  A PARTICULAR PURPOSE.  All parts of this program are subject to
 *  change without notice including the program's CLI options.
 *
 *  Unlimited use and re-distribution of this unmodified source code is   
 *  authorized only with written permission.  Use of part or modified  
 *  source code must carry prominent notices stating that you modified it, 
 *  and give a relevant date.
 */
package com.solacesystems.pubsub.sdkperf.config;

import java.util.Set;

import com.solacesystems.common.ObjectPropertySet;

/**
 * Set of configuration properties used by the sdkperf application; these can be
 * either parsed out of CLI arguments or configured through XML-RPC. Generally,
 * this class is created and initialized by RuntimePropertiesBuilder.
 * 
 */
public class RuntimeProperties extends ObjectPropertySet implements Cloneable {

	public static final String REQUEST_REPLY_WAIT_TIME = "REQUEST_REPLY_WAIT_TIME";
	public static final String NUM_CLIENTS = "NUM_CLIENTS";
	public static final String NUM_CONTEXT_THREADS = "NUM_CONTEXT_THREADS";
	public static final String NUM_PUB_THREADS = "NUM_PUB_THREADS";
	public static final String NUM_PUBS_PER_SESSION = "NUM_PUBS_PER_SESSION";
	public static final String PUBLISH_END_DELAY_IN_SEC = "PUBLISH_END_DELAY_IN_SEC";
	public static final String PUBLISH_RATE_PER_PUB = "PUBLISH_RATE_PER_PUB";
	public static final String NUM_MSGS_TO_PUBLISH = "NUM_MSGS_TO_PUBLISH";
	public static final String XML_PAYLOAD_SIZE_LIST = "XML_PAYLOAD_SIZE_LIST";
	public static final String ATTACHMENT_SIZE_LIST = "ATTACHMENT_SIZE_LIST";
	public static final String CLIENT_IP_ADDR = "CLIENT_IP_ADDR";
	public static final String CLIENT_USERNAME = "CLIENT_USERNAME";
	public static final String CLIENT_VPN = "CLIENT_VPN";
	public static final String CLIENT_NAME_PREFIX = "CLIENT_NAME_PREFIX";
	public static final String CHANGE_CLIENT_NAMES_FLAG = "CHANGE_CLIENT_NAMES_FLAG";
	public static final String CLIENT_PASSWORD = "CLIENT_PASSWORD";
	public static final String CLIENT_DESCRIPTION = "CLIENT_DESCRIPTION";
	public static final String CLIENT_DTO_LOCAL_PRIORITY = "CLIENT_DTO_LOCAL_PRIORITY";
	public static final String CLIENT_DTO_NETWORK_PRIORITY = "CLIENT_DTO_NETWORK_PRIORITY";
	public static final String CLIENT_COMPRESSION_LEVEL = "CLIENT_COMPRESSION_LEVEL";
	public static final String WANT_TCP_NODELAY = "WANT_TCP_NODELAY";
	public static final String PUBLISH_FILE_LIST = "PUBLISH_FILE_LIST";
	public static final String PUBLISH_ATTACH_LIST = "PUBLISH_ATTACH_LIST";
	public static final String SMF_BINARY_FILE_LIST = "SMF_BINARY_FILE_LIST";
	public static final String SUBSCRIPTION_REFRESH = "SUBSCRIPTION_REFRESH";
	public static final String PUBLISH_TOPIC_LIST = "PUBLISH_TOPIC_LIST";
	public static final String PUBLISH_QUEUE_LIST = "PUBLISH_QUEUE_LIST";
	public static final String NUM_MESSAGE_PRODUCER = "NUM_MESSAGE_PRODUCER";
	public static final String SELECTOR_LIST = "SELECTOR_LIST";
	public static final String WANT_REMOVE_SUBSCRIBER = "WANT_REMOVE_SUBSCRIBER";
	public static final String WANT_SUBSCRIPTION_MEMORY = "WANT_SUBSCRIPTION_MEMORY";
	public static final String WANT_PER_SUB_THRU_STATS = "WANT_PER_SUB_THRU_STATS";
	public static final String WANT_SUBSCRIPTION_RATE_STATS = "WANT_SUBSCRIPTION_RATE_STATS";
	public static final String AD_PUB_WINDOW_SIZE = "AD_PUB_WINDOW_SIZE";
	public static final String AD_PUB_ACK_TIMEOUT = "AD_PUB_ACK_TIMEOUT";
	public static final String AD_SUB_WINDOW_SIZE = "AD_SUB_WINDOW_SIZE";
	public static final String AD_SUB_ACK_TIMEOUT = "AD_SUB_ACK_TIMEOUT";
	public static final String AD_SUB_WINDOW_THRESHOLD = "AD_SUB_WINDOW_THRESHOLD";
	public static final String AD_TRANSACTION_SIZE = "AD_TRANSACTION_SIZE";
	public static final String AD_WANT_XA_TRANSACTION = "AD_WANT_XA_TRANSACTION";
	public static final String XA_WANT_ONE_PHASE_COMMIT_TRANSACTION = "XA_WANT_ONE_PHASE_COMMIT_TRANSACTION";
	public static final String XA_NUM_MSGS_PER_TRANSACTION_SEGMENT = "XA_NUM_MSGS_PER_TRANSACTION_SEGMENT";
	public static final String XA_NUM_SUSPENDED_TRANSACTIONS = "XA_NUM_SUSPENDED_TRANSACTIONS";
	public static final String AD_WANT_PRODUCER_CONSUMERS_TRANSACTION = "AD_WANT_PRODUCER_CONSUMERS_TRANSACTION";
	public static final String XA_TRANSACTION_IDLE_TIMEOUT = "XA_TRANSACTION_IDLE_TIMEOUT";
	public static final String XA_TRANSACTION_PHASE_DELAY_BEFORE_SUSPENDING = "XA_TRANSACTION_PHASE_DELAY_BEFORE_SUSPENDING";
	public static final String XA_TRANSACTION_PHASE_DELAY_BEFORE_ENDING = "XA_TRANSACTION_PHASE_DELAY_BEFORE_ENDING";
	public static final String XA_TRANSACTION_PHASE_DELAY_BEFORE_PREPARING = "XA_TRANSACTION_PHASE_DELAY_BEFORE_PREPARING";
	public static final String XA_TRANSACTION_PHASE_DELAY_BEFORE_COMMITTING = "XA_TRANSACTION_PHASE_DELAY_BEFORE_COMMITTING";
	public static final String AD_TRANSACTION_IDLE_TIME = "AD_TRANSACTION_IDLE_TIME";
	public static final String AD_TRANSACTION_ROLLBACK_INTERVAL = "AD_TRANSACTION_ROLLBACK_INTERVAL";
	public static final String AD_WANT_ACTIVE_FLOW_INDICATION = "AD_WANT_ACTIVE_FLOW_INDICATION";
	public static final String AD_ACK_IMMEDIATELY_INTERVAL = "AD_ACK_IMMEDIATELY_INTERVAL";
	public static final String AD_ACK_EVENT_MODE = "AD_ACK_EVENT_MODE";
	public static final String AD_WANT_PUB_ACK_ORDER_CHECK = "AD_WANT_PUB_ACK_ORDER_CHECK";
	public static final String CID_STATS = "CID_STATS";
	public static final String WANT_DI_STATS = "WANT_DI_STATS";
	public static final String AD_PUB_MAX_RESEND = "AD_PUB_MAX_RESEND";
	public static final String WANT_VERBOSE = "WANT_VERBOSE";
	public static final String WANT_QUIET = "WANT_QUIET";
	public static final String WANT_UD = "WANT_UD";
	public static final String WANT_SYNC_RECEIVE = "WANT_SYNC_RECEIVE";
	public static final String PUB_MESSAGE_TYPE = "PUB_MESSAGE_TYPE";
	public static final String WANT_SMOOTH_PUB_CALC_LAT = "WANT_SMOOTH_PUB_CALC_LAT";
	public static final String WANT_STRUCT_MSG_CHECK = "WANT_STRUCT_MSG_CHECK";
	public static final String STRUCT_DATA_MSGS_LIST = "STRUCT_DATA_MSGS_LIST";
	public static final String SUB_NOTIFICATION_QUEUE_DEPTH = "SUB_NOTIFICATION_QUEUE_DEPTH";
	public static final String PUBLISH_COS = "PUBLISH_COS";
	public static final String PUBLISH_TO_ONE = "PUBLISH_TO_ONE";
	public static final String BURST_DURATION = "BURST_DURATION";
	public static final String INTER_BURST_DURATION = "INTER_BURST_DURATION";
	public static final String PUB_SEND_VECT_SIZE = "PUB_SEND_VECT_SIZE";
	public static final String MSG_DMQ_ELIGIBLE = "MSG_DMQ_ELIGIBLE";
	public static final String MSG_TTL = "MSG_TTL";
	public static final String MSG_ELIDING_ELIGIBLE = "MSG_ELIDING_ELIGIBLE";
	public static final String PUB_STREAM_ID_OFFSET = "PUB_STREAM_ID_OFFSET";
	public static final String PUB_ORDER_OFFSET = "PUB_ORDER_OFFSET";
	public static final String SUBSCRIPTION_CLIENT_NAME = "SUBSCRIPTION_CLIENT_NAME";
	public static final String MSG_RATE_IS_MAX = "MSG_RATE_IS_MAX";
	public static final String IGNORE_EXISTS_ERRORS = "IGNORE_EXISTS_ERRORS";
	public static final String SUB_MSG_QUEUE_DEPTH = "SUB_MSG_QUEUE_DEPTH";
	public static final String WANT_CLIENT_ACK = "WANT_CLIENT_ACK";
	public static final String WANT_CLIENT_ACK_THREAD = "WANT_CLIENT_ACK_THREAD";
	public static final String CLIENT_ACK_SKIP_NUM = "CLIENT_ACK_SKIP_NUM";
	public static final String CLIENT_ACK_FLUSH_QUEUE = "CLIENT_ACK_FLUSH_QUEUE";
	public static final String CLIENT_ACK_QUEUE_REVERSE = "CLIENT_ACK_QUEUE_REVERSE";
	public static final String CLIENT_ACK_RANDOM_DEPTH = "CLIENT_ACK_RANDOM_DEPTH";
	public static final String TRANSACTED_SESSION_NAME_LIST = "TRANSACTED_SESSION_NAME_LIST";
	public static final String WEB_TRANSPORT_PROTOCOL = "WEB_TRANSPORT_PROTOCOL";
	public static final String WEB_TRANSPORT_PROTOCOL_LIST = "WEB_TRANSPORT_PROTOCOL_LIST";
	public static final String TRANSPORT_PROTOCOL_DOWNGRADE_TIMEOUT_MS = "TRANSPORT_PROTOCOL_DOWNGRADE_TIMEOUT_MS";
	public static final String SKIP_FINAL_COMMIT = "SKIP_FINAL_COMMIT";
	
	// PubSubTools can request the details of the last message received
	public static final String WANT_PER_MESSAGE_DETAILS = "WANT_PER_MESSAGE_DETAILS";
	

	// Provisioning of Endpoints
	public static final String WANT_PROVISIONED_ENDPOINT = "WANT_PROVISIONED_ENDPOINT";
	public static final String PE_PERMISSION = "PE_PERMISSION";
	public static final String PE_ACCESS_TYPE = "PE_ACCESS_TYPE";
	public static final String PE_QUOTA_MB = "PE_QUOTA_MB";
	public static final String PE_MAXMSG_SIZE = "PE_MAXMSG_SIZE";
	public static final String PE_RESPECT_TTL = "PE_RESPECT_TTL";
	public static final String DISCARD_NOTIFY_SENDER = "DISCARD_NOTIFY_SENDER";
	public static final String PE_MAX_MSG_REDELIVERY = "PE_MAX_MSG_REDELIVERY";
	
	// Destination parameters.
	public static final String SUB_DESTINATION_TYPE = "SUB_DESTINATION_TYPE";
	//public static final String SUB_XPE_LISTS = "SUB_XPE_LISTS";
	public static final String SUB_TOPIC_LISTS = "SUB_TOPIC_LISTS";
	public static final String SUB_DTE_LISTS = "SUB_DTE_LISTS";
	public static final String SUB_QUEUE_LISTS = "SUB_QUEUE_LISTS";
	public static final String NUM_TEMP_QUEUE_ENDPOINTS = "NUM_TEMP_QUEUE_ENDPOINTS";
	public static final String NUM_TEMP_TOPIC_ENDPOINTS = "NUM_TEMP_TOPIC_ENDPOINTS";
	public static final String WANT_NO_LOCAL = "WANT_NO_LOCAL";

	public static final String WANT_VERSIONPRINT = "WANT_VERSIONPRINT";
	public static final String WANT_MESSAGE_EXAMINE_CONTENT = "WANT_MESSAGE_EXAMINE_CONTENT";
	public static final String WANT_ORDER_CHECK = "WANT_ORDER_CHECK";
	public static final String WANT_LOSS_AND_DUPLICATE_DETECTION = "WANT_LOSS_AND_DUPLICATE_DETECTION";
	public static final String WANT_ORDER_MEMORY = "WANT_ORDER_MEMORY";
	public static final String WANT_PAYLOAD_CHECK = "WANT_PAYLOAD_CHECK";
	public static final String OPTION_FILE = "OPTION_FILE";

	// Latency Params
	public static final String WANT_LATENCY = "WANT_LATENCY";
	public static final String WANT_FULL_LATENCY_STATS = "WANT_FULL_LATENCY_STATS";
	public static final String LATENCY_BUCKETS = "LATENCY_BUCKETS";
	public static final String LATENCY_GRANULARITY = "LATENCY_GRANULARITY";
	public static final String LATENCY_WARMUP_IN_SECS = "LATENCY_WARMUP_IN_SECS";

	// JMS Specific properties.
	public static final String JMS_SUBACK_MODE = "JMS_SUBACK_MODE";
	public static final String JMS_CONNECTION_FACTORY = "jms-connection-factory";
	public static final String WANT_JNDI_FOR_JMS = "WANT_JNDI_FOR_JMS";
	public static final String SOLACE_JMS_OPTIMIZE_DIRECT = "SOLACE_JMS_OPTIMIZE_DIRECT";
	public static final String APPLICATION_SERVER_RA_TRANSACTION = "APPLICATION_SERVER_RA_TRANSACTION";

	public static final String SUBSCRIBER_SUB_DELAY = "SUBSCRIBER_SUB_DELAY";
	public static final String SLOW_SUB_DELAY_COUNT = "SLOW_SUB_DELAY_COUNT";
	public static final String SUBSCRIBER_RATE_INTERVAL = "SUBSCRIBER_RATE_INTERVAL";

	// Cache Properties
	public static final String CACHE_PROP_NAME = "CACHE_PROP_NAME";
	public static final String CACHE_PROP_MAX_MSGS_PER_TOPIC = "CACHE_PROP_MAX_MSGS_PER_TOPIC";
	public static final String CACHE_PROP_MAX_AGE = "CACHE_PROP_MAX_AGE";
	public static final String CACHE_PROP_TIMEOUT_IN_MSEC = "CACHE_PROP_TIMEOUT_IN_MSEC";
	public static final String CACHE_WANT_REQUESTS_ON_SUBSCRIBE = "CACHE_WANT_REQUESTS_ON_SUBSCRIBE";
	public static final String CACHE_REQ_MSG_RATE = "CACHE_REQ_MSG_RATE";
	public static final String CACHE_NUM_REQ = "CACHE_NUM_REQ";
	public static final String CACHE_LIVE_DATA_ACTION = "CACHE_LIVE_DATA_ACTION";
	public static final String CACHE_WANT_STATS = "CACHE_WANT_STATS";
	public static final String CACHE_REQ_MIN_SEQUENCE_NUM = "CACHE_REQ_MIN_SEQUENCE_NUM";
	public static final String CACHE_REQ_MAX_SEQUENCE_NUM = "CACHE_REQ_MAX_SEQUENCE_NUM";
	public static final String CACHE_REQ_WAIT_FOR_CONFIRM = "CACHE_REQ_WAIT_FOR_CONFIRM";
	
	// SSL Properties
	public static final String SSL_PROTOCOL = "SSL_PROTOCOL";
	public static final String SSL_CONNECTION_DOWNGRADE_TO = "SSL_CONNECTION_DOWNGRADE_TO";
	public static final String SSL_EXLCUDED_PROTOCOLS = "SSL_EXLCUDED_PROTOCOLS";
	public static final String SSL_CLIENT_CERTIFICATE_FILE = "SSL_CLIENT_CERTIFICATE_FILE";
	public static final String SSL_CLIENT_PRIVATE_KEY_FILE = "SSL_CLIENT_PRIVATE_KEY_FILE";
	public static final String SSL_CLIENT_PRIVATE_KEY_FILE_PASSWORD = "SSL_CLIENT_PRIVATE_KEY_FILE_PASSWORD";
	public static final String SSL_VALIDATE_CERTIFICATE = "SSL_VALIDATE_CERTIFICATE";
	public static final String SSL_VALIDATE_CERTIFICATE_DATE = "SSL_VALIDATE_CERTIFICATE_DATE";
	public static final String SSL_CIPHER_SUITES = "SSL_CIPHER_SUITES";
	public static final String SSL_TRUST_STORE = "SSL_TRUST_STORE";
	public static final String SSL_TRUST_STORE_DIR = "SSL_TRUST_STORE_DIR";
	public static final String SSL_TRUST_STORE_PASSWORD = "SSL_TRUST_STORE_PASSWORD";
	public static final String SSL_TRUST_STORE_FORMAT = "SSL_TRUST_STORE_FORMAT";
	public static final String SSL_TRUSTED_COMMON_NAME_LIST = "SSL_TRUSTED_COMMON_NAME_LIST";
	public static final String SSL_KEY_STORE = "SSL_KEY_STORE";
	public static final String SSL_KEY_STORE_PASSWORD = "SSL_KEY_STORE_PASSWORD";
	public static final String SSL_KEY_STORE_FORMAT = "SSL_KEY_STORE_FORMAT";
	public static final String SSL_PRIVATE_KEY_ALIAS = "SSL_PRIVATE_KEY_ALIAS";
	public static final String SSL_PRIVATE_KEY_PASSWORD = "SSL_PRIVATE_KEY_PASSWORD";
	public static final String SSL_REST_KEY_STORE="SSL_REST_KEY_STORE";
	public static final String SSL_REST_KEY_STORE_PASSWORD ="SSL_REST_KEY_STORE_PASSWORD";
	public static final String SSL_REST_TRUST_STORE = "SSL_REST_TRUST_STORE";
	public static final String SSL_REST_TRUST_STORE_PASSWORD = "SSL_REST_TRUST_STORE_PASSWORD";
	public static final String SSL_REST_PRIVATE_KEY_PASSWORD="SSL_REST_PRIVATE_KEY_PASSWORD";
	
	
	public static final String AUTHENTICATION_SCHEME = "AUTHENTICATION_SCHEME";
	
	// Channel properties
	public static final String READ_TIMEOUT_IN_MSEC = "READ_TIMEOUT_IN_MSEC";
	public static final String KEEPALIVE_INTERVAL_MSEC = "KEEPALIVE_INTERVAL_MSEC";
	public static final String RECONNECT_ATTEMPTS = "RECONNECT_ATTEMPTS";
	public static final String RECONNECT_FAIL_ACTION = "RECONNECT_FAIL_ACTION";
	public static final String RECONNECT_INTERVAL_MSEC = "RECONNECT_INTERVAL_MSEC";

	// Queue Browsing properties
	public static final String WANT_QUEUE_BROWSER = "WANT_QUEUE_BROWSER";
	public static final String QB_DELETE_FREQUENCY = "QB_DELETE_FREQUENCY";
	public static final String QB_DELETE_BUFFER = "QB_DELETE_BUFFER";
	
	// Web Messaging SDK
	public static final String WEB_MESSAGING_GOTO_URL = "WEB_MESSAGING_GOTO_URL";
	public static final String WEB_MESSAGING_BROWSER_TYPE = "WEB_MESSAGING_BROWSER_TYPE";
	public static final String WEB_MESSAGING_TRANSPORT_SCHEME = "WEB_MESSAGING_TRANSPORT_SCHEME";
	public static final String WEB_MESSAGING_USE_PROXY = "WEB_MESSAGING_USE_PROXY";
	public static final String WANT_DISPATCH_SESSION = "WANT_DISPATCH_SESSION";
	public static final String WEB_MESSAGING_SEND_BUFFER_MAX_SIZE = "WEB_MESSAGING_SEND_BUFFER_MAX_SIZE";
	public static final String WEB_MESSAGING_MAX_WEB_PAYLOAD = "WEB_MESSAGING_MAX_WEB_PAYLOAD";
	
	// General Properties
	public static final String WANT_CONTEXT_PER_CIENT = "WANT_CONTEXT_PER_CIENT";
	public static final String WANT_STOP_ON_ERROR = "WANT_STOP_ON_ERROR";
	public static final String EXTRA_PROP_LIST = "EXTRA_PROP_LIST";
	public static final String WANT_MSG_DUMP = "WANT_MSG_DUMP";
	public static final String MSG_DUMP_DIR = "MSG_DUMP_DIR";
	public static final String CLIENT_MODE = "CLIENT_MODE"; // tied to reflection options
	public static final String WANT_MSG_REFLECT = "WANT_MSG_REFLECT";	
	public static final String WANT_USER_PROP_TOOL_DATA = "WANT_USER_PROP_TOOL_DATA";
	public static final String WANT_NON_BLOCKING_CONNECT = "WANT_NON_BLOCKING_CONNECT";
	
    public static final String MESSAGE_CALLBACK_ON_REACTOR = "MESSAGE_CALLBACK_ON_REACTOR";
    public static final String WANT_REPLY_TOPIC = "WANT_REPLY_TOPIC";
    public static final String WANT_REPLY_TEMPORARY_QUEUE = "WANT_REPLY_TEMPORARY_QUEUE";
    public static final String REPLY_TO_POSTFIX = "REPLY_TO_POSTFIX";
    public static final String REPLY_TO_STRING = "REPLY_TO_STRING";
    public static final String WANT_REPLICATION_RECONNECT = "WANT_REPLICATION_RECONNECT";
    public static final String WANT_CUT_THROUGH_PERSISTENCE = "WANT_CUT_THROUGH_PERSISTENCE";
    
	public static final String TOOL_MODE = "TOOL_MODE";
	public static final String API_MODE = "API_MODE";
	public static final String TOOL_THIRD_PARTY_EXTERNAL_CLIENT_CLASS = "TOOL_THIRD_PARTY_EXTERNAL_CLIENT_CLASS";
	
	// Runtime properties for "Publish On Receive" feature
    public static final String NUMBER_OF_MSGS_TO_PUB_ON_RCV = "NUMBER_OF_MSGS_TO_PUB_ON_RCV";
    public static final String POR_TOPIC_LIST = "POR_TOPIC_LIST";
    public static final String POR_QUEUE_LIST = "POR_QUEUE_LIST";
    public static final String POR_MESSAGE_TYPE = "POR_MESSAGE_TYPE";
    public static final String POR_ATTACHMENT_SIZE_LIST = "POR_ATTACHMENT_SIZE_LIST";
    public static final String POR_REFLECT_MESSAGE = "POR_REFLECT_MESSAGE";
	
	// For interaction with an application server
	public static final String APPLICATION_SERVER_COMMAND = "APPLICATION_SERVER_COMMAND";
	
	// REST specific RuntimeProperties
	public static final String SERVER_PORT_LIST = "SERVER_PORT_LIST";
	public static final String RESTCLIENT_MODE = "RESTCLIENT_MODE";
	public static final String REST_DATA_MODE = "REST_DATA_MODE";
	public static final String RESTSERVER_CONNECTION_TYPE="RESTSERVER_CONNECTION_TYPE";
	public static final String REST_IP_LIST="REST_IP_LIST";
	public static final String RESTSERVER_PROB_RESP="RESTSERVER_PROB_RESP"; 
	public static final String MESSAGE_REPLY_DELAY_LIST ="MESSAGE_REPLY_DELAY_LIST";
	
	//MQTT specific RuntimeProperties
	public static final String MQTT_PUBLISH_QOS = "MQTT_PUBLISH_QOS";
	// TODO: MQTT_PUBLISH_RETAIN
	public static final String MQTT_SUBSCRIBE_QOS = "MQTT_SUBSCRIBE_QOS";
	public static final String MQTT_WILL_TOPIC = "MQTT_WILL_TOPIC";
	public static final String MQTT_WILL_QOS = "MQTT_WILL_QOS";
	public static final String MQTT_WILL_RETAINED = "MQTT_WILL_RETAINED";
	public static final String MQTT_WILL_MSG_SIZE = "MQTT_WILL_MSG_SIZE";
	public static final String MQTT_WANT_CLEAN_CONNECT = "MQTT_WANT_CLEAN_CONNECT";
	
	// JMS specific RuntimeProperties
	public static final String  CUSTOM_PROPERTIES_LIST = "CUSTOM_PROPERTIES_LIST";
	
	//Abstract Api Switch RuntimeProperties
	public static final String CLIENT_VERSION="CLIENT_VERSION";
	
	// HTTP Properties
	public static final String HTTP_CONTENT_ENCODING = "HTTP_CONTENT_ENCODING";
	public static final String HTTP_CONTENT_TYPE = "HTTP_CONTENT_TYPE";



	/*
	 * The default constructor is only visible to the config package, to allow
	 * construction only by the builder (no app-level access).
	 */
	protected RuntimeProperties() {
	}
	
	@Override
	public Object clone() {

		Set<String> names = this.propertyNames();
		// Perform a shallow copy of the hashMap		
		try {
			RuntimeProperties output = (RuntimeProperties) super.clone();
			for(String name : names) {
				output.setProperty(name, this.getProperty(name));			
			}
			return (Object) output;
		}
		catch (CloneNotSupportedException e) {
			throw new AssertionError(e.toString());
		}
	}
	
}
