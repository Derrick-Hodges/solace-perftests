package com.solacesystems.pubsub.sdkperf.core;

/**
 * Appliance capabilities that could vary depending on the Solace appliance platform. 
 */

import com.solacesystems.common.SolReserved;

public enum GenericCapabilityType {
	/**
	 * [SolReserved] Session allows Guaranteed delivery publisher flows. Type:
	 * Boolean.
	 */
	@SolReserved
	PUB_FLOW_GUARANTEED,
	/**
	 * Session allows Guaranteed message publishing. Type: Boolean.
	 */
	PUB_GUARANTEED,
	/**
	 * Session allows creation of temporary Endpoints (Queues / TopicEndpoints).
	 * Type: Boolean.
	 */
	TEMP_ENDPOINT,
	/**
	 * Session allows binding a Guaranteed delivery flow to an Endpoint. Type:
	 * Boolean.
	 */
	SUB_FLOW_GUARANTEED,
	/**
	 * Session accepts compressed (DEFLATE) data. Type: Boolean.
	 */
	COMPRESSION,
	/**
	 * Session accepts JNDI queries. Type: Boolean.
	 */
	JNDI,
	/**
	 * Maximum size of a Direct message (in bytes), including all optional message
	 * headers and data. Type: Integer.
	 */
	MAX_DIRECT_MSG_SIZE,
	/**
	 * Maximum size of a Guaranteed message (in bytes), including all optional
	 * message headers and data. Type: Integer.
	 */
	MAX_GUARANTEED_MSG_SIZE,
	/**
	 * Type of the port the client has connected to (currently "Ethernet").
	 * Type: String.
	 */
	PEER_PORT_TYPE,
	/**
	 * Speed (in Mbps) of the port the client connects to. Type: Integer.
	 */
	PEER_PORT_SPEED,
	/**
	 * Peer's software load version. Type: String.
	 */
	PEER_SOFTWARE_VERSION,
	/**
	 * Peer's software release date. Type: String.
	 */
	PEER_SOFTWARE_DATE,
	/**
	 * Peer's platform. Type: String.
	 */
	PEER_PLATFORM,
	/**
	 * Peer's router name. Type: String.
	 * 
	 * This property is useful when sending SEMP requests to a peer's SEMP
	 * topic, which may be constructed as '
	 * <code>#P2P/routername/#client/SEMP</code>'.
	 */
	PEER_ROUTER_NAME,
	/**
	 * Session supports XPath Expression subscriptions. Type: Boolean.
	 */
	SUPPORTS_XPE_SUBSCRIPTIONS,
	/**
	 * Peer supports creating message Browsers on Endpoints. Type: Boolean.
	 */
	BROWSER,
	/**
	 * Peer allows Endpoint create/delete and supports Endpoint permissions.
	 * Type: Boolean.
	 */
	ENDPOINT_MANAGEMENT,
	/**
	 * Peer supports specifying message selectors on flows and Browsers. Type:
	 * Boolean.
	 */
	SELECTOR, 
	/**
	 * Peer supports time to live (TTL) expiry on Guaranteed messages spooled to
	 * Endpoints.
	 * 
	 * @see XMLMessage#setTimeToLive(long)
	 */
	ENDPOINT_MESSAGE_TTL,
	/**
	 * Peer supports adding subscriptions to Queue Endpoints.
	 */
	QUEUE_SUBSCRIPTIONS,
	/**
	 * [SolReserved] Peer supports the flow recover operation. (Unimplemented)
	 */
	@SolReserved
	FLOW_RECOVER,
	/**
	 * Peer supports subscription manager operations (add / remove subscriptions
	 * on behalf of client name).
	 */
	SUBSCRIPTION_MANAGER,
	/**
	 * Peer supports message eliding.
	 */
	MESSAGE_ELIDING,
	/**
	 * [SolReserved] Peer supports transacted sessions.
	 * @since 5.1
	 */
	@SolReserved
	TRANSACTED_SESSIONS,
	/**
	 * Peer supports NoLocal option (client may avoid receiving messages
	 * published by itself). See {@link JCSMPProperties#NO_LOCAL}.
	 */
	NO_LOCAL,
	/**
	 * @deprecated Use {@link CapabilityType#ACTIVE_FLOW_INDICATION} 
	 * Peer supports Flow Change Updates.
	 */
	FLOW_CHANGE_UPDATES,
	/**
	 * Peer supports per topic sequence numbering.
	 */
	PER_TOPIC_SEQUENCE_NUMBERING,
	/**
	 * Peer supports configurable endpoint discard behavior.
	 * 
	 * @see EndpointProperties#setDiscardBehavior(Integer)
	 */
	ENDPOINT_DISCARD_BEHAVIOR,
	/**
	 * Peer supports cut-through guaranteed messaging.
	 */
	CUT_THROUGH,
	/**
	 * Peer supports active flow indication. Type: Boolean.
	 */
	ACTIVE_FLOW_INDICATION,
	
	// Used mainly for JMS where a connection is needed
	// before the API version can be fetched (reference: bug #47491)
	API_VERSION,
}