package com.solacesystems.pubsub.sdkperf.jms.solace;

import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Topic;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.jms.SolEventListener;
import com.solacesystems.jms.SolEventSource;
import com.solacesystems.jms.events.ActiveFlowIndicationEvent;
import com.solacesystems.jms.events.SolEvent;
import com.solacesystems.pubsub.sdkperf.core.AbstractClientTransactedSession;
import com.solacesystems.pubsub.sdkperf.core.FlowStatus;
import com.solacesystems.pubsub.sdkperf.jms.core.AbstractJmsClient;
import com.solacesystems.pubsub.sdkperf.jms.core.BasicMessageListener;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.ActiveFlowIndicationType;

/**
 * Class to receive JMS messages asynchronously
 * 
 */
public class SolJmsMessageListener extends BasicMessageListener {

	private static final Log Trace = LogFactory
			.getLog(SolJmsMessageListener.class);

	protected boolean wantActiveFlowIndication = false;
	protected ActiveFlowIndicationEventListener afiEventListener = null;
	protected String clientIdStr = "";

	public SolJmsMessageListener(AbstractJmsClient client, String destination,
			boolean isTopic, Topic topic, boolean isNonDurable,
			AbstractClientTransactedSession transactedSession, MessageConsumer consumer,
			boolean wantActiveFlowIndication,
			String clientId) {
		super(client, destination, isTopic, topic, isNonDurable, transactedSession, consumer);

		this.wantActiveFlowIndication = wantActiveFlowIndication;
		this.clientIdStr = clientId;
		this.setWrappedMessageClass(JmsSolaceWrappedMessage.class);
	}

	@Override
	public FlowStatus getFlowStatus() {
		if (afiEventListener == null) {
			return new FlowStatus();
		} else {
			return afiEventListener.getFlowStatus();
		}
	}

	public void startMessageListener() throws JMSException {
		super.startMessageListener();

		// If active flow indication events are wanted, attach an event
		// listener.ActiveFlowIndicationEventListener afiEventListener = null;
		if (wantActiveFlowIndication) {
			SolEventSource eventSource = (SolEventSource) _consumer;

			afiEventListener = new ActiveFlowIndicationEventListener();
			eventSource.addSolEventListener(afiEventListener,
					SolEvent.SOLEVENT_TYPE_ACTIVE_FLOW_INDICATION);
		}
	}

	public void restartMessageListener() throws JMSException {
		// no different than starting fresh.
		this.startMessageListener();
	}

	class ActiveFlowIndicationEventListener implements SolEventListener {

		FlowStatus flowStatus = new FlowStatus();

		public void handleEvent(SolEventSource source, SolEvent event) {
			ActiveFlowIndicationEvent afiEvent = (ActiveFlowIndicationEvent) event;
			switch (afiEvent.getFlowState()) {
			case ActiveFlowIndicationEvent.FLOW_ACTIVE:
				// Flow is active. Make sure we only get one event for
				// each flow active occurrence. Otherwise it's an error.
				if (flowStatus.getAfiState() == ActiveFlowIndicationType.ACTIVE) {
					Trace.error("CLIENT " + clientIdStr + ": Flow (" + source
							+ ") received FLOW_ACTIVE while already ACTIVE");
				} else {
					Trace.info("CLIENT " + clientIdStr + ": Flow (" + source
							+ ") received FLOW_ACTIVE");
				}

				flowStatus.setAfiState(ActiveFlowIndicationType.ACTIVE);
				break;

			case ActiveFlowIndicationEvent.FLOW_INACTIVE:
				// Flow is inactive. Make sure we only get one event for
				// each flow inactive occurrence. Otherwise it's an error.
				if (flowStatus.getAfiState() == ActiveFlowIndicationType.INACTIVE) {
					Trace.error("CLIENT " + clientIdStr + ": Flow (" + source
							+ ") received FLOW_INACTIVE while already INACTIVE");
				} else {
					Trace.info("CLIENT " + clientIdStr + ": Flow (" + source
							+ ") received FLOW_INACTIVE");
				}

				flowStatus.setAfiState(ActiveFlowIndicationType.INACTIVE);
				break;

			default:
				Trace.error("CLIENT " + clientIdStr + ": Unknown flow event "
						+ event.toString() + "(" + event.getEventType() + ")");
				break;
			}
		}

		public FlowStatus getFlowStatus() {
			return flowStatus;
		}

	}

}
