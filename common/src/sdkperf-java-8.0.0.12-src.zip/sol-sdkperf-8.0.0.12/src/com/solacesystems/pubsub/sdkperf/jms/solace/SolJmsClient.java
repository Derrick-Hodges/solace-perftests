/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.jms.solace;

import java.util.Map;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TransactionRolledBackException;
import javax.jms.XAConnectionFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.jcsmp.Endpoint;
import com.solacesystems.jcsmp.JCSMPErrorResponseException;
import com.solacesystems.jcsmp.JCSMPRuntime;
import com.solacesystems.jcsmp.impl.flow.FlowHandleImpl;
import com.solacesystems.jcsmp.protocol.nio.impl.ConsumerNotificationDispatcher;
import com.solacesystems.jcsmp.transaction.TransactionResultUnknownException;
import com.solacesystems.jcsmp.transaction.xa.SolXAException;
import com.solacesystems.jms.SolJMSVersion;
import com.solacesystems.jms.SolJmsUtility;
import com.solacesystems.jms.SolMessageConsumer;
import com.solacesystems.jms.SolMessageConsumerIF;
import com.solacesystems.jms.SolMessageProducer;
import com.solacesystems.jms.SolProducerEventListener;
import com.solacesystems.jms.SolSessionIF;
import com.solacesystems.jms.SupportedProperty;
import com.solacesystems.jms.events.SolProducerEvent;
import com.solacesystems.jms.events.SolProducerEvent.EventType;
import com.solacesystems.pubsub.sdkperf.config.EpConfigProperties;
import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.AbstractClientTransactedSession;
import com.solacesystems.pubsub.sdkperf.core.BasicMsgRep;
import com.solacesystems.pubsub.sdkperf.core.PubSubException;
import com.solacesystems.pubsub.sdkperf.core.TransactionRollbackException;
import com.solacesystems.pubsub.sdkperf.core.PerfStats.PerfStatType;
import com.solacesystems.pubsub.sdkperf.jms.core.AbstractJmsClient;
import com.solacesystems.pubsub.sdkperf.jms.core.BasicMessageListener;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsClientTransactedSession;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsClientXaSession;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsSdkperfFactory;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsSdkperfVersion;

/**
 * Class for managing all activities of a single client.  Handles
 * all JMS sdk interactions. 
 */
public class SolJmsClient extends AbstractJmsClient implements SolProducerEventListener	{
	
	private static final Log Trace = LogFactory.getLog(SolJmsClient.class);
	private SolJmsSdkperfFactory sdkperfFactory = null;
	
	public SolJmsClient() {}
	
	public SolJmsClient(ConnectionFactory cf, Map<String, Queue> queueMap, Map<String, Topic> topicMap) {
		super(cf, queueMap, topicMap);
	}
	
	@Override
	protected ConnectionFactory setupConnectionFactory() throws Exception {
		String  jmsCF = _rxProps.getStringProperty(RuntimeProperties.JMS_CONNECTION_FACTORY);
		ConnectionFactory jmsCf = (ConnectionFactory)_initialContext.lookup(jmsCF);
		
		return jmsCf;
	}
	
	@Override
	public void connect() throws Exception {
		super.connect();
		// Set Producer event handlers
		if (_producers != null) {
			for (int i = 0; i < _producers.length; i++) {
				if (_producers[i] instanceof SolMessageProducer) {
					((SolMessageProducer) _producers[i]).setProducerEventListener(this);
				}
			}
		}
	}
	
	@Override
	protected XAConnectionFactory setupXAConnectionFactory() throws Exception {
		String  jmsCF = _rxProps.getStringProperty(RuntimeProperties.JMS_CONNECTION_FACTORY);
		try {
			XAConnectionFactory jmsXaCf = (XAConnectionFactory)_initialContext.lookup(jmsCF);
			
			return jmsXaCf;
		} catch (Exception exception) {
			throw new PubSubException("XA is not enabled on Connection Factory.");
		}
	}
	

	@Override
	protected String getSessionName(Session session) {
		
		return ((SolSessionIF)session).getName();
	}
	
	@Override
	protected void modifyMsgForJmsExtendedProps(Message jmsMessage) throws JMSException {
		if (_txProps.getBooleanProperty(RuntimeProperties.MSG_DMQ_ELIGIBLE) != null) {
			jmsMessage.setBooleanProperty(SupportedProperty.SOLACE_JMS_PROP_DEAD_MSG_QUEUE_ELIGIBLE,
					_txProps.getBooleanProperty(RuntimeProperties.MSG_DMQ_ELIGIBLE));
		}

		if (_txProps.getBooleanProperty(RuntimeProperties.MSG_ELIDING_ELIGIBLE) != null) {
			jmsMessage.setBooleanProperty(SupportedProperty.SOLACE_JMS_PROP_ELIDING_ELIGIBLE,
					_txProps.getBooleanProperty(RuntimeProperties.MSG_ELIDING_ELIGIBLE));
		}

		if (_txProps.getBooleanProperty(RuntimeProperties.PUBLISH_TO_ONE) != null) {
			jmsMessage.setBooleanProperty(SupportedProperty.SOLACE_JMS_PROP_DELIVER_TO_ONE,
					_txProps.getBooleanProperty(RuntimeProperties.PUBLISH_TO_ONE));
		}
	}
	
	@Override
	protected void publishBinarySmfMsg(BasicMsgRep msgRep,  int pubSessionIndex) throws Exception {
		
		if (msgRep.getSmfBytes() == null) {
			throw new PubSubException("CLIENT " + _clientIdStr + ": Error trying to publish SMF binary message (null).");
		}
		
		Message jmsMessage = SolJmsUtility.fromByteArray(msgRep.getSmfBytes());
		
        Destination dest = jmsMessage.getJMSDestination();

		if (_txProps.getBooleanProperty(RuntimeProperties.WANT_REPLY_TOPIC)	||
			_txProps.getBooleanProperty(RuntimeProperties.WANT_REPLY_TEMPORARY_QUEUE)) {			
			updateReplyToTopic(msgRep, jmsMessage);
		}
        
		try {
			_producers[pubSessionIndex].send(dest, jmsMessage);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
	}
	
	@Override
	protected String getMessageConsumerName(MessageConsumer msgConsumer) {
		// This is a hack.  Under normal operation, there is no need to get the
		// provider specific name of a Temporary Topic.  However, to allow our
		// internal automated testing tools the ability to access CLI information,
		// we use the following to extract the name from the underlying Endpoint
		// representation of our MessageConsumer.
		Endpoint endpoint = ((SolMessageConsumerIF)msgConsumer).getEndpoint();
		String tteName = null;

		// If our consumer has an endpoint, we will get its name.  Otherwise, we are
		// in direct transport mode and create a name that will be used for keeping
		// track of this consumer.
		if (endpoint != null) {
			tteName = endpoint.getName();
		} else {
			tteName = "DirectTTE_" + _tteUID.incrementAndGet();
		}
		
		return tteName;
	}

	
	@Override
	protected void updateLastErrorResponse(JMSException exception) {
		Exception e = exception.getLinkedException();
		int MAX_LOOP = 10;
		int numiterations = 0;
		while ((e != null) && (!(e instanceof JCSMPErrorResponseException)) && 
				(numiterations < MAX_LOOP)) {
			e = (Exception)e.getCause();
			numiterations++;
		}
		
		if (e instanceof JCSMPErrorResponseException) {
			_lastErrorResponse = (JCSMPErrorResponseException)e;
		}
	}

	@Override
	public void commitTransactionOnCurrPub(int producerIndex,
			boolean wantRollback) throws Exception {
		try {
			if (wantRollback) {
				_currTransactedSession.rollback();
			} else {
				_currTransactedSession.commit();
			}
		} catch (TransactionRolledBackException e) {
			updateLastErrorResponse(e);
			throw new TransactionRollbackException(-1, e);
		} catch (JMSException e) {
			updateLastErrorResponse(e);
			if(e.getCause() instanceof TransactionResultUnknownException) {
				throw new com.solacesystems.pubsub.sdkperf.core.TransactionResultUnknownException(e);
			} else {
				throw e;	
			}
		}
	}
	
	
	@Override
	public void commitXaSessionOnCurrPub(int producerIndex,
			boolean wantRollback, boolean onePhase, boolean noStart) throws Exception {
		try {
			super.commitXaSessionOnCurrPub(producerIndex, wantRollback, onePhase, noStart);
		} catch (Exception e) {
			if(e instanceof TransactionRolledBackException) {
				throw new TransactionRollbackException(-1, e);
			} else if(e instanceof SolXAException) {
				throw new TransactionRollbackException(-1, e);
			}
		}
	}


	
	@Override
	public void updateLastErrorResponse(Exception exception) {
		if (exception instanceof JMSException) {
			updateLastErrorResponse((JMSException) exception);
		} else {
			_lastErrorResponse = exception;
		}
	}

	@Override
	protected BasicMessageListener createMessageListener(
			MessageConsumer msgConsumer, EpConfigProperties epProps,
			String destName, boolean isTopic) throws JMSException,
			PubSubException {
		
		AbstractClientTransactedSession txSession = null;

		if (!epProps.getTransactedSessionName().equals("")) {
			FlowHandleImpl flowHandle = (FlowHandleImpl) ((SolMessageConsumer) msgConsumer).mConsumer;
			ConsumerNotificationDispatcher cnd = flowHandle.getConsumerNotifDsp();
			
			if (_xaSessions.containsKey(epProps.getTransactedSessionName())) {
				txSession = _xaSessions.get(epProps.getTransactedSessionName());
				((JmsClientXaSession) txSession).setDispatcher(cnd);
			} else {
				txSession = _transactedSessions.get(epProps.getTransactedSessionName());
				((JmsClientTransactedSession) txSession).setDispatcher(cnd);
			}
		}

		SolJmsMessageListener myMsgListener = new SolJmsMessageListener(this,
				destName, isTopic, null, false, txSession, msgConsumer, epProps.getWantActiveFlowIndication(), _clientIdStr);
		myMsgListener.startMessageListener();
		return myMsgListener;
	}


	@Override
	public String getFormattedVersionInfo() {
		StringBuilder sb = new StringBuilder();
		sb.append(JmsSdkperfVersion.getSdkPerfJmsVersion() + System.getProperty("line.separator"));
		SolJMSVersion v = new SolJMSVersion();
		sb.append("sol-jms version: " + v.getSwVersion() + System.getProperty("line.separator"));
		sb.append("sol-jcsmp version: " + JCSMPRuntime.onlyInstance().getVersion().getSwVersion());
		return sb.toString();
	}

	@Override
	protected JmsSdkperfFactory getJmsFactory() {
		if (sdkperfFactory == null) {
			sdkperfFactory = new SolJmsSdkperfFactory();
		}
		return sdkperfFactory;
	}

	public void onEvent(SolProducerEvent event) {
		if(event.getType() == EventType.REPUBLISH_UNACKED_MESSAGES) {
			_stats.incStat(PerfStatType.SESSION_EVENT_REPUBLISH_UNACKED_MESSAGES, 1);
		}
        Trace.info(event.toString());
	}


}
