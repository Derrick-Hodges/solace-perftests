/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;

/**
 * Cache thread.  When sending cache requests at a specific
 * rate each client will contain a cache request thread that
 * will execute the cache request task. This thread runs to
 * completion and in general aborts when encountering errors.
 */
public class CacheThread {
	private static final Log Trace = LogFactory.getLog(CacheThread.class);
	
	//wait threshold at which we switch to the special waiting algorithm.
	private static final int RATE_CHK_THRESH = 1000000000/500;
	private static final int RATE_CHK_INTERV = 10;

	
	protected AbstractClient _client;
	protected RuntimeProperties _perfProps;
	
	private long _numMsgsToSend;
	
	protected volatile boolean _isRequesting;
	protected volatile boolean _isDoneRequesting; 
	protected volatile boolean _shutdown; 
	protected volatile long _startTime;
	protected volatile long _endTime;
	protected RequestThreadObj _requestThread;
	
	List<String> _topics;
	
	
	public CacheThread(AbstractClient client) throws Exception {
		_client = client;
	}

	public void start(
			final List<String> topicslist,
			final int numMsgs,
			final RuntimeProperties props) throws Exception
	{
		_numMsgsToSend = numMsgs;
		_perfProps = (RuntimeProperties)props.clone();
		
		_isDoneRequesting = false;
		
		_topics = new ArrayList<String>(topicslist);
		
		if (_requestThread != null) {
			// previous thread object
			if (_requestThread.isAlive())
				throw new IllegalStateException("Attempted to start a publisher thread when one was already running.");
		}
		_requestThread = new RequestThreadObj();
		_requestThread.start();
	}
	
	public void stop() throws Exception
	{
		_shutdown = true;
	}
	
	public boolean isRequesting() { return _isRequesting; }
	public boolean isDoneRequesting() { return _isDoneRequesting; }
	
	public long getStartTimeInNanos() { return _startTime; }
	public long getEndTimeInNanos() { return _endTime; }
	
	public void resetTimes() 
	{
		if (isRequesting())
		{
			_startTime = System.nanoTime();
			_endTime = 0;
		}
		else 
		{
			_startTime = 0;
			_endTime = 0;
		}
	}
	
	class RequestThreadObj extends Thread {
		@Override
		public void run() {
			long interDocDelayNs;
			
			// calculate inter-doc delay from publish rate
			int reqRate = 0;
			if (_perfProps.getIntegerProperty(RuntimeProperties.CACHE_REQ_MSG_RATE) != null) {
				reqRate = _perfProps.getIntegerProperty(RuntimeProperties.CACHE_REQ_MSG_RATE);
			}
			if (reqRate == 0) {
				// 0 is a magic number, it means "as fast as you can go"
				interDocDelayNs = 0;
			} else {
				interDocDelayNs = (1000000000 / reqRate);
			}
			
			_shutdown = false; //reset shutdown request
			
			try {
				if (Trace.isDebugEnabled()) {
					Trace.debug("CLIENT " + _client.getIdStr() + ":CacheThread about to connect.");
				}
				_client.connect();
				if (Trace.isDebugEnabled()) {
					Trace.debug("CLIENT " + _client.getIdStr() + ":CacheThread connected successfully.");
				}
			} catch (Exception e) {
				Trace.error("CLIENT " + _client.getIdStr() + ":CacheThread unable to open connection, shutdown", e);			
				_shutdown = true;
			}
		
			long cntReqSent = 0;
			
			if (Trace.isDebugEnabled()) {
				Trace.debug(String.format("CLIENT " + _client.getIdStr() + ":About to enter publish loop (%s) messages", _numMsgsToSend));
			}
			
			_startTime = System.nanoTime();
			
			// Need a local variable for rate calculation because,
		    // don't want to reset this when stats are reset (ie resetTimes() is called).
		    // but set it equal to the startTime_m.
		    long loopStartTime = _startTime;
		    
			_isRequesting = true;
			int arrayIndex = 0;
			boolean subscribe = false;
			
			AbstractCacheLiveDataAction liveDataAction = (AbstractCacheLiveDataAction)_perfProps.getProperty(RuntimeProperties.CACHE_LIVE_DATA_ACTION);
			boolean waitForConfirm = _perfProps.getBooleanProperty(RuntimeProperties.CACHE_REQ_WAIT_FOR_CONFIRM);
			
			// TODO: Need to get real values for this.
			long minSeq = _perfProps.getLongProperty(RuntimeProperties.CACHE_REQ_MIN_SEQUENCE_NUM);
			long maxSeq = _perfProps.getLongProperty(RuntimeProperties.CACHE_REQ_MAX_SEQUENCE_NUM);
			
			while( !_shutdown && (cntReqSent < _numMsgsToSend)) {
				interReqDelay(loopStartTime, interDocDelayNs, cntReqSent);
				
				try {
					arrayIndex = (int) (cntReqSent % _topics.size());
					List<String> topicsToSend = new ArrayList<String>();
					topicsToSend.add(_topics.get(arrayIndex));
					_client.cacheRequest(
							topicsToSend, 
							subscribe, 
							minSeq,
							maxSeq,
							liveDataAction, 
							waitForConfirm);
				} catch (Exception e) {
					Trace.error("CLIENT " + _client.getIdStr() + ":CacheThread sendMessage, shutdown due to: " + e.getMessage(), e);
					_shutdown = true;
				}
				cntReqSent++;
			}
			if (Trace.isDebugEnabled()) {
				Trace.debug(String.format("Exited request loop (numpublished=%s)",
					cntReqSent));
			}
		 
			_endTime = System.nanoTime();

			_isRequesting = false;
			_isDoneRequesting = true;
		}
	}
	
	/**
	 * Performs the inter-doc delay. If operating at low rate, delay is applied
	 * between each doc. If operating at high rate (> 500 msgs/sec), delay is
	 * applied only once per 10 docs.
	 * 
	 * @param cntPublished
	 *            Count of messages published
	 */
	private final void interReqDelay(
			final long pubStartTimeNs,
			final long interDocDelayNs,
			final long cntPublished) 
	{
		long nextPubTimeNs;
		if (interDocDelayNs > 0) {
			if (interDocDelayNs < RATE_CHK_THRESH) {
				if (cntPublished % RATE_CHK_INTERV == 0) {
					long timeSinceStartInNs = interDocDelayNs * cntPublished;
					/*
					 * The pause runs only every RATE_CHK_INTERV docs.
					 */
					nextPubTimeNs = pubStartTimeNs + timeSinceStartInNs;
					waitUntil(nextPubTimeNs);
				}
			} else {
				long timeSinceStartInNs = interDocDelayNs * cntPublished;
				/*
				 * The pause runs only every RATE_CHK_INTERV docs.
				 */
				nextPubTimeNs = pubStartTimeNs + timeSinceStartInNs;
				waitUntil(nextPubTimeNs);
			}
		}
	}
	
	private static final void waitUntil(long targetNanoTime) {
		long curtime = System.nanoTime();
		long waittimeInMs = (targetNanoTime - curtime) / 1000000;
		if (waittimeInMs > 0) {
			try {
				Thread.sleep(waittimeInMs);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
