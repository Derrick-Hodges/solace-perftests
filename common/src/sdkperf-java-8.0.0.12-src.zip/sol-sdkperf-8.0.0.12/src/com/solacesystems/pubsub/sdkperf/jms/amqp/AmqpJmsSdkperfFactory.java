/** 
 *  Copyright 2009-2017 Solace Corporation. All rights reserved
 *  
 *  http://www.solace.com
 *  
 *  This source is distributed WITHOUT ANY WARRANTY or support;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 *  A PARTICULAR PURPOSE.  All parts of this program are subject to
 *  change without notice including the program's CLI options.
 *
 *  Unlimited use and re-distribution of this unmodified source code is   
 *  authorized only with written permission.  Use of part or modified  
 *  source code must carry prominent notices stating that you modified it, 
 *  and give a relevant date.
 */
package com.solacesystems.pubsub.sdkperf.jms.amqp;

import java.util.Hashtable;
import java.util.List;

import javax.jms.Connection;
import javax.jms.Session;
import javax.jms.XAConnection;
import javax.jms.XASession;
import javax.naming.InitialContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.AbstractClient;
import com.solacesystems.pubsub.sdkperf.core.ClientFactory;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericAuthenticationScheme;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsClientTransactedSession;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsClientXaSession;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsSdkperfFactory;

public class AmqpJmsSdkperfFactory implements JmsSdkperfFactory {

	private static final Log Trace = LogFactory.getLog(AmqpJmsSdkperfFactory.class);
	public static final String INITIAL_CONTEXT_FACTORY_NAME = "org.apache.qpid.jms.jndi.JmsInitialContextFactory";
	private static final String CONNECTION_FACTORY_PREFIX = "connectionfactory";
	
	public InitialContext createInitialContext(RuntimeProperties rxProps, int clientIdInt) throws Exception {
		// Must build the provider URL string array.
		String hostList = rxProps.getStringProperty(RuntimeProperties.CLIENT_IP_ADDR);
		
		// check host
		StringBuilder bldr = new StringBuilder();
		String[] hostListArray = hostList.split(",");
		for(int i = 0; i < hostListArray.length; i++) {
			if (i > 0) {
				bldr.append(",");
			}
			if (hostListArray[i].indexOf("://") == -1) {
				bldr.append("amqp://");
			}
			bldr.append(hostListArray[i]);
		}

		Hashtable<String,Object> 	env = new Hashtable<String,Object>();
		env.put(InitialContext.INITIAL_CONTEXT_FACTORY, INITIAL_CONTEXT_FACTORY_NAME);
		
		String s = CONNECTION_FACTORY_PREFIX + "." + AmqpJmsClient.CONNECTION_FACTORY_LOOKUP;
		env.put(s, bldr.toString());
		
		GenericAuthenticationScheme authScheme = (GenericAuthenticationScheme) rxProps.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME);
		
		if (!rxProps.getStringProperty(RuntimeProperties.CLIENT_USERNAME).equals("") ||
				(rxProps.getStringProperty(RuntimeProperties.CLIENT_USERNAME).equals("") &&
				 !authScheme.equals(GenericAuthenticationScheme.CLIENT_CERTIFICATE) &&
				 !authScheme.equals(GenericAuthenticationScheme.GSS_KRB))) {
			String jmsUsername = ClientFactory.generateClientUsername(rxProps, clientIdInt);
			env.put(javax.naming.Context.SECURITY_PRINCIPAL, jmsUsername);
		}
		
		String jmsPassword = rxProps.getStringProperty(RuntimeProperties.CLIENT_PASSWORD);
		env.put(javax.naming.Context.SECURITY_CREDENTIALS, jmsPassword);
		
		
//		if (!rxProps.getProperty(RuntimeProperties.SSL_PROTOCOL).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_PROTOCOL, rxProps.getProperty(RuntimeProperties.SSL_PROTOCOL));
//		}
		
//		if (rxProps.getProperty(RuntimeProperties.SSL_CONNECTION_DOWNGRADE_TO) != null
//				&& !rxProps.getProperty(RuntimeProperties.SSL_CONNECTION_DOWNGRADE_TO).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_CONNECTION_DOWNGRADE_TO,
//					rxProps.getProperty(RuntimeProperties.SSL_CONNECTION_DOWNGRADE_TO));
//		}
		
//		if (!rxProps.getProperty(RuntimeProperties.SSL_EXLCUDED_PROTOCOLS).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_EXCLUDED_PROTOCOLS, rxProps
//					.getProperty(RuntimeProperties.SSL_EXLCUDED_PROTOCOLS));
//		}
		
//		if (!rxProps.getBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE)) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_VALIDATE_CERTIFICATE, rxProps
//					.getBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE));
//		}
		
//		if (!rxProps.getBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE_DATE)) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_VALIDATE_CERTIFICATE_DATE, rxProps
//					.getBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE_DATE));
//		}
		
//		if (!rxProps.getProperty(RuntimeProperties.SSL_CIPHER_SUITES).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_CIPHER_SUITES, rxProps
//					.getProperty(RuntimeProperties.SSL_CIPHER_SUITES));
//		}
		
//		if (!rxProps.getProperty(RuntimeProperties.SSL_TRUST_STORE).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_TRUST_STORE, rxProps
//					.getProperty(RuntimeProperties.SSL_TRUST_STORE));
//		}
		
		// Check for WANT_NON_BLOCKING_CONNECT
		Boolean value = rxProps.getBooleanProperty(RuntimeProperties.WANT_NON_BLOCKING_CONNECT);
		if (value != null && value) {
			Trace.warn("Cannot connect in a non-blocking way when using the JmsClient.");
		}
//		
//		if (!rxProps.getProperty(RuntimeProperties.SSL_TRUST_STORE_PASSWORD).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_TRUST_STORE_PASSWORD, rxProps
//					.getProperty(RuntimeProperties.SSL_TRUST_STORE_PASSWORD));
//		}
//		
//		if (!rxProps.getProperty(RuntimeProperties.SSL_TRUST_STORE_FORMAT).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_TRUST_STORE_FORMAT, rxProps
//					.getProperty(RuntimeProperties.SSL_TRUST_STORE_FORMAT));
//		}
//		
//		if (!rxProps.getProperty(RuntimeProperties.SSL_TRUSTED_COMMON_NAME_LIST).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_TRUSTED_COMMON_NAME_LIST, rxProps
//					.getProperty(RuntimeProperties.SSL_TRUSTED_COMMON_NAME_LIST));
//		}
		
//		if (!rxProps.getProperty(RuntimeProperties.SSL_KEY_STORE).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_KEY_STORE, rxProps
//					.getProperty(RuntimeProperties.SSL_KEY_STORE));
//		}
//		
//		if (!rxProps.getProperty(RuntimeProperties.SSL_KEY_STORE_PASSWORD).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_KEY_STORE_PASSWORD, rxProps
//					.getProperty(RuntimeProperties.SSL_KEY_STORE_PASSWORD));
//		}
		
//		if (!rxProps.getProperty(RuntimeProperties.SSL_KEY_STORE_FORMAT).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_KEY_STORE_FORMAT, rxProps
//					.getProperty(RuntimeProperties.SSL_KEY_STORE_FORMAT));
//		}
//		
//		if (!rxProps.getProperty(RuntimeProperties.SSL_PRIVATE_KEY_ALIAS).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_PRIVATE_KEY_ALIAS, rxProps
//					.getProperty(RuntimeProperties.SSL_PRIVATE_KEY_ALIAS));
//		}
//		
//		if (!rxProps.getProperty(RuntimeProperties.SSL_PRIVATE_KEY_PASSWORD).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_SSL_PRIVATE_KEY_PASSWORD, rxProps
//					.getProperty(RuntimeProperties.SSL_PRIVATE_KEY_PASSWORD));
//		}
		
//		if (!rxProps.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME).equals("")) {
//			env.put(SupportedProperty.SOLACE_JMS_AUTHENTICATION_SCHEME, rxProps
//					.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME));
//			
//			if (authScheme.equals(GenericAuthenticationScheme.BASIC)) {
//				env.put(SupportedProperty.SOLACE_JMS_AUTHENTICATION_SCHEME, SupportedProperty.AUTHENTICATION_SCHEME_BASIC);
//			} else if (authScheme.equals(GenericAuthenticationScheme.CLIENT_CERTIFICATE)) {
//				env.put(SupportedProperty.SOLACE_JMS_AUTHENTICATION_SCHEME, SupportedProperty.AUTHENTICATION_SCHEME_CLIENT_CERTIFICATE);
//			} else if (authScheme.equals(GenericAuthenticationScheme.GSS_KRB)) {
//				env.put(SupportedProperty.SOLACE_JMS_AUTHENTICATION_SCHEME, SupportedProperty.AUTHENTICATION_SCHEME_GSS_KRB);
//			} else {
//				throw new IllegalArgumentException("Unknown authentication type \"" + authScheme + "\".");
//			}
//		}
		
		if (rxProps.getProperty(RuntimeProperties.EXTRA_PROP_LIST) != null) {
			@SuppressWarnings("unchecked")
			List<String> extraProp = (List<String>) rxProps.getProperty(RuntimeProperties.EXTRA_PROP_LIST);
			
			for(int i = 0; i < (extraProp.size() - 1); i +=2) {
				env.put(extraProp.get(i), extraProp.get(i+1));
			}
		}
		
		if (rxProps.getIntegerProperty(RuntimeProperties.RECONNECT_INTERVAL_MSEC) != null) {
		}
		if (rxProps.getIntegerProperty(RuntimeProperties.KEEPALIVE_INTERVAL_MSEC) != null) {
		}
		if (rxProps.getIntegerProperty(RuntimeProperties.CLIENT_COMPRESSION_LEVEL) != null) {
		}
		
		return new InitialContext(env);
	}
	
	public JmsClientTransactedSession createClientTransactedSession(AbstractClient client, Connection connection, Session transactedSession, RuntimeProperties rprops) {
		return new JmsClientTransactedSession(client, transactedSession, rprops);
	}

	public JmsClientXaSession createXaTransactedSession(AbstractClient client,
			XAConnection xaConnection, XASession xaSession, RuntimeProperties rprops) {
		return new JmsClientXaSession(client, xaSession, rprops);
	}
}
