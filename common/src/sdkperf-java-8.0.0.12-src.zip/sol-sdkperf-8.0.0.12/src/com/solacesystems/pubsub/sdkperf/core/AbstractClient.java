/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.zip.CRC32;

import org.apache.commons.lang.mutable.MutableLong;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.pubsub.sdkperf.config.EpConfigProperties;
import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.PerfStats.PerfStatType;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.ClientModeType;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.PublisherDestinationsType;
import com.solacesystems.pubsub.sdkperf.util.DestinationUtils.DestinationBean;
import com.solacesystems.pubsub.sdkperf.util.PerfIO;
import com.solacesystems.pubsub.sdkperf.util.SdkperfConstants;
import com.solacesystems.pubsub.sdkperf.util.SdkperfVersion;
import com.solacesystems.pubsub.sdkperf.util.Timing;

/**
 * Abstract base class defining all abstract methods of a clients (connection
 * setup, message reception, subscribing and publishing).
 */
public abstract class AbstractClient {
	private static final Log Trace = LogFactory.getLog(AbstractClient.class);

	protected RuntimeProperties _rxProps;
	protected RuntimeProperties _txProps;
	protected boolean _wantPublishFlags = false;
	
	protected boolean _listenFlag;
	
	protected PerfStats _stats;
	
	protected String _clientIdStr;
	protected int _clientIdInt;
	protected int _numContextThreads;
	protected int _numPubPerSession;
		
	protected ToolDataProperties _rxToolDataProps;
	protected ToolDataProperties _txToolDataProps;
	
	protected AtomicInteger _tteUID = new AtomicInteger();
	protected volatile Exception _lastErrorResponse;
	protected volatile boolean _asyncExceptionOccured = false;
	protected boolean _wantStopOnError = true;
	protected boolean _wantUserPropToolData = false;
	
	protected volatile ChannelState _channelState = ChannelState.CLIENT_STATE_UNKNOWN;
	
	private AtomicLong _msgCount = new AtomicLong();
	
	private CRC32 _rxChecksumTool;
	private long _TIMESTAMP_INTERVAL;
	
	// Used for message reflect/reply
	private List<Integer> _replyDelayList = null;
	private int _delayToUse = 0;

	protected AbstractClientCollection _clientCollection;
	
	protected long _numMsgPub;
	protected boolean _isStartPub;
	protected long _numMsgsPubOffset = 1;
	
	// Publish On Receive
	protected BasicMsgRep[] _pubOnRecMsgArray = null;
	protected long _pubOnRecMsgArrayIndex = 0;

	
	// Constructor
	public AbstractClient() {}	
	
	protected AbstractClient(final RuntimeProperties perfProps, final int clientIdInt) throws Exception {
		this.init(perfProps, clientIdInt);
	}
	
	// Version Info
	public String getVersionString() throws Exception {
		
		String version = SdkperfVersion.getSdkperfVersion() + System.getProperty("line.separator");
		version += this.getFormattedVersionInfo();
		
		return version;
	}
	
	// Return a formatted string containing the version information
	public abstract String getFormattedVersionInfo();
	
	// Initialize the client
	@SuppressWarnings("unchecked")
	public void init(final RuntimeProperties perfProps, final int clientIdInt) throws Exception {
		_rxProps = (RuntimeProperties)perfProps.clone();
		_clientIdStr = ClientFactory.generateClientIdStr(perfProps, clientIdInt);
		_clientIdInt = clientIdInt;
		
		// Parse the number of pubs per session wanted
		try {
			_numPubPerSession = perfProps.getIntegerProperty(RuntimeProperties.NUM_PUBS_PER_SESSION);
			if(_numPubPerSession < 1)
				_numPubPerSession = 1;
		} catch (Exception e) { _numPubPerSession = 1; }
		
		_stats = new PerfStats(
				_clientIdStr, 
				perfProps.getIntegerProperty(RuntimeProperties.LATENCY_BUCKETS), 
				perfProps.getIntegerProperty(RuntimeProperties.LATENCY_GRANULARITY),
				perfProps.getDoubleProperty(RuntimeProperties.LATENCY_WARMUP_IN_SECS));
		_msgCount.set(0);
		_tteUID.set(0);
		_rxChecksumTool = new CRC32();
		_TIMESTAMP_INTERVAL = _rxProps.getIntegerProperty(RuntimeProperties.SUBSCRIBER_RATE_INTERVAL);
		
		_rxToolDataProps = new ToolDataProperties(_rxProps);
		
		_wantUserPropToolData = perfProps.getBooleanProperty(RuntimeProperties.WANT_USER_PROP_TOOL_DATA);
		_wantStopOnError = perfProps.getBooleanProperty(RuntimeProperties.WANT_STOP_ON_ERROR);
		
		_lastErrorResponse = null;
		
		if(perfProps.getProperty(RuntimeProperties.MESSAGE_REPLY_DELAY_LIST) != null) {
			_replyDelayList = (List<Integer>) perfProps.getProperty(RuntimeProperties.MESSAGE_REPLY_DELAY_LIST);
		}
		
		// Configure/create the Publish On Receive messages
		if(_rxToolDataProps.NUM_MSG_PUB_ON_RCV > 0) {
			
			
			GenericMessageDeliveryMode mt = (GenericMessageDeliveryMode) _rxProps.getProperty(RuntimeProperties.POR_MESSAGE_TYPE);
			
			List<String> topicList = (List<String>) _rxProps.getProperty(RuntimeProperties.POR_TOPIC_LIST);
			List<String> queueList = (List<String>) _rxProps.getProperty(RuntimeProperties.POR_QUEUE_LIST);
					
			List<Integer> attSizeList = (List<Integer>)  _rxProps.getProperty(RuntimeProperties.POR_ATTACHMENT_SIZE_LIST);

			List<DestinationBean> destList = new ArrayList<DestinationBean>();
			if(topicList != null) {
				for(String t : topicList) {
				    destList.add(new DestinationBean(t, PublisherDestinationsType.TOPIC));
				}
			}
			if(queueList != null) {
				for(String q : queueList) {
				    destList.add(new DestinationBean(q, PublisherDestinationsType.QUEUE));
				}
			}
			
			int attachmentListSize = (attSizeList == null)? 0: attSizeList.size();
			
			int messageCombinations = 1;
			
			if (destList.size() > 0 && attachmentListSize > 0) {
				messageCombinations = destList.size() * attachmentListSize;
			} else if (destList.size() > 0 && attachmentListSize == 0) {
				messageCombinations = destList.size();
			} else if (destList.size() == 0 && attachmentListSize > 0) {
				messageCombinations = attachmentListSize;
			}
			
			BasicMsgRep[] msg = new BasicMsgRep[messageCombinations];
			for (int i = 0; i < msg.length; i++) {
				msg[i] = new BasicMsgRep();
			}

			if (destList.size() == 0 && attachmentListSize == 0) {
				msg[0].configureForNormalMsg(null, null, null, null, mt, null, null);
			} else if (destList.size() > 0 && attachmentListSize > 0) {
				int index = 0;
				for (DestinationBean dest : destList) {
					for (Integer size : attSizeList) {
						
						byte[] att = null;
						if (size != null)
							att = new byte[size];
						String destName = null;
						PublisherDestinationsType destType = null;
						if (dest != null) {
							destName = dest.getDestinationName();
							destType = dest.getDestinationType();
						}

						msg[index++].configureForNormalMsg(null, att, destName, destType, mt, null, null);
					}
				}
			} else if (destList.size() > 0 && attachmentListSize == 0) {
				int index = 0;
				for (DestinationBean dest : destList) {
					String destName = null;
						PublisherDestinationsType destType = null;
						if (dest != null) {
							destName = dest.getDestinationName();
							destType = dest.getDestinationType();
						}
						msg[index++].configureForNormalMsg(null, null, destName, destType, mt, null, null);
				}
			} else if (destList.size() == 0 && attachmentListSize > 0) {
				int index = 0;
				for (Integer size : attSizeList) {
					byte[] att = null;
					if (size != null)
						att = new byte[size];
					msg[index++].configureForNormalMsg(null, att, null, null, mt, null, null);
				}

			}
			
			_pubOnRecMsgArray = this.cloneToApiSpecificMsgRep(msg);

		}
	}
	
	// Can be used to destroy context, or clean-up any other items
	public void destroy() {}
	
	// Accessors
	public String getIdStr() { return _clientIdStr; }
	public RuntimeProperties getProps() { return _rxProps; }
	public boolean getWantStopOnError() { return _wantStopOnError; }
	
	public void setPublishProps(RuntimeProperties props, int producerIndex, String transactedSessionName) throws Exception 
	{ 
		_txToolDataProps = new ToolDataProperties(props);
		_txProps = (RuntimeProperties)props.clone();
		
		// The number of published messages ack'd makes use of last msg id ack'd.
		// Make sure this value is correct in the case of a publish order offset.
		setLastAckedMsgId(props.getIntegerProperty(RuntimeProperties.PUB_ORDER_OFFSET));

		if ((_txProps.getProperty(RuntimeProperties.PUBLISH_COS) != null) ||
			((_txProps.getBooleanProperty(RuntimeProperties.PUBLISH_TO_ONE) != null) &&
			 (_txProps.getBooleanProperty(RuntimeProperties.PUBLISH_TO_ONE) == true)) ||
			(_txProps.getProperty(RuntimeProperties.MSG_DMQ_ELIGIBLE) != null) ||
			(_txProps.getProperty(RuntimeProperties.MSG_ELIDING_ELIGIBLE) != null) ||
			(_txProps.getProperty(RuntimeProperties.MSG_TTL) != null))
		{
			_wantPublishFlags = true;
		} else {
			_wantPublishFlags = false;
		}
		
		// Reset this each time publish props are updated as this means we're trying a new publish.
	    _asyncExceptionOccured = false;
	    
		publishPropsUpdateNotify(producerIndex, transactedSessionName);
	}

	// Channel management
	public abstract void connect() throws Exception;
	public abstract void disconnect() throws Exception;

	public boolean isConnected() {
		return (_channelState == ChannelState.CLIENT_STATE_CONNECTED || _channelState == ChannelState.CLIENT_STATE_RECONNECTING);
	}

	public abstract void start() throws Exception;
	public abstract void stop() throws Exception;
	
	// Transaction Management
	public abstract String openTransactedSession(RuntimeProperties rprops) throws Exception;
	public abstract void closeTransactedSession(String sessionName) throws Exception;
	public abstract void closeAllTransactedSessions() throws Exception;
	public abstract void commitTransaction(String sessionName, boolean wantRollback) throws Exception;
	public abstract void commitTransactionOnCurrPub(int producerIndex, boolean wantRollback) throws Exception;
	
	// XA Management
	public abstract String openXaSession(RuntimeProperties rprops) throws Exception;
	public abstract void closeXaSession(String sessionName) throws Exception;
	public abstract void closeAllXaSessions() throws Exception;
	public abstract String createXid(String sessionName) throws Exception;
	public abstract void commitXaSession(String sessionName, String xid, boolean onePhase) throws Exception;
	public abstract void endXaSession(String sessionName, String xid, int flags) throws Exception;
	public abstract void forgetXaSession(String sessionName, String xid) throws Exception;
	public abstract void prepareXaSession(String sessionName, String xid) throws Exception;
	public abstract Vector<String> recoverXaSession(String sessionName, int flag) throws Exception;
	public abstract void rollbackXaSession(String sessionName, String xid) throws Exception;
	public abstract void startXaSession(String sessionName, String xid, int flags) throws Exception;
	public abstract void commitXaSessionOnCurrPub(int producerIndex, boolean wantRollback, boolean onePhase, boolean noStart) throws Exception;
	public abstract void suspendXaSessionOnCurrPub(int producerIndex) throws Exception;
	public abstract void setXaTransactionTimeout(String sessionName, int seconds) throws Exception;
	public abstract int getXaTransactionTimeout(String sessionName) throws Exception;
	
	public String createXid(String sessionName, int formatId, String globalTransactionId, String branchQualifier) throws Exception {
		throw new UnsupportedOperationException("XA Transactions are not supported for standard client.");
	}
	
	public String getActiveXid(String sessionName) throws Exception {
		throw new UnsupportedOperationException("XA Transactions are not supported for standard client.");
	}
	
	public Vector<String> getXids(String sessionName) throws Exception {
		throw new UnsupportedOperationException("XA Transactions are not supported for standard client.");
	}
	
	// Subscription management
	public abstract void subscriptionUpdate(EpConfigProperties epProps) throws Exception;
	public abstract void topicUpdate(EpConfigProperties epProps) throws Exception;
	public abstract void queueUpdate(EpConfigProperties epProps) throws Exception;
	public abstract Vector<String> tempEndpointUpdate(EpConfigProperties epProps) throws Exception;
	public abstract void cacheRequest(List<String> topics, boolean subscribe, long minSeq, long maxSeq, AbstractCacheLiveDataAction liveDataAction, boolean waitForConfirm) throws Exception;
	public abstract void mapTopics(String queue, List<String> topics, boolean isAdding) throws Exception;
	public abstract void endpointProvisioning(EpConfigProperties eProps) throws Exception;
	public abstract void unbindAllTempEndpoints() throws Exception;
			
	public abstract void clearSubscriptionMemory() throws Exception;
	public abstract void clearKeptMsgs() throws Exception;
	public abstract void clearKeptMsgs(String destination, boolean isTopic) throws Exception;
	
	public abstract void cancelCacheRequests() throws Exception;

	// Publish methods
	public abstract void publishMsg(BasicMsgRep msg, int producerIndex) throws Exception;
	protected abstract void publishOnReceive(Object producer, BasicMsgRep msg) throws Exception;
	public abstract void publishSendMultiple(List<BasicMsgRep> msgs, int producerIndex) throws Exception;
	public abstract void publishPropsUpdateNotify(int producerIndex, String transactedSessionName) throws Exception;
	
	// Queue Browsing methods
	public abstract void createBrowsers(List<String>queues, String selector, int deleteFrequency, int msgBufSize) throws Exception;
	public abstract boolean browseMsg(Integer browseIndex) throws Exception;  // return true if message was found
	public abstract void deleteBrowsers() throws Exception;
	
	
	protected LastMessageDetails _lastMessageDetails = new LastMessageDetails();
	public void setLastMessageDetails(AbstractWrappedMessage message) {}
	public LastMessageDetails getLastMessageDetails() {
		synchronized (_lastMessageDetails) {
			return _lastMessageDetails;
		}
	}
	
	// Other Utility methods
	public abstract BasicMsgRep[] cloneToApiSpecificMsgRep(BasicMsgRep[] inputMsgReps) throws PubSubException; // Clients can extend BasicMsgRep as required to cache per msg structures.
	// AbstractClient implementations must provide a way for the
	// AbstractClientConnection to create an API specific Context object
	public Object cloneToApiSpecificContext(Object context) {
		return null;
	}
	public void destroyApiSpecificContext(Object context) {}
	
	// Used for setting the Context ("subscriber thread")
	public void setContext(Object context) {}
	
	public abstract void updateLastErrorResponse(Exception e);
	
	public void logExceptionAsError(Exception e) {
		Trace.error("CLIENT " + _clientIdStr + ": " + e.getClass().getName() + " - " + e.getMessage(), e);
	}
	
	// Message processing (Client ACKs and kept messages)
	public abstract void processKeptMsgs(int desiredQueueSize, boolean wantClientAck);	
	
	@Override
	public abstract String toString();	

	
	// Extraction of tool data from properties is SDK specific.
	protected abstract void readToolDataFromProperties(AbstractWrappedMessage message, ToolData toolData);	
	
	
	// Stats access
	public PerfStats getRxStats() {
		return _stats;
	}
	
	public long getSdkStat(GenericStatType statName) throws Exception {
		Trace.warn("Unsupported method call getSdkStat(), returning 0");
		return 0;
	}
	
	public void resetStats() {
		_stats.resetStats();
		_msgCount.set(0);
	}
	
	public Exception getLastErrorResponse()
	{
		return _lastErrorResponse;
	}
	public void clearLastErrorResponse()
	{
		_lastErrorResponse = null;
	}
	
	// Support for message reflection only in derived classes.
	// This is called when we receive messages if we have
	// WANT_MSG_REFLECT set to true in the ToolDataProperties.
	public abstract void reflectMsg(AbstractWrappedMessage message);

	// Other general methods.
	public abstract long getLastAckedMsgId();
	public abstract void setLastAckedMsgId(long value);
	public abstract String getClientName() throws Exception;
	public String getReplyToDestination() {
		if(_rxProps.getBooleanProperty(RuntimeProperties.WANT_REPLY_TOPIC)) {
			if(_rxProps.getProperty(RuntimeProperties.REPLY_TO_STRING) != null &&
			   _rxProps.getStringProperty(RuntimeProperties.REPLY_TO_STRING).length() > 0) {
				return _rxProps.getStringProperty(RuntimeProperties.REPLY_TO_STRING);
			} else if (_rxProps.getProperty(RuntimeProperties.REPLY_TO_POSTFIX) != null &&
					   _rxProps.getStringProperty(RuntimeProperties.REPLY_TO_POSTFIX).length() > 0) {
				return _rxProps.getStringProperty(RuntimeProperties.REPLY_TO_POSTFIX);
			}
		}
		
		return null;
	}
	
	public abstract void setClientName(String value) throws Exception;
	public abstract String requestReply(String topic, String request) throws Exception;
	public abstract Hashtable<GenericCapabilityType, String> getRtrCapabilities() throws Exception;
	public abstract FlowStatus getFlowStatus(String epName) throws Exception;
	protected abstract void keepMsg(AbstractMessageAckData messageAckData);



	
	public void populateToolData(
			final BasicMsgRep msgRep,
			final long orderId,
			final long transactionId,
			final int transactionMsgId,
			final int transactionSize) {
		
		// If we don't want tool data then return immediately.
		if (!_txToolDataProps.WANT_TOOL_DATA) {
			return;
		}
		
		ToolData txToolData = msgRep.getToolData();
		//do some magic to set toolData
		txToolData.reset();
		
		if(_txToolDataProps.WANT_ORDER_MEMORY ||
			_txToolDataProps.WANT_ORDER_CHECK ||
			_txToolDataProps.WANT_LOSS_AND_DUPLICATE_DETECTION) {
			
			txToolData.setMessageIdentifier(orderId + _txToolDataProps.PUB_ORDER_OFFSET);
			if (_txToolDataProps.PUB_STREAM_ID_OFFSET >= 0) {
				txToolData.setStreamId(_txToolDataProps.PUB_STREAM_ID_OFFSET + _clientIdInt);
			}
			
			txToolData.setTransactionInfo(transactionId, transactionMsgId, transactionSize);
		}
		
		
		if(_txToolDataProps.WANT_LATENCY) {
			txToolData.setLatency(Timing.getClockValue());
		}

		if(_txToolDataProps.WANT_PAYLOAD_CHECK) {
			
			if (msgRep.getXmlBytes() != null) {
				CRC32 txChecksumTool = new CRC32();
				txChecksumTool.reset();
				txChecksumTool.update(msgRep.getXmlBytes());
				txToolData.setXmlPayloadHash(txChecksumTool.getValue());
			}			
			
	        // Attachments are special.  Binary attachment encoded tool data
	        // is not included in the crc calculation.
			if (msgRep.getAttachmentBytes() != null) {
				
	            // Tool data size refers to the number of bytes in the binary attachment
		        // encoded tool data. For purposes of calculating the crc of the binary 
	            // attachment without including the tool data portion of the attachment
	            // in the calculation, we need to know the size that the tool data will 
	            // be once encoded.  Note: Tool data size will be zero if the tool data
	            // is being sent using a property map.
				
				int toolDataSize = 0;
				if (!_wantUserPropToolData) {
					txToolData.setBinAttachHash(1);
					toolDataSize = txToolData.getEncodedSize();
				}
				
				// In the case where our tool data takes up the entire binary
				// attachment, we do not include
				if (toolDataSize < msgRep.getAttachmentBytes().length) {
					CRC32 txChecksumTool = new CRC32();
					txChecksumTool.reset();
					txChecksumTool.update(msgRep.getAttachmentBytes(), toolDataSize, (msgRep.getAttachmentBytes().length - toolDataSize));
					txToolData.setBinAttachHash(txChecksumTool.getValue());
				} else {
					txToolData.clearBinAttachHash();
				}
			}
		}
	}
	
	// ToolData object provided will be reset before being used.
	protected void processMessage(AbstractWrappedMessage message, ToolData toolData) {
		
		
		long timeRecv = 0;
		
		// Create or reset tool data object
		if(toolData == null)
			toolData = new ToolData();
		else
			toolData.reset();

		_msgCount.incrementAndGet();
			
		if ((_rxToolDataProps.WANT_LATENCY || _msgCount.get() % _TIMESTAMP_INTERVAL == 0)) {
			// every X messages we take timing
			timeRecv = System.nanoTime();
		}
		
		byte[] attachmentBytes = null;
		
		if (_rxToolDataProps.WANT_LATENCY || _rxToolDataProps.WANT_SLOW_PATH) {
			
			if (message.hasAttachment()) {
				attachmentBytes = message.getAttachmentBytes();
			}
			if (_wantUserPropToolData) {
				this.readToolDataFromProperties(message, toolData);
			} else {
				if (attachmentBytes != null) {
					toolData.decode(attachmentBytes, attachmentBytes.length);
				}
			}
		}
		
		if(_rxToolDataProps.WANT_PER_MESSAGE_DETAILS) {
			synchronized (_lastMessageDetails) {
				this.setLastMessageDetails(message);
			}
		}
		
		if (_rxToolDataProps.WANT_LATENCY) {
			this.processMessageLatency(timeRecv, attachmentBytes, toolData);
		}
		
		if (_rxToolDataProps.WANT_SLOW_PATH) {
			this.processMessageSlowPath(message, toolData);
		}
		
		// Must update this stat last since AFW often polls for this.  To avoid race conditions, 
        // increment this after all other message processing is done.
		if (timeRecv != 0) {
			_stats.incStat(PerfStatType.NUM_MSGS_RECV, timeRecv, 1);
		} else {
			_stats.incStat(PerfStatType.NUM_MSGS_RECV, 1);
		}

	}
	
	public void processMessage(AbstractWrappedMessage message) {
		processMessage(message, null);
	}
	
	protected void processMessageLatency(long timeRecv, byte[] attachmentBytes, ToolData toolData) {

		if(toolData.hasLatency()) {
			long currentTime = Timing.getClockValue();
			if (currentTime < toolData.getLatency()) 
			{
				Trace.error("CLIENT " + _clientIdStr + ": Negative Lat. Rcv: " + toolData.getLatency() +
						" Curr: " + currentTime + " Lat: " + (currentTime - toolData.getLatency())+ 
						" ToUs: " + Timing.microSecDivisor());
			} 
			
			_stats.incLatency(timeRecv, currentTime - toolData.getLatency());
		}
		
	}
	
	protected void processMessageSlowPath(AbstractWrappedMessage message, ToolData toolData) {
		
		if(_rxToolDataProps.WANT_PAYLOAD_CHECK) {
			boolean anyHashFails = false;
			byte[] userData = message.getUserdata();

			if(userData != null && userData.length != 0) {
				
				if(userData.length == SdkperfConstants.userDataBytes.length &&
						Arrays.equals(userData, SdkperfConstants.userDataBytes)) {
					_stats.incStat(PerfStatType.NUM_MSGS_USERDATA_OK, 1);
				} else {
					_stats.incStat(PerfStatType.NUM_MSGS_USERDATA_FAIL, 1);
					anyHashFails = true;
					Trace.warn("CLIENT " + _clientIdStr + ": MsgCount: Userdata doesn't match. MsgId:" +
							_msgCount + " Rcv: " + new String(userData));
				}
			}
			
			if(toolData.hasXmlPayloadHash()){
				byte[] scratchpad = message.getXmlBytes();
				// We do nothing if we get null back here.  No OKs or FAILs
				if (scratchpad != null && scratchpad.length != 0) {
					_rxChecksumTool.reset();
					_rxChecksumTool.update(scratchpad, 0, scratchpad.length);
					if (toolData.getXmlPayloadHash() == _rxChecksumTool.getValue()) {
						_stats.incStat(PerfStatType.NUM_MSGS_CRC_XML_PAY_OK, 1);
					} else {
						anyHashFails = true;
						_stats.incStat(PerfStatType.NUM_MSGS_CRC_XML_PAY_FAIL, 1);
						Trace.warn("CLIENT " + _clientIdStr + ": MsgCount: xml payload crc err. MsgId:" +
								_msgCount + " Rcv: " + toolData.getXmlPayloadHash() + 
								" Calc: " + _rxChecksumTool.getValue());
					}
				}
			}
			
			if(toolData.hasBinAttachHash()){
				// We need to chop off the tool data info and then check sum
				// on the remainder.  In the case where the tool data is in 
				// the user properties, the whole attachment is checked because
				// getToolDataSize() will return 0.
				byte [] scratchpad = message.getAttachmentBytes();
				
				// We do nothing if we get null back here.  No OKs or FAILs
				if (scratchpad != null && scratchpad.length != 0) {
					_rxChecksumTool.reset();
					_rxChecksumTool.update(scratchpad, 
				   						toolData.getDecodedSize(), 
				   						scratchpad.length - toolData.getDecodedSize());
					
					if (toolData.getBinAttachHash() == _rxChecksumTool.getValue()) {
						_stats.incStat(PerfStatType.NUM_MSGS_CRC_BIN_ATT_OK, 1);
					} else {
						anyHashFails = true;
						_stats.incStat(PerfStatType.NUM_MSGS_CRC_BIN_ATT_FAIL, 1);
						Trace.warn("CLIENT " + _clientIdStr + ": MsgCount: bin attach crc err. MsgId:" +
								_msgCount + " Rcv: " + toolData.getBinAttachHash() + 
								" Calc: " + _rxChecksumTool.getValue());						
					}
				}
			}
					
			if(anyHashFails) {
				//increment the global stats
				_stats.incStat(PerfStatType.NUM_MSGS_CRC_FAIL, 1);
				// dump messages that failed CRC here to avoid dumping them 3 times
				Trace.warn(message.dump());
			} else {
				_stats.incStat(PerfStatType.NUM_MSGS_CRC_OK, 1);
			}
			
		}
		
		if (_rxToolDataProps.WANT_ORDER_CHECK && 
				(toolData.hasMessageIdentifier() || message.getTopicSequence() != null)) {
			
			_stats.incStat(PerfStatType.NUM_MSGS_ORDER_CHECKED, 1);
			boolean redelivered = message.getRedelivered();

			if (redelivered) {
				_stats.incStat(PerfStatType.NUM_MSGS_REDELIVERED, 1);
			}
			
			Long topicSequenceNum = message.getTopicSequence();
			
			_stats.checkOrder(toolData, redelivered, topicSequenceNum);
		}
		
		if(_rxToolDataProps.WANT_LOSS_AND_DUPLICATE_DETECTION) {
			_stats.addMessageForLossAndDuplicateDetection(toolData.getStreamId(), toolData.getMessageIdentifier());
		}
		
		
		if (_rxToolDataProps.WANT_ORDER_MEMORY && toolData.hasStreamId()) {
			long msgId = toolData.getMessageIdentifier();
			long streamId = toolData.getStreamId();
			
			_stats.updateOrderMemory(msgId, (int)streamId);
		}

		
		if (_rxToolDataProps.CID_STATS) {
			List<Long> cids = message.getCids();
			if (cids != null) {
				Iterator<Long> allCids = cids.iterator();
				Long currentCid = null;
				while (allCids.hasNext()) {
					currentCid = (Long)allCids.next();
					_stats.incCidBucket(currentCid.intValue(), new MutableLong(1));
				}
			}
		}
		
		if (_rxToolDataProps.WANT_MESSAGE_EXAMINE_CONTENT) {
			//check for a bunch of stuffs
			
			//check for CIDs
			List<Long> cids = message.getCids();
			if (cids != null && cids.size() != 0) {
				_stats.incStat(PerfStatType.NUM_MSGS_CID, 1);				
			}
			
			//check for xml payload
			if (message.hasXml()) {
				_stats.incStat(PerfStatType.NUM_MSGS_XML_PAY, 1);
			}

			//check for a regular attachment
			if (message.hasAttachment()) {
				_stats.incStat(PerfStatType.NUM_MSGS_BIN_ATTACH, 1);
			}

			//check for userdata
			byte[] userData = message.getUserdata();
			if (userData != null && userData.length != 0) {
				_stats.incStat(PerfStatType.NUM_MSGS_USERDATA, 1);
			}
			
			//check for topic informationS
			if (message.hasTopic()) {
				_stats.incStat(PerfStatType.NUM_MSGS_TOPIC, 1);
			}
		}

		if (_rxToolDataProps.WANT_STRUCT_MSG_CHECK) {
			if (message.validateStructDataMsg()) {
				_stats.incStat(PerfStatType.NUM_MSGS_CRC_OK, 1);
				_stats.incStat(PerfStatType.NUM_MSGS_CRC_SDM_OK, 1);
			} else {
				_stats.incStat(PerfStatType.NUM_MSGS_CRC_FAIL, 1);
				_stats.incStat(PerfStatType.NUM_MSGS_CRC_SDM_FAIL, 1);
			}
		}
		
		if (_rxToolDataProps.CACHE_WANT_STATS) {
			if (message.isCacheMessage()) {
				_stats.incStat(PerfStatType.NUM_CACHE_MSGS_RECV, 1);
			} else {
				_stats.incStat(PerfStatType.NUM_LIVE_MSGS_RECV, 1);
			}
			if (message.isSuspect()) {
				_stats.incStat(PerfStatType.NUM_CACHE_SUSPECT_RECV, 1);
			}
		}
		
		if (_rxToolDataProps.WANT_DI_STATS && message.hasDiscardIndication()) {
			_stats.incStat(PerfStatType.NUM_MSGS_DI_SET, 1);
		}
		
		// The messages could already be dumped during the CRC checking step
		// but this WANT_MSG_DUMP systematic message dump is somewhat independent
		// of the CRC failure reporting errors.
		if (_rxToolDataProps.WANT_MSG_DUMP) {
			if (_rxProps.getStringProperty(RuntimeProperties.MSG_DUMP_DIR).length() > 0) {
				// Want dump to file.
				String dir = _rxProps.getStringProperty(RuntimeProperties.MSG_DUMP_DIR);
				String filename = dir + (File.separator) + 
								  _clientIdStr + "_" +
								  _stats.getStat(PerfStatType.NUM_TPUT_MSGS) + "_" +
								  Timing.getClockValue();
				try {
					byte[] bytes = message.getMessageAsBytes();
					PerfIO.writeFile(filename, bytes);
				} catch (Exception e) {
					Trace.error("CLIENT " + _clientIdStr + 
							": io exception persisting message." + 
							e.getMessage());
				} 
			} else {
				// Dump the current message.
				String msgDumpStr = message.dump();
				
				if (msgDumpStr != null) {
					System.out.println("^^^^^^^^^^^^^^^^^^ Start Message ^^^^^^^^^^^^^^^^^^^^^^^^^^^");
					System.out.println(msgDumpStr);
					if (message.hasAttachment() && toolData.hasData()) {
						System.out.println("Tool Data:");
						System.out.println(toolData.toString());
					}
					System.out.println("^^^^^^^^^^^^^^^^^^ End Message ^^^^^^^^^^^^^^^^^^^^^^^^^^^");
				} else {
					System.out.println("Skipping dump of null message.");
				}
			}
		}
		
		if (_rxToolDataProps.WANT_MSG_REFLECT) {
			// This will be handled by the actual client implementation
			// because it involves sending messages.
			try {
				
				if(message.hasReplyToDestination()) {
					if(_replyDelayList != null){					
						MessageReplyTask.scheduleMessageReplyTask(this, message, _replyDelayList.get(_delayToUse));
						_delayToUse++;
						_delayToUse = _delayToUse % _replyDelayList.size();					
					} else {
						MessageReplyTask.scheduleMessageReplyTask(this, message, 0);
					}	
				}
			} catch (Exception e) {
				Trace.error("CLIENT " + _clientIdStr + 
						": exception when reflecting message. " + 
						e.getMessage());
			}
		}
		
		if (_rxToolDataProps.NUM_MSG_PUB_ON_RCV > 0) {

			int messageSent = 0;
			
			if(_rxToolDataProps.POR_REFLECT_MESSAGE) {
				
				if(message.getReplyToDestinationName() != null && message.getReplyToDestinationName().length() > 0) {
					
					BasicMsgRep[] msg = new BasicMsgRep[1];
					msg[0] = new BasicMsgRep();
					
					byte [] xmlBytes = message.getXmlBytes();
					byte [] attBytes = message.getAttachmentBytes();
					String destName = message.getReplyToDestinationName();
					PublisherDestinationsType destType = message.getReplyToDestinationType();
					GenericMessageDeliveryMode mt = message.getDeliveryMode();

					msg[0].configureForNormalMsg(xmlBytes, attBytes, destName, destType, mt, null, null);

					try {
						msg = this.cloneToApiSpecificMsgRep(msg);
						this.publishOnReceive(message._prodOnReceive, msg[0]);
					} catch (Exception e) {
						Trace.warn("Failed to reflect message on receive.", e);
					}
					messageSent++;
				}
			}		
			
			for (; messageSent < _rxToolDataProps.NUM_MSG_PUB_ON_RCV; messageSent++) {
				try {
					
					BasicMsgRep msg = _pubOnRecMsgArray[(int) (_pubOnRecMsgArrayIndex++ % _pubOnRecMsgArray.length)];
					if (msg.destination == null || msg.destination.length() == 0) {
						// Clone the message so that we do not modify the original
						msg = msg.clone();
						msg.destination = message.getDestinationName();
						msg.destType = message.getDestinationType();
					}

					this.publishOnReceive(message._prodOnReceive, msg);
				} catch (Exception e) {
					Trace.warn("Failed to publish message #" + (messageSent + 1) + " of "
							+ _rxToolDataProps.NUM_MSG_PUB_ON_RCV + " on receive.", e);
				}
			}
		}
		
		// Must check if connected here, because once we call disconnect, we
	    // want to speed up so that the session can properly cleanup.
	    // Otherwise connect will keep processing events queued internally
	    // in the sdk with the slow sub delay.

		// Also must check that we haven't exhausted the count.
	    if (isConnected() && _rxToolDataProps.SLOW_SUB_DELAY_MSEC != 0 &&
	    		_rxToolDataProps.SLOW_SUB_DELAY_COUNT != 0) {
	    	slowSubscriberDelay();
	    }
	}
	
	protected void slowSubscriberDelay() {
        int delay = _rxToolDataProps.SLOW_SUB_DELAY_MSEC;
        if (delay == -1) {
            delay = 1000 * 60 * 60; // for -1 we'll choose 60 min for our delay
        }

        // if sleep > 500 ms, wake up occasionally to look for SIGINT etc.
        int sleepCounts;
        int sleepTimeInMillis  = 0;
        if (_rxToolDataProps.SLOW_SUB_DELAY_MSEC > 500) {
            sleepCounts = _rxToolDataProps.SLOW_SUB_DELAY_MSEC / 100;
            sleepTimeInMillis = 100;
        } else {
            sleepCounts = 1;
            sleepTimeInMillis = _rxToolDataProps.SLOW_SUB_DELAY_MSEC;
        }

        while (isConnected() && sleepCounts != 0) {
            try {
				Thread.sleep(sleepTimeInMillis);
			} catch (InterruptedException e) {
				Trace.error("Unexpected exception.", e);
			}
            sleepCounts--;
        }
        
		synchronized (this) {
			if (_rxToolDataProps.SLOW_SUB_DELAY_COUNT > 0) {
				_rxToolDataProps.SLOW_SUB_DELAY_COUNT--;
			}
		}
		
        if (Trace.isDebugEnabled())
        	Trace.debug("CLIENT " + _clientIdStr + ": Done Sleeping for slow subscriber.");
	}
	
	
	protected int setToolDataAsAttachment(final BasicMsgRep msgRep) {
		ToolData txToolData = msgRep.getToolData();
		
		if(_txToolDataProps.WANT_LATENCY) {
			long latencyTime = txToolData.getLatency();
			if (latencyTime == 0) {
				latencyTime = Timing.getClockValue();
			}
			txToolData.setLatency(latencyTime);
		}
		
		return msgRep.encodeToolDataToAttachment();
	}
	
	public void handleMessageProcessingError(Exception exception) {
		updateLastErrorResponse(exception);
		logExceptionAsError(exception);
		_asyncExceptionOccured = true;
	}
	
	/**
	 * Cache of config switches to save on map lookups in the fast path.
	 * 
	 */
	protected static class ToolDataProperties {
		public volatile boolean WANT_PAYLOAD_CHECK, WANT_UD, WANT_ORDER_CHECK,
				WANT_LOSS_AND_DUPLICATE_DETECTION, WANT_ORDER_MEMORY,
				WANT_LATENCY, CID_STATS, WANT_MESSAGE_EXAMINE_CONTENT,
				WANT_STRUCT_MSG_CHECK, CACHE_WANT_STATS, WANT_MSG_DUMP,
				WANT_DI_STATS, WANT_KEEP_MSGS, WANT_CLIENT_ACK,
				WANT_MSG_REFLECT, WANT_REPLY_TOPIC, WANT_REPLY_DELAY, WANT_PER_MESSAGE_DETAILS,
				WANT_PUB_ACK_ORDER_CHECK, POR_REFLECT_MESSAGE;
		public volatile int NUM_MSG_PUB_ON_RCV;
		
		// Derived flag/
		public volatile boolean WANT_SLOW_PATH, WANT_TOOL_DATA;
		
		public final int PUB_STREAM_ID_OFFSET, PUB_ORDER_OFFSET, SLOW_SUB_DELAY_MSEC;
		public int SLOW_SUB_DELAY_COUNT;

		public ClientModeType CLIENT_MODE;
		public String REPLY_TO_POSTFIX;
		
		public ToolDataProperties(RuntimeProperties prop) {
			this.WANT_LATENCY = prop.getBooleanProperty(RuntimeProperties.WANT_LATENCY);
			this.WANT_UD = prop.getBooleanProperty(RuntimeProperties.WANT_UD);
			this.WANT_ORDER_CHECK = prop.getBooleanProperty(RuntimeProperties.WANT_ORDER_CHECK);
			this.WANT_LOSS_AND_DUPLICATE_DETECTION = prop.getBooleanProperty(RuntimeProperties.WANT_LOSS_AND_DUPLICATE_DETECTION);
			this.WANT_ORDER_MEMORY = prop.getBooleanProperty(RuntimeProperties.WANT_ORDER_MEMORY);
			this.WANT_PAYLOAD_CHECK = prop.getBooleanProperty(RuntimeProperties.WANT_PAYLOAD_CHECK);
			this.CID_STATS = prop.getBooleanProperty(RuntimeProperties.CID_STATS);
			this.WANT_MESSAGE_EXAMINE_CONTENT = prop.getBooleanProperty(RuntimeProperties.WANT_MESSAGE_EXAMINE_CONTENT);
			this.WANT_STRUCT_MSG_CHECK = prop.getBooleanProperty(RuntimeProperties.WANT_STRUCT_MSG_CHECK);
			this.CACHE_WANT_STATS = prop.getBooleanProperty(RuntimeProperties.CACHE_WANT_STATS);
			this.PUB_STREAM_ID_OFFSET = prop.getIntegerProperty(RuntimeProperties.PUB_STREAM_ID_OFFSET);
			this.PUB_ORDER_OFFSET = prop.getIntegerProperty(RuntimeProperties.PUB_ORDER_OFFSET);
			this.WANT_MSG_DUMP = prop.getBooleanProperty(RuntimeProperties.WANT_MSG_DUMP);
			this.SLOW_SUB_DELAY_MSEC = prop.getIntegerProperty(RuntimeProperties.SUBSCRIBER_SUB_DELAY);
			this.SLOW_SUB_DELAY_COUNT = prop.getIntegerProperty(RuntimeProperties.SLOW_SUB_DELAY_COUNT);
			this.WANT_DI_STATS = prop.getBooleanProperty(RuntimeProperties.WANT_DI_STATS);
			this.WANT_MSG_REFLECT = prop.getBooleanProperty(RuntimeProperties.WANT_MSG_REFLECT);
			this.CLIENT_MODE = (ClientModeType)(prop.getProperty(RuntimeProperties.CLIENT_MODE));
			this.WANT_REPLY_TOPIC = prop.getBooleanProperty(RuntimeProperties.WANT_REPLY_TOPIC);
			this.REPLY_TO_POSTFIX = (String)(prop.getProperty(RuntimeProperties.REPLY_TO_POSTFIX));
			this.WANT_PER_MESSAGE_DETAILS = (prop.getBooleanProperty(RuntimeProperties.WANT_PER_MESSAGE_DETAILS));
			this.WANT_PUB_ACK_ORDER_CHECK = prop.getBooleanProperty(RuntimeProperties.AD_WANT_PUB_ACK_ORDER_CHECK);
			this.NUM_MSG_PUB_ON_RCV = prop.getIntegerProperty(RuntimeProperties.NUMBER_OF_MSGS_TO_PUB_ON_RCV);
			this.POR_REFLECT_MESSAGE = prop.getBooleanProperty(RuntimeProperties.POR_REFLECT_MESSAGE);
			
			// Do we want a reply delay?
			if(prop.getProperty(RuntimeProperties.MESSAGE_REPLY_DELAY_LIST) == null) {
				this.WANT_REPLY_DELAY = false;
			} else {
				@SuppressWarnings("unchecked")
				List<Integer> list = (List<Integer>) prop.getProperty(RuntimeProperties.MESSAGE_REPLY_DELAY_LIST);
				if(list.size() > 0) {
					// Make sure at least one is non-null and greater than 0
					for(Integer i: list) {
						if(i != null && i > 0) {
							this.WANT_REPLY_DELAY = true;
							break;
						}
					}
				} else {
					this.WANT_REPLY_DELAY = false;
				}
			}
						
			if (prop.getIntegerProperty(RuntimeProperties.SUB_MSG_QUEUE_DEPTH) > 0) {
				this.WANT_KEEP_MSGS = true;
			} else {
				this.WANT_KEEP_MSGS = false;
			}
			
			// This doesn't force you to slow path.
			this.WANT_CLIENT_ACK = prop.getBooleanProperty(RuntimeProperties.WANT_CLIENT_ACK);
			
			
			if (this.WANT_PAYLOAD_CHECK ||
			    this.WANT_ORDER_CHECK ||
			    this.WANT_LOSS_AND_DUPLICATE_DETECTION ||
			    this.WANT_ORDER_MEMORY ||
			    this.CID_STATS ||
			    this.WANT_DI_STATS ||
			    this.WANT_MESSAGE_EXAMINE_CONTENT ||
			    this.WANT_STRUCT_MSG_CHECK ||
			    this.CACHE_WANT_STATS ||
			    this.WANT_MSG_DUMP ||
			    this.SLOW_SUB_DELAY_MSEC > 0 ||
			    this.SLOW_SUB_DELAY_COUNT > 0 ||
			    this.WANT_MSG_REFLECT ||
			    this.WANT_KEEP_MSGS ||
			    this.NUM_MSG_PUB_ON_RCV > 0 ) {
		        this.WANT_SLOW_PATH = true;
		    } else {
		    	this.WANT_SLOW_PATH = false;
		    }
			
			if (this.WANT_PAYLOAD_CHECK ||
				this.WANT_LOSS_AND_DUPLICATE_DETECTION ||
			    this.WANT_ORDER_CHECK ||
			    this.WANT_ORDER_MEMORY ||
			    this.WANT_LATENCY) {
				this.WANT_TOOL_DATA = true;
			} else {
				this.WANT_TOOL_DATA = false;
			}
		}
	}


	public ChannelState getChannelState() {
		return _channelState;
	}
	
	// Can be used to set which ClientCollection owns this Client
	public void setCollection(AbstractClientCollection cc) {
		_clientCollection = cc;
	}
	
	public AbstractClientCollection getOwner() {
		return _clientCollection;
	}

}
