/** 
*  Copyright 2004-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.jcsmpcore;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.jcsmp.AccessDeniedException;
import com.solacesystems.jcsmp.Browser;
import com.solacesystems.jcsmp.BrowserProperties;
import com.solacesystems.jcsmp.BytesXMLMessage;
import com.solacesystems.jcsmp.CacheLiveDataAction;
import com.solacesystems.jcsmp.CacheRequestListener;
import com.solacesystems.jcsmp.CacheRequestResult;
import com.solacesystems.jcsmp.CacheSession;
import com.solacesystems.jcsmp.CacheSessionProperties;
import com.solacesystems.jcsmp.CapabilityType;
import com.solacesystems.jcsmp.Consumer;
import com.solacesystems.jcsmp.ConsumerFlowProperties;
import com.solacesystems.jcsmp.Context;
import com.solacesystems.jcsmp.ContextProperties;
import com.solacesystems.jcsmp.Destination;
import com.solacesystems.jcsmp.DestinationUtils;
import com.solacesystems.jcsmp.DurableTopicEndpoint;
import com.solacesystems.jcsmp.Endpoint;
import com.solacesystems.jcsmp.EndpointProperties;
import com.solacesystems.jcsmp.FlowEventArgs;
import com.solacesystems.jcsmp.FlowEventHandler;
import com.solacesystems.jcsmp.FlowReceiver;
import com.solacesystems.jcsmp.JCSMPChannelProperties;
import com.solacesystems.jcsmp.JCSMPErrorResponseException;
import com.solacesystems.jcsmp.JCSMPErrorResponseSubcodeEx;
import com.solacesystems.jcsmp.JCSMPException;
import com.solacesystems.jcsmp.JCSMPFactory;
import com.solacesystems.jcsmp.JCSMPFlowTransportException;
import com.solacesystems.jcsmp.JCSMPInterruptedException;
import com.solacesystems.jcsmp.JCSMPProducerEventHandler;
import com.solacesystems.jcsmp.JCSMPProperties;
import com.solacesystems.jcsmp.JCSMPRuntime;
import com.solacesystems.jcsmp.JCSMPSendMultipleEntry;
import com.solacesystems.jcsmp.JCSMPSession;
import com.solacesystems.jcsmp.JCSMPStreamingPublishCorrelatingEventHandler;
import com.solacesystems.jcsmp.JCSMPStreamingPublishEventHandler;
import com.solacesystems.jcsmp.JCSMPTransportException;
import com.solacesystems.jcsmp.MapMessage;
import com.solacesystems.jcsmp.Producer;
import com.solacesystems.jcsmp.ProducerEventArgs;
import com.solacesystems.jcsmp.ProducerFlowProperties;
import com.solacesystems.jcsmp.Queue;
import com.solacesystems.jcsmp.Requestor;
import com.solacesystems.jcsmp.SDTException;
import com.solacesystems.jcsmp.SDTMap;
import com.solacesystems.jcsmp.SessionEventArgs;
import com.solacesystems.jcsmp.SessionEventHandler;
import com.solacesystems.jcsmp.StreamMessage;
import com.solacesystems.jcsmp.Subscription;
import com.solacesystems.jcsmp.TextMessage;
import com.solacesystems.jcsmp.Topic;
import com.solacesystems.jcsmp.TopicProperties;
import com.solacesystems.jcsmp.User_Cos;
import com.solacesystems.jcsmp.XMLMessage;
import com.solacesystems.jcsmp.XMLMessageListener;
import com.solacesystems.jcsmp.XMLMessageProducer;
import com.solacesystems.jcsmp.impl.flow.FlowHandleImpl;
import com.solacesystems.jcsmp.impl.sdt.InteropTest;
import com.solacesystems.jcsmp.transaction.RollbackException;
import com.solacesystems.jcsmp.transaction.TransactedSession;
import com.solacesystems.jcsmp.transaction.TransactionResultUnknownException;
import com.solacesystems.pubsub.sdkperf.config.EpConfigProperties;
import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.AbstractCacheLiveDataAction;
import com.solacesystems.pubsub.sdkperf.core.AbstractClient;
import com.solacesystems.pubsub.sdkperf.core.AbstractClientTransactedSession;
import com.solacesystems.pubsub.sdkperf.core.AbstractMessageAckData;
import com.solacesystems.pubsub.sdkperf.core.AbstractWrappedMessage;
import com.solacesystems.pubsub.sdkperf.core.BasicMsgRep;
import com.solacesystems.pubsub.sdkperf.core.ChannelState;
import com.solacesystems.pubsub.sdkperf.core.ClientFactory;
import com.solacesystems.pubsub.sdkperf.core.Constants;
import com.solacesystems.pubsub.sdkperf.core.Constants.EndpointAccessType;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericAuthenticationScheme;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericSupportedAckEvent;
import com.solacesystems.pubsub.sdkperf.core.Constants.ReconnectFailAction;
import com.solacesystems.pubsub.sdkperf.core.FlowStatus;
import com.solacesystems.pubsub.sdkperf.core.GenericCapabilityType;
import com.solacesystems.pubsub.sdkperf.core.GenericStatType;
import com.solacesystems.pubsub.sdkperf.core.PerfStats.PerfStatType;
import com.solacesystems.pubsub.sdkperf.core.PubSubException;
import com.solacesystems.pubsub.sdkperf.core.ToolData;
import com.solacesystems.pubsub.sdkperf.core.TransactionRollbackException;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.ActiveFlowIndicationType;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.ClientModeType;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.PublisherDestinationsType;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.SubscriberDestinationsType;
import com.solacesystems.pubsub.sdkperf.util.SdkperfConstants;
import com.solacesystems.pubsub.sdkperf.util.SubscriptionUtils;
import com.solacesystems.pubsub.sdkperf.util.SubscriptionUtils.SubscriptionBean;
import com.solacesystems.pubsub.sdkperf.util.Timing;


/**
 * Class for managing all activities of a single client.  Handles
 * all JCSMP sdk interactions. 
 */
public class JcsmpClient 
	extends AbstractClient 
	implements JCSMPStreamingPublishEventHandler,
	           JCSMPStreamingPublishCorrelatingEventHandler,
			   CacheRequestListener,
			   SessionEventHandler,
			   JCSMPProducerEventHandler
{

	private static final Log Trace = LogFactory.getLog(JcsmpClient.class);
	//private static final HashMap<Integer, Context> _contextsMap = new HashMap<Integer, Context>();
	
	private Context _context;
	private static volatile boolean JcsmpGlobalPropsInitialized = false;

	//protected Context _context;
	protected JCSMPSession _jSession = null;
	protected CacheSession _cacheSession = null;
	protected JCSMPProperties _jProps;
	protected CacheSessionProperties _cacheProps;
	protected List<MesssageListener> _consumersList;
	protected XMLMessageProducer _defaultProducer;
	protected List<XMLMessageProducer> _producerList;
	protected long _producerListIndex = 0;
	protected MesssageListener _defaultConsumer;
	protected Consumer _syncConsumer;
    
	protected XMLMessageProducer _currProducer;
	protected TransactedSession _currProducerXaSession;
	
	protected long _requestId = 0;
	protected Set<Subscription> _subscriptionMem;
	private String _clientName;
	private boolean _customClientName = false; 
	protected List<Browser> _browserList;
	protected List<BytesXMLMessage> _qbBufferedMsgList;
	protected int _qbDeleteFrequency;
	protected long _qbMsgCount;
	protected int _qbMaxBufferedMsgs;
	protected BytesXMLMessage[] _messagesArray;
	protected List<JCSMPSendMultipleEntry[]> _sendVectorMsgs;
	protected ConcurrentLinkedQueue<JcsmpMessageAckData> _keptMsgQueue;
	protected int _maxKeptMsgs;
	protected Random _randomGenerator;
	protected HashMap<String, JcsmpClientTransactedSession> _transactedSessions;
	protected HashMap<String, XMLMessageProducer> _transactedProducers;
	// the next two variables are buffers to speed up message reflection
	protected long _highestCorrelationTagValueAcked;
	
	protected ClientAckThread _clientAckThread;
	
	
	public JcsmpClient() {}
	
	public void init(final RuntimeProperties perfProps, final int clientIdInt) throws Exception {
		super.init(perfProps, clientIdInt);
		
		if (!JcsmpGlobalPropsInitialized) {
			if (perfProps.getIntegerProperty(RuntimeProperties.SUB_NOTIFICATION_QUEUE_DEPTH) > 0) {
				com.solacesystems.jcsmp.JCSMPGlobalProperties g_prop = JCSMPFactory.onlyInstance().getGlobalProperties();
				g_prop.setConsumerDispatcherQueueSize(perfProps.getIntegerProperty(RuntimeProperties.SUB_NOTIFICATION_QUEUE_DEPTH));
				JCSMPFactory.onlyInstance().setGlobalProperties(g_prop);
			}
			
			JcsmpGlobalPropsInitialized = true;
		}

		
		
		final JCSMPProperties jprops = buildJCSMPProps(perfProps, clientIdInt);
		final CacheSessionProperties cacheProps = buildJCSMPCacheProps(perfProps);
		
		
		_jProps = jprops;
		_cacheProps = cacheProps;
		_defaultConsumer = null;
		_consumersList = new ArrayList<MesssageListener>();
		_producerList = new ArrayList<XMLMessageProducer>();

		// Must set this to true for sdkperf interop testing.
		InteropTest.IgnoreGeneratedSendTimestamps = true;
		
		_browserList = new ArrayList<Browser>();
		
		_messagesArray = new BytesXMLMessage[_numPubPerSession];
		_sendVectorMsgs = new ArrayList<JCSMPSendMultipleEntry[]>();
		
		for (int i = 0; i < _numPubPerSession; i++) {
			// Use internal buffers for now.
			_messagesArray[i] = JCSMPFactory.onlyInstance().createMessage(BytesXMLMessage.class);
			_sendVectorMsgs.add(null);
			
		}
		
		_keptMsgQueue = new ConcurrentLinkedQueue<JcsmpMessageAckData>();
		_maxKeptMsgs = _rxProps.getIntegerProperty(RuntimeProperties.SUB_MSG_QUEUE_DEPTH);
		_randomGenerator = new Random();
		_transactedSessions = new HashMap<String, JcsmpClientTransactedSession>();
		_transactedProducers = new HashMap<String, XMLMessageProducer>();
		
		if (_rxProps.getBooleanProperty(RuntimeProperties.WANT_CLIENT_ACK_THREAD)) {
			_clientAckThread = new ClientAckThread(this, _keptMsgQueue);
			_clientAckThread.setDaemon(true);
			_clientAckThread.start();
		}
		
		_highestCorrelationTagValueAcked = 0;
	}
	
	@Override
    public long getLastAckedMsgId() {
        return _highestCorrelationTagValueAcked;
    }
	
	@Override
	public void setLastAckedMsgId(long value) {
		_highestCorrelationTagValueAcked = value;
	}
	
	@Override
	public String getClientName() {
		return (String)_jSession.getProperty(JCSMPProperties.CLIENT_NAME);
	}
	
	@Override
	public String getReplyToDestination() {
		String s = super.getReplyToDestination();
		
		if(s != null) {
			return s;
		}
		
		if (_rxProps.getBooleanProperty(RuntimeProperties.WANT_REPLY_TEMPORARY_QUEUE)) {
			// TODO: currently not supported for JcsmpClient.
		} else if (_rxProps.getBooleanProperty(RuntimeProperties.WANT_REPLY_TOPIC)) {
			// Default is to use #P2P topic
			if(_jSession == null)
				return null;
			else {
				try {
					s = ((Topic)_jSession.getProperty(JCSMPProperties.P2PINBOX_IN_USE)).getName();
					return s;
				} catch (Exception e) {
					Trace.warn("Exception received when attempting to get P2P inbox in use.", e);
					return null;
				}
			}
		}
		
		Trace.warn("Could not determine reply-to destination.");
		return null;
	}

	@Override
	public void setClientName(String value) throws JCSMPException {
		_jSession.setProperty(JCSMPProperties.CLIENT_NAME, value);
		_customClientName = true;
	}
	
	@Override
	public void clearSubscriptionMemory() throws Exception {
		_consumersList.clear();
	}
	
	@Override
	public void clearKeptMsgs() throws JCSMPException {
		
		// Must empty any kept messages
		for(JcsmpMessageAckData messageAckData : _keptMsgQueue) {
			
			JcsmpWrappedMessage jWmsg = messageAckData.getMessage();
			BytesXMLMessage bXmlMsg = jWmsg.getMessage();
			// Ack the message
			bXmlMsg.ackMessage();
		}
		_keptMsgQueue.clear();		
	}

	@Override
	public void clearKeptMsgs(String destination, boolean isTopic) throws JCSMPException {
		// Only ack messages matching the endpoint.
		for(JcsmpMessageAckData messageAckData : _keptMsgQueue) {
			if (messageAckData.isFromFlow(destination, isTopic)) {
				JcsmpWrappedMessage jwMsg = messageAckData.getMessage();
				jwMsg.getMessage().ackMessage();
				_keptMsgQueue.remove(messageAckData);
			}
		}	
	}

	@Override
	public void subscriptionUpdate(EpConfigProperties epProps) throws JCSMPException {
		
		// If we're here and default consumer is still null, then we need to start up the
		// default consumer.
		if (epProps.getIsAdding()) {
			try {
				connectDefaultFlow();
			} catch (Exception e) {
				Trace.error("CLIENT " + _clientIdStr + ": " + e.getMessage(), e);
			}
		}
		
		if (epProps.getType() == SubscriberDestinationsType.NULL) {
			if (_jSession.isCapable(CapabilityType.SUPPORTS_XPE_SUBSCRIPTIONS)) {
				epProps.setType(SubscriberDestinationsType.XPE);
			} else {
				epProps.setType(SubscriberDestinationsType.TOPIC);
			}		
		}
		
		// If automation passed us the default queue as a name, then all it wanted 
		// was for us to bind the default queue, so skip on.
		List<String> lst = epProps.getSubscriptions();
		if (lst.contains(Constants.SUB_DEFAULT_QUEUE_NAME)) {
			if (!epProps.getIsAdding() && _defaultConsumer != null) {
				// We got a request to unbind the default flow.  So do it.
				_defaultConsumer.consumer.close();
				_defaultConsumer = null;
			}
			// No further processing of this xpe.
			return;
		}
		
		Endpoint endpoint = null;
		
		if (!epProps.getClientName().equals("")) {
			endpoint = JCSMPFactory.onlyInstance().createClientName(epProps.getClientName());
		}
		
		String s;
		Iterator<String> strIt = lst.iterator();
		int waitForConfirm = 0;
		while (strIt.hasNext() && (s = strIt.next()) != null) {
			
			// If we're on the last item, then we want to wait for confirm.
			if (!strIt.hasNext()) 
			{
				waitForConfirm = JCSMPSession.WAIT_FOR_CONFIRM;
			}
			
			Subscription subscription = generateTopicFromString(s);
						
			try {
				if (epProps.getIsAdding()) {
					_jSession.addSubscription(endpoint, subscription, waitForConfirm);
				} else {
					_jSession.removeSubscription(endpoint, subscription, waitForConfirm);
				}
			} catch (JCSMPErrorResponseException ex) {
				if (ex.getSubcodeEx() == JCSMPErrorResponseSubcodeEx.SUBSCRIPTION_ALREADY_PRESENT) {
					Trace.info(String.format("Ignoring SUBSCRIPTION_ALREADY_PRESENT. (%s)%n", subscription));
				} else {
					_lastErrorResponse = ex;
					throw ex;
				}
			}
		}
	}
	
	@Override
	public void queueUpdate(EpConfigProperties epProps) throws JCSMPException {
		List<String> queues = epProps.getEpNames();
		List<String> selectors = epProps.getSelectors();
		
		int iQueueSize = (queues == null) ? 0 : queues.size();
		int iSelectorsSize = (selectors == null) ? 0 : selectors.size();
		int i = 0;
		
		if (iQueueSize == 0) {
			Trace.error("CLIENT " + _clientIdStr + ": Empty queue list provided. Aborting queue update");
			return;
		}
		if ((iQueueSize != iSelectorsSize) && (iSelectorsSize != 0)) {
			Trace.error("CLIENT " + _clientIdStr + ": Queue list must be the same size as selector list");
			return;
		}
		
        try {
			if (epProps.getIsAdding()) {
				for (String queueName : queues) {
					Queue queue = JCSMPFactory.onlyInstance().createQueue(queueName);
					boolean isTopic = false;
					
					JcsmpClientTransactedSession transactedSession = null;
					if (!epProps.getTransactedSessionName().equals("")) {
						transactedSession = _transactedSessions.get(epProps.getTransactedSessionName());
					}
					
					MesssageListener myConsumer = new MesssageListener(queueName, isTopic, null, false, transactedSession);
					ConsumerFlowProperties consFlowProps = new ConsumerFlowProperties();
					consFlowProps.setEndpoint(queue);
					consFlowProps.setNoLocal(epProps.getNoLocal());
					consFlowProps.setActiveFlowIndication(epProps.getWantActiveFlowIndication());
					
					if(iSelectorsSize > 0) {
						String curSelector = selectors.get(i % selectors.size());
						consFlowProps.setSelector(curSelector);
					}
					
					Consumer consumer = null;
					if (!epProps.getTransactedSessionName().equals("")) {
						consumer = ((TransactedSession)transactedSession.getTransactedSession()).createFlow(myConsumer, consFlowProps, null, myConsumer);
						transactedSession.setDispatcher(((FlowHandleImpl)consumer).getConsumerNotifDsp());
						
					} else {
						consumer = _jSession.createFlow(myConsumer, consFlowProps, null, myConsumer);
					}
					
					myConsumer.consumer = consumer;
					_consumersList.add(myConsumer);
					i++;
				}
			} else {
				// Removing.
				
				// For each topic, must find matching consumer.  For now do it this slow way
				// we can look at speeding this up if required.
				boolean matchfound = false;
				for (String queueName : queues) {
					// Find matching consumer and close it.
					Iterator<MesssageListener> iter = _consumersList.iterator();
					while (iter.hasNext()) {
						MesssageListener cons = iter.next();
						if (cons.destination.equals(queueName)) {
							if (cons.consumer != null) {
								// We've found the matchin dte.
								matchfound = true;
								
								if (_rxProps.getBooleanProperty(RuntimeProperties.WANT_CLIENT_ACK)) {
									// Process any outstanding acks that may be queued.
									cons.consumer.stop();
									synchronized(_keptMsgQueue) {
										clearKeptMsgs(cons.destination, cons.isTopic);
									}
								}
                                cons.consumer.close();
							}
							
							iter.remove();
							if (cons.consumer != null) {
								break;
							}
						}
					}
				}
				if (!matchfound) {
					Trace.error("CLIENT " + _clientIdStr + ": Did not find matching in topic remove.");
				}
			}
		} catch (JCSMPErrorResponseException ex) {
			
			_lastErrorResponse = ex;
			throw ex;
		}
	}

	@Override
	public void topicUpdate(EpConfigProperties epProps) throws JCSMPException {
		List<String> topics = epProps.getSubscriptions();
		List<String> endpointNames = epProps.getEpNames();
		List<String> selectors = epProps.getSelectors();
		
		int iTopicsSize = (topics == null) ? 0 : topics.size();
		int iDTESize = (endpointNames == null) ? 0 : endpointNames.size();
		int iSelectorsSize = (selectors == null) ? 0 : selectors.size();
		
		if (iDTESize == 0) 
		{
			Trace.error("CLIENT " + _clientIdStr + ": Empty durable topic endpoint list provided. Aborting topic update");
			return;
		}
		
		try {
			if (epProps.getIsAdding()) {
				if (iSelectorsSize > 0 && iTopicsSize > 0 
						&& ((iTopicsSize != iDTESize) || (iTopicsSize != iSelectorsSize)) 
						&& (iSelectorsSize != 1) ) {
					Trace.error("CLIENT " + _clientIdStr + ": Topics and Selectors specified for DTEs but not of same length.  Aborting topic update");
					return;
				}
				
				for (int i = 0; i < iDTESize; i++) {
					String dteName = endpointNames.get(i);
					DurableTopicEndpoint dte = JCSMPFactory.onlyInstance().createDurableTopicEndpoint(dteName);

					Topic topic = generateTopicFromString(topics.get(i));
					
					JcsmpClientTransactedSession transactedSession = null;
					if (!epProps.getTransactedSessionName().equals("")) {
						transactedSession = _transactedSessions.get(epProps.getTransactedSessionName());
					}
					
					MesssageListener myConsumer = new MesssageListener(dteName, true, topic, false, transactedSession);
					
					ConsumerFlowProperties consFlowProps = new ConsumerFlowProperties();
					consFlowProps.setEndpoint(dte);
					consFlowProps.setNewSubscription(topic);
					consFlowProps.setNoLocal(epProps.getNoLocal());
					
					if(iSelectorsSize > 0) {
						if(iSelectorsSize > 1) {
							consFlowProps.setSelector(selectors.get(i));
						} else {
							consFlowProps.setSelector(selectors.get(0));
						}
					}
					
					Consumer consumer = null;
					if (!epProps.getTransactedSessionName().equals("")) {
						consumer = ((TransactedSession)transactedSession.getTransactedSession()).createFlow(myConsumer, consFlowProps, null);
						transactedSession.setDispatcher(((FlowHandleImpl)consumer).getConsumerNotifDsp());
					} else {
						consumer = _jSession.createFlow(myConsumer, consFlowProps);
					}
					myConsumer.consumer = consumer;
					_consumersList.add(myConsumer);
				}
			} else {
				// Removing.
				
				// For each topic, must find matching consumer.  For now do it this slow way
				// we can look at speeding this up if required.
				boolean matchfound = false;
				for (String dteStr : endpointNames) {
					// Find matching consumer and close it.
					Iterator<MesssageListener> iter = _consumersList.iterator();
					while (iter.hasNext()) {
						MesssageListener cons = iter.next();
						if (cons.destination.equals(dteStr)) {
							if (cons.consumer != null) {
								// We've found the matching dte.
								matchfound = true;
								
								if (_rxProps.getBooleanProperty(RuntimeProperties.WANT_CLIENT_ACK)) {
									// Process any outstanding acks that may be queued.
									cons.consumer.stop();
									synchronized(_keptMsgQueue) {
										clearKeptMsgs(cons.destination, cons.isTopic);
									}
								}
								cons.consumer.close();
								
								if(epProps.getTopicUnsubscribe()) {
									FlowReceiver tempFlow = (FlowReceiver) cons.consumer;	
									if(tempFlow.getEndpoint() instanceof DurableTopicEndpoint) {
										_jSession.unsubscribeDurableTopicEndpoint((DurableTopicEndpoint) tempFlow.getEndpoint());
									}
								}
							}
							
							iter.remove();
							if (cons.consumer != null) {
								break;
							}
						}
					}
				}
				if (!matchfound) {
					Trace.error("CLIENT " + _clientIdStr + ": Did not find matching in topic remove.");
				}
			}
		} catch (JCSMPErrorResponseException ex) {
			
			_lastErrorResponse = ex;
			throw ex;
		}
	}

	@Override
	public Vector<String> tempEndpointUpdate(EpConfigProperties epProps) throws Exception {
		Vector<String> retList = new Vector<String>();
		
		List<String> topics = epProps.getSubscriptions();
		List<String> selectors = epProps.getSelectors();
		int iSelectorsSize = (selectors == null) ? 0 : selectors.size();
		
		if (epProps.getNumTempEndpoints() > 0 && iSelectorsSize > 0 && epProps.getNumTempEndpoints() != iSelectorsSize && iSelectorsSize != 1 ) {
			Trace.error("CLIENT " + _clientIdStr + ": Size of selector list and number of temporary endpoints are not equal");
			return null;
		}
		
		try {
			Iterator<String> topicsIter = null; 
			for (int i = 0; i < epProps.getNumTempEndpoints(); i++) {
				MesssageListener myConsumer = null;
				Endpoint endpoint = null;
				Topic topic = null;
				
				boolean isTopic = true;
				if (epProps.getType() == SubscriberDestinationsType.TOPIC) {
					isTopic = true;
					
					if (topics == null || topics.isEmpty()) {
						topic = _jSession.createTemporaryTopic();
					} else {
						if (topicsIter == null || !topicsIter.hasNext()) {
							topicsIter = topics.iterator();
						}

						topic = generateTopicFromString(topicsIter.next());
					}
					endpoint = _jSession.createNonDurableTopicEndpoint();
				} else {
					isTopic = false;
					endpoint = _jSession.createTemporaryQueue();
				}
				
				JcsmpClientTransactedSession transactedSession = null;
				if (!epProps.getTransactedSessionName().equals("")) {
					transactedSession = _transactedSessions.get(epProps.getTransactedSessionName());
				}
				
				myConsumer = new MesssageListener("", isTopic, topic, true, transactedSession);
				ConsumerFlowProperties consFlowProps = new ConsumerFlowProperties();
				consFlowProps.setEndpoint(endpoint);
				consFlowProps.setNewSubscription(topic);
				consFlowProps.setNoLocal(epProps.getNoLocal());
				consFlowProps.setActiveFlowIndication(epProps.getWantActiveFlowIndication());
				
				EndpointProperties endpointProps = new EndpointProperties();

				if (epProps.getMaxMsgSize() != -1) {
					endpointProps.setMaxMsgSize(epProps.getMaxMsgSize());
				}

				if (epProps.getQuota() != -1) {
					endpointProps.setQuota(epProps.getQuota());
				}

				if (!epProps.getPermission().equals("")) {
					if (epProps.getPermission().equalsIgnoreCase("n")) {
						endpointProps.setPermission(EndpointProperties.PERMISSION_NONE);
					} else if (epProps.getPermission().equalsIgnoreCase("r")) {
						endpointProps.setPermission(EndpointProperties.PERMISSION_READ_ONLY);
					} else if (epProps.getPermission().equalsIgnoreCase("c")) {
						endpointProps.setPermission(EndpointProperties.PERMISSION_CONSUME);
					} else if (epProps.getPermission().equalsIgnoreCase("m")) {
						endpointProps.setPermission(EndpointProperties.PERMISSION_MODIFY_TOPIC);
					} else if (epProps.getPermission().equalsIgnoreCase("d")) {
						endpointProps.setPermission(EndpointProperties.PERMISSION_DELETE);
					} else {
						throw new PubSubException("PE permission not understood: " + epProps.getPermission());
					}
				}

				if (epProps.getRespectTTL()) {
					endpointProps.setRespectsMsgTTL(epProps.getRespectTTL());
				}

				// We use -1 as the placeholder for the default value
				// to indicate that we'll leave this value to the sdk
				// to determine.
				if (epProps.getDiscardNotifySender() != -1) {
					endpointProps.setDiscardBehavior( epProps.getDiscardNotifySender() );
				}
				
				if (epProps.getMaxMsgRedelivery() != -1) {
					endpointProps.setMaxMsgRedelivery( epProps.getMaxMsgRedelivery() );
				}
				
				if(iSelectorsSize > 0) {
					if(iSelectorsSize > 1) {
						consFlowProps.setSelector(selectors.get(i));
					} else {
						consFlowProps.setSelector(selectors.get(0));
					}
				}
				
				Consumer consumer = null;
				if (!epProps.getTransactedSessionName().equals("")) {
					consumer = ((TransactedSession)transactedSession.getTransactedSession()).createFlow(myConsumer, consFlowProps, endpointProps, myConsumer);
					transactedSession.setDispatcher(((FlowHandleImpl)consumer).getConsumerNotifDsp());
				} else {
					consumer = _jSession.createFlow(myConsumer, consFlowProps, endpointProps, myConsumer);
				}
								
				myConsumer.consumer = consumer;
				
				if (isTopic) {
					myConsumer.destination = endpoint.getName();
				} else {
					myConsumer.destination = DestinationUtils.onlyInstance().getNetworkName((Queue)endpoint);
				}
				
				_consumersList.add(myConsumer);
				retList.add(myConsumer.destination);
			}
		} catch (JCSMPErrorResponseException ex) {
			_lastErrorResponse = ex;
			throw ex;
		}
		return retList;
	}
	
	@Override
	public void unbindAllTempEndpoints() throws Exception {
		// Find matching non-durable consumers and close them.
		Iterator<MesssageListener> iter = _consumersList.iterator();
		while (iter.hasNext()) {
			MesssageListener cons = iter.next();
			if (cons.isNonDurable) {
				
				if (cons.consumer != null) {
					if (_rxProps.getBooleanProperty(RuntimeProperties.WANT_CLIENT_ACK)) {
						// Process any outstanding acks that may be queued.
						cons.consumer.stop();
						synchronized(_keptMsgQueue) {
							clearKeptMsgs(cons.destination, cons.isTopic);
						}
					}
					cons.consumer.close();
				}
				
				iter.remove();
			}
		}
	}
	
	private Topic generateTopicFromString(String topic) {
		
		SubscriptionBean sb = SubscriptionUtils.buildSubscriptionBeanFromExpression(topic);

		TopicProperties tp = new TopicProperties();
		tp.setRxAllDeliverToOne(sb.getDeliverAlways());
		tp.setName(sb.getTopic());

		return JCSMPFactory.onlyInstance().createTopic(tp);
	}
	
	@Override
	public void mapTopics(String queueName, List<String> topics, boolean isAdding) throws Exception {
		int iTopicsSize = (topics == null) ? 0 : topics.size();
		
		if (iTopicsSize == 0) {
			Trace.error("CLIENT " + _clientIdStr + ": Empty topics list provided. Aborting topic mapping");
			return;
		}
		
		try {
			Queue queue = (Queue) DestinationUtils.onlyInstance().queueFromNetworkName(queueName);
			
			String s;
			Iterator<String> strIt = topics.iterator();
			int waitForConfirm = 0;
			while (strIt.hasNext() && (s = strIt.next()) != null) {
				
				// If we're on the last item, then we want to wait for confirm.
				if (!strIt.hasNext()) 
				{
					waitForConfirm = JCSMPSession.WAIT_FOR_CONFIRM;
				}
				
				Topic subscription = generateTopicFromString(s);
				
				if (isAdding) {
					_jSession.addSubscription(queue, subscription, waitForConfirm);
				} else {
					_jSession.removeSubscription(queue, subscription, waitForConfirm);
				}
			}
		} catch (AccessDeniedException adEx) {
			
			_lastErrorResponse = (JCSMPErrorResponseException) adEx.getCause();
			throw adEx;
		} catch (JCSMPErrorResponseException ex) {
			
			_lastErrorResponse = ex;
			throw ex;
		}
	}
	
	@Override
	public void endpointProvisioning(EpConfigProperties epProps) throws Exception 
    {

		// Rip out the values in epProps to use them in this function
		// in a way that sets apart the instance of EpConfigProperties
		// passed in as argument and the instance of EndpointProperties
		// passed to an SDK call.
		List<String> epNames = epProps.getEpNames();
		boolean isTopic = epProps.getIsTopic();
		boolean isAdding = epProps.getIsAdding();

		EndpointAccessType accessType = epProps.getAccessType();
        int maxMsgSize = epProps.getMaxMsgSize();
        int quota = epProps.getQuota();
        String permission = epProps.getPermission();
        boolean respectTTL = epProps.getRespectTTL();
        int discardNotifySender = epProps.getDiscardNotifySender();
        int maxMsgRedelivery = epProps.getMaxMsgRedelivery();

        if(Trace.isDebugEnabled())
        	Trace.debug("epProps in endpointProvisioning(...) : \n" + epProps.toString());
        
        
		for (String endpoint : epNames) {
			Endpoint tempEndpoint;
			
			if (isTopic) {
				tempEndpoint = JCSMPFactory.onlyInstance().createDurableTopicEndpointEx(endpoint);
			} else {
				tempEndpoint = JCSMPFactory.onlyInstance().createQueue(endpoint);
			}
			
			if (isAdding) {
			
				// Don't confuse endpointProps and epProps.
				EndpointProperties endpointProps = new EndpointProperties();
				
				if (accessType != EndpointAccessType.ACCESSTYPE_API_DEFAULT) {
					if(accessType == EndpointAccessType.ACCESSTYPE_NONEXCLUSIVE) {
						endpointProps.setAccessType(EndpointProperties.ACCESSTYPE_NONEXCLUSIVE);
					} else if(accessType == EndpointAccessType.ACCESSTYPE_EXCLUSIVE) {
						endpointProps.setAccessType(EndpointProperties.ACCESSTYPE_EXCLUSIVE);
					} else {
						Trace.warn("Unknown Endpoint Access Type, using API default.");
					}
				}
				
				if (quota != -1) {
					endpointProps.setQuota(quota);
				}

				if (maxMsgSize != -1) {
					endpointProps.setMaxMsgSize(maxMsgSize);
				}

				if (!permission.equals("")) {
					
					// Casting to int for ease here because I can't see why we'll ever get to long values.
					if (permission.equalsIgnoreCase("n")) {
						endpointProps.setPermission(EndpointProperties.PERMISSION_NONE);
					} else if (permission.equalsIgnoreCase("r")) {
						endpointProps.setPermission(EndpointProperties.PERMISSION_READ_ONLY);
					} else if (permission.equalsIgnoreCase("c")) {
						endpointProps.setPermission(EndpointProperties.PERMISSION_CONSUME);
					} else if (permission.equalsIgnoreCase("m")) {
						endpointProps.setPermission(EndpointProperties.PERMISSION_MODIFY_TOPIC);
					} else if (permission.equalsIgnoreCase("d")) {
						endpointProps.setPermission(EndpointProperties.PERMISSION_DELETE);
					} else {
						throw new PubSubException("PE permission not understood: " + permission);
			        }
				}
				
				if (discardNotifySender != -1) {
					endpointProps.setDiscardBehavior(discardNotifySender);
				}
				
				if (maxMsgRedelivery != -1) {
					endpointProps.setMaxMsgRedelivery(maxMsgRedelivery);
				}
				
				if (respectTTL) {
					endpointProps.setRespectsMsgTTL(respectTTL);
				}
				
				_jSession.provision(tempEndpoint, endpointProps, JCSMPSession.FLAG_IGNORE_ALREADY_EXISTS);
			} else {
				_jSession.deprovision(tempEndpoint, JCSMPSession.FLAG_IGNORE_DOES_NOT_EXIST);
			}
		}
	}
	
	@Override
	public FlowStatus getFlowStatus(String epName) {
		
		FlowStatus flowStatus = new FlowStatus();
		
		for (MesssageListener cons : _consumersList) {
			if (cons.destination.equals(epName)) {
				flowStatus = cons.getFlowStatus();
				break;
			}
		}
		
		return flowStatus;
	}
	
	@Override
	public void cacheRequest(List<String> topics, boolean subscribe, long minSeq, long maxSeq, AbstractCacheLiveDataAction liveDataAction, boolean waitForConfirm)
	throws Exception {
		if (_cacheSession == null) {
			throw new PubSubException("Cache Session null - aborting cacheRequest");
		}
		
		CacheLiveDataAction jcsmpLiveDataAction = getCacheLiveDataActionFromAbstract(liveDataAction);
				
		for (String topicName : topics) 
		{
			_requestId++;

			Topic subscription = generateTopicFromString(topicName);

			if (Trace.isDebugEnabled())
				Trace.debug("CLIENT " + _clientIdStr + ": Sending cache request ID: " + _requestId);

			_stats.incStat(PerfStatType.NUM_CACHE_REQ_SENT, 1);

			if (waitForConfirm) {
				
				// Only the async interface is supported for sequence number cache requests.  So check for this.
				CacheRequestResult result = null;
				try {
					if (minSeq != -1 || maxSeq != -1) {
						result = _cacheSession.sendCacheRequest(_requestId, subscription, minSeq, maxSeq, subscribe, jcsmpLiveDataAction);
					} else {
						result = _cacheSession.sendCacheRequest(_requestId, subscription, subscribe, jcsmpLiveDataAction);
					}
		      		onComplete(_requestId, subscription, result);
				} catch (JCSMPException ex) {
						Trace.error("CLIENT " + _clientIdStr + ": error doing cache request ID: " + _requestId, ex);
						onException(_requestId, subscription, ex);
				}
			} else {
				
				// If either of these are set, we'll presume the user wanted sequence number cache
				// requests.  Setting only 1 would not be good for the router as -1 is invalid.
				if (minSeq != -1 || maxSeq != -1) {
					_cacheSession.sendCacheRequest(_requestId, subscription, minSeq, maxSeq, subscribe, jcsmpLiveDataAction, this);
				} else {
					_cacheSession.sendCacheRequest(_requestId, subscription, subscribe, jcsmpLiveDataAction, this);
				}
			}
		}
	}
	
	
	private CacheLiveDataAction getCacheLiveDataActionFromAbstract(
			AbstractCacheLiveDataAction liveDataAction) {
		
		switch (liveDataAction) {
		case FLOW_THRU:
			return CacheLiveDataAction.FLOW_THRU;
		case FULFILL:
			return CacheLiveDataAction.FULFILL;
		case QUEUE:
			return CacheLiveDataAction.QUEUE;
		default:
			throw new IllegalArgumentException("Invalid CacheLiveDataAction: "
					+ liveDataAction.toString());
		}
	}
	
	
	
	@Override
	public void cancelCacheRequests() throws Exception {
		_cacheSession.cancelCacheRequests();
	}
	

	@Override
	public String requestReply(String topic, String request) throws Exception {
		final int C_TIMEOUT_IN_MSEC = 10000; 
		Topic destination = generateTopicFromString(topic);

		BytesXMLMessage requestMsg = _defaultProducer.createBytesXMLMessage();
		requestMsg.writeAttachment(request.getBytes());
		
		Requestor requestor = _jSession.createRequestor();
		BytesXMLMessage replyMsg = requestor.request(requestMsg, C_TIMEOUT_IN_MSEC, destination);
		
		String replyStr = "";
		if (replyMsg.getAttachmentContentLength() > 0) {
			byte[] bytes = new byte[replyMsg.getAttachmentContentLength()];
			replyMsg.readAttachmentBytes(bytes);
			replyStr = new String(bytes, "US-ASCII");
		}
		return replyStr;
	}
	
	@Override
	public boolean browseMsg(Integer browserIndex) throws Exception {
		
		if (browserIndex >= _browserList.size()) {
			StringBuffer buf = new StringBuffer();
			buf.append(String.format("CLIENT %s: browserIndex out of range.  Index is %d, Browser List Size is %d",
					_clientIdStr, browserIndex, _browserList.size()));
			throw new PubSubException(buf.toString());
		}
		
		Browser qb = _browserList.get(browserIndex);
		BytesXMLMessage msg = qb.getNextNoWait();
		
		boolean foundMsg = false;
		if (msg != null) {
			
			_qbMsgCount++;
			foundMsg = true;
			
			JcsmpWrappedMessage m = new JcsmpWrappedMessage(msg);
			processMessage(m);
			
			if (_qbMaxBufferedMsgs <= 0 && _qbDeleteFrequency > 0 && _qbMsgCount % _qbDeleteFrequency == 0) {
				qb.remove(msg);
			} else if (_qbMaxBufferedMsgs > 0) {
				_qbBufferedMsgList.add(msg);
			}
		} 
		
		if (_qbMaxBufferedMsgs > 0 && _qbBufferedMsgList.size() >=  _qbMaxBufferedMsgs) {
			int msgId = 0;
			for (BytesXMLMessage delMsg : _qbBufferedMsgList) {
				if (_qbDeleteFrequency > 0 && msgId % _qbDeleteFrequency == 0) {
					qb.remove(delMsg);
				}
				msgId++;
				
			}
			_qbBufferedMsgList.clear();				
		}
		return foundMsg;
	}

	@Override
	public void createBrowsers(List<String> queues, String selector, int deleteFrequency, int msgBufSize) throws Exception {
		
		// Must cleanup any existing browsers.
		deleteBrowsers();
		
		_qbBufferedMsgList = new Vector<BytesXMLMessage>();
		_qbDeleteFrequency = deleteFrequency;
		_qbMsgCount = 0;
		_qbMaxBufferedMsgs = msgBufSize;
		
		for (String queueName : queues) {
			Queue queue = (Queue) DestinationUtils.onlyInstance().queueFromNetworkName(queueName);
			BrowserProperties bp = new BrowserProperties();
			
			bp.setEndpoint(queue);
			if (selector != null && !selector.equals("")) {
				bp.setSelector(selector);
			}
			Browser qb = _jSession.createBrowser(bp);
			_browserList.add(qb);
		}
	}
	

	@Override
	public void deleteBrowsers() throws Exception {
		
		for (Browser browser : _browserList) {
			browser.close();
		}
		_browserList.clear();
	}
	
	
	@Override
	public void connect() throws Exception {
		
		if (isConnected()) {
			return;
		}

		try {
			// If we're here and default consumer is still null, then we need to start up the
			// default consumer.
			if (_jSession == null || _jSession.isClosed()) {
				
				// Create the context handle (if not created)
				_jSession = JCSMPFactory.onlyInstance().createSession(_jProps, _context, this);
				
				if (_cacheProps != null) {
					_cacheSession = _jSession.createCacheSession(_cacheProps);
				} else {
					_cacheSession = null;
				}
			}
			
			_defaultProducer = _jSession.getMessageProducer(this, this);
			
			int numMsgProducer = _rxProps.getIntegerProperty(RuntimeProperties.NUM_MESSAGE_PRODUCER);
			if(numMsgProducer > 1) {
				_producerList.clear();
				_producerList.add(_defaultProducer);
				
				for(int i=0; i<numMsgProducer-1; i++) {
					XMLMessageProducer prod = _jSession.createProducer(null, this, this);
					_producerList.add(prod);
				}
			}
			
			if(_clientName != null) {
				this.setClientName(_clientName);
			}
			else if (!_rxProps.getStringProperty(RuntimeProperties.CLIENT_NAME_PREFIX).equals("") &&
					_rxProps.getBooleanProperty(RuntimeProperties.CHANGE_CLIENT_NAMES_FLAG)) {
					this.setClientName(ClientFactory.generateClientName(_rxProps, _clientIdInt));
			}
			
			connectDefaultFlow();
			reconnectToFlows();
			
			if (_subscriptionMem != null) {
				// Do an apply if we're in CR mode (supports XPE)
				if (_jSession.isCapable(CapabilityType.SUPPORTS_XPE_SUBSCRIPTIONS)) {
					_jSession.applySubscriptions(_subscriptionMem);
				} else {
					for (Subscription subn : _subscriptionMem) {
						try {
							// Don't wait for confirm here.
							_jSession.addSubscription(subn, false);
						}
						catch (JCSMPErrorResponseException ex){
							if (ex.getSubcodeEx() != JCSMPErrorResponseSubcodeEx.SUBSCRIPTION_ALREADY_PRESENT) {
								throw ex;
							}
							else {
								Trace.warn("CLIENT " + _clientIdStr + ": Error during connect - " + ex.getMessage(), ex);	
							}
						}
					}
				}
				
				_subscriptionMem = null;
			}

		} catch (JCSMPErrorResponseException ex) {
			
			_lastErrorResponse = ex;
			throw ex;
		}
		_channelState = ChannelState.CLIENT_STATE_CONNECTED;
	}

	@Override
	public void disconnect() throws Exception {
		_channelState = ChannelState.CLIENT_STATE_DISCONNECTED;
		
		_subscriptionMem = _jSession.getSubscriptionCache();
		
		if(_customClientName) {
		   _clientName = this.getClientName(); 
		}
		
		// Since all the objects will be invalid after a disconnect, clear the lists as well.
		_transactedProducers.clear();
		_transactedSessions.clear();
		
		//Trace.info(String.format("%s, pre-closeSession", System.currentTimeMillis()));
		 _jSession.closeSession();
		//Trace.info(String.format("%s, post-closeSession", System.currentTimeMillis()));
		_defaultConsumer = null;
	}
	


	@Override
	public void start() throws Exception {
		for (MesssageListener consumer: _consumersList) {
			if (consumer.consumer != null) {
				consumer.consumer.start();
				consumer.isStarted = true;
			}
		}
		
		if (_defaultConsumer != null) {
			_defaultConsumer.consumer.start();
			_defaultConsumer.isStarted = true;
		}
	}

	@Override
	public void stop() {
		for (MesssageListener consumer: _consumersList) {
			if (consumer.consumer != null) {
				consumer.consumer.stop();
				consumer.isStarted = false;
			}
		}

		if (_defaultConsumer != null) {
			_defaultConsumer.consumer.stop();
			_defaultConsumer.isStarted = false;			
		}
	}	

	@Override
	public String openTransactedSession(RuntimeProperties rprops) throws Exception {
		TransactedSession transactedSession = null;
		try {
			transactedSession = _jSession.createTransactedSession();
		} catch (JCSMPErrorResponseException ex) {
			
			_lastErrorResponse = ex;
			throw ex;
		}
		String name = transactedSession.getName();
		_transactedSessions.put(name, new JcsmpClientTransactedSession((AbstractClient)this, transactedSession, rprops));
		
		return name;
	}
	
	@Override
	public void closeTransactedSession(String sessionName) throws Exception {
		
		AbstractClientTransactedSession transactedSession = _transactedSessions.remove(sessionName);
		if (transactedSession == null) {
			throw new PubSubException("CLIENT " + _clientIdStr + ": Transacted Session not found (" + sessionName + ")");
		}
		
		Producer producer = _transactedProducers.remove(sessionName);
		if (producer != null) {
			producer.close();
		}
		transactedSession.close();
		
	}
	
	@Override
	public void closeAllTransactedSessions() {
		for (Producer producer : _transactedProducers.values()) {
			producer.close();
		}
		_transactedProducers.clear();

		for (AbstractClientTransactedSession session : _transactedSessions.values()) {
			session.close();
		}
		_transactedSessions.clear();
	}

	@Override
	public void commitTransaction(String sessionName, boolean wantRollback)
			throws Exception {
		AbstractClientTransactedSession transactedSession = _transactedSessions.get(sessionName);
		try {			
			transactedSession.commitOnDispatcher(wantRollback);
		} catch (Exception e) {
			updateLastErrorResponse(e);
			throw e;
		}
	}
	

	@Override
	public void commitTransactionOnCurrPub(int producerIndex, boolean wantRollback) throws Exception {
		try {
			if (wantRollback) {
				_currProducerXaSession.rollback();
			} else {
				_currProducerXaSession.commit();
			}
		} catch (RollbackException e) {
			updateLastErrorResponse(e);
			int subCode = -1;
			if(e.getCause() != null && e.getCause() instanceof JCSMPErrorResponseException) {
				subCode = ((JCSMPErrorResponseException) e.getCause()).getSubcodeEx();
			}
			throw new TransactionRollbackException(subCode, e);
		} catch (TransactionResultUnknownException e) {
            updateLastErrorResponse(e);
            throw new com.solacesystems.pubsub.sdkperf.core.TransactionResultUnknownException(e);
		} catch (Exception e) {
            updateLastErrorResponse(e);
            throw e;
		}
	}


	@Override
	public String openXaSession(RuntimeProperties rprops) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public void closeXaSession(String sessionName) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public void closeAllXaSessions() throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public String createXid(String sessionName) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public void commitXaSession(String sessionName, String xid, boolean onePhase) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public void endXaSession(String sessionName, String xid, int flags) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public void forgetXaSession(String sessionName, String xid) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public void prepareXaSession(String sessionName, String xid) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public Vector<String> recoverXaSession(String sessionName, int flag) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public void rollbackXaSession(String sessionName, String xid) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public void startXaSession(String sessionName, String xid, int flags) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public void commitXaSessionOnCurrPub(int producerIndex, boolean wantRollback, boolean onePhase, boolean noStart) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public void suspendXaSessionOnCurrPub(int producerIndex) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public void setXaTransactionTimeout(String sessionName, int seconds) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}

	@Override
	public int getXaTransactionTimeout(String sessionName) throws Exception {
		throw new UnsupportedOperationException("XA Transactions is not supported for JCSMP Clients.");
	}
	
	@Override
	protected void publishOnReceive(Object prod, BasicMsgRep msgRep) throws Exception {
		if (prod == null) {
			throw new IllegalArgumentException("Cannot publish on receive, producer provided is null.");
		}
		if (msgRep == null) {
			throw new IllegalArgumentException("Cannot publish on receive, message provided is null.");
		}
		
		BytesXMLMessage jcsmpMsg = ((XMLMessageProducer)prod).createBytesMessage();
		JcsmpMsgRep.setDeliveryModeOnXMLMessage(msgRep, jcsmpMsg);
		
		if (msgRep.getAttachmentBytes() != null && msgRep.getAttachmentBytes().length > 0)
			jcsmpMsg.writeAttachment(msgRep.getAttachmentBytes());
		if (msgRep.getXmlBytes() != null && msgRep.getXmlBytes().length > 0)
			jcsmpMsg.writeBytes(msgRep.getXmlBytes());
		
		if (((JcsmpMsgRep) msgRep).getJcsmpDestination() == null)
			((JcsmpMsgRep) msgRep).cacheDestination();
		
		Destination dest = ((JcsmpMsgRep)msgRep).getJcsmpDestination();
		((XMLMessageProducer)prod).send(jcsmpMsg, dest);
	}
	
	@Override
	public void publishMsg(BasicMsgRep msgRep, int pubSessionIndex) throws Exception 
	{
		
		if(_rxProps.getBooleanProperty(RuntimeProperties.WANT_SYNC_RECEIVE)) {	
			BytesXMLMessage message = _syncConsumer.receiveNoWait();
                        while (message == null) {
                           TimeUnit.MICROSECONDS.sleep(1);
                            message = _syncConsumer.receiveNoWait();
                        }
			_defaultConsumer.onReceive(message);
                        return;
		}
		
		if (_wantStopOnError && _asyncExceptionOccured) {
			throw new PubSubException("CLIENT " + _clientIdStr + ": Async exception occured.  Aborting publish of message.");
		}
		
		if (Trace.isDebugEnabled())
			Trace.debug("CLIENT " + _clientIdStr + ": sendMessage() called");
		
		BytesXMLMessage jcsmpMsg = null;
		if (msgRep.getStructDataMsgId() != SdkperfConstants.SDM_ID_NULL) {
			jcsmpMsg = InteropTest.createMessageByNumber(
							(XMLMessageProducer)_defaultProducer, 
							msgRep.getStructDataMsgId());
		} else {
			jcsmpMsg = _messagesArray[pubSessionIndex];
		}
		
		this.buildMsg(msgRep, jcsmpMsg);
		
		// Set the destination
		Destination dest = ((JcsmpMsgRep)msgRep).getJcsmpDestination();
		
		if(_producerList.size() > 1) {
			XMLMessageProducer prod = _producerList.get((int) (_producerListIndex % _producerList.size()));
			prod.send(jcsmpMsg, dest);
			_producerListIndex++;
		} else {
			_currProducer.send(jcsmpMsg, dest);
		}
		
	}
	
	@Override
	public void publishSendMultiple(List<BasicMsgRep> msgReps, int pubSessionIndex) throws Exception {
		// pubSessionIndex unused for now.
		JCSMPSendMultipleEntry[] msgsArray = _sendVectorMsgs.get(pubSessionIndex);
		
		if (msgsArray.length < msgReps.size()) {
			throw new PubSubException("CLIENT " + _clientIdStr + ": Send vector set incorrect: " + msgsArray.length + " " + msgReps.size());
		}
		
		int index = 0;
		for (BasicMsgRep msgRep : msgReps) {

			this.buildMsg(msgRep, (BytesXMLMessage)msgsArray[index].getMessage());
			msgsArray[index].setDestination(((JcsmpMsgRep)msgRep).getJcsmpDestination());
			
			index++;
		}
		
		// Send using msgIds size as on last send may not be using a full vector.
		int sent = _currProducer.sendMultiple(msgsArray, 0, msgReps.size(), 0);
		if (sent != msgReps.size()) {
			// Something horrible has happened
			throw new PubSubException("CLIENT " + _clientIdStr + ": Not able to send all messages in call to sendMultiple: " + sent);
		}
	}
	
	public void resetStats() {
		super.resetStats();
		_jSession.getSessionStats().resetStats();
	}
	
	public long getSdkStat(GenericStatType statName) throws Exception {
		return _jSession.getSessionStats().getStat( JcsmpSdkperfUtils.convertGStatTypeToStatType(statName) );
	}
	

	@Override
	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
		buf.append(String.format("Subscriber name: %s%n", _jProps.getStringProperty(JCSMPProperties.USERNAME)));
		buf.append(_jSession.getSessionStats().toString());
		return buf.toString();
	}

	@Override
	public BasicMsgRep[] cloneToApiSpecificMsgRep(BasicMsgRep[] inputMsgReps) throws PubSubException {
		BasicMsgRep [] retArray = new BasicMsgRep[inputMsgReps.length];
		
		for (int i = 0; i < inputMsgReps.length; i++) {
			JcsmpMsgRep outputMsgRep = new JcsmpMsgRep(inputMsgReps[i]);
			retArray[i] = outputMsgRep;
		}
		
		return retArray;
	}
	
	@Override
	public void publishPropsUpdateNotify(int pubSessionIndex, String transactedSessionName) throws Exception {
		// pubSessionIndex unused for now.
		
		int psv = _txProps.getIntegerProperty(RuntimeProperties.PUB_SEND_VECT_SIZE);
		if (psv > 0) {
			// Need to cache some bytes messages to use when sending message vectors.
			JCSMPSendMultipleEntry[] msgsArray = new JCSMPSendMultipleEntry[psv];
			for (int i = 0; i < psv; i++) {
				// Use internal buffers for now.
				XMLMessage m = JCSMPFactory.onlyInstance().createMessage(BytesXMLMessage.class);
				msgsArray[i] = JCSMPFactory.onlyInstance().createSendMultipleEntry(m, null);
			}
			_sendVectorMsgs.set(pubSessionIndex, msgsArray);
		}
		
		this.resetMsgs(pubSessionIndex);

		// Must also determine and set the current message producer.
		if (!transactedSessionName.equals("")) {
			_currProducerXaSession = (TransactedSession)_transactedSessions.get(transactedSessionName).getTransactedSession();
			if (_currProducerXaSession == null) {
				throw new PubSubException("CLIENT " + _clientIdStr + ": Transacted Session session not found (" + transactedSessionName + ")");
			}
			
			_currProducer = _transactedProducers.get(transactedSessionName);
			
			if (_currProducer == null) {
				// For now we'll not bother with any flow properties.  They can just inherit from the session.
			    ProducerFlowProperties fprops = null;
			    _currProducer = _currProducerXaSession.createProducer(fprops, this);
				
				_transactedProducers.put(transactedSessionName, _currProducer);
			}
		} else {
			_currProducer = _defaultProducer;
			_currProducerXaSession = null;
		}
	}
	
	@SuppressWarnings("deprecation")
	@Override
	public Hashtable<GenericCapabilityType, String> getRtrCapabilities() throws Exception 
	{
		Hashtable<GenericCapabilityType, String> retList = new Hashtable<GenericCapabilityType, String>();
		
	    // For interest log the router capabilities
			retList.put(GenericCapabilityType.PUB_GUARANTEED, 
			                (_jSession.isCapable(CapabilityType.PUB_GUARANTEED) ? "1" : "0"));
			retList.put(GenericCapabilityType.PUB_FLOW_GUARANTEED, 
			                (_jSession.isCapable(CapabilityType.PUB_FLOW_GUARANTEED) ? "1" : "0"));
			retList.put(GenericCapabilityType.SUB_FLOW_GUARANTEED, 
			                (_jSession.isCapable(CapabilityType.SUB_FLOW_GUARANTEED) ? "1" : "0"));
			retList.put(GenericCapabilityType.TEMP_ENDPOINT, 
			                (_jSession.isCapable(CapabilityType.TEMP_ENDPOINT) ? "1" : "0"));
			retList.put(GenericCapabilityType.JNDI, 
			                (_jSession.isCapable(CapabilityType.JNDI) ? "1" : "0"));
			retList.put(GenericCapabilityType.COMPRESSION, 
			                (_jSession.isCapable(CapabilityType.COMPRESSION) ? "1" : "0"));
			retList.put(GenericCapabilityType.SUPPORTS_XPE_SUBSCRIPTIONS, 
			                (_jSession.isCapable(CapabilityType.SUPPORTS_XPE_SUBSCRIPTIONS) ? "1" : "0"));
			retList.put(GenericCapabilityType.TRANSACTED_SESSIONS, 
			                (_jSession.isCapable(CapabilityType.TRANSACTED_SESSIONS) ? "1" : "0"));
			retList.put(GenericCapabilityType.MAX_DIRECT_MSG_SIZE, 
			                ((Integer)_jSession.getCapability(CapabilityType.MAX_DIRECT_MSG_SIZE)).toString());
			retList.put(GenericCapabilityType.MAX_GUARANTEED_MSG_SIZE, 
			                ((Integer)_jSession.getCapability(CapabilityType.MAX_GUARANTEED_MSG_SIZE)).toString());
			retList.put(GenericCapabilityType.PEER_PORT_TYPE, 
			                ((String)_jSession.getCapability(CapabilityType.PEER_PORT_TYPE)));
			retList.put(GenericCapabilityType.PEER_PORT_SPEED, 
			                ((Integer)_jSession.getCapability(CapabilityType.PEER_PORT_SPEED)).toString());
			retList.put(GenericCapabilityType.PEER_SOFTWARE_VERSION, 
			                ((String)_jSession.getCapability(CapabilityType.PEER_SOFTWARE_VERSION)));
			retList.put(GenericCapabilityType.PEER_SOFTWARE_DATE, 
			                ((String)_jSession.getCapability(CapabilityType.PEER_SOFTWARE_DATE)));
			retList.put(GenericCapabilityType.PEER_PLATFORM, 
			                ((String)_jSession.getCapability(CapabilityType.PEER_PLATFORM)));
			retList.put(GenericCapabilityType.PEER_ROUTER_NAME, 
			                ((String)_jSession.getCapability(CapabilityType.PEER_ROUTER_NAME)));
			retList.put(GenericCapabilityType.BROWSER, 
			                (_jSession.isCapable(CapabilityType.BROWSER) ? "1" : "0"));
			retList.put(GenericCapabilityType.ENDPOINT_MANAGEMENT, 
			                (_jSession.isCapable(CapabilityType.ENDPOINT_MANAGEMENT) ? "1" : "0"));
			retList.put(GenericCapabilityType.SELECTOR, 
			                (_jSession.isCapable(CapabilityType.SELECTOR) ? "1" : "0"));
			retList.put(GenericCapabilityType.ENDPOINT_MESSAGE_TTL, 
			                (_jSession.isCapable(CapabilityType.ENDPOINT_MESSAGE_TTL) ? "1" : "0"));
			retList.put(GenericCapabilityType.QUEUE_SUBSCRIPTIONS, 
			                (_jSession.isCapable(CapabilityType.QUEUE_SUBSCRIPTIONS) ? "1" : "0"));
			retList.put(GenericCapabilityType.FLOW_RECOVER, 
			                (_jSession.isCapable(CapabilityType.FLOW_RECOVER) ? "1" : "0"));
			retList.put(GenericCapabilityType.SUBSCRIPTION_MANAGER, 
			                (_jSession.isCapable(CapabilityType.SUBSCRIPTION_MANAGER) ? "1" : "0"));
			retList.put(GenericCapabilityType.MESSAGE_ELIDING, 
			                (_jSession.isCapable(CapabilityType.MESSAGE_ELIDING) ? "1" : "0"));
			retList.put(GenericCapabilityType.NO_LOCAL, 
			                (_jSession.isCapable(CapabilityType.NO_LOCAL) ? "1" : "0"));
			retList.put(GenericCapabilityType.FLOW_CHANGE_UPDATES, 
			                (_jSession.isCapable(CapabilityType.FLOW_CHANGE_UPDATES) ? "1" : "0"));
			retList.put(GenericCapabilityType.ACTIVE_FLOW_INDICATION, 
			                (_jSession.isCapable(CapabilityType.ACTIVE_FLOW_INDICATION) ? "1" : "0"));
			retList.put(GenericCapabilityType.PER_TOPIC_SEQUENCE_NUMBERING, 
			                (_jSession.isCapable(CapabilityType.PER_TOPIC_SEQUENCE_NUMBERING) ? "1" : "0"));
			retList.put(GenericCapabilityType.ENDPOINT_DISCARD_BEHAVIOR, 
			                (_jSession.isCapable(CapabilityType.ENDPOINT_DISCARD_BEHAVIOR) ? "1" : "0"));
			retList.put(GenericCapabilityType.CUT_THROUGH, 
			                (_jSession.isCapable(CapabilityType.CUT_THROUGH) ? "1" : "0"));
	    return retList;
	}

	@Override
	protected void keepMsg(AbstractMessageAckData messageAckData) {
			
		if(!(messageAckData instanceof JcsmpMessageAckData)) {
			throw new IllegalArgumentException("JcsmpClient only expects to keep message of type: " + JcsmpMessageAckData.class.toString());
		}
		
		_keptMsgQueue.add((JcsmpMessageAckData) messageAckData);
		
		if (_keptMsgQueue.size() > _maxKeptMsgs) {
			
			int desiredQueueSize = _maxKeptMsgs;
			
			if (_rxProps.getBooleanProperty(RuntimeProperties.CLIENT_ACK_FLUSH_QUEUE)) {
				desiredQueueSize = 0;
			}
			
			if (_rxProps.getBooleanProperty(RuntimeProperties.WANT_CLIENT_ACK_THREAD)) {
				_clientAckThread.setDesiredQueueSize(desiredQueueSize);
				_clientAckThread.setEnableAcking(_rxProps.getBooleanProperty(RuntimeProperties.WANT_CLIENT_ACK));
				synchronized(_keptMsgQueue) {
					_keptMsgQueue.notify();
				}
			} else {
				processKeptMsgs(
						desiredQueueSize, 
						_rxProps.getBooleanProperty(RuntimeProperties.WANT_CLIENT_ACK));
			}
		}
	}
	
	@Override
	public void setLastMessageDetails(AbstractWrappedMessage message) {	
		
		if(!(message instanceof JcsmpWrappedMessage)) {
			Trace.error("Can only process JcsmpWrappedMessage in JcsmpClient.");
			return;
		}
		
		// Clear the last message
		_lastMessageDetails.clear();
		
		BytesXMLMessage msg = (BytesXMLMessage) message.getMessage();
		
		// Set Reply-to destination if it exists
		Destination rtd = msg.getReplyTo();
		if (rtd != null) {
			_lastMessageDetails.setReplyToDestination(rtd.getName());

			if (rtd instanceof Topic) {
				_lastMessageDetails.setReplyToDestinationType(SubscriberDestinationsType.TOPIC);
			} else if (rtd instanceof Queue) {
				_lastMessageDetails.setReplyToDestinationType(SubscriberDestinationsType.QUEUE);
			} else {
				Trace.warn("Unkown reply-to destination type: " + rtd.getClass());
			}
		}
		
		// Set destination if it exists
		Destination d = msg.getDestination();
		if (d != null) {
			_lastMessageDetails.setDestination(d.getName());

			if (d instanceof Topic) {
				_lastMessageDetails.setDestinationType(SubscriberDestinationsType.TOPIC);
			} else if (d instanceof Queue) {
				_lastMessageDetails.setDestinationType(SubscriberDestinationsType.QUEUE);
			} else {
				Trace.warn("Unkown reply-to destination type: " + d.getClass());
			}
		}
		
		_lastMessageDetails.setHttpContentEncoding(msg.getHTTPContentEncoding());
		_lastMessageDetails.setHttpContentType(msg.getHTTPContentType());
		_lastMessageDetails.setCorrelationId(msg.getCorrelationId());
		_lastMessageDetails.setExpiration(msg.getExpiration());
		_lastMessageDetails.setPriority(msg.getPriority());
		_lastMessageDetails.setApplicationMessageId(msg.getApplicationMessageId());
		_lastMessageDetails.setApplicationMessageType(msg.getApplicationMessageType());
		_lastMessageDetails.setSenderTimestamp(msg.getSenderTimestamp());
		_lastMessageDetails.setCos(msg.getCos().toString());
		_lastMessageDetails.setDeliveryMode(msg.getDeliveryMode().toString());
		_lastMessageDetails.setMessageId(msg.getMessageId());
				
		SDTMap map = msg.getProperties();
		
		if(map != null) {
		//type,name,value,type,name,value
		StringBuilder propList = new StringBuilder();
		
		// Accepted types are: , Float, Int, Long, Short

			for (String s : map.keySet()) {
				try {
					Object o = map.get(s);

					if (o instanceof Boolean) {
						String value = ((Boolean) o) ? "true" : "false";
						propList.append("Boolean," + s + "," + value + ",");
					} else if (o instanceof String) {
						propList.append("String," + s + "," + o.toString()
								+ ",");
					} else if (o instanceof Double) {
						propList.append("Double," + s + "," + o.toString()
								+ ",");
					} else if (o instanceof Float) {
						propList.append("Float," + s + "," + o.toString() + ",");
					} else if (o instanceof Integer) {
						propList.append("Int," + s + "," + o.toString() + ",");
					} else if (o instanceof Long) {
						propList.append("Long," + s + "," + o.toString() + ",");
					} else if (o instanceof Short) {
						propList.append("Short," + s + "," + o.toString() + ",");
					} else {
						if (Trace.isWarnEnabled())
							Trace.warn(String
									.format("Ignored key '%s' while building last message details because it was using an unsuported type '%s'.",
											s, o.getClass()));
					}

				} catch (SDTException e) {
					Trace.warn(
							"Caught exception trying to loop over SDTMap while building last message details.",
							e);
				}
			}
			
			if(propList.length() > 0) {
				if(propList.charAt(propList.length() - 1) == ',') {
					propList.deleteCharAt(propList.length() - 1);
				}
				_lastMessageDetails.setCustomPropertyList(propList.toString());
			}
		}
		
		
	}
		
	public void processKeptMsgs(int desiredQueueSize, boolean enableAcking) {
		// Check if there are any messages to remove from the queue.
		while (_keptMsgQueue.size() > desiredQueueSize) {
				
		    BytesXMLMessage msg = null;
		    
		    if (_rxProps.getIntegerProperty(RuntimeProperties.CLIENT_ACK_RANDOM_DEPTH) > 0) {
		    	
		    	int maxValue = Math.min(
		    			_rxProps.getIntegerProperty(RuntimeProperties.CLIENT_ACK_RANDOM_DEPTH), 
		    			_keptMsgQueue.size());
		    	
		    	// Since Math.random() does not include '1' in its range, randomValue will be
		    	// strictly smaller than our keptMsgQueue size.
		    	int randomValue = (int)(Math.random() * maxValue);
		    	
		    	synchronized (_keptMsgQueue) {
		    		Iterator<JcsmpMessageAckData> it = _keptMsgQueue.iterator();

			    	// Move into the list according to our randomValue.
			    	for (int i = 0; i < randomValue; ++i) {
			    		it.next();
			    	}
			    	
			    	// Since randomValue is strictly smaller than our queue size, we can always
			    	// take the next().
			    	msg = (it.next().getMessage()).getMessage();
			    	it.remove();
		    	}
			} else if (_rxProps.getBooleanProperty(RuntimeProperties.CLIENT_ACK_QUEUE_REVERSE)) {
				// TODO: Very inefficient
				Iterator<JcsmpMessageAckData> it = _keptMsgQueue.iterator();
				while (it.hasNext()) {
					msg = it.next().getMessage().getMessage();
				}
				it.remove();
				
		    } else {
		    	msg = _keptMsgQueue.poll().getMessage().getMessage();
		    }
		    
			if (enableAcking) {
				msg.ackMessage();
			}
		}
	}
	
	
	protected void readToolDataFromProperties(AbstractWrappedMessage message, ToolData toolData) {
		
		// Validate message input
		if(!(message instanceof JcsmpWrappedMessage)) {
			throw new IllegalArgumentException("Message must be of type "+ JcsmpWrappedMessage.class.toString());
		}

		toolData.reset();
		
		BytesXMLMessage m = ((JcsmpWrappedMessage)message).getMessage();
		SDTMap properties = m.getProperties();
		
		if (properties != null) {
			try {
				if (properties.containsKey(ToolData.PROP_XML_PAYLOAD_HASH)) {
					toolData.setXmlPayloadHash(0xffffffffL & properties.getInteger(ToolData.PROP_XML_PAYLOAD_HASH));
				}
				
				if (properties.containsKey(ToolData.PROP_BIN_PAYLOAD_HASH)) {
					toolData.setBinAttachHash(0xffffffffL & properties.getInteger(ToolData.PROP_BIN_PAYLOAD_HASH));
				}
				
				if (properties.containsKey(ToolData.PROP_MESSAGE_ID)) {
					toolData.setMessageIdentifier(properties.getLong(ToolData.PROP_MESSAGE_ID));
				}
				
				if (properties.containsKey(ToolData.PROP_STREAM_ID)) {
					toolData.setStreamId(properties.getInteger(ToolData.PROP_STREAM_ID));
				}
				
				if (properties.containsKey(ToolData.PROP_LATENCY)) {
					toolData.setLatency(properties.getLong(ToolData.PROP_LATENCY));
				}
				
				if (properties.containsKey(ToolData.PROP_REPUBLISHED)) {
					toolData.setRepublished(properties.getBoolean(ToolData.PROP_REPUBLISHED));
				}
				
			} catch (SDTException e) {
				Trace.error("CLIENT " + _clientIdStr + ": " + e.getMessage(), e);
			}
		}
	}
	
	///////////////////////////////////////////////////////////////////////////////////////
	// Private Methods
    ///////////////////////////////////////////////////////////////////////////////////////
	
	private void connectDefaultFlow() throws Exception {
		// If we're here and default consumer is still null, then we need to start up the
		// default consumer.
		if (_defaultConsumer == null) {

			if(!_rxProps.getBooleanProperty(RuntimeProperties.WANT_SYNC_RECEIVE)) {
				
				// Connect the default handler if required.
				boolean dummyValue = false; // isTopic is never checked on default flow.
				
				_defaultConsumer = new MesssageListener(
						Constants.SUB_DEFAULT_QUEUE_NAME, dummyValue, null, false,
						null);

				try {
					Consumer consumer = _jSession
							.getMessageConsumer(_defaultConsumer);
					_defaultConsumer.consumer = consumer;

					_defaultConsumer.consumer.start();
					_defaultConsumer.isStarted = true;

				} catch (JCSMPException e) {
					Trace.error("CLIENT " + _clientIdStr + ": " + e.getMessage(), e);
					throw e;
				}

			} else {
				_syncConsumer = _jSession.getMessageConsumer((XMLMessageListener) null);
				
				_defaultConsumer = new MesssageListener(
						Constants.SUB_DEFAULT_QUEUE_NAME, false, null, false,
						null);
				
				_defaultConsumer.consumer = _syncConsumer;
				_defaultConsumer.consumer.start();
				_defaultConsumer.isStarted = true;

			}


		}
	}
	
	private void reconnectToFlows() throws Exception {
		
		// We iterate over the elements from _consumersList and we either
		//   1) want to get rid of them
		//   2) want to keep them, and act on them (reconnecting the flows)
		// We accumulate the elements of _consumersList that are to be kept
		// in the list filteredConsumersList and perform a swap at the end
		// of this method.
		
		ArrayList<MesssageListener> filteredConsumersList = new ArrayList<MesssageListener>();
		
		// Must bind to any flows we were previously bound to.
		for (MesssageListener consumerInfo: _consumersList) {
			// Don't reconnect any nonDurable flows. Filter them out.
            if (consumerInfo.isNonDurable) {
            		Trace.warn("Removing non-durable consumer from flows to reconnect");
            		continue;
            } else if (consumerInfo.transactedSession != null) {
            		Trace.warn("Removing non-durable consumer from flows to reconnect");
            		continue;
            } else {
            	
                Trace.info("Bind loop: Consumer isNonDurable: " + consumerInfo.isNonDurable);

                Consumer consumer = null;
    		
                if (consumerInfo.isTopic) {
                	DurableTopicEndpoint dte = JCSMPFactory.onlyInstance().createDurableTopicEndpoint(
                			consumerInfo.destination);
                consumer = _jSession.createFlow(dte, consumerInfo.topic, consumerInfo);
                } else {
                    	Queue queue = JCSMPFactory.onlyInstance().createQueue(consumerInfo.destination);
                    	consumer = _jSession.createFlow(queue, null, consumerInfo);
                }
                consumerInfo.consumer = consumer;
                
    			filteredConsumersList.add(consumerInfo);
            }
		}	
		// only those ones were kept
        _consumersList = filteredConsumersList;
	}
		
	private void buildMsg(BasicMsgRep msgRep, BytesXMLMessage pubMsg) throws Exception 
	{
		if (_txToolDataProps.WANT_PAYLOAD_CHECK ||
				_txToolDataProps.WANT_ORDER_CHECK ||
				_txToolDataProps.WANT_ORDER_MEMORY ||
				_txToolDataProps.WANT_LATENCY ||
				_txToolDataProps.WANT_LOSS_AND_DUPLICATE_DETECTION) {
			// Want 1 based message Id's so add 1 here.
			
			int attachSize = 0;

			if (_wantUserPropToolData) {
				if (msgRep.getAttachmentBytes() != null){
					attachSize = msgRep.getAttachmentBytes().length;
				}
				setToolDataAsProperties(msgRep, pubMsg);
			} else {
				attachSize = setToolDataAsAttachment(msgRep);
			}
    		
			if (attachSize > 0) {
				pubMsg.writeAttachment(msgRep.getAttachmentBytes(), 0, attachSize);
			}
			
		} else {
			if (msgRep.getAttachmentBytes() != null) pubMsg.writeAttachment(msgRep.getAttachmentBytes());
		}
		
		if(_txToolDataProps.WANT_UD) {
			pubMsg.setUserData(SdkperfConstants.userDataBytes);
		}
		if (msgRep.getXmlBytes() != null) {
			pubMsg.clearContent();
			pubMsg.writeBytes(msgRep.getXmlBytes() );
		}

		JcsmpMsgRep.setDeliveryModeOnXMLMessage(msgRep, pubMsg);
				
		if (_wantPublishFlags)
		{
			if (_txProps.getProperty(RuntimeProperties.PUBLISH_COS) != null)
			{
				int cosValue = _txProps.getIntegerProperty(RuntimeProperties.PUBLISH_COS);
				
				switch (cosValue) {
				case 1:
					pubMsg.setCos(User_Cos.USER_COS_1);
					break;
				case 2:
					pubMsg.setCos(User_Cos.USER_COS_2);
					break;
				case 3:
					pubMsg.setCos(User_Cos.USER_COS_3);
					break;
				default:
					throw new PubSubException("Invalid Cos value \"" + cosValue + "\". Valid values are: 1, 2 and 3.");
				}	
			}
			
			if (_txProps.getBooleanProperty(RuntimeProperties.PUBLISH_TO_ONE) != null)
			{
				pubMsg.setDeliverToOne(_txProps.getBooleanProperty(RuntimeProperties.PUBLISH_TO_ONE));
			}
			
			if (_txProps.getBooleanProperty(RuntimeProperties.MSG_DMQ_ELIGIBLE) != null)
			{
				pubMsg.setDMQEligible(_txProps.getBooleanProperty(RuntimeProperties.MSG_DMQ_ELIGIBLE));
			}
			
			if (_txProps.getLongProperty(RuntimeProperties.MSG_TTL) != null)
			{
				pubMsg.setTimeToLive(_txProps.getLongProperty(RuntimeProperties.MSG_TTL));
			}
			
			if (_txProps.getBooleanProperty(RuntimeProperties.MSG_ELIDING_ELIGIBLE) != null)
			{
				pubMsg.setElidingEligible(_txProps.getBooleanProperty(RuntimeProperties.MSG_ELIDING_ELIGIBLE));
			}
		}
		
		// This applies only to topics and not queues, so we make the assumption
		// that the destinations given are topics.
		if (_txProps.getBooleanProperty(RuntimeProperties.WANT_REPLY_TOPIC)) {
			
			String replyToDest = msgRep.getReplyToDestination();

			if (replyToDest != null && replyToDest.length() > 0) {
				if (msgRep.getReplyToDestType() == PublisherDestinationsType.TOPIC) {
					Destination dest = DestinationUtils.onlyInstance().topicFromNetworkName(replyToDest);
					pubMsg.setReplyTo(dest);
				} else if (msgRep.getReplyToDestType() == PublisherDestinationsType.QUEUE) {
					Destination dest = DestinationUtils.onlyInstance().queueFromNetworkName(replyToDest);
					pubMsg.setReplyTo(dest);
				}
			} else {
				pubMsg.setReplyTo((Topic)_jSession.getProperty(JCSMPProperties.P2PINBOX_IN_USE));
			}
		}
		
		// used to keep track of the AD message acks 
		if (_txToolDataProps.WANT_ORDER_CHECK) {
		    ToolData txToolData = msgRep.getToolData();
		    pubMsg.setCorrelationKey(txToolData.getMessageIdentifier());
		    
		    if(_txToolDataProps.WANT_REPLY_TOPIC || _txProps.getBooleanProperty(RuntimeProperties.WANT_REPLY_TEMPORARY_QUEUE))
		    	pubMsg.setCorrelationId(Long.toString(txToolData.getMessageIdentifier()));
		}
		
		pubMsg.setAckImmediately(msgRep.getAckImmediately());
		
		// Set HTTP Headers
        pubMsg.setHTTPContentEncoding(msgRep.getHttpContentEncoding());
        pubMsg.setHTTPContentType(msgRep.getHttpContentType());

		// Set Custom Properties
		
		if(_txProps.getProperty(RuntimeProperties.CUSTOM_PROPERTIES_LIST) != null) {
			
			@SuppressWarnings("unchecked")
			List<String> customProps = (List<String>) _txProps.getProperty(RuntimeProperties.CUSTOM_PROPERTIES_LIST);
			
			SDTMap propMap = JCSMPFactory.onlyInstance().createMap();
					
			int propIndex = 0;
			while(customProps.size() >= (propIndex+3)) {
				String type = customProps.get(propIndex++); 
				String name = customProps.get(propIndex++);
				String value = customProps.get(propIndex++);
				
				try {
					if(type.equalsIgnoreCase("Boolean")) {
						if(value.equalsIgnoreCase("true") || value.equals("1"))
							propMap.putBoolean(name, true);
						else if(value.equalsIgnoreCase("false") || value.equals("0")) {
							propMap.putBoolean(name, false);
						} else {
							Trace.warn("Could not parse Boolean property for custom property \""
									+ type + "," + name + "," + value + "\"");
						}
					} else if(type.equalsIgnoreCase("String")) {
						propMap.putString(name, value);
					} else if(type.equalsIgnoreCase("Float")) {
						propMap.putFloat(name, Float.parseFloat(value));
					} else if(type.equalsIgnoreCase("Int")) {
						propMap.putInteger(name, Integer.parseInt(value));
					} else if(type.equalsIgnoreCase("Long")) {
						propMap.putLong(name, Long.parseLong(value));
					} else if(type.equalsIgnoreCase("Short")) {
						propMap.putShort(name, Short.parseShort(value));
					} else {
						Trace.warn("Invalid Type for custom property \""
								+ type + "," + name + "," + value + "\"");
					}
				
				} catch (NumberFormatException e) {
					Trace.warn("Could not parse custom property \"" + type
							+ "," + name + "," + value + "\"", e);
				}
			}
			
			pubMsg.setProperties(propMap);
		}
	}
	
	private void setToolDataAsProperties(BasicMsgRep msgRep, BytesXMLMessage message) {
		
		ToolData txToolData = msgRep.getToolData();
		
		SDTMap properties = _defaultProducer.createMap();
		
		try {
			if (_txToolDataProps.WANT_PAYLOAD_CHECK) {
				
				if (txToolData.hasXmlPayloadHash()) {
					properties.putInteger(ToolData.PROP_XML_PAYLOAD_HASH, (int) txToolData.getXmlPayloadHash());
				}
				
				if (txToolData.hasBinAttachHash()) {
					properties.putInteger(ToolData.PROP_BIN_PAYLOAD_HASH, (int) txToolData.getBinAttachHash());
				}
			}
						
			if(txToolData.hasStreamId()) {
				properties.putInteger(ToolData.PROP_STREAM_ID, txToolData.getStreamId());
			} 
			
			if(txToolData.hasMessageIdentifier()) {
				properties.putLong(ToolData.PROP_MESSAGE_ID, txToolData.getMessageIdentifier());
			}
			
			if(_txToolDataProps.WANT_LATENCY) {
				long latencyTime = txToolData.getLatency();
				if (latencyTime == 0) {
					latencyTime = Timing.getClockValue();
				}
				properties.putLong(ToolData.PROP_LATENCY, latencyTime);
			}
			
			if(txToolData.getRepublished()) {
			    properties.putBoolean(ToolData.PROP_REPUBLISHED, true);
			}
			
			message.setProperties(properties);
			
		} catch (SDTException e) {
			Trace.error("CLIENT " + _clientIdStr + ": " + e.getMessage(), e);
		}
	}
	
	private void resetMsgs(int pubSessionIndex) 
	{
		_messagesArray[pubSessionIndex].reset();

		JCSMPSendMultipleEntry[] msgsArray = _sendVectorMsgs.get(pubSessionIndex);
		if (msgsArray != null) {
			for (JCSMPSendMultipleEntry msgEntry : msgsArray) {
				msgEntry.getMessage().reset();
		    }
		}
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	private static JCSMPProperties buildJCSMPProps(
		final RuntimeProperties rprops,
		final int clientId) {

		JCSMPProperties jprops = new JCSMPProperties();
		
		if (System.getProperty("JMS_Solace_localhost") != null) {
			jprops.setProperty(JCSMPProperties.LOCALHOST, System.getProperty("JMS_Solace_localhost"));
		}

		jprops.setProperty(JCSMPProperties.HOST, rprops.getProperty(RuntimeProperties.CLIENT_IP_ADDR));

		if (!rprops.getStringProperty(RuntimeProperties.CLIENT_USERNAME).equals("") ||
				(rprops.getStringProperty(RuntimeProperties.CLIENT_USERNAME).equals("") &&
				 !rprops.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME).equals(GenericAuthenticationScheme.CLIENT_CERTIFICATE) &&
				 !rprops.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME).equals(GenericAuthenticationScheme.GSS_KRB))) {
			String username = ClientFactory.generateClientUsername(rprops, clientId);
			jprops.setProperty(JCSMPProperties.USERNAME, username);
		}

		jprops.setProperty(JCSMPProperties.PASSWORD, rprops
				.getProperty(RuntimeProperties.CLIENT_PASSWORD));

		if (!rprops.getStringProperty(RuntimeProperties.CLIENT_VPN).equals("")) {
			jprops.setProperty(JCSMPProperties.VPN_NAME, rprops.
				getStringProperty(RuntimeProperties.CLIENT_VPN));
		}
		if (!rprops.getStringProperty(RuntimeProperties.CLIENT_NAME_PREFIX).equals("") &&
				!rprops.getBooleanProperty(RuntimeProperties.CHANGE_CLIENT_NAMES_FLAG)) {
			String clientname = ClientFactory.generateClientName(rprops, clientId);
			jprops.setProperty(JCSMPProperties.CLIENT_NAME, clientname);
		}

		if (!rprops.getStringProperty(RuntimeProperties.CLIENT_DESCRIPTION).equals("")) {
			jprops.setProperty(
					JCSMPProperties.APPLICATION_DESCRIPTION,
					rprops.getStringProperty(RuntimeProperties.CLIENT_DESCRIPTION));
		}
		
		// Check for WANT_NON_BLOCKING_CONNECT
		Boolean value = rprops.getBooleanProperty(RuntimeProperties.WANT_NON_BLOCKING_CONNECT);
		if (value != null && value) {
			Trace.warn("Cannot connect in a non-blocking way when using the JcsmpClient.");
		}

		if (rprops.getProperty(RuntimeProperties.AD_PUB_ACK_TIMEOUT) != null) {
			jprops.setIntegerProperty(JCSMPProperties.PUB_ACK_TIME, rprops
				.getIntegerProperty(RuntimeProperties.AD_PUB_ACK_TIMEOUT));
		}
		if (rprops.getProperty(RuntimeProperties.AD_PUB_MAX_RESEND) != null) {
			jprops.setIntegerProperty(JCSMPProperties.MAX_RESENDS, rprops
				.getIntegerProperty(RuntimeProperties.AD_PUB_MAX_RESEND));
		}
		if (rprops.getProperty(RuntimeProperties.AD_PUB_WINDOW_SIZE) != null) {
			jprops.setIntegerProperty(JCSMPProperties.PUB_ACK_WINDOW_SIZE, rprops
				.getIntegerProperty(RuntimeProperties.AD_PUB_WINDOW_SIZE));
		}

		if (rprops.getProperty(RuntimeProperties.AD_SUB_ACK_TIMEOUT) != null) {
			jprops.setIntegerProperty(JCSMPProperties.SUB_ACK_TIME, rprops
				.getIntegerProperty(RuntimeProperties.AD_SUB_ACK_TIMEOUT));
		}
		if (rprops.getProperty(RuntimeProperties.AD_SUB_WINDOW_SIZE) != null) {
			jprops.setIntegerProperty(JCSMPProperties.SUB_ACK_WINDOW_SIZE, rprops
				.getIntegerProperty(RuntimeProperties.AD_SUB_WINDOW_SIZE));
		}
		if (rprops.getProperty(RuntimeProperties.AD_SUB_WINDOW_THRESHOLD) != null) {
			jprops.setIntegerProperty(JCSMPProperties.SUB_ACK_WINDOW_THRESHOLD, rprops
				.getIntegerProperty(RuntimeProperties.AD_SUB_WINDOW_THRESHOLD));
		}
		if (rprops.getProperty(RuntimeProperties.AD_ACK_EVENT_MODE) != null) {
			GenericSupportedAckEvent ackMode = (GenericSupportedAckEvent) rprops.getProperty(RuntimeProperties.AD_ACK_EVENT_MODE);
			if(ackMode != null) {
				if (ackMode == GenericSupportedAckEvent.PER_MSG) {
					jprops.setProperty(JCSMPProperties.ACK_EVENT_MODE, JCSMPProperties.SUPPORTED_ACK_EVENT_MODE_PER_MSG);
				} else if (ackMode == GenericSupportedAckEvent.WINDOWED) {
					jprops.setProperty(JCSMPProperties.ACK_EVENT_MODE, JCSMPProperties.SUPPORTED_ACK_EVENT_MODE_WINDOWED);
				}
			}
		}

		Boolean nodelay = rprops.getBooleanProperty(RuntimeProperties.WANT_TCP_NODELAY);
		JCSMPChannelProperties clientchannel = (JCSMPChannelProperties) jprops
			.getProperty(JCSMPProperties.CLIENT_CHANNEL_PROPERTIES);
		if (nodelay != null)
			clientchannel.setTcpNoDelay(nodelay);
		if (rprops.getProperty(RuntimeProperties.CLIENT_COMPRESSION_LEVEL) != null) {
			clientchannel.setCompressionLevel(rprops
				.getIntegerProperty(RuntimeProperties.CLIENT_COMPRESSION_LEVEL));
		}
		if (rprops.getProperty(RuntimeProperties.READ_TIMEOUT_IN_MSEC) != null) {
			clientchannel.setReadTimeoutInMillis(rprops
				.getIntegerProperty(RuntimeProperties.READ_TIMEOUT_IN_MSEC));
		}
		if (rprops.getProperty(RuntimeProperties.KEEPALIVE_INTERVAL_MSEC) != null) {
			clientchannel.setKeepAliveIntervalInMillis(rprops
				.getIntegerProperty(RuntimeProperties.KEEPALIVE_INTERVAL_MSEC));
		}
		if (rprops.getProperty(RuntimeProperties.RECONNECT_ATTEMPTS) != null) {
			clientchannel.setReconnectRetries(rprops
				.getIntegerProperty(RuntimeProperties.RECONNECT_ATTEMPTS));
		}
		if (rprops.getProperty(RuntimeProperties.RECONNECT_INTERVAL_MSEC) != null) {
			clientchannel.setReconnectRetryWaitInMillis(rprops
				.getIntegerProperty(RuntimeProperties.RECONNECT_INTERVAL_MSEC));
		}
		
		if (rprops.getProperty(RuntimeProperties.CLIENT_DTO_LOCAL_PRIORITY) != null) {
			jprops.setIntegerProperty(JCSMPProperties.SUBSCRIBER_LOCAL_PRIORITY, rprops
				.getIntegerProperty(RuntimeProperties.CLIENT_DTO_LOCAL_PRIORITY));
		}
		
		if (rprops.getProperty(RuntimeProperties.CLIENT_DTO_NETWORK_PRIORITY) != null) {
			jprops.setIntegerProperty(JCSMPProperties.SUBSCRIBER_NETWORK_PRIORITY, rprops
				.getIntegerProperty(RuntimeProperties.CLIENT_DTO_NETWORK_PRIORITY));
		}
		
		if (rprops.getBooleanProperty(RuntimeProperties.WANT_SUBSCRIPTION_MEMORY)) {
			jprops.setBooleanProperty(JCSMPProperties.REAPPLY_SUBSCRIPTIONS, true);
		}
		
		if (rprops.getBooleanProperty(RuntimeProperties.IGNORE_EXISTS_ERRORS)) {
			jprops.setBooleanProperty(JCSMPProperties.IGNORE_DUPLICATE_SUBSCRIPTION_ERROR, true);
			jprops.setBooleanProperty(JCSMPProperties.IGNORE_SUBSCRIPTION_NOT_FOUND_ERROR, true);
		} else {
			jprops.setBooleanProperty(JCSMPProperties.IGNORE_DUPLICATE_SUBSCRIPTION_ERROR, false);
			jprops.setBooleanProperty(JCSMPProperties.IGNORE_SUBSCRIPTION_NOT_FOUND_ERROR, false);
		}
		
		if (rprops.getBooleanProperty(RuntimeProperties.WANT_CLIENT_ACK)) {
			jprops.setProperty(JCSMPProperties.MESSAGE_ACK_MODE, JCSMPProperties.SUPPORTED_MESSAGE_ACK_CLIENT);
		}
		
		if (rprops.getBooleanProperty(RuntimeProperties.WANT_NO_LOCAL)) {
			jprops.setBooleanProperty(JCSMPProperties.NO_LOCAL, true);
		}

		if (rprops.getProperty(RuntimeProperties.MESSAGE_CALLBACK_ON_REACTOR) != null) {
		    jprops.setBooleanProperty(JCSMPProperties.MESSAGE_CALLBACK_ON_REACTOR, rprops
	                .getBooleanProperty(RuntimeProperties.MESSAGE_CALLBACK_ON_REACTOR));
	    }
		
		if (!rprops.getProperty(RuntimeProperties.SSL_PROTOCOL).equals("")) {
			jprops.setProperty(JCSMPProperties.SSL_PROTOCOL, rprops
					.getProperty(RuntimeProperties.SSL_PROTOCOL));
		}
		
		if (rprops.getProperty(RuntimeProperties.SSL_CONNECTION_DOWNGRADE_TO) != null &&
				rprops.getProperty(RuntimeProperties.SSL_CONNECTION_DOWNGRADE_TO) instanceof String
				&& !rprops.getProperty(RuntimeProperties.SSL_CONNECTION_DOWNGRADE_TO).equals("")) {
			
			String scdt = rprops.getStringProperty(RuntimeProperties.SSL_CONNECTION_DOWNGRADE_TO);
			
			if (scdt.equalsIgnoreCase(JCSMPProperties.TRANSPORT_PROTOCOL_PLAIN_TEXT)) {
				jprops.setProperty(JCSMPProperties.SSL_CONNECTION_DOWNGRADE_TO,
						JCSMPProperties.TRANSPORT_PROTOCOL_PLAIN_TEXT);
			} else {
				jprops.setProperty(JCSMPProperties.SSL_CONNECTION_DOWNGRADE_TO, scdt);
			}
			
		}
		
		if (!rprops.getProperty(RuntimeProperties.SSL_EXLCUDED_PROTOCOLS).equals("")) {
			jprops.setProperty(JCSMPProperties.SSL_EXCLUDED_PROTOCOLS, rprops
					.getProperty(RuntimeProperties.SSL_EXLCUDED_PROTOCOLS));
		}

		if (!rprops.getBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE)) {
			jprops.setBooleanProperty(JCSMPProperties.SSL_VALIDATE_CERTIFICATE, rprops
					.getBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE));
		}

		if (!rprops.getBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE_DATE)) {
			jprops.setBooleanProperty(JCSMPProperties.SSL_VALIDATE_CERTIFICATE_DATE, rprops
					.getBooleanProperty(RuntimeProperties.SSL_VALIDATE_CERTIFICATE_DATE));
		}

		if (!rprops.getProperty(RuntimeProperties.SSL_CIPHER_SUITES).equals("")) {
			jprops.setProperty(JCSMPProperties.SSL_CIPHER_SUITES, rprops
					.getProperty(RuntimeProperties.SSL_CIPHER_SUITES));
		}

		if (!rprops.getProperty(RuntimeProperties.SSL_TRUST_STORE).equals("")) {
			jprops.setProperty(JCSMPProperties.SSL_TRUST_STORE, rprops
					.getProperty(RuntimeProperties.SSL_TRUST_STORE));
		}

		if (!rprops.getProperty(RuntimeProperties.SSL_TRUST_STORE_PASSWORD).equals("")) {
			jprops.setProperty(JCSMPProperties.SSL_TRUST_STORE_PASSWORD, rprops
					.getProperty(RuntimeProperties.SSL_TRUST_STORE_PASSWORD));
		}

		if (!rprops.getProperty(RuntimeProperties.SSL_TRUST_STORE_FORMAT).equals("")) {
			jprops.setProperty(JCSMPProperties.SSL_TRUST_STORE_FORMAT, rprops
					.getProperty(RuntimeProperties.SSL_TRUST_STORE_FORMAT));
		}

		if (!rprops.getProperty(RuntimeProperties.SSL_TRUSTED_COMMON_NAME_LIST).equals("")) {
			jprops.setProperty(JCSMPProperties.SSL_TRUSTED_COMMON_NAME_LIST, rprops
					.getProperty(RuntimeProperties.SSL_TRUSTED_COMMON_NAME_LIST));
		}

        if (!rprops.getProperty(RuntimeProperties.SSL_KEY_STORE).equals("")) {
            jprops.setProperty(JCSMPProperties.SSL_KEY_STORE, rprops
                    .getProperty(RuntimeProperties.SSL_KEY_STORE));
        }

        if (!rprops.getProperty(RuntimeProperties.SSL_KEY_STORE_PASSWORD).equals("")) {
            jprops.setProperty(JCSMPProperties.SSL_KEY_STORE_PASSWORD, rprops
                    .getProperty(RuntimeProperties.SSL_KEY_STORE_PASSWORD));
        }

        if (!rprops.getProperty(RuntimeProperties.SSL_KEY_STORE_FORMAT).equals("")) {
            jprops.setProperty(JCSMPProperties.SSL_KEY_STORE_FORMAT, rprops
                    .getProperty(RuntimeProperties.SSL_KEY_STORE_FORMAT));
        }

        if (!rprops.getProperty(RuntimeProperties.SSL_PRIVATE_KEY_ALIAS).equals("")) {
            jprops.setProperty(JCSMPProperties.SSL_PRIVATE_KEY_ALIAS, rprops
                    .getProperty(RuntimeProperties.SSL_PRIVATE_KEY_ALIAS));
        }

        if (!rprops.getProperty(RuntimeProperties.SSL_PRIVATE_KEY_PASSWORD).equals("")) {
            jprops.setProperty(JCSMPProperties.SSL_PRIVATE_KEY_PASSWORD, rprops
                    .getProperty(RuntimeProperties.SSL_PRIVATE_KEY_PASSWORD));
        }

        if (!rprops.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME).equals("")) {
            if (rprops.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME).equals(GenericAuthenticationScheme.BASIC)) {
                jprops.setProperty(JCSMPProperties.AUTHENTICATION_SCHEME, JCSMPProperties.AUTHENTICATION_SCHEME_BASIC);
            } else if (rprops.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME).equals(GenericAuthenticationScheme.CLIENT_CERTIFICATE)) {
                jprops.setProperty(JCSMPProperties.AUTHENTICATION_SCHEME, JCSMPProperties.AUTHENTICATION_SCHEME_CLIENT_CERTIFICATE);
            } else if (rprops.getProperty(RuntimeProperties.AUTHENTICATION_SCHEME).equals(GenericAuthenticationScheme.GSS_KRB)) {
                jprops.setProperty(JCSMPProperties.AUTHENTICATION_SCHEME, JCSMPProperties.AUTHENTICATION_SCHEME_GSS_KRB);
            }
        }
        
        if(rprops.getProperty(RuntimeProperties.RECONNECT_FAIL_ACTION) != null && 
        		rprops.getProperty(RuntimeProperties.RECONNECT_FAIL_ACTION) instanceof ReconnectFailAction) {
        	
        	ReconnectFailAction rfa = (ReconnectFailAction) rprops.getProperty(RuntimeProperties.RECONNECT_FAIL_ACTION);
			if (rfa == ReconnectFailAction.AUTO_RETRY) {
				jprops.setProperty(JCSMPProperties.GD_RECONNECT_FAIL_ACTION,
						JCSMPProperties.GD_RECONNECT_FAIL_ACTION_AUTO_RETRY);
			} else if (rfa == ReconnectFailAction.DISCONNECT) {
				jprops.setProperty(JCSMPProperties.GD_RECONNECT_FAIL_ACTION,
						JCSMPProperties.GD_RECONNECT_FAIL_ACTION_DISCONNECT);
			}
        	
        }

		if (rprops.getProperty(RuntimeProperties.EXTRA_PROP_LIST) != null) { 
			List<String> extraProp = (List<String>) rprops.getProperty(RuntimeProperties.EXTRA_PROP_LIST);
			Properties tempProp = jprops.toProperties();
			
			for(int i = 0; i < (extraProp.size() - 1); i +=2) {
				tempProp.setProperty(extraProp.get(i), 
						extraProp.get(i+1));
			}
			jprops = JCSMPProperties.fromProperties(tempProp);
		}
		
		return jprops;
	}
	
	private static CacheSessionProperties buildJCSMPCacheProps(
			final RuntimeProperties rprops) {

		CacheSessionProperties cacheProps = null;
		
		if (rprops.getProperty(RuntimeProperties.CACHE_PROP_NAME) != null &&
			!rprops.getStringProperty(RuntimeProperties.CACHE_PROP_NAME).equals("")) {
			
			cacheProps = new CacheSessionProperties(rprops.getStringProperty(RuntimeProperties.CACHE_PROP_NAME));
			
			if (rprops.getProperty(RuntimeProperties.CACHE_PROP_MAX_MSGS_PER_TOPIC) != null &&
				rprops.getIntegerProperty(RuntimeProperties.CACHE_PROP_MAX_MSGS_PER_TOPIC) != -1) {
				cacheProps.setMaxMsgs(rprops.getIntegerProperty(RuntimeProperties.CACHE_PROP_MAX_MSGS_PER_TOPIC));
			}

			if (rprops.getProperty(RuntimeProperties.CACHE_PROP_MAX_AGE) != null &&
				rprops.getIntegerProperty(RuntimeProperties.CACHE_PROP_MAX_AGE) != -1) {
				cacheProps.setMaxAge(rprops.getIntegerProperty(RuntimeProperties.CACHE_PROP_MAX_AGE));
			}

			if (rprops.getProperty(RuntimeProperties.CACHE_PROP_TIMEOUT_IN_MSEC) != null &&
				rprops.getIntegerProperty(RuntimeProperties.CACHE_PROP_TIMEOUT_IN_MSEC) != -1) {
				cacheProps.setTimeout(rprops.getIntegerProperty(RuntimeProperties.CACHE_PROP_TIMEOUT_IN_MSEC));
			}

		}
		
		return cacheProps;
	}

	public void reflectMsg(AbstractWrappedMessage message) {
		
		// The fact that this method was called implies that we were in a 
		// situation where _rxToolDataProps.WANT_MSG_REFLECT was true.
		
		if (_rxToolDataProps.CLIENT_MODE == ClientModeType.SINK) {
			throw new IllegalStateException("Error in the logic. This method shouldn't be called in mode ClientModeType.SINK.");
		}
		if (_rxToolDataProps.CLIENT_MODE == ClientModeType.REFLECT) {
			throw new IllegalStateException("Error in the logic. This method shouldn't be called in mode ClientModeType.REFLECT.");
		}
		
		if(!(message instanceof JcsmpWrappedMessage)) {
			throw new IllegalArgumentException("Message must be of type "+ JcsmpWrappedMessage.class.toString());
		}
		
		// BytesXMLMessage
		BytesXMLMessage msg = ((JcsmpWrappedMessage)message).getMessage();
		Destination dest = msg.getReplyTo();
		
		if (dest == null) {
			// don't reflect anything if the replyTo address isn't set up.
			Trace.info("Cannot reflect message with 'null' reply-to destination.");
			return;
		}
		
		BytesXMLMessage msgCopy = JCSMPFactory.onlyInstance().createMessage(BytesXMLMessage.class);
		
		if (msg.hasAttachment()) {
			// we can just copy the attachments here if we want
			ByteBuffer bbuf = msg.getAttachmentByteBuffer();

			if (bbuf.hasArray()) {
				// fastest
				msgCopy.writeAttachment(bbuf.array(), bbuf.position(), msg.getAttachmentContentLength());
			} else {
				// It turns out that JCSMP gives us messages where the binary
				// attachment is backed by a byte array that we can have access to.
				Trace.error("The ByteBuffer returned from the message did not contain an array, no message will be reflected.");
				return;
			}
		} else {
			msgCopy.clearAttachment();
		}
		
		// _currProducer might be null right now because the reflecting side of sdkperf
		// doesn't necessarily send any messages before reflecting the ones sent to it
		try {
			_defaultProducer.send(msgCopy, dest);
		} catch (JCSMPException e) {
			Trace.error("Exception caught when trying to reflect message.", e);
		}	
	}
	
	public void handleError(String messageID, JCSMPException exception, long timestamp) {
		Exception e = exception;
		int MAX_LOOP = 10;
		int numiterations = 0;
		while ((e != null) && (!(e instanceof JCSMPErrorResponseException)) && 
				(numiterations < MAX_LOOP)) {
			e = (Exception)e.getCause();
			numiterations++;
		}
		
		if (e instanceof JCSMPErrorResponseException) {
			_lastErrorResponse = (JCSMPErrorResponseException)e;
		}
		
		if (exception == null) {
            Trace.warn("CLIENT " + _clientIdStr + ": handleError called with a null exception.");
        } else {
            Trace.warn("CLIENT " + _clientIdStr + ": handleError called - " + exception.getMessage(), exception);
        }
		_asyncExceptionOccured = true;
	}
	
	public void responseReceived(String messageID) {
		
	}

	public void handleErrorEx(Object key, JCSMPException exception, long timestamp) {
		
		if (exception == null) {
	        Trace.warn("CLIENT " + _clientIdStr + ": handleErrorEx called with a null exception.");
	    } else {
	        Trace.warn("CLIENT " + _clientIdStr + ": handleErrorEx called - " + exception.getMessage(), exception);
	    }
	    
	    if (key == null) {
	        handleError("no_key_object_given_to_handleErrorEx", exception, timestamp);
	        
	        if ((exception != null) && (exception instanceof JCSMPTransportException) &&
	                (exception.getCause() != null) && (exception.getCause() instanceof JCSMPErrorResponseException)) {
	            JCSMPErrorResponseException errorRespEx = (JCSMPErrorResponseException)exception.getCause();
	            if (errorRespEx.getSubcodeEx() == JCSMPErrorResponseSubcodeEx.UNKNOWN_FLOW_NAME) {
	                Trace.info("CLIENT " + _clientIdStr + ": Received UNKNOWN_FLOW_NAME");
	    	        if (_rxProps.getBooleanProperty(RuntimeProperties.WANT_REPLICATION_RECONNECT)) {
		                try {
		                    disconnect();
		                    connect();
		                    _currProducer = _defaultProducer;
		                    start();
		                } catch (Exception e) {
		                    Trace.warn("CLIENT " + _clientIdStr + ": Exception while reconnecting due to UNKNOWN_FLOW_NAME: " + e.getMessage(), e);
		                }
	    	        }
	            }
	        }
	        
	    } else {
	        handleError(key.toString(), exception, timestamp);
            
            _stats.incStat(PerfStatType.NUM_NACK_EVENTS, 1);
            
			if (_rxToolDataProps.WANT_PUB_ACK_ORDER_CHECK && key instanceof Long) {
	            long correlationValue = ((Long)key).longValue();
	            if (_highestCorrelationTagValueAcked < correlationValue) {
	            	_stats.incStat(PerfStatType.NUM_PUB_MSGS_ACKED, 1);

                    if ((exception != null) && (exception instanceof JCSMPTransportException) &&
                            (exception.getCause() != null) && (exception.getCause() instanceof JCSMPErrorResponseException)) {
                        JCSMPErrorResponseException errorRespEx = (JCSMPErrorResponseException)exception.getCause();
                        if (errorRespEx.getSubcodeEx() != JCSMPErrorResponseSubcodeEx.REPLICATION_IS_STANDBY) {
                            if (correlationValue - _highestCorrelationTagValueAcked != 1) {
                                Trace.error("CLIENT " + _clientIdStr + ": Received NACK for " + correlationValue + " after " +  _highestCorrelationTagValueAcked);
                            }

                            _highestCorrelationTagValueAcked = correlationValue;
                        }
	            	}
	            } else {
	            	Trace.error("CLIENT " + _clientIdStr + ": Received NACK for " + correlationValue + " after " +  _highestCorrelationTagValueAcked);
	            }
	        }
	    }
	}
	
    public void responseReceivedEx(Object key) {
    	
    	_stats.incStat(PerfStatType.NUM_ACK_EVENTS, 1);
    	_stats.incStat(PerfStatType.SESSION_EVENT_ACKNOWLEDGEMENT, 1);
    	
        if (_rxToolDataProps.WANT_PUB_ACK_ORDER_CHECK && (key != null) && (key instanceof Long)) {
            long correlationValue = ((Long)key).longValue();
            if (_highestCorrelationTagValueAcked < correlationValue) {
            	_stats.incStat(PerfStatType.NUM_PUB_MSGS_ACKED, correlationValue-_highestCorrelationTagValueAcked);
                _highestCorrelationTagValueAcked = correlationValue;
            } else {
            	Trace.error("CLIENT " + _clientIdStr + ": Received ACK for " + correlationValue + " after " +  _highestCorrelationTagValueAcked);
            }
        }
    }
	
	// Cache API listener implementation.
	public void onComplete(Long requestId, Topic topic, CacheRequestResult result) {
        _stats.incStat(PerfStatType.NUM_CACHE_RESP_RECV, 1);
        switch(result) {
        case OK:
            _stats.incStat(PerfStatType.NUM_CACHE_REQ_OK, 1);
            break;
           case NO_DATA:
               _stats.incStat(PerfStatType.NUM_CACHE_REQ_INCOMP_NODATA, 1);
               break;
           case SUSPECT_DATA: 
               _stats.incStat(PerfStatType.NUM_CACHE_REQ_INCOMP_SUSPECT, 1);
               break;
           default:
               Trace.error("CLIENT " + _clientIdStr + ": Received unexpected cache result: " + result);
        }
    }
	
	public void onException(Long requestId, Topic topic, JCSMPException exception) {
		_stats.incStat(PerfStatType.NUM_CACHE_RESP_RECV, 1);
	    // To add timeout test
		if (exception instanceof JCSMPInterruptedException) {
			_stats.incStat(PerfStatType.NUM_CACHE_REQ_INCOMP_CANCELLED, 1);			
		} else if (!exception.getMessage().toLowerCase().
                contains("Timeout occurred performing cache request")) {
			_stats.incStat(PerfStatType.NUM_CACHE_REQ_INCOMP_TIMEOUT, 1);
		} else {
			_stats.incStat(PerfStatType.NUM_CACHE_REQ_ERROR, 1);
		}
    }
	
    class MesssageListener implements XMLMessageListener, FlowEventHandler {

		public String destination;
		public Consumer consumer;
		public volatile boolean isStarted;
		public final boolean isTopic;
		public final boolean isNonDurable;
		private final AbstractClientTransactedSession transactedSession;
		private int clientAckSkipNum = _rxProps.getIntegerProperty(RuntimeProperties.CLIENT_ACK_SKIP_NUM);
		private FlowStatus flowStatus = new FlowStatus();
		
		
		// Needed in topics as jcsmp won't remember the topic.
		public final Topic topic;
		
		public MesssageListener (String destination, boolean isTopic, Topic topic, boolean isNonDurable, AbstractClientTransactedSession transactedSession) {
			this.destination = destination;
			this.isStarted = false;
			this.isTopic = isTopic;
			this.topic = topic;
			this.isNonDurable = isNonDurable;
			this.transactedSession = transactedSession;
		}
		
		public void onException(JCSMPException exception) {
			updateLastErrorResponse(exception);
			Trace.warn("CLIENT " + _clientIdStr + ": onException called - " + exception.getMessage(), exception);
			if (exception instanceof JCSMPFlowTransportException) {
				this.consumer = null;
			}
		}

		public void onReceive(BytesXMLMessage message) {
			
			if(message.isStructuredMsg()) {
				_stats.incStat(PerfStatType.NUM_MSGS_RECEIVED_STRUCTURED_TOTAL, 1);
				
				if(message instanceof TextMessage) {
					_stats.incStat(PerfStatType.NUM_MSGS_RECEIVED_STRUCTURED_TEXT, 1);
				} else if(message instanceof StreamMessage) {
					_stats.incStat(PerfStatType.NUM_MSGS_RECEIVED_STRUCTURED_STREAM, 1);
				} else if (message instanceof MapMessage) {
					_stats.incStat(PerfStatType.NUM_MSGS_RECEIVED_STRUCTURED_MAP, 1);
				} else {
					Trace.error("Received structured message of type: " + message.getClass());
				}
			} else {
				_stats.incStat(PerfStatType.NUM_MSGS_RECEIVED_UNSTRUCTURED_TOTAL, 1);
				
				if(message.hasAttachment()) {
					_stats.incStat(PerfStatType.NUM_MSGS_RECEIVED_UNSTRUCTURED_BYTES, 1);
				}
				if(message.getBytes() != null) {
					_stats.incStat(PerfStatType.NUM_MSGS_RECEIVED_UNSTRUCTURED_XML, 1);
				}
			}
						
			JcsmpWrappedMessage wMsg = new JcsmpWrappedMessage(message);
			
			
			if (_rxToolDataProps.NUM_MSG_PUB_ON_RCV > 0) {
				try {
					// Use the transacted session's producer if we have a
					// transacted session
					if (transactedSession != null) {
						wMsg.setProducerOnReceive(transactedSession.getProducer());
					} else {
						// Use the default producer if we do not have a transacted session
						wMsg.setProducerOnReceive(_defaultProducer);
					}
				} catch (Exception e) {
					Trace.warn("Failed to set producer to use on receive.", e);
				}
			}

			processMessage(wMsg);
			
			if (_rxToolDataProps.WANT_CLIENT_ACK) {
				if (clientAckSkipNum > 0) {
					Trace.info("CLIENT " + _clientIdStr + ": Skipping Ack of Msg Id: " + message.getMessageId());
					clientAckSkipNum--;
					return;
				}
				
				if (_rxToolDataProps.WANT_KEEP_MSGS) {
					keepMsg(new JcsmpMessageAckData(this.destination, this.isTopic, wMsg));
				} else {
					message.ackMessage();
				}
			}
			
			if (transactedSession != null) {
				try {
					transactedSession.onMessage();
				} catch (Exception e) {
					handleMessageProcessingError(e);
				}
			}
		}
		
		public FlowStatus getFlowStatus() {
			return flowStatus;
		}

		public void handleEvent(Object source, FlowEventArgs eventArgs) {
			
			switch (eventArgs.getEvent()) {			
				case FLOW_ACTIVE:
					// Flow is active.  Make sure we only get one event for
					// each flow active occurrence.  Otherwise it's an error.					
					if (flowStatus.getAfiState() == ActiveFlowIndicationType.ACTIVE) {
						Trace.error("CLIENT " + _clientIdStr + ": Flow (" + source + ") received FLOW_ACTIVE while already ACTIVE");
					} else {
						Trace.info("CLIENT " + _clientIdStr + ": Flow (" + source + ") received FLOW_ACTIVE");
					}
					
					flowStatus.setAfiState(ActiveFlowIndicationType.ACTIVE);
					break;
					
				case FLOW_INACTIVE:
					// Flow is inactive.  Make sure we only get one event for
					// each flow inactive occurrence.  Otherwise it's an error.
					if (flowStatus.getAfiState() == ActiveFlowIndicationType.INACTIVE) {
						Trace.error("CLIENT " + _clientIdStr + ": Flow (" + source + ") received FLOW_INACTIVE while already INACTIVE");
					} else {
						Trace.info("CLIENT " + _clientIdStr + ": Flow (" + source + ") received FLOW_INACTIVE");
					}
					
					flowStatus.setAfiState(ActiveFlowIndicationType.INACTIVE);
					break;
					
				default:
					Trace.error("CLIENT " + _clientIdStr + ": Unknown flow event " + eventArgs.getEvent().toString() + "(" + eventArgs.getInfo() + ")");
					break;
			}
		}
	}

	public void handleEvent(SessionEventArgs event) {
		if (Trace.isDebugEnabled()) 
		{
			Trace.debug("CLIENT " + _clientIdStr + ": handleEvent() called." + 
						" Event: " + event.getEvent() +
						" RC: " + event.getResponseCode() +
						" Info: " + event.getInfo());
		}
		
		switch(event.getEvent()) {
		case DOWN_ERROR:
			_stats.incStat(PerfStatType.SESSION_EVENT_DOWN_ERROR, 1);
			_channelState = ChannelState.CLIENT_STATE_DISCONNECTED;
			break;
		case INCOMPLETE_LARGE_MESSAGE_RECVD:
			_stats.incStat(PerfStatType.SESSION_EVENT_INCOMPLETE_LARGE_MESSAGE_RECVD, 1);
			break;
		case RECONNECTED:
			_stats.incStat(PerfStatType.SESSION_EVENT_RECONNECTED_NOTICE, 1);
			_channelState = ChannelState.CLIENT_STATE_CONNECTED;
			break;
		case RECONNECTING:
			_stats.incStat(PerfStatType.SESSION_EVENT_RECONNECTING_NOTICE, 1);
			_channelState = ChannelState.CLIENT_STATE_RECONNECTING;
			break;
		case SUBSCRIPTION_ERROR:
			_stats.incStat(PerfStatType.SESSION_EVENT_SUBSCRIPTION_ERROR, 1);
			break;
		case UNKNOWN_TRANSACTED_SESSION_NAME:
			_stats.incStat(PerfStatType.SESSION_EVENT_UNKNOWN_TRANSACTED_SESSION_NAME, 1);
			break;
		case VIRTUAL_ROUTER_NAME_CHANGED:
			_stats.incStat(PerfStatType.SESSION_EVENT_VIRTUAL_ROUTER_NAME_CHANGED, 1);
			break;
		default:
			break;
		
		}
		
	}
	
	
	//get the version of the client
	public String getFormattedVersionInfo() {
		StringBuilder sb = new StringBuilder();
		sb.append(JcsmpSdkperfVersion.getSdkPerfJcsmpVersion() + System.getProperty("line.separator"));
		sb.append("sol-jcsmp version: " + JCSMPRuntime.onlyInstance().getVersion().getSwVersion());
		return sb.toString();
	}
	
	

	public void updateLastErrorResponse(Exception e) {
		int MAX_LOOP = 10;
		int numiterations = 0;
		while ((e != null) && (!(e instanceof JCSMPErrorResponseException)) && 
				(numiterations < MAX_LOOP)) {
			e = (Exception)e.getCause();
			numiterations++;
		}
		
		if (e instanceof JCSMPErrorResponseException) {
			_lastErrorResponse = (JCSMPErrorResponseException)e;
		}
	}
	
	@Override
	public Object cloneToApiSpecificContext(Object msgRepArray) {
		ContextProperties cp = new ContextProperties();
		return JCSMPFactory.onlyInstance().createContext(cp);
	}
	
	@Override
	public void destroyApiSpecificContext(Object context) {
		
		if(context == null) {
			Trace.error("JcsmpClient cannot destroy a 'null' Context.");
			return;
		}
		
		if(!(context instanceof Context)) {
			throw new IllegalArgumentException("JcsmpClient can only destroy contexts of type 'Context'.");
		}
		
		// Destroy the context
		((Context) context).destroy();
	}
	
	@Override
	public void setContext(Object context) {
		
		if(!(context instanceof Context)) {
			throw new IllegalArgumentException("JcsmpClient's context must be an instance of 'Context'.");
		}
		_context = (Context) context;
	}

	public void handleEvent(ProducerEventArgs args) {

		StringBuilder sb = new StringBuilder();
		sb.append(" Event: " + args.getEvent());
		sb.append(" Event Object: " + args.getEventObject());
		sb.append(" RC: " + args.getResponseCode());
		sb.append(" Info: " + args.getInfo());
		sb.append(" Exception: " + args.getException());

		switch (args.getEvent()) {
		case REPUBLISH_UNACKED_MESSAGES:
			_stats.incStat(PerfStatType.SESSION_EVENT_REPUBLISH_UNACKED_MESSAGES, 1);
			Trace.info("CLIENT " + _clientIdStr + ": handleEvent() called." + sb.toString());
			break;
		default:
			Trace.error("CLIENT " + _clientIdStr + ": handleEvent() called for unhandled ProducerEvent type."
					+ sb.toString());
			break;
		}
	}
	
}
