/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.Constants.InternalApiMode;


/**
 * Factory examining the supplied RuntimeProperties instance to determine which
 * specific subclass of AbstractClient to return to
 * caller. 
 */
public final class ClientFactory {

	private final static String DEFAULT_CLIENT_USERNAME = "perf_client";
	
	private ClientFactory() {
	}

	
	public static String getVersionString(final RuntimeProperties rprop) throws Exception {

		InternalApiMode mode = (InternalApiMode) rprop.getProperty(RuntimeProperties.API_MODE);
		String extClientClassStr = rprop.getStringProperty(RuntimeProperties.TOOL_THIRD_PARTY_EXTERNAL_CLIENT_CLASS);
		AbstractClient client = createClientObject(mode, extClientClassStr);
		
		return client.getVersionString();
	}
	
	public static AbstractClient createClient(final RuntimeProperties rprop, final int clientId, AbstractClientCollection cc) throws Exception {
		
		InternalApiMode mode = (InternalApiMode) rprop.getProperty(RuntimeProperties.API_MODE);
		String extClientClassStr = rprop.getStringProperty(RuntimeProperties.TOOL_THIRD_PARTY_EXTERNAL_CLIENT_CLASS);
		
		AbstractClient client = createClientObject(mode, extClientClassStr);
		// Let's the client know which collection he's part of
		client.setCollection(cc);
		// Initialize the client.
		client.init(rprop, clientId);
		
		return client;
	}
	
	private static AbstractClient createClientObject(InternalApiMode mode, String externalClientClassStr) throws Exception {
		
		Class<?> clientClass;
		
		switch (mode) {
		case JCSMP:
			clientClass = Class.forName("com.solacesystems.pubsub.sdkperf.jcsmpcore.JcsmpClient");
			break;
		case JMS:
			clientClass = Class.forName("com.solacesystems.pubsub.sdkperf.jms.solace.SolJmsClient");
			break;
		case JNI:
			clientClass = Class.forName("com.solacesystems.pubsub.sdkperf.jnicore.JniClient");
			break;
		case REST:
			clientClass = Class.forName("com.solacesystems.pubsub.sdkperf.restcore.RestClient");
			break;
		case MQTT: 
			clientClass = Class.forName("com.solacesystems.pubsub.sdkperf.mqttcore.MQTTClient");
			break;
		case THIRDPARTY:
			clientClass = Class.forName(externalClientClassStr);
			break;
		default:
			throw new PubSubException("Unsupported API mode");
		}
		
		return (AbstractClient) clientClass.newInstance();
	}

	public static String generateClientIdStr(final RuntimeProperties rprop, final int clientId) {
	    String clientIdStr = "";

	    // Client ID is always client name prefix if specified and a 6 digit number.
	    if (rprop.getStringProperty(RuntimeProperties.CLIENT_NAME_PREFIX).length() > 0) {
	        clientIdStr += rprop.getStringProperty(RuntimeProperties.CLIENT_NAME_PREFIX);
	    } else {
	    	clientIdStr += "perf_client";
	    }
	        
	    clientIdStr += String.format("%06d", clientId);

	    return clientIdStr;
	}

	public static String generateClientUsername(final RuntimeProperties rprop, final int clientId) {
		String clientUsernameStr = "";

	    if (rprop.getStringProperty(RuntimeProperties.CLIENT_USERNAME).equals("")) {
	        if (rprop.getStringProperty(RuntimeProperties.CLIENT_NAME_PREFIX).equals("")) {
	            clientUsernameStr += DEFAULT_CLIENT_USERNAME;
	        } else {
	            clientUsernameStr += rprop.getStringProperty(RuntimeProperties.CLIENT_NAME_PREFIX);
	        }
	        clientUsernameStr += String.format("%06d", clientId);
	    } else {
	        clientUsernameStr += rprop.getStringProperty(RuntimeProperties.CLIENT_USERNAME);
	    }

	    return clientUsernameStr;
	}

	public static String generateClientName(final RuntimeProperties rprop, final int clientId) {
	    String clientNameStr = "";

	    if (rprop.getStringProperty(RuntimeProperties.CLIENT_NAME_PREFIX).equals("")) {
	        clientNameStr += DEFAULT_CLIENT_USERNAME;
	    } else {
	        clientNameStr += rprop.getStringProperty(RuntimeProperties.CLIENT_NAME_PREFIX);
	    }
	        
	    clientNameStr += String.format("%06d", clientId);
	    
	    return clientNameStr;
	}
}
