package com.solacesystems.pubsub.sdkperf.util;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.util.List;

public class MemoryUtils {

	private static List<GarbageCollectorMXBean> _gcBean = ManagementFactory.getGarbageCollectorMXBeans();
	private static MemoryMXBean _memBean = ManagementFactory.getMemoryMXBean();
	
	private MemoryUtils() {}
	
	private static long _resetGcCollectionCount = 0;
	private static long _resetGcCollectionTime = 0;
	
	public static void printGcInformation() {
		printGcInformation(false);
	}
	
	// resetStats doesn't actually reset stats, it basically just keep track of
	// the stats and deducts them next time this method is called.
	public static void printGcInformation(boolean resetStats) {
		// Prints out garbage collector stats
		int collectionCount = 0;
		int collectionTime = 0;
		
		for (GarbageCollectorMXBean garbageCollectorMXBean : _gcBean) { 
			collectionCount += garbageCollectorMXBean.getCollectionCount();
			collectionTime += garbageCollectorMXBean.getCollectionTime();
		}
		
		System.out.println("==> Garbage collection information");
		System.out.println("====> Collection count " + (collectionCount - _resetGcCollectionCount));
		System.out.println("====> Collection time " + (collectionTime - _resetGcCollectionTime) + " ms.");
		
		if(resetStats) {
			_resetGcCollectionCount = collectionCount;
			_resetGcCollectionTime = collectionTime;
			System.out.println("====> Resetting GC stats.");
		}
		System.out.println();
	}
	
	
	public static void printHeapInformation() {
		System.out.println("==> Heap Memory Usage: ");
		System.out.println("====> Initial Memory: " + _memBean.getHeapMemoryUsage().getInit());
		System.out.println("====> Max Memory: " + _memBean.getHeapMemoryUsage().getMax());
		System.out.println("====> Used Memory: " + _memBean.getHeapMemoryUsage().getUsed());
		System.out.println("====> Commited Memory: " + _memBean.getHeapMemoryUsage().getCommitted());
	}	
}
