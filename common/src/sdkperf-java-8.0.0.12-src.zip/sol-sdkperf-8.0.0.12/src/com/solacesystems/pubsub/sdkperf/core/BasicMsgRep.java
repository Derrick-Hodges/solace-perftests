/** 
 *  Copyright 2009-2017 Solace Corporation. All rights reserved.
 *  
 *  http://www.solacesystems.com
 *  
 *  This source is distributed WITHOUT ANY WARRANTY or support;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 *  A PARTICULAR PURPOSE.  All parts of this program are subject to
 *  change without notice including the program's CLI options.
 *
 *  Unlimited use and re-distribution of this unmodified source code is   
 *  authorized only with written permission.  Use of part or modified  
 *  source code must carry prominent notices stating that you modified it, 
 *  and give a relevant date.
 */
package com.solacesystems.pubsub.sdkperf.core;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.pubsub.sdkperf.util.DataTypes.PublisherDestinationsType;
import com.solacesystems.pubsub.sdkperf.util.SdkperfConstants;

/**
 * Contains properties of the message that will be published. This includes all
 * data for the message such as topic or queue, byte arrays of message parts or
 * the structured data message ID, etc.
 */
public class BasicMsgRep implements Cloneable {

	private static final Log Trace = LogFactory.getLog(BasicMsgRep.class);
	
	protected byte[] xml, smf;
	protected String destination;
	protected PublisherDestinationsType destType;
	protected GenericMessageDeliveryMode msgtype;

	protected int structDataMsgId;
	protected byte[] attach;
	protected ToolData toolData;
	protected boolean ackImmediately;
	
	// Http Headers
	protected String _httpContentType;
	protected String _httpContentEncoding;
	
	// Used to specify if a reply-to destination is needed on the message
	protected String _replyToDestination;
	protected PublisherDestinationsType _replyToDestType;
	protected int _mqttQos=-1;
	

	public BasicMsgRep() {}
	
	public void setMqttQos(int qos){
		_mqttQos=qos;
	}
	
	public int getMqttQos(){
		return _mqttQos;
	}

	// Static create methods
	public void configureForNormalMsg(byte[] xml, byte[] attach,
			String destination, PublisherDestinationsType destType,
			GenericMessageDeliveryMode type, String replyToDestination,
			PublisherDestinationsType replyToDestType) {

		// Make sure we have our own copy of the bytes.
		if (xml != null) {
			this.xml = new byte[xml.length];
			System.arraycopy(xml, 0, this.xml, 0, xml.length);
		} else {
			this.xml = null;
		}

		if (attach != null) {
			this.attach = new byte[attach.length];
			System.arraycopy(attach, 0, this.attach, 0, attach.length);
		} else {
			this.attach = null;
		}

		this.destination = destination;
		this.destType = destType;
		this.msgtype = type;
		this.structDataMsgId = SdkperfConstants.SDM_ID_NULL;
		this.toolData = new ToolData();
		this.smf = null;
		this.ackImmediately = false;
		this._replyToDestination = replyToDestination;
		this._replyToDestType = replyToDestType;
		this._httpContentType = null;
		this._httpContentEncoding = null;

	}

	public void configureForStructuredMsg(String destination,
			PublisherDestinationsType destType,
			GenericMessageDeliveryMode type, int structMsgId,
			String replyToDestination, PublisherDestinationsType replyToDestType) {

		this.xml = null;
		this.attach = null;
		this.destination = destination;
		this.destType = destType;
		this.msgtype = type;
		this.structDataMsgId = structMsgId;
		this.toolData = new ToolData();
		this.smf = null;
		this.ackImmediately = false;
		this._replyToDestination = replyToDestination;
		this._replyToDestType = replyToDestType;
		this._httpContentType = null;
		this._httpContentEncoding = null;

	}

	public void configureForSmfBytesMsg(byte[] smfBytes) {
		// Make sure we have our own copy of the bytes.
		if (smfBytes != null) {
			this.smf = new byte[smfBytes.length];
			System.arraycopy(smfBytes, 0, this.smf, 0, smfBytes.length);
		} else {
			this.smf = null;
		}

		this.destination = null;
		this.destType = null;
		this.msgtype = null;
		this.structDataMsgId = SdkperfConstants.SDM_ID_NULL;
		this.xml = null;
		this.attach = null;
		this.ackImmediately = false;
		this._replyToDestination = null;
		this._replyToDestType = null;
		this._httpContentType = null;
		this._httpContentEncoding = null;
	}

	public void configureForAppServer(String destination,
			PublisherDestinationsType destType,
			GenericMessageDeliveryMode type, byte[] binaryAttachment,
			String replyToDestination, PublisherDestinationsType replyToDestType) {

		this.attach = binaryAttachment;

		this.xml = null;
		this.destination = destination;
		this.destType = destType;
		this.msgtype = type;
		this.structDataMsgId = SdkperfConstants.SDM_ID_NULL;
		this.toolData = new ToolData();
		this.smf = null;
		this.ackImmediately = false;
		this._replyToDestination = replyToDestination;
		this._replyToDestType = replyToDestType;
		this._httpContentType = null;
		this._httpContentEncoding = null;

	}

	public BasicMsgRep clone() {
		BasicMsgRep mr;
		try {
			mr = (BasicMsgRep) super.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e);
		}

		if (this.xml != null) {
			mr.xml = new byte[this.xml.length];
			System.arraycopy(this.xml, 0, mr.xml, 0, this.xml.length);
		}

		if (this.smf != null) {
			mr.smf = new byte[this.smf.length];
			System.arraycopy(this.smf, 0, mr.smf, 0, this.smf.length);
		}

		if (this.attach != null) {
			mr.attach = new byte[this.attach.length];
			System.arraycopy(this.attach, 0, mr.attach, 0, this.attach.length);
		}

		// Don't copy the tool data because it is regenerated on every publish.
		mr.toolData = new ToolData();

		mr.destination = this.destination;
		mr.structDataMsgId = this.structDataMsgId;
		mr.ackImmediately = this.ackImmediately;
		mr.destType = this.destType;
		mr.msgtype = this.msgtype;
		mr._replyToDestination = this._replyToDestination;
		mr._replyToDestType = this._replyToDestType;
		mr._httpContentType = this._httpContentType;
		mr._httpContentEncoding = this._httpContentEncoding;
		mr._mqttQos = this._mqttQos;
		
		return mr;
	}

	public byte[] getXmlBytes() {
		return xml;
	}

	public byte[] getSmfBytes() {
		return smf;
	}

	public byte[] getAttachmentBytes() {
		return attach;
	}

	public void setAttachmentBytes(byte[] value) {

		this.attach = null;
		if (value != null) {
			this.attach = new byte[value.length];
			System.arraycopy(value, 0, this.attach, 0, value.length);
		}
	}

	public String getDestinationString() {
		return destination;
	}

	public void setDestinationString(String destination) {
		this.destination = destination;
	}
	
	public PublisherDestinationsType getDestinationType() {
		return destType;
	}

	public GenericMessageDeliveryMode getMessageDeliveryMode() {
		return msgtype;
	}

	public int getStructDataMsgId() {
		return structDataMsgId;
	}

	public boolean getAckImmediately() {
		return ackImmediately;
	}

	public void setAckImmediately(boolean value) {
		ackImmediately = value;
	}

	public void setRepublished(boolean value) {
		toolData.setRepublished(value);
	}
	
	public String getReplyToDestination() {
		return _replyToDestination;
	}

	public void setReplyToDestination(String replyToDestination) {
		this._replyToDestination = replyToDestination;
	}

	public PublisherDestinationsType getReplyToDestType() {
		return _replyToDestType;
	}

	public void setReplyToDestType(PublisherDestinationsType replyToDestType) {
		this._replyToDestType = replyToDestType;
	}
	
	public String getHttpContentEncoding() {
		return _httpContentEncoding;
	}

	public void setHttpContentEncoding(String httpContentEncoding) {
		this._httpContentEncoding = httpContentEncoding;
	}
	
	public String getHttpContentType() {
		return _httpContentType;
	}

	public void setHttpContentType(String httpContentType) {
		this._httpContentType = httpContentType;
	}

	@Override
	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("[xml=").append(xml == null ? "NULL" : xml.length + "B").append(", ");
		buf.append("att=").append(attach == null ? "NULL" : attach.length + "B").append(", ");
		buf.append("dest=").append(destination == null ? "NULL" : destination.length() + "B").append(", ");
		buf.append("destType=").append(destType == null ? "NULL" : destType).append(", ");
		buf.append("type=").append(msgtype == null ? "NULL" : msgtype).append(", ");
		buf.append("ackImm=").append(ackImmediately).append(", ");
		buf.append("replyToDest=").append(_replyToDestination == null ? "NULL" : _replyToDestination.length() + "B").append(", ");
		buf.append("replyToDestType=").append(_replyToDestType == null ? "NULL" : _replyToDestType).append(", ");
		buf.append("httpContentEncoding=").append(_httpContentEncoding == null ? "NULL" : _httpContentEncoding).append(", ");
		buf.append("httpContentType=").append(_httpContentType == null ? "NULL" : _httpContentType).append("]");
		return buf.toString();
	}

	public ToolData getToolData() {
		return toolData;
	}
	
	protected int encodeToolDataToAttachment() {
		int toolDataSize = toolData.getEncodedSize();
		if (toolDataSize > 0) {
			if (attach == null || toolDataSize > attach.length) {	
				if(attach != null)
					Trace.warn("BasicMsgRep.encodeToolDataToAttachment() - Encoded tooldata is larger than attachment size. Growing attachment bytes[] to accomodate.");
				attach = new byte[toolDataSize];
			}
			toolData.encode(attach);
		}
		return (attach == null) ? 0 : attach.length;
	}

}
