package com.solacesystems.pubsub.sdkperf.core;

public enum ChannelState {
	CLIENT_STATE_DISCONNECTED ("disconnected"),
	CLIENT_STATE_CONNECTING ("connecting"),
	CLIENT_STATE_RECONNECTING ("reconnecting"),
	CLIENT_STATE_CONNECTED ("connected"),
	CLIENT_STATE_UNKNOWN ("unknown");
	
    private final String text;

    /**
     * @param text
     */
    private ChannelState(final String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }
    
}
