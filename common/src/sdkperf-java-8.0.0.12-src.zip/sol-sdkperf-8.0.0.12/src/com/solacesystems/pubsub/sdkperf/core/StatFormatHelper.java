/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import org.apache.commons.lang.mutable.MutableLong;

import com.solacesystems.pubsub.sdkperf.core.GenericMessageDeliveryMode;
import com.solacesystems.pubsub.sdkperf.core.GenericStatType;
import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.PerfStats.PerfStatType;
import com.solacesystems.pubsub.sdkperf.core.PerfStats.SingleStreamOrderCheckingData;
import com.solacesystems.pubsub.sdkperf.core.PerfStats.TransactionData;

/**
 *
 * Methods to help output display info to the user.
 */
public class StatFormatHelper {

	public static String getFmtInstantStats(
		AbstractClientCollection client,
		long pubrate_i,
		long subrate_i,
		double usage) throws PubSubException 
	{
		NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(2);        
		return String.format(
			"PUB MR(5s)=%5d, SUB MR(5s)=%5d, CPU=%s", 
			pubrate_i,
			subrate_i,
			nf.format(usage));
	}
	
	public static String getFmtEndStats(
			AbstractClientCollection client, 
			RuntimeProperties prop,
			double usage) throws PubSubException {
		
		int client_cnt = prop.getIntegerProperty(RuntimeProperties.NUM_CLIENTS).intValue();
		
		Boolean wantVerbose = prop.getBooleanProperty(RuntimeProperties.WANT_VERBOSE);

		/* ***** RATE STATS ***** */
		StringBuffer buf = new StringBuffer();
		buf.append("\n");
		buf.append("-------------------------------------------------\n");
		buf.append(
				String.format("Aggregate Stats (Total # clients: %s):%n", 
				client_cnt));
		
		buf.append("-------------------------------------------------\n");
		buf.append("Total Messages transmitted = " + client.getSdkStat(GenericStatType.TOTAL_MSGS_SENT, SdkperfClientCollection.ALL_CLIENT_INDEX) + "\n");
		buf.append("Computed publish rate (msg/sec) = " + client.getTxThroughput() + "\n");
	
		PerfStats stats = client.getRxStats(SdkperfClientCollection.ALL_CLIENT_INDEX);
		buf.append("-------------------------------------------------\n");
		buf.append("Total Messages received across all subscribers = " + 
				stats.getStat(PerfStatType.NUM_MSGS_RECV) + "\n");
		buf.append("Messages received with discard indication = " + 
				stats.getStat(PerfStatType.NUM_MSGS_DI_SET) + "\n");
		buf.append("Computed subscriber rate (msg/sec across all subscribers) = " + 
				(long)stats.getThruPut(PerfStatType.NUM_TPUT_MSGS) + "\n");
		
		buf.append("\nCPU usage = " + (long)usage + "%\n");

	    if (prop.getStringProperty(RuntimeProperties.AD_ACK_EVENT_MODE) != null ||
	    	stats.getStat(PerfStatType.NUM_ACK_EVENTS) > 0 ||
	    	stats.getStat(PerfStatType.NUM_NACK_EVENTS) > 0 ) {
	    	buf.append("\n");
	    	buf.append("AD Pub ACK stats:\n");
	    	buf.append("  Total ACK Events     = " + stats.getStat(PerfStatType.NUM_ACK_EVENTS) + "\n");
	    	buf.append("  Total NACK Events    = " + stats.getStat(PerfStatType.NUM_NACK_EVENTS) + "\n");

	    	// We only count ACKED messages when order checking is enabled on publish streams.
			if (prop.getBooleanProperty(RuntimeProperties.WANT_ORDER_CHECK)
					|| prop.getBooleanProperty(RuntimeProperties.WANT_LOSS_AND_DUPLICATE_DETECTION)) {
	    		buf.append("  Total ACKED Messages = " + stats.getStat(PerfStatType.NUM_PUB_MSGS_ACKED) + "\n");
	    	}
	    }
	    
	    
		if (prop.getBooleanProperty(RuntimeProperties.WANT_LOSS_AND_DUPLICATE_DETECTION)) {
			
			buf.append("-------------------------------------------------\n");
			buf.append("Message loss and duplicate detection: \n");

			// Message Loss and Duplicate Detection Map
			Map<Integer, ArrayList<Long>> lddMap = stats.getMessageLossAndDuplicateDetectionMap();
			
			for(ArrayList<Long> list : lddMap.values()) {
				Collections.sort(list);
			}
			
			// Find duplicates
			for(Entry<Integer, ArrayList<Long>> map : lddMap.entrySet()) {
				
				List<Long> duplicates = new ArrayList<Long>();
				List<Long> losses = new ArrayList<Long>();
				
				long lastValue = Long.MIN_VALUE;
				
				// Find duplicates
				for(Long msgId : map.getValue()) {
					
					if(lastValue == msgId) {
						// Found duplicate
						duplicates.add(msgId);
					}
					
					if(lastValue != Long.MIN_VALUE && lastValue + 1 != msgId) {
						for(long i=lastValue+1; i<msgId; i++) {
							losses.add(i);
						}
					}
					
					lastValue = msgId;
				}
				
				String streamId;
				
				if(map.getKey().equals(PerfStats.C_DEFAULT_STREAM_ID))
					streamId = "DEFAULT";
				else if(map.getKey().equals(PerfStats.C_TOPIC_SEQUENCE_STREAM_ID))
					streamId = "TOPIC SEQUENCE";
				else
					streamId = map.getKey().toString();
				
				buf.append("Stream ID: " + streamId + "\n");
				buf.append("  Duplicates: ");
				if(duplicates.size() > 0) {
					for(int i=0; i<duplicates.size(); i++) {
						if(i == duplicates.size() - 1) {
							buf.append(duplicates.get(i) + "\n");
						} else {
							buf.append(duplicates.get(i) + ", ");
						}
					}
					
					buf.append("  Total Duplicates: " + duplicates.size() + "\n");
				} else {
					buf.append("none\n");
				}
				
				buf.append("  Losses: ");
				if(losses.size() > 0) {
					for(int i=0; i<losses.size(); i++) {
						if(i == losses.size() - 1) {
							buf.append(losses.get(i) + "\n");
						} else {
							buf.append(losses.get(i) + ", ");
						}
					}
					
					buf.append("  Total Losses: " + losses.size() + "\n");
				} else {
					buf.append("none" + "\n");
				}

				buf.append("-------------------------------------------------\n");
				
			}
			
		}

		if (prop.getBooleanProperty(RuntimeProperties.WANT_ORDER_CHECK)) {
			
			int totOooMsgs = 0;
			int totLostMsgs = 0;
			int totDupMsgs = 0;
			int totRedDupMsgs = 0;
			int totRpubDupMsgs = 0;
			
			for (Map.Entry<Integer, SingleStreamOrderCheckingData> oooEntry : stats.getOrderData().entrySet()) {
				totOooMsgs += oooEntry.getValue().oooMsgIds.size();
				totLostMsgs += oooEntry.getValue().lostMsgIds.size();
				totDupMsgs += oooEntry.getValue().dupMsgIds.size();
				totRedDupMsgs += oooEntry.getValue().redeliveredDupMsgIds.size();
				totRpubDupMsgs += oooEntry.getValue().republishedDupMsgIds.size();
		    }
			
			buf.append("\n");
			buf.append("Message Order Check Summary: \n");
			buf.append("Total Msgs Order Checked        : " + stats.getStat(PerfStatType.NUM_MSGS_ORDER_CHECKED) + "\n");
			buf.append("Total Out of Order Msgs         : " + totOooMsgs  + "\n");
			buf.append("Total Missing Msgs              : " + totLostMsgs + "\n");
			buf.append("Total Duplicate Msgs            : " + totDupMsgs + "\n");
			buf.append("Total Redelivered Msgs          : " + stats.getStat(PerfStatType.NUM_MSGS_REDELIVERED) + "\n");
			buf.append("Total Redelivered Duplicate Msgs: " + totRedDupMsgs + "\n");
			buf.append("Total Republished Duplicate Msgs: " + totRpubDupMsgs + "\n");
			buf.append("\n");
			
			if (stats.getTransactionOrderData().size() > 0) {
				HashMap<Integer, TransactionData> tranStats = stats.getTransactionOrderData();
				
				int totTransactionsProcessed = 0;
				int totTransactionErrors = 0;
				int totTranMessagesReceived = 0;
				
				for (TransactionData td : tranStats.values()) {
					totTransactionsProcessed += td.getNumFullTranReceived();
					totTransactionErrors += td.getNumTranErrorsRaised();
					totTranMessagesReceived += td.getTotalNumberOfMessagesProcessed();
			    }
				buf.append("Transaction Order Check Summary: \n");
				buf.append("Total Full Transactions Processed: " + totTransactionsProcessed + "\n");
				buf.append("Total Transacted Messages Processed: " + totTranMessagesReceived + "\n");
				buf.append("Total Transaction Errors raised: " + totTransactionErrors + "\n");
				buf.append("\n");
			}
						

			if (totOooMsgs > 0 || totLostMsgs > 0 || totDupMsgs > 0 || totRedDupMsgs > 0 || totRpubDupMsgs > 0) {
				for (int i = 0; i < client_cnt; i++) {
					PerfStats individualSubStats = client.getRxStats(i);
					buf.append("Message Order Details Client: " + individualSubStats.getName() + "\n");
					
					// Always output the topic sequence first followed by default stream ID.
					if (individualSubStats.getOrderData().containsKey(PerfStats.C_TOPIC_SEQUENCE_STREAM_ID)) {
						buf.append("  Stream: TOPIC_SEQUENCE \n");
				    	buf.append(individualSubStats.getOrderData().get(PerfStats.C_TOPIC_SEQUENCE_STREAM_ID).toString());
					}
					
					if (individualSubStats.getOrderData().containsKey(PerfStats.C_DEFAULT_STREAM_ID)) {
						buf.append("  Stream: DEFAULT \n");
				    	buf.append(individualSubStats.getOrderData().get(PerfStats.C_DEFAULT_STREAM_ID).toString());
					}
					
					for (Map.Entry<Integer, SingleStreamOrderCheckingData> oooEntry : individualSubStats.getOrderData().entrySet()) {
						// We've printed the special streams above.
						if (oooEntry.getKey().equals(PerfStats.C_DEFAULT_STREAM_ID) || 
							oooEntry.getKey().equals(PerfStats.C_TOPIC_SEQUENCE_STREAM_ID)) { 
							continue;
						}
						
						buf.append("  Stream: " + oooEntry.getKey() + "\n");
						buf.append(oooEntry.getValue().toString());
				    }
				}
			}
			
			// displaying the lastAckedMessages when we used guaranteed messages
			GenericMessageDeliveryMode msgtype = (GenericMessageDeliveryMode) prop.getProperty(RuntimeProperties.PUB_MESSAGE_TYPE);
			if (msgtype == GenericMessageDeliveryMode.PERSISTENT) {
			    buf.append("\n");
			    for (int i = 0; i < client_cnt; i++) {
                    Vector<Long> vl = client.getLastAckedMsgId(i);
                    buf.append("Last Acked Message Id: " + vl.get(0).toString());
                    buf.append("\n");
			    }
			    buf.append("\n");
			}
			
		}
		
			
		if (prop.getBooleanProperty(RuntimeProperties.WANT_ORDER_MEMORY)) {
			buf.append(StatFormatHelper.getOrderMemoryString(stats));
		}
		
		if (prop.getBooleanProperty(RuntimeProperties.WANT_PAYLOAD_CHECK) ||
			prop.getBooleanProperty(RuntimeProperties.WANT_STRUCT_MSG_CHECK)) {
			
			buf.append("\n");
			buf.append("Message Integrity Checking: \n");
			buf.append("Total Messages with OK          = " + 
					   stats.getStat(PerfStatType.NUM_MSGS_CRC_OK)  + "\n");
			buf.append("Total Messages with ERRORS      = " + 
					   stats.getStat(PerfStatType.NUM_MSGS_CRC_FAIL) + "\n");
			buf.append("Msgs with xml payload OK        = " + 
					   stats.getStat(PerfStatType.NUM_MSGS_CRC_XML_PAY_OK) + "\n");
			buf.append("Msgs with xml payload ERRORS    = " + 
					   stats.getStat(PerfStatType.NUM_MSGS_CRC_XML_PAY_FAIL) + "\n");
			buf.append("Msgs with attachment OK         = " + 
					   stats.getStat(PerfStatType.NUM_MSGS_CRC_BIN_ATT_OK) + "\n");
			buf.append("Msgs with attachment ERRORS     = " + 
					   stats.getStat(PerfStatType.NUM_MSGS_CRC_BIN_ATT_FAIL) + "\n");
			buf.append("Msgs with userdata OK           = " + 
					   stats.getStat(PerfStatType.NUM_MSGS_USERDATA_OK) + "\n");
			buf.append("Msgs with userdata ERRORS       = " + 
					   stats.getStat(PerfStatType.NUM_MSGS_USERDATA_FAIL) + "\n");
			buf.append("Msgs with stuctured data OK     = " + 
					   stats.getStat(PerfStatType.NUM_MSGS_CRC_SDM_OK) + "\n");
			buf.append("Msgs with stuctured data ERRORS = " + 
					   stats.getStat(PerfStatType.NUM_MSGS_CRC_SDM_FAIL) + "\n");
		}
		
		if (prop.getBooleanProperty(RuntimeProperties.WANT_LATENCY)) {
			
			buf.append("\n");
			buf.append("Latency Info: \n");
			buf.append("Individual latency bucket size = " + stats.getLatencyBucketSize() + " us\n");
			buf.append("Latency warmup                 = " + prop.getDoubleProperty(RuntimeProperties.LATENCY_WARMUP_IN_SECS) + "s\n");
			buf.append("Latency Messages received      = " + 
					   stats.getStat(PerfStatType.NUM_LATENCY_MSGS) + "\n");
			buf.append("Latency msg rate (msg/sec)     = " + 
					(long)stats.getThruPut(PerfStatType.NUM_LATENCY_MSGS) + "\n");
			buf.append("\n");
			buf.append("Latency Stats: \n");
			if (prop.getBooleanProperty(RuntimeProperties.WANT_FULL_LATENCY_STATS)) {
				buf.append("Minimum latency for subs       = " + stats.getStat(PerfStatType.LATENCY_USEC_MIN) + " us\n");
			}
			buf.append("Average latency for subs       = " + stats.getStat(PerfStatType.LATENCY_USEC_AVG) + " us\n");
			buf.append("50th percentile latency        = " + stats.getPercentileLatencyInUSec(50) + " us\n");
			buf.append("95th percentile latency        = " + 
					((stats.getPercentileLatencyInUSec(95) == 0) ? 
							"N/A" : stats.getPercentileLatencyInUSec(95)) + " us\n");
			buf.append("99th percentile latency        = " + 
					((stats.getPercentileLatencyInUSec(99) == 0) ? 
					"N/A" : stats.getPercentileLatencyInUSec(99)) + " us\n");
			buf.append("99.9th percentile latency      = " + 
					((stats.getPercentileLatencyInUSec(99.9) == 0) ? 
					"N/A" : stats.getPercentileLatencyInUSec(99.9)) + " us\n");
			if (prop.getBooleanProperty(RuntimeProperties.WANT_FULL_LATENCY_STATS)) {
				buf.append("Maximum latency for subs       = " + stats.getStat(PerfStatType.LATENCY_USEC_MAX) + " us\n");
			}
			buf.append("Standard Deviation             = " + stats.getLatencyStdDevInUSec() + " us\n");
		}
			
		if (prop.getBooleanProperty(RuntimeProperties.CID_STATS) == true) { 
			buf.append("\n");
			buf.append("Msgs Received Per Consumer ID:\n");
			
			HashMap<Integer, MutableLong> cidBuckets = stats.getCidBuckets();
			Set<Integer> ks = cidBuckets.keySet();
			List<Integer> listToSort = new ArrayList<Integer>(ks.size());
			for (Integer i : ks) {
				listToSort.add(i);
			}
			Collections.sort(listToSort);
			for (Integer cid : listToSort) {
				buf.append(String.format("CID: %10s - Msg: %10s%n", cid, cidBuckets.get(cid)));
			}
			buf.append("\n");
			
		}
		
		if (prop.getBooleanProperty(RuntimeProperties.WANT_MESSAGE_EXAMINE_CONTENT)) {
			buf.append("\n");
			buf.append("Message Content Inspection Stats:\n");
			buf.append("Received Total         = " + stats.getStat(PerfStatType.NUM_MSGS_RECV) + "\n");
			buf.append("With XML payload       = " + stats.getStat(PerfStatType.NUM_MSGS_XML_PAY)  + "\n");
			buf.append("With Binary Attachment = " + stats.getStat(PerfStatType.NUM_MSGS_BIN_ATTACH) + "\n");
			buf.append("With user data         = " + stats.getStat(PerfStatType.NUM_MSGS_USERDATA) + "\n");
			buf.append("With consumer IDs      = " + stats.getStat(PerfStatType.NUM_MSGS_CID) + "\n");
			buf.append("With Topics            = " + stats.getStat(PerfStatType.NUM_MSGS_TOPIC) + "\n");
			buf.append("\n");
		}
		
		if (prop.getBooleanProperty(RuntimeProperties.CACHE_WANT_STATS)) {
			buf.append("Cache Stats:\n");
			buf.append("Num Requests Sent           = " + 
					   stats.getStat(PerfStatType.NUM_CACHE_REQ_SENT) + "\n");
			buf.append("Num Responses Recv          = " + 
					   stats.getStat(PerfStatType.NUM_CACHE_RESP_RECV) + "\n");
			buf.append("Num Requests Completed OK   = " + 
					   stats.getStat(PerfStatType.NUM_CACHE_REQ_OK) + "\n");
			buf.append("Num Requests Incomp No Data = " + 
					   stats.getStat(PerfStatType.NUM_CACHE_REQ_INCOMP_NODATA) + "\n");
			buf.append("Num Requests Incomp Suspect = " + 
					   stats.getStat(PerfStatType.NUM_CACHE_REQ_INCOMP_SUSPECT) + "\n");
			buf.append("Num Requests Incomp Timeout = " + 
					   stats.getStat(PerfStatType.NUM_CACHE_REQ_INCOMP_TIMEOUT) + "\n");
			buf.append("Num Requests Errored        = " + 
					   stats.getStat(PerfStatType.NUM_CACHE_REQ_ERROR) + "\n");
			buf.append("Num Live Data Msgs Recv     = " + 
					   stats.getStat(PerfStatType.NUM_LIVE_MSGS_RECV) + "\n");
			buf.append("Num Cached Data Msgs Recv   = " + 
					   stats.getStat(PerfStatType.NUM_CACHE_MSGS_RECV) + "\n");
			buf.append("Num Msgs Recv Suspect       = " + 
					   stats.getStat(PerfStatType.NUM_CACHE_SUSPECT_RECV) + "\n");
			buf.append("Num Resp Discarded          = " + 
					   (client.getSdkStat(GenericStatType.CACHE_FULFILL_REPLIES_DISCARDED, SdkperfClientCollection.ALL_CLIENT_INDEX) + 
					    client.getSdkStat(GenericStatType.REPLIES_DISCARDED, SdkperfClientCollection.ALL_CLIENT_INDEX) + "\n"));
		}
		
		/* ***** DETAILED SDK STATS ***** */
		if (wantVerbose != null 
			&& wantVerbose.booleanValue()) {
			
			buf.append((client != null) ? client.toString() : "");
			
			PerfStats clientStats = client.getRxStats(SdkperfClientCollection.ALL_CLIENT_INDEX);
			buf.append(clientStats.toString());
		}

		return buf.toString();
	}
	
	public static String getOrderMemoryString(PerfStats stats) {
		StringBuffer buf = new StringBuffer();
		buf.append("Message Order Memory:\n");
		for (MutableLong msgId : stats.getOrderMemory()) {
			buf.append(String.format(" 0x%016x,", msgId.longValue()));
		}
		buf.append("\n");
		return buf.toString();
	}
}
