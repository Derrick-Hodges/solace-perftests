package com.solacesystems.pubsub.sdkperf.core;

/**
 * Abstract equivalent of the CacheLiveDataAction available in JCSMP.
 */
public enum AbstractCacheLiveDataAction {

/**
 * The live data action dictates the disposition of live data received while the
 * cache request is outstanding to the solCache. One of the live data actions
 * must be chosen.
 * 
 */

	/**
	 * Consider the cache request finished when live data arrives that matches
	 * the topic. Note that wildcard cache requests must always be
	 * <code>FLOW_THRU</code>.
	 */
	FULFILL,

	/**
	 * Queue live data that arrives that matches the topic until the cache
	 * request completes. Note that wildcard cache requests must always be
	 * <code>FLOW_THRU</code>.
	 */
	QUEUE,

	/**
	 * Pass through to the application live data that arrives that matches the
	 * topic while a cache request is outstanding. Note that wildcard cache
	 * requests must always be <code>FLOW_THRU</code>.
	 */
	FLOW_THRU
}
