package com.solacesystems.pubsub.sdkperf.core;

public enum GenericMessageDeliveryMode {
	PERSISTENT, NON_PERSISTENT, DIRECT
}
