/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import javax.transaction.xa.XAResource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.common.util.CPUUsage;
import com.solacesystems.pubsub.sdkperf.config.EpConfigProperties;
import com.solacesystems.pubsub.sdkperf.config.RuntimeProperties;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericClientVersion;
import com.solacesystems.pubsub.sdkperf.core.Constants.GenericRestMode;
import com.solacesystems.pubsub.sdkperf.core.Constants.InternalApiMode;
import com.solacesystems.pubsub.sdkperf.core.Constants.ToolMode;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.PublisherDestinationsType;
import com.solacesystems.pubsub.sdkperf.util.DestinationUtils;
import com.solacesystems.pubsub.sdkperf.util.DestinationUtils.DestinationBean;
import com.solacesystems.pubsub.sdkperf.util.Helpers;
import com.solacesystems.pubsub.sdkperf.util.SdkperfConstants;
import com.solacesystems.pubsub.sdkperf.util.DataTypes.SubscriberDestinationsType;

/**
 * This class represents a collection of clients and presents
 * an interface so that actions can be performed on one or more
 * of these clients.  For example starting publishing.
 * 
 * This collection keeps the following internal lists:
 *      - CscsmpClient - For connection management, publishing,
 *                       subscribing, etc.
 *      - PubThread - 1 per client publishing threads.
 *      - CacheThread - 1 per client cache requesting thread.
 */
public abstract class AbstractClientCollection {
	private static final Log Trace = LogFactory.getLog(AbstractClientCollection.class);

	public static final int ALL_CLIENT_INDEX = -1;
	
	protected List<AbstractClient> _clients = new ArrayList<AbstractClient>();
	protected List<Object> _contexts;
	
	protected int _numClients;
	protected int _numContexts = 1;
	protected RuntimeProperties _rprops;
	protected CPUUsage _cpuMon;
	protected int clientId = 0;
	
	protected boolean _createClients=true;
	
	// Used by REST "subscribers" only. Every time a rest client
    // is initialized, it first checks in this list to see if it should
	// open a rest server. Once the rest server is opened, the port
	// is removed from the list. After all servers have been opened, the
	// publisher (regular clients) will be created (if necessary) because
	// the list of server ports will be empty.
	private List<Integer> restServerPorts = new LinkedList<Integer>();

	
	// Abstract methods
	

	//Create RestServer if needed.
	@SuppressWarnings("unchecked")
	public void initRestServers() throws Exception{
		Set<Integer> numServerThreads = (Set<Integer>) _rprops.getProperty(RuntimeProperties.SERVER_PORT_LIST);
		
		String clientIp = _rprops.getStringProperty(RuntimeProperties.CLIENT_IP_ADDR); 
		if (clientIp == null || clientIp.equals("")) {
			_createClients = false;
		}
		
		if(numServerThreads != null)
			for(int i=0; i < numServerThreads.size(); i++) {
				clientId++;
				AbstractClient client = ClientFactory.createClient(_rprops, clientId, this);
				_clients.add(client);
			}
	}
	
	//check for client Version
	
	public void checkClientVersion(){
		GenericClientVersion clientVersion=(GenericClientVersion) _rprops.getProperty(RuntimeProperties.CLIENT_VERSION);
		
		if(clientVersion!=null){
			return;
		}
		
		InternalApiMode api=(InternalApiMode) _rprops.getProperty(RuntimeProperties.API_MODE);
		ToolMode tm=(ToolMode) _rprops.getProperty(RuntimeProperties.TOOL_MODE);
		
		if(api.equals(InternalApiMode.REST)){
			if(tm.equals(ToolMode.RTRPERF)){
				_rprops.setProperty(RuntimeProperties.CLIENT_VERSION,GenericClientVersion.SOCKET);
			}else{
				_rprops.setProperty(RuntimeProperties.CLIENT_VERSION,GenericClientVersion.HTTPCLIENT);
			}
		}
	}
	
	// Perform some required cleanup.
	public void destroy() {
		
		Trace.debug("Destroying all clients...");

		try {
			this.stopPublishing();
			this.stopCacheRequesting();
			this.closeAllTransactedSessions(ALL_CLIENT_INDEX);
			if (_rprops.getBooleanProperty(RuntimeProperties.AD_WANT_XA_TRANSACTION)) {
				this.closeAllXaSessions(ALL_CLIENT_INDEX);
			}
			
			if(this.isConnected()) {
				this.disconnect();
			}
			// Destroy all clients
			for (AbstractClient client : _clients) {
				client.destroy();
			}
			
			// Destroy all contexts
			for (Object context: _contexts) {
				_clients.get(0).destroyApiSpecificContext(context);
			}
			
			_contexts.clear();
			_clients.clear();
			
		} catch (Exception e) {
			Trace.error("Exception in destroy:", e);
		}
	}
	
	///////////////////////////////////////////////////////////////////////
	// Publishing Access
	public abstract void startPublishing(RuntimeProperties pubprops) throws Exception;
	public abstract void stopPublishing() throws PubSubException;
	public abstract boolean isPublishing();
	
	protected abstract long getLastPubTimeInNanos();
	protected abstract void setLastPubTimeInNanos(long timeInNanos, int clientidx);
			
	///////////////////////////////////////////////////////////////////////
	// Cache Requesting Access
	public abstract void startCacheRequesting(List<String> topics, RuntimeProperties reqProps) throws Exception;
	public abstract void stopCacheRequesting() throws PubSubException;
	public abstract boolean isCacheRequesting();
	
	///////////////////////////////////////////////////////////////////////
	// Queue Browsing Access
	public abstract void startQueueBrowsing(List<String> queues, String selector, RuntimeProperties props) throws Exception;
	public abstract void stopQueueBrowsing() throws PubSubException;
	public abstract boolean isQueueBrowsing();
	
	public abstract double getTxThroughput();
	public abstract PerfStats getTxStats(final int clientidx);
	


	public AbstractClientCollection(RuntimeProperties prop, CPUUsage cpuMon) throws Exception {
		_cpuMon = cpuMon;
		initAbstractClientCollection(prop, null); // Create new list of client objects
	}
	
	public AbstractClientCollection(RuntimeProperties prop, List<AbstractClient> clientList) throws Exception {	
		initAbstractClientCollection(prop, clientList); // Use specified list of client objects
	}

	protected void initAbstractClientCollection(RuntimeProperties prop, List<AbstractClient> clientList) throws Exception {
		_rprops = (RuntimeProperties)prop.clone();
		_numClients = _rprops.getIntegerProperty(RuntimeProperties.NUM_CLIENTS).intValue();
		
		//TODO: -cpc and -numContext (to be done) should not be on at the same time
		// if -cpc is specified, then we want the same number of contexts as clients
		if(_rprops.getBooleanProperty(RuntimeProperties.WANT_CONTEXT_PER_CIENT)) {
			_rprops.setIntegerProperty(RuntimeProperties.NUM_CONTEXT_THREADS, _rprops.getIntegerProperty(RuntimeProperties.NUM_CLIENTS));
		}
		
		// Parse the Number of Context Thread wanted
		try {
			_numContexts = _rprops.getIntegerProperty(RuntimeProperties.NUM_CONTEXT_THREADS);
			
			if(_numContexts > _numClients) {
				// Cannot have more contexts than clients
				_numContexts = _numClients;
			}
			
			if(_numContexts < 1)
				_numContexts = 1;
		} catch (Exception e) { _numContexts = 1; }
		

		if ((_rprops.getProperty(RuntimeProperties.STRUCT_DATA_MSGS_LIST) != null)
				&& (_rprops.getBooleanProperty(RuntimeProperties.WANT_ORDER_CHECK) ||
					_rprops.getBooleanProperty(RuntimeProperties.WANT_LATENCY) ||
					_rprops.getBooleanProperty(RuntimeProperties.WANT_PAYLOAD_CHECK) ||
					_rprops.getBooleanProperty(RuntimeProperties.WANT_LOSS_AND_DUPLICATE_DETECTION))) {
			throw new PubSubException("Cannot use order check, loss/duplicate detection, latency or payload check with structured messages");
		}
		
		// Check if we need to launch a Rest Server
		@SuppressWarnings("unchecked")
		Set<Integer> serverPortList = (Set<Integer>) _rprops.getProperty(RuntimeProperties.SERVER_PORT_LIST);

		if (serverPortList != null) {
				restServerPorts.clear();
				restServerPorts.addAll(serverPortList);
		}
		
		
		
		_clients.clear();
		
		checkClientVersion();
		
		if (prop.getProperty(RuntimeProperties.API_MODE).equals(InternalApiMode.REST)){
			this.initRestServers();
			if(prop.getProperty(RuntimeProperties.TOOL_MODE).equals(ToolMode.RTRPERF)){
				
				if(!_clients.isEmpty() && _numClients!=0){
					throw new IllegalStateException("Cannot create a RestPublisher & RestSubscriber at the same time with RtrPerf, Please Use Sdkperf");
				}
				
				if(_numClients!=0){	

						if(prop.getProperty(RuntimeProperties.RESTCLIENT_MODE)==null ){
							prop.setProperty(RuntimeProperties.RESTCLIENT_MODE,GenericRestMode.SOCKET);
						}
						
						if(prop.getProperty(RuntimeProperties.RESTCLIENT_MODE).equals(GenericRestMode.SOCKET)){
							_numClients=prop.getIntegerProperty(RuntimeProperties.NUM_PUB_THREADS);	;	
						}
				}
					
				
			}else{
				if(prop.getProperty(RuntimeProperties.RESTCLIENT_MODE)==null){
					prop.setProperty(RuntimeProperties.RESTCLIENT_MODE,GenericRestMode.HTTPCLIENT);
				}
				
				if(prop.getProperty(RuntimeProperties.RESTCLIENT_MODE).equals(GenericRestMode.SOCKET)){
					_numClients=prop.getIntegerProperty(RuntimeProperties.NUM_PUB_THREADS);	
				}
			}
		}
		
		if (!prop.getProperty(RuntimeProperties.API_MODE).equals(InternalApiMode.JAVASCRIPT) &&
				!prop.getProperty(RuntimeProperties.API_MODE).equals(InternalApiMode.ACTIONSCRIPT) &&
				!prop.getProperty(RuntimeProperties.API_MODE).equals(InternalApiMode.SILVERLIGHT)) {
			_contexts = new ArrayList<Object>(_numContexts);
	
			for(int i=0; i < _numContexts; i++) {
				_contexts.add(new Object());
			}
	
			if (clientList == null) {
				for (int i = 0; i < _numClients; i++) {
					clientId ++;
					AbstractClient client = ClientFactory.createClient(_rprops, clientId, this);
					_clients.add(client);
				}
			} else {
				_clients.addAll(clientList);
			}
			
			// Convert the context objects to API specific contexts
			List<Object> apiSpecificContext = new ArrayList<Object>(_numContexts);
			
			Iterator<Object> contextIt = _contexts.iterator();
			while (contextIt.hasNext()) {
				Object newContext = _clients.get(0).cloneToApiSpecificContext( contextIt.next() );
				apiSpecificContext.add(newContext);
			}
			
			_contexts.clear();
			_contexts.addAll(apiSpecificContext);
			
			// Assigns contexts to all clients
			for (int i = 0; i < _numClients; i++) {
				Object assignedContext = _contexts.get(i % _numContexts);
				_clients.get(i).setContext(assignedContext);
			}
		}

	}
		
	public Vector<Long> getLastAckedMsgId(int clientidx) 
    {
        Vector<Long> ret = new Vector<Long>();
        ret.clear();
        
        if (clientidx == ALL_CLIENT_INDEX) {
            for (AbstractClient client : _clients) {
                ret.add(client.getLastAckedMsgId());
            }
        } else {
            ret.add(_clients.get(clientidx).getLastAckedMsgId());
        }
        return ret;
    }
	
	public Vector<String> getClientName(int clientidx) throws Exception 
	{
		Vector<String> ret = new Vector<String>();
		ret.clear();
		
		if (clientidx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				ret.add(client.getClientName());
			}
		} else {
			ret.add(_clients.get(clientidx).getClientName());
		}
		return ret;
	}
	
	public Vector<String> getClientReplyToDestination(int clientidx) throws Exception 
	{
		Vector<String> ret = new Vector<String>();
		
		if (clientidx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				ret.add(client.getReplyToDestination());
			}
		} else {
			ret.add(_clients.get(clientidx).getReplyToDestination());
		}
		return ret;
	}

	public LastMessageDetails getLastMessageDetails(int clientidx) {
		if (clientidx == ALL_CLIENT_INDEX) {
			throw new IllegalArgumentException("Cannot get Last Message Details for all clients, must specify specific client.");
		} else {
			return _clients.get(clientidx).getLastMessageDetails();
		}
	}
	
	public void setClientName(String name, int clientidx) throws Exception 
	{
		if (clientidx < 0 || clientidx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientidx);
		} 
		
		_clients.get(clientidx).setClientName(name);
	}

	public List<Integer> getRestServerPorts() {
		return restServerPorts;
	}

	public ChannelState getChannelState() {
		
	    ChannelState retState = ChannelState.CLIENT_STATE_CONNECTED;
	    
	    Iterator<AbstractClient> iter = _clients.iterator();

	    while (iter.hasNext()) {
	    	
	    	AbstractClient client = iter.next();
	    	
	    	ChannelState clientState = client.getChannelState();

	        // If in aggregate we currently believe the channel is down and it's
	        // connecting or reconnecting then update but continue searching
	        if ((clientState == ChannelState.CLIENT_STATE_CONNECTING ||
	             clientState == ChannelState.CLIENT_STATE_RECONNECTING) &&
	            retState != ChannelState.CLIENT_STATE_DISCONNECTED) {
	            retState = clientState;
	            continue;
	        } 

	        // If client is down then in aggregate we're down stop searchin.
	        if (clientState == ChannelState.CLIENT_STATE_DISCONNECTED) {
	            retState = clientState;
	            break;
	        }
	    }
	    
	    return retState;
	}
	
	
	///////////////////////////////////////////////////////////////////////////
	// Channel Manipulation
	public boolean isConnected() 
	{
		for (AbstractClient client : _clients)
		{
			if (!client.isConnected())
			    return false;
		}
		return true;
	}

	public void connect() throws PubSubException {
		if (isConnected()) {
			Trace.info("Called connect, clients already connected. Returning.");
			return;
		}

		Trace.info("Connecting all clients.");
		
		for (AbstractClient client : _clients) {
			// Startup the subscriber thread
			try {
				client.connect();
			} catch (Exception e) {
				throw new PubSubException("Error while connecting.", e);
			}
		}

		// Wait for all subs to be up
		int guard = 1200;
		if(Trace.isDebugEnabled())
			Trace.debug("Waiting for all clients to connect.");
		while (!isConnected() && guard-- > 0) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}
		
		if (!isConnected()) {
			Trace.error("Unable to start all clients.");
			throw new PubSubException("Unable to start all clients");
		}
		
		try {
			Hashtable<GenericCapabilityType, String> rtrCaps = _clients.get(0).getRtrCapabilities();
			StringBuffer buf = new StringBuffer();
			
			buf.append("( ");
			
			if(rtrCaps.get(GenericCapabilityType.PUB_GUARANTEED) != null)
				buf.append("PFG="+rtrCaps.get(GenericCapabilityType.PUB_GUARANTEED)+"; ");
		    
			if(rtrCaps.get(GenericCapabilityType.SUB_FLOW_GUARANTEED) != null)
				buf.append("SFG="+rtrCaps.get(GenericCapabilityType.SUB_FLOW_GUARANTEED)+"; ");

			if(rtrCaps.get(GenericCapabilityType.TEMP_ENDPOINT) != null)
				buf.append("TEMP="+rtrCaps.get(GenericCapabilityType.TEMP_ENDPOINT)+"; ");

			if(rtrCaps.get(GenericCapabilityType.JNDI) != null)
				buf.append("JNDI="+rtrCaps.get(GenericCapabilityType.JNDI)+"; ");

			if(rtrCaps.get(GenericCapabilityType.COMPRESSION) != null)
				buf.append("Z="+rtrCaps.get(GenericCapabilityType.COMPRESSION)+"; ");
			
			if(rtrCaps.get(GenericCapabilityType.TRANSACTED_SESSIONS) != null)
				buf.append("XA="+rtrCaps.get(GenericCapabilityType.TRANSACTED_SESSIONS)+"; ");

			if(rtrCaps.get(GenericCapabilityType.API_VERSION) != null)
				buf.append("API_V="+rtrCaps.get(GenericCapabilityType.API_VERSION)+"; ");

		    buf.append(")");
		    

			Trace.info("Router capabilities / Environment details: " + buf.toString());
			
		} catch (Exception ex) {
			Trace.info("Router capabilities: Unavailable due to: " + ex.getMessage());
		}
	    // For interest log the router capabilities
	}

	public void disconnect() throws PubSubException 
	{
		Trace.info("Disconnecting all clients...");
		boolean disconnected = false;
		
		try {
			for (AbstractClient client : _clients) 
			{
				client.disconnect();
			}
			// Wait some time to verify they're all down
			for (int check_count = 0; check_count < 1000; check_count++) 
			{
				disconnected = true;
				for (AbstractClient client : _clients) 
				{
					if (client.isConnected()) 
					{ 
						disconnected = false; 
						break;
					}
				}
				
				if (disconnected) { break; }
				
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
				}
			}
		} catch (Exception e) {
			Trace.error("Error disconnecting clients.", e);
			throw new PubSubException("Error while disconnecting", e);
		}

		if (!disconnected) {
			Trace.error("Unable to disconnect all clients.");
			throw new PubSubException("Unable to disconnect all clients.");
		}
	}
	
	
	public void start() throws PubSubException 
	{
		if (!isConnected()) {
			Trace.info("Called start, clients are not connected. Returning.");
			return;
		}

		for (AbstractClient client : _clients) {
			// Startup the subscriber thread
			try {
				client.start();
			} catch (Exception e) {
				Trace.error(e.getMessage(), e);
				throw new PubSubException("Unable to start clients.", e);
			}
		}
	}

	public void stop() throws PubSubException {
		Trace.debug("Stopping all client.");
		for (AbstractClient client : _clients) {
			try {
				client.stop();
			} catch (Exception e) {
				Trace.error(e.getMessage(), e);
				throw new PubSubException("Unable to stop client.", e);
			}
		}
	}

	public String openTransactedSession(int clientIdx, RuntimeProperties rprops) throws PubSubException 
	{
		if (!isConnected()) {
			Trace.info("Called openTransactedSession, clients are not connected. Returning.");
			return "";
		}
		
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		} 
		
		String sessionName = "";
		// Startup the subscriber thread
		try {
			sessionName = _clients.get(clientIdx).openTransactedSession(rprops);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to openTransactedSession.", e);
		}
		return sessionName;
	}

	public void closeTransactedSession(String sessionName, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		
		try {
			_clients.get(clientIdx).closeTransactedSession(sessionName);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to closeTransactedSession.", e);
		}
	}
	
	public void closeAllTransactedSessions(int clientIdx) throws Exception {
		if (clientIdx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				client.closeAllTransactedSessions();
			}
		} else {
			_clients.get(clientIdx).closeAllTransactedSessions();
		}
	}

	public void commitTransaction(String sessionName, boolean wantRollback, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		try {
			_clients.get(clientIdx).commitTransaction(sessionName, wantRollback);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to commitTransaction.", e);
		}
	}

	public String openXaSession(int clientIdx, RuntimeProperties rprops) throws PubSubException 
	{
		if (!isConnected()) {
			Trace.info("Called openXaSession, clients are not connected. Returning.");
			return "";
		}
		
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		String sessionName = "";
		// Startup the subscriber thread
		try {
			sessionName = _clients.get(clientIdx).openXaSession(rprops);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to openXaSession.", e);
		}
		return sessionName;
	}
	
	public void closeXaSession(String sessionName, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		try {
			_clients.get(clientIdx).closeXaSession(sessionName);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to closeXaSession.", e);
		}
	}
	
	public void closeAllXaSessions(int clientIdx) throws Exception {
		if (clientIdx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				client.closeAllXaSessions();
			}
		} else {
			_clients.get(clientIdx).closeAllXaSessions();
		}
	}
	
	public String createXid(String sessionName, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}

		String xid = "";
		try {
			xid = _clients.get(clientIdx).createXid(sessionName);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to createXid.", e);
		}
		return xid;
	}
	
	public void commitXaSession(String sessionName, String xid, boolean onePhase, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		try {
			_clients.get(clientIdx).commitXaSession(sessionName, xid, onePhase);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to commitXaSession.", e);
		}
	}
	
	public void endXaSession(String sessionName, String xid, int flags, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		try {
			_clients.get(clientIdx).endXaSession(sessionName, xid, flags);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to endXaSession.", e);
		}
	}
	
	public void forgetXaSession(String sessionName, String xid, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		try {
			_clients.get(clientIdx).forgetXaSession(sessionName, xid);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to forgetXaSession.", e);
		}
	}
	
	public void prepareXaSession(String sessionName, String xid, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		try {
			_clients.get(clientIdx).prepareXaSession(sessionName, xid);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to prepareXaSession.", e);
		}
	}
	
	public Vector<String> recoverXaSession(String sessionName, int flag, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		Vector<String> retList = new Vector<String>();
		try {
			retList = _clients.get(clientIdx).recoverXaSession(sessionName, flag);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to recoverXaSession.", e);
		}
		return retList;
	}
	
	public void rollbackXaSession(String sessionName, String xid, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		try {
			_clients.get(clientIdx).rollbackXaSession(sessionName, xid);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to rollbackXaSession.", e);
		}
	}
	
	public void startXaSession(String sessionName, String xid, int flags, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		try {
			_clients.get(clientIdx).startXaSession(sessionName, xid, flags);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to startXaSession.", e);
		}
	}
	
	public void setXaTransactionTimeout(String sessionName, int seconds, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		try {
			_clients.get(clientIdx).setXaTransactionTimeout(sessionName, seconds);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to setXaTransactionTimeout.", e);
		}
	}

	public int getXaTransactionTimeout(String sessionName, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		int seconds = -1;
		try {
			seconds = _clients.get(clientIdx).getXaTransactionTimeout(sessionName);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to getXaTransactionTimeout.", e);
		}
		return seconds;
	}
	
	public String createXid(String sessionName, int formatId, String globalTransactionId, String branchQualifier, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}

		String xid = "";
		try {
			xid = _clients.get(clientIdx).createXid(sessionName, formatId, globalTransactionId, branchQualifier);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to createXid.", e);
		}
		return xid;
	}
	
	public String getActiveXid(String sessionName, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		String activeXid;
		try {
			activeXid = _clients.get(clientIdx).getActiveXid(sessionName);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to getActiveXid.", e);
		}
		return activeXid;
	}

	public Vector<String> getXids(String sessionName, int clientIdx) throws PubSubException {
		if (clientIdx < 0 || clientIdx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientIdx);
		}
		
		Vector<String> xidList = new Vector<String>();
		try {
			xidList = _clients.get(clientIdx).getXids(sessionName);
		} catch (Exception e) {
			Trace.warn(e.getMessage(), e);
			throw new PubSubException("Unable to getXids.", e);
		}
		return xidList;
	}
	
	public String initXaTransactions(String sessionName, int clientIdx) throws Exception {
		String clientXid = this.getActiveXid(sessionName, clientIdx);
		String firstClientXid = clientXid;
		if (this.getActiveXid(sessionName, clientIdx) == null) {
			// Create XID
			clientXid = this.createXid(sessionName, clientIdx);
			firstClientXid = clientXid;
			
			// Start XA Session
			this.startXaSession(sessionName, clientXid, XAResource.TMNOFLAGS, clientIdx);
		}
		
		if ((_rprops.getIntegerProperty(RuntimeProperties.XA_NUM_SUSPENDED_TRANSACTIONS) > 0)) {
			// Suspend XA Session
			this.endXaSession(sessionName, clientXid, XAResource.TMSUSPEND, clientIdx);
			
			for (int j = 1; j < _rprops.getIntegerProperty(RuntimeProperties.XA_NUM_SUSPENDED_TRANSACTIONS); j++) {
				// Create XID
				clientXid = this.createXid(sessionName, clientIdx);
				
				// Start XA Session
				this.startXaSession(sessionName, clientXid, XAResource.TMNOFLAGS, clientIdx);
				
				// Suspend XA Session
				this.endXaSession(sessionName, clientXid, XAResource.TMSUSPEND, clientIdx);
			}
			
			// Resume XA Session
			this.startXaSession(sessionName, firstClientXid, XAResource.TMRESUME, clientIdx);
		}
		
		return firstClientXid;
	}
	
	//////////////////////////////////////////////////////////////////////
	// Subscriptions management

	public void subscriptionUpdate(EpConfigProperties epProps, int clientidx) throws Exception {
		if (clientidx == ALL_CLIENT_INDEX) {
			if (epProps.getDistributeTopics()) {
				List<String> topicList = epProps.getSubscriptions();
				List<List<String>> clientTopicLists = new ArrayList<List<String>>();;
				int topicIndex = 0;
				for (String topic : topicList) {
					if (topicIndex < _clients.size()) {
						List<String> topics = new ArrayList<String>();
						topics.add(topic);
						clientTopicLists.add(topics);
					} else {
						clientTopicLists.get(topicIndex % _clients.size()).add(topic);
					}
					topicIndex++;
				}
				int clientIndex = 0;
				for (AbstractClient client : _clients) {
					epProps.setSubscriptions(clientTopicLists.get(clientIndex % clientTopicLists.size()));
					client.subscriptionUpdate(epProps);
					clientIndex++;
				}
				epProps.setSubscriptions(topicList);
			} else {
				for (AbstractClient client : _clients) {
					client.subscriptionUpdate(epProps);
				}
			}
		} else {
			_clients.get(clientidx).subscriptionUpdate(epProps);
		}
	}

	public void topicUpdate(EpConfigProperties epProps, int clientidx) throws Exception {
		if (clientidx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				client.topicUpdate(epProps);
			}
		} else {
			_clients.get(clientidx).topicUpdate(epProps);
		}
	}

	public void queueUpdate(EpConfigProperties epProps, int clientidx) throws Exception {
		if (clientidx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				client.queueUpdate(epProps);
			}
		} else {
			_clients.get(clientidx).queueUpdate(epProps);
		}
	}
	
	public Vector<String> tempEndpointUpdate(EpConfigProperties epProps, int clientidx) throws Exception {
		Vector<String> retList = new Vector<String>();
		if (clientidx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				Vector<String> tempList = client.tempEndpointUpdate(epProps);
				retList.addAll(tempList);
			}
		} else {
			retList = _clients.get(clientidx).tempEndpointUpdate(epProps);
		}
		if (epProps.getType() != SubscriberDestinationsType.TOPIC &&
				epProps.getSubscriptions() != null && !(epProps.getSubscriptions()).isEmpty()) {
			for (String endpoint : retList) {
				this.mapTopics(endpoint, epProps.getSubscriptions(), true, clientidx);
			}
		}
		return retList;
	}
	
	public void unbindAllTempEndpoints(int clientidx) throws Exception {
		if (clientidx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				client.unbindAllTempEndpoints();
			}
		} else {
			_clients.get(clientidx).unbindAllTempEndpoints();
		}
	}
	
	public void mapTopics(String queue, List<String> topics, boolean isAdding, int subidx) throws Exception {
		if (subidx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				client.mapTopics(queue, topics, isAdding);
			}
		} else {
			_clients.get(subidx).mapTopics(queue, topics, isAdding);
		}
	}
	
	
	public void endpointProvisioning(EpConfigProperties epProps,	int clientidx) throws Exception {
		if (clientidx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				client.endpointProvisioning(epProps);
			}
		} else {
			_clients.get(clientidx).endpointProvisioning(epProps);
		}
	}

	
	public void clearSubscriptionMemory() throws Exception {
		for (AbstractClient client : _clients) {
			client.clearSubscriptionMemory();
		}
	}
	
	public FlowStatus getFlowStatus(String epName, int clientidx) throws Exception {
		
		FlowStatus flowStatus = null;
		
		if (clientidx == ALL_CLIENT_INDEX) {
			StringBuffer str = new StringBuffer();
			str.append("AbstractClientCollection: ");
			str.append("getFlowStatus only available on specific client index.  Not ALL_CLIENT_INDEX");
			throw new PubSubException(str.toString());
		} else {
			if (clientidx < 0 || clientidx >= _numClients) {
				StringBuffer str = new StringBuffer();
				str.append("AbstractClientCollection: Client Index out of range.  Range (0-");
				str.append(_numClients - 1);
				str.append("), Index used: ");
				str.append(clientidx);
				throw new PubSubException(str.toString());				
			}
			
			flowStatus = _clients.get(clientidx).getFlowStatus(epName);
		}
		
		return flowStatus;
	}
	
	///////////////////////////////////////////////////////////////////////
	// Other methods
	public void clearKeptMsgs() throws Exception {
		for (AbstractClient client : _clients) {
			client.clearKeptMsgs();
		}
	}

	
	public String requestReply(String topic, String request, int clientidx) throws Exception 
	{
		if (clientidx < 0 || clientidx >= _clients.size()) {
			throw new PubSubException(
					"PerfClientCollection: Client Index out of range." +
					"Range (0-" + (_clients.size() - 1) + "), Index used: " +
					clientidx);
		} 
		
		return _clients.get(clientidx).requestReply(topic, request);
	}
	
	/////////////////////////////////////////////////////////////////
	// Cache Requesting Methods
	public void cacheRequest(List<String> topics, boolean subscribe, AbstractCacheLiveDataAction liveDataAction,
			boolean waitForConfirm, long minSeq, long maxSeq, int clientIdx) throws Exception {
		
		if (clientIdx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				client.cacheRequest(topics, subscribe, minSeq, maxSeq, liveDataAction, waitForConfirm);
			}
		} else {
			_clients.get(clientIdx).cacheRequest(topics, subscribe, minSeq, maxSeq, liveDataAction, waitForConfirm);
		}
	}
	
	public void cancelCacheRequests(int clientIdx) throws Exception {
		if (clientIdx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				client.cancelCacheRequests();
			}
		} else {
			_clients.get(clientIdx).cancelCacheRequests();
		}
	}
	
	/////////////////////////////////////////////////////////////////
	// Publishing Methods
	@SuppressWarnings("unchecked")
	public void publishMessage(RuntimeProperties pubprops, int clientidx) throws Exception {
		if (isPublishing())
			throw new IllegalStateException(
				"Already publishing, must call stopPublishing before publish message.");
		
		
		if ((_rprops.getProperty(RuntimeProperties.STRUCT_DATA_MSGS_LIST) != null)
				&& (_rprops.getBooleanProperty(RuntimeProperties.WANT_ORDER_CHECK) ||
					_rprops.getBooleanProperty(RuntimeProperties.WANT_LATENCY) ||
					_rprops.getBooleanProperty(RuntimeProperties.WANT_PAYLOAD_CHECK) ||
					_rprops.getBooleanProperty(RuntimeProperties.WANT_LOSS_AND_DUPLICATE_DETECTION)))
		{
			throw new PubSubException("Cannot use order check, loss/duplicate detection, latency or payload check with structured messages");
	    }
		
		
		// doclist is a not a list of immutable objects, it not shared with all pubs
		// each pub takes a copy of the list so that tool data can be updated
		// on message publish.
		// To save on memory, the call to create a doc list will also erase
		// loaded message buffers since they will then have been copied to the
		// MsgRep objects.
		List<BasicMsgRep> tempDocList;
		if (pubprops.getProperty(RuntimeProperties.STRUCT_DATA_MSGS_LIST) != null)
		{
			tempDocList = createDoclistForStructMsgs(pubprops);
		}
		else if (pubprops.getProperty(RuntimeProperties.SMF_BINARY_FILE_LIST) != null)
		{
			tempDocList = createDoclistFromBinarySmf(pubprops);
		}
		else
		{
			tempDocList = createDoclist(pubprops);
		}
		if (tempDocList.size() > 1) {
	        throw new PubSubException("Properties generated message list when trying to publish a single message.");
	    }

		List<String> transactedSessionNameList = (List<String>)pubprops.getProperty(RuntimeProperties.TRANSACTED_SESSION_NAME_LIST);

		// Must create an API specific version of the message list to allow the APIs to cache some things like destinations.
		// Use the first client for the conversion for simplicity
		BasicMsgRep[] doclist = _clients.get(0).cloneToApiSpecificMsgRep(tempDocList.toArray(new BasicMsgRep[tempDocList.size()]));
		
		pubprops.setProperty(RuntimeProperties.PUBLISH_FILE_LIST, null);
		pubprops.setProperty(RuntimeProperties.PUBLISH_ATTACH_LIST, null);
		
		// Always use the first producer thread as we only need to send a single message.
	    int producerIndex = 0;
	    long msgId = 1;
	    String transactedSessionName = "";
	    
        // Ack Immediately flag on MsgRep is typically set by the publish thread
        // at regular intervals as specified by the publish property for Ack Immediately
        // Interval.
        // For the special case of publishing a single message, we will allow any value
        // greater than 0 to cause the Ack Immediately flag to get set.
	    if (pubprops.getIntegerProperty(RuntimeProperties.AD_ACK_IMMEDIATELY_INTERVAL) > 0) {
	    	doclist[0].setAckImmediately(true);
	    }
	    
	    if(pubprops.getStringProperty(RuntimeProperties.HTTP_CONTENT_ENCODING) != null) {
	    	for(BasicMsgRep m : doclist) {
	    		m.setHttpContentEncoding(pubprops.getStringProperty(RuntimeProperties.HTTP_CONTENT_ENCODING));
	    	}
	    }
	    if(pubprops.getStringProperty(RuntimeProperties.HTTP_CONTENT_TYPE) != null) {
	    	for(BasicMsgRep m : doclist) {
	    		m.setHttpContentType(pubprops.getStringProperty(RuntimeProperties.HTTP_CONTENT_TYPE));
	    	}
	    }
	    
	    this.waitForAdPubAcks(pubprops);
	    
		if (clientidx == ALL_CLIENT_INDEX) {
			// If trying to publish with transactions then we need to make sure that the session names list is the same length as the clients list.
			if (transactedSessionNameList != null &&
					transactedSessionNameList.size() > 0 &&
					transactedSessionNameList.size() != _clients.size()) {
				throw new PubSubException("Error trying to publishing using transacted sessions.  Session names list not equal to num clients");
			}

			for (int i = 0; i < _clients.size(); i++) {
				AbstractClient client = _clients.get(i);
				if (transactedSessionNameList != null &&
						transactedSessionNameList.size() > 0) {
					transactedSessionName = transactedSessionNameList.get(i);
				}
				// Must be connected in order to publish.  So call connect here.  If we're already connected this will 
				// return immediately.  If we don't do this then we have to check for null producers on each publish.
				client.connect();
				
				client.setPublishProps(pubprops, producerIndex, transactedSessionName);
				client.populateToolData(doclist[0], msgId, -1, -1, -1);
				client.publishMsg(doclist[0], producerIndex);
				
				if (pubprops.getBooleanProperty(RuntimeProperties.AD_WANT_PUB_ACK_ORDER_CHECK)) {
					setLastPubTimeInNanos(System.nanoTime(), i);
				}
			}
		} else {
			if (transactedSessionNameList != null &&
					transactedSessionNameList.size() > 0) {
				if (transactedSessionNameList.size() != 1) {
					throw new PubSubException("Error trying to publishing using transacted sessions.  Session names size 1 when specific client chosen");
				}
				transactedSessionName = transactedSessionNameList.get(0);
			}
			AbstractClient client = _clients.get(clientidx);
			
			// Must be connected in order to publish.  So call connect here.  If we're already connected this will 
			// return immediately.  If we don't do this then we have to check for null producers on each publish.
			client.connect();
			
			client.setPublishProps(pubprops, producerIndex, transactedSessionName);
			client.populateToolData(doclist[0], msgId, -1, -1, -1);
			client.publishMsg(doclist[0], producerIndex);
			
			if (pubprops.getBooleanProperty(RuntimeProperties.AD_WANT_PUB_ACK_ORDER_CHECK)) {
				setLastPubTimeInNanos(System.nanoTime(), clientidx);
			}
		}
	}
	
	///////////////////////////////////////////////////////////////////////
	// Stats Access
	
	public PerfStats getRxStats(final int clientidx) {
		PerfStats ret_stats;
		if (clientidx == ALL_CLIENT_INDEX) {
			ret_stats = new PerfStats(
					"aggregate", 
					_rprops.getIntegerProperty(RuntimeProperties.LATENCY_BUCKETS), 
					_rprops.getIntegerProperty(RuntimeProperties.LATENCY_GRANULARITY), 
					_rprops.getDoubleProperty(RuntimeProperties.LATENCY_WARMUP_IN_SECS));
			for (AbstractClient client : _clients) {
				ret_stats.aggregate(client.getRxStats());
			}
		} else {
			ret_stats = _clients.get(clientidx).getRxStats();
		}
		return ret_stats;
	}

	public void resetStats(final int clientidx) {
		if (_cpuMon != null) {
			// Must reset the cpu usage when stats are reset.  Cpu usage is always since last stats reset.
			_cpuMon.resetInterval();
		}
		
		if (clientidx == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				client.resetStats();
			}
		} else {
			_clients.get(clientidx).resetStats();
		}
	}

	public long getSdkStat(GenericStatType stype, int clientIndex) throws PubSubException {
		long value = 0;
		if (clientIndex == ALL_CLIENT_INDEX) {
			// return for all
			for (AbstractClient client : _clients) {
				try {
					value += client.getSdkStat(stype);
				} catch (Exception e) {
					throw new PubSubException(e);
				}
			}
		} else {
			// return specific subscriber
			try {
				value = _clients.get(clientIndex).getSdkStat(stype);
			} catch (Exception e) {
				throw new PubSubException(e);
			}
		}
		return value;
	}

	public double getCpuUsage() {
		double cpuUsage = 0;
        if (_cpuMon != null) {
        	cpuUsage = _cpuMon.getCpuUsageSofar();
        }
        return cpuUsage;
	}

	public Exception getLastErrorResponse(int clientIndex) throws PubSubException
	{
		if (clientIndex == ALL_CLIENT_INDEX) {
			if (_clients.size() > 1) {
				throw new PubSubException(
						"PerfClientCollection: Cannot request last error on all clients " +
						"if there is more than 1 client in object");
			}
			return _clients.get(0).getLastErrorResponse();
		} else {
			return _clients.get(clientIndex).getLastErrorResponse();
		}
	}
	
	public void clearLastErrorResponse(int clientIndex)
	{
		if (clientIndex == ALL_CLIENT_INDEX) {
			for (AbstractClient client : _clients) {
				client.clearLastErrorResponse();
			}
		} else {
			_clients.get(clientIndex).clearLastErrorResponse();
		}
	}
	
	public Hashtable<GenericCapabilityType, String> getRtrCapabilities() throws Exception
	{
		return _clients.get(0).getRtrCapabilities();
	}

	/////////////////////////////////////////////////////////////
	// Other Methods

	@SuppressWarnings("unchecked")
	protected List<BasicMsgRep> createDoclist(RuntimeProperties pubprops) {
		/*
		 * Create the doclist to be used by all pubs: iterate over xmldocs,
		 * attachments and meta|topics
		 */
		
		List<BasicMsgRep> returnList = new ArrayList<BasicMsgRep>();
		
		List<ByteBuffer> listXmlDocs = (List<ByteBuffer>) pubprops
			.getProperty(RuntimeProperties.PUBLISH_FILE_LIST);
		List<ByteBuffer> listAttachDocs = (List<ByteBuffer>) pubprops
			.getProperty(RuntimeProperties.PUBLISH_ATTACH_LIST);
		List<String> listTopics = (List<String>) pubprops
			.getProperty(RuntimeProperties.PUBLISH_TOPIC_LIST);
		List<String> listQueues = (List<String>) pubprops
			.getProperty(RuntimeProperties.PUBLISH_QUEUE_LIST);
	
		GenericMessageDeliveryMode msgType = (GenericMessageDeliveryMode) pubprops.getProperty(RuntimeProperties.PUB_MESSAGE_TYPE);
		
		int cntXmlDocs = (listXmlDocs == null) ? 0 : listXmlDocs.size();
		int cntAttachDocs = (listAttachDocs == null) ? 0 : listAttachDocs.size();
		int cntTopics = (listTopics == null) ? 0 : listTopics.size();
		int cntQueues = (listQueues == null) ? 0 : listQueues.size();
		int cntQTDestinations = cntTopics + cntQueues;
		
		// If no input xmldocs specified, autogenerate one.
		if (listXmlDocs == null) {
			List<Integer> sizes = (List<Integer>)pubprops.getProperty(RuntimeProperties.XML_PAYLOAD_SIZE_LIST);
			if (sizes != null && !sizes.isEmpty()) {
				listXmlDocs = new ArrayList<ByteBuffer>();
				for (Integer size : sizes) {
					listXmlDocs.add(ByteBuffer.wrap(Helpers.createGeneratedXmlDoc(size).getBytes()));
					
				}
				cntXmlDocs = listXmlDocs.size();
			}
		}

		// If no input attachments specified, autogenerate one.
		if (listAttachDocs == null) {
			List<Integer> sizes = (List<Integer>)pubprops.getProperty(RuntimeProperties.ATTACHMENT_SIZE_LIST);
			if (sizes != null && !sizes.isEmpty()) {
				listAttachDocs = new ArrayList<ByteBuffer>();
				for (Integer size : sizes) {
					listAttachDocs.add(ByteBuffer.wrap(Helpers.createGeneratedDoc(size).getBytes()));
				}
				cntAttachDocs = listAttachDocs.size();
			}
		}
		
		if (cntTopics == 0 && (listXmlDocs == null || listXmlDocs.size() == 0) && cntQueues == 0) {
	        throw new IllegalStateException("Must specify at least one routable component (i.e. topic or queue)");
	    }
		
		int cntDistinct = 0;
		cntDistinct = java.lang.Math.max(cntDistinct, cntXmlDocs);
		cntDistinct = java.lang.Math.max(cntDistinct, cntAttachDocs);


		if (cntDistinct == 0) {
			/* 
			 * We're publishing empty messages so use the destinations as the guide.
			 */
			cntDistinct = cntQTDestinations;
		}
		
		if (cntDistinct == 1 && cntQTDestinations > 1) {
			/*
			 * In the case where a single message is prepared for publishing,
			 * but several TOPICS | QUEUES are specified for publishing, copy
			 * that data message for each TOPIC | QUEUE.
			 */
			cntDistinct = cntQTDestinations;
		}
		
		
		if (Trace.isDebugEnabled()) {
			StringBuffer debugmsg = new StringBuffer();
			debugmsg.append("Preparing message element tables: ");
			debugmsg.append(String.format("[xmldocs:%s x attachs:%s]", 
				cntXmlDocs, cntAttachDocs));
			Trace.debug(debugmsg.toString());
		}
		
		
		/*
		 * Create message rep objects.
		 * 
		 * Only 1 of topics or queues will be populated if at all.  So use it as destination.
		 */
		
		Iterator<ByteBuffer> xmlDocIter = null; 
		Iterator<ByteBuffer> attachIter = null; 
		Iterator<String> topicsIter = null; 
		Iterator<String> queuesIter = null; 
		for (int i = 0; i < cntDistinct; i++) {
			
			byte[] curXmlDoc = null;
			if (cntXmlDocs > 0) {
				if (xmlDocIter == null || !xmlDocIter.hasNext()) {
					xmlDocIter = listXmlDocs.iterator();
				}
				curXmlDoc = xmlDocIter.next().array();
			}
				
			byte[] curAttach = null;
			if (cntAttachDocs > 0) {
				if (attachIter == null || !attachIter.hasNext()) {
					attachIter = listAttachDocs.iterator();
				}
				curAttach = attachIter.next().array();
			}

			String curTopic = null;
			if (cntTopics > 0) {
				if (topicsIter == null || !topicsIter.hasNext()) {
					topicsIter = listTopics.iterator();
				}
				curTopic = topicsIter.next();
			}
			
			String curQueue = null;
			if (cntQueues > 0) {
				if (queuesIter == null || !queuesIter.hasNext()) {
					queuesIter = listQueues.iterator();
				}
				curQueue = queuesIter.next();
			}
			
			String replyToPostfix = (String) pubprops.getProperty(RuntimeProperties.REPLY_TO_POSTFIX);
			String replyToString = (String) pubprops.getProperty(RuntimeProperties.REPLY_TO_STRING);
			
			String replyToDest = null;
			PublisherDestinationsType replyToDestType = null;
			
			if(replyToString != null && replyToString.length() > 0) {
				DestinationBean db = DestinationUtils.buildDestinationBeanFromExpression(replyToString);
				replyToDest = db.getDestinationName();
				replyToDestType = db.getDestinationType();
			} else if(replyToPostfix != null && replyToPostfix.length() > 0) {
				if (curTopic != null) {
					replyToDest = curTopic + replyToPostfix;
					replyToDestType = PublisherDestinationsType.TOPIC;
				} else if (curQueue != null) {
					replyToDest = curQueue + replyToPostfix;
					replyToDestType = PublisherDestinationsType.QUEUE;
				}
			}
			
			
			// Create a message representation
			BasicMsgRep msgRep = new BasicMsgRep();
			if (curTopic != null) {
				msgRep.configureForNormalMsg(curXmlDoc, curAttach, curTopic, PublisherDestinationsType.TOPIC, msgType, replyToDest, replyToDestType);
			} else if (curQueue != null) {
				msgRep.configureForNormalMsg(curXmlDoc, curAttach, curQueue, PublisherDestinationsType.QUEUE, msgType, replyToDest, replyToDestType);
			} else {
				msgRep.configureForNormalMsg(curXmlDoc, curAttach, null, PublisherDestinationsType.NULL, msgType, replyToDest, replyToDestType);
			}
			
			int qos = pubprops.getIntegerProperty(RuntimeProperties.MQTT_PUBLISH_QOS);
			msgRep.setMqttQos(qos);
			
			returnList.add(msgRep);
		}

		if (Trace.isDebugEnabled()) {
			Trace.debug(String.format("Created %s messages, dumping message list:", cntDistinct));
			for (BasicMsgRep m : returnList) {
				Trace.debug(m.toString());
			}
		}
		
		return returnList;
	}
	
	
	protected List<BasicMsgRep> createDoclistForApplicationServerCommand(RuntimeProperties pubprops) {
		
		List<BasicMsgRep> returnList = new ArrayList<BasicMsgRep>();
		
		@SuppressWarnings("unchecked")
		List<String> listTopics = (List<String>) pubprops.getProperty(RuntimeProperties.PUBLISH_TOPIC_LIST);
		@SuppressWarnings("unchecked")
		List<String> listQueues = (List<String>) pubprops.getProperty(RuntimeProperties.PUBLISH_QUEUE_LIST);
	
		GenericMessageDeliveryMode msgType = (GenericMessageDeliveryMode) pubprops.getProperty(RuntimeProperties.PUB_MESSAGE_TYPE);
		
		/*
		 * Create message rep objects.
		 */

		String applicationServerCommand = pubprops.getStringProperty(RuntimeProperties.APPLICATION_SERVER_COMMAND);
		byte [] appSerCmdByteArr = null;
				
		if(applicationServerCommand != null && applicationServerCommand.length() > 0) {
			// UTF-8 encode it inside the binary attachment of the message.
			try {
				appSerCmdByteArr = applicationServerCommand.getBytes("UTF-8");
			} catch (UnsupportedEncodingException e) {
				Trace.error("Could not encode application server command.");
			}
		}
		

		String replyToPostfix = (String) pubprops.getProperty(RuntimeProperties.REPLY_TO_POSTFIX);
		String replyToString = (String) pubprops.getProperty(RuntimeProperties.REPLY_TO_STRING);
		
		String replyToDest = null;
		PublisherDestinationsType replyToDestType = null;

		if(replyToString != null && replyToString.length() > 0) {
			DestinationBean db = DestinationUtils.buildDestinationBeanFromExpression(replyToString);
			replyToDest = db.getDestinationName();
			replyToDestType = db.getDestinationType();
		}
		
		
		if(listTopics != null) {
			for (int i = 0; i < listTopics.size(); i++) {

				String curTopic = listTopics.get(i);
				
				 if(replyToDest == null && replyToPostfix != null && replyToPostfix.length() > 0) {
					if (curTopic != null) {
						replyToDest = curTopic + replyToPostfix;
						replyToDestType = PublisherDestinationsType.TOPIC;
					}
				}
				
				// Create a message representation
				BasicMsgRep msgRep = new BasicMsgRep();
				msgRep.configureForAppServer(curTopic, PublisherDestinationsType.TOPIC, msgType, appSerCmdByteArr, replyToDest, replyToDestType);
				returnList.add(msgRep);
			}
		}
		
		if(listQueues != null) {
			for (int i = 0; i < listQueues.size(); i++) {
				
				String curQueue = listQueues.get(i);
				
				if(replyToDest == null && replyToPostfix != null && replyToPostfix.length() > 0) {
				    if (curQueue != null) {
					    replyToDest = curQueue + replyToPostfix;
					    replyToDestType = PublisherDestinationsType.QUEUE;
				    }
				}
				 
				// Create a message representation
				BasicMsgRep msgRep = new BasicMsgRep();
				msgRep.configureForAppServer(curQueue, PublisherDestinationsType.QUEUE, msgType, appSerCmdByteArr, replyToDest, replyToDestType);
				returnList.add(msgRep);
			}
		}
		

		
		
		if (Trace.isDebugEnabled()) {
			Trace.debug(String.format("Created %d messages, dumping message list:", (((listTopics == null)? 0 : listTopics.size()) + ((listQueues == null)? 0 : listQueues.size()))));
			for (BasicMsgRep m : returnList) {
				Trace.debug(m.toString());
			}
		}
		
		return returnList;
	}
	
	@SuppressWarnings("unchecked")
	protected List<BasicMsgRep> createDoclistForStructMsgs(RuntimeProperties pubprops) {
		
		/*
		 * Create the doclist to be used by all pubs: iterate over xmldocs,
		 * attachments and meta|topics
		 */
		
		List<BasicMsgRep> returnList = new ArrayList<BasicMsgRep>();
		
		List<Integer> listStructMsgIds = (List<Integer>) pubprops
			.getProperty(RuntimeProperties.STRUCT_DATA_MSGS_LIST);
		List<String> listTopics = (List<String>) pubprops
			.getProperty(RuntimeProperties.PUBLISH_TOPIC_LIST);
		List<String> listQueues = (List<String>) pubprops
			.getProperty(RuntimeProperties.PUBLISH_QUEUE_LIST);
	
		GenericMessageDeliveryMode msgType = (GenericMessageDeliveryMode) pubprops.getProperty(RuntimeProperties.PUB_MESSAGE_TYPE);
		
		
		
		int cntMsgIds = (listStructMsgIds == null) ? 0 : listStructMsgIds.size();
		int cntTopics = (listTopics == null) ? 0 : listTopics.size();
		int cntQueues = (listQueues == null) ? 0 : listQueues.size();
		int cntQTDestinations = cntTopics + cntQueues;
		
		// Can't have both topics and queues.  Checked in runtime props but will check
		// for safety here too.
		if (cntQueues > 0 && cntTopics > 0) {
			Trace.error("Error: Can't publish to queues and topics at same time.  Using topics.");
		} 
		
		if ((cntMsgIds == 1) &&
			listStructMsgIds.get(0) == SdkperfConstants.SDM_ID_ALL) {
			
			listStructMsgIds.clear();
	        for (int i = 1; i <= 21; ++i) {
	        	listStructMsgIds.add(i);
	        }
	        
	        cntMsgIds = listStructMsgIds.size();
	    }
		int cntDistinct = cntMsgIds;
		
		if (cntDistinct < 1) {
			throw new IllegalStateException(
						"Must specify at least 1 valid message part..");
		}
		
		if (cntDistinct == 1 && cntQTDestinations > 1) {
			/*
			 * In the case where a single message is prepared for publishing,
			 * but several TOPICS | QUEUES are specified for publishing, copy
			 * that data message for each TOPIC | QUEUE.
			 */
			cntDistinct = cntQTDestinations;
		}
		
		
		if (Trace.isDebugEnabled()) {
			StringBuffer debugmsg = new StringBuffer();
			debugmsg.append("Preparing message element tables: ");
			debugmsg.append(String.format("[structMsgIds:%s]", 
					cntMsgIds));
			Trace.debug(debugmsg.toString());
		}
		
		
		/*
		 * Create message rep objects.
		 * 
		 * Only 1 of topics or queues will be populated if at all.  So use it as destination.
		 */
		Iterator<Integer> structMsgIdsIter = null; 
		Iterator<String> topicsIter = null; 
		Iterator<String> queuesIter = null; 
		for (int i = 0; i < cntDistinct; i++) {
			
			if (structMsgIdsIter == null || !structMsgIdsIter.hasNext()) {
				structMsgIdsIter = listStructMsgIds.iterator();
			}
			Integer curStuctMsgId = structMsgIdsIter.next();
			
			String curTopic = null;
			if (cntTopics > 0) {
				if (topicsIter == null || !topicsIter.hasNext()) {
					topicsIter = listTopics.iterator();
				}
				curTopic = topicsIter.next();
			}
			
			String curQueue = null;
			if (cntQueues > 0) {
				if (queuesIter == null || !queuesIter.hasNext()) {
					queuesIter = listQueues.iterator();
				}
				curQueue = queuesIter.next();
			}
		    
			
			String replyToPostfix = (String) pubprops.getProperty(RuntimeProperties.REPLY_TO_POSTFIX);
			String replyToString = (String) pubprops.getProperty(RuntimeProperties.REPLY_TO_STRING);
			
			String replyToDest = null;
			PublisherDestinationsType replyToDestType = null;
			
			if(replyToString != null && replyToString.length() > 0) {
				DestinationBean db = DestinationUtils.buildDestinationBeanFromExpression(replyToString);
				replyToDest = db.getDestinationName();
				replyToDestType = db.getDestinationType();
			} else if(replyToPostfix != null && replyToPostfix.length() > 0) {
				if (curTopic != null) {
					replyToDest = curTopic + replyToPostfix;
					replyToDestType = PublisherDestinationsType.TOPIC;
				} else if (curQueue != null) {
					replyToDest = curQueue + replyToPostfix;
					replyToDestType = PublisherDestinationsType.QUEUE;
				}
			}
			
			
			// Create a message representation
			BasicMsgRep msgRep = new BasicMsgRep();
			if (curTopic != null) {
				msgRep.configureForStructuredMsg(curTopic, PublisherDestinationsType.TOPIC, msgType, curStuctMsgId, replyToDest, replyToDestType);
			} else if (curQueue != null) {
				msgRep.configureForStructuredMsg(curQueue, PublisherDestinationsType.QUEUE, msgType, curStuctMsgId, replyToDest, replyToDestType);
			} else {
				msgRep.configureForStructuredMsg(null, PublisherDestinationsType.NULL, msgType, curStuctMsgId, replyToDest, replyToDestType);
			}
			returnList.add(msgRep);
		}

		if (Trace.isDebugEnabled()) {
			Trace.debug(String.format("Created %s messages, dumping message list:", cntDistinct));
			for (BasicMsgRep m : returnList) {
				Trace.debug(m.toString());
			}
		}
		
		return returnList;
	}
	
	@SuppressWarnings("unchecked")
	protected List<BasicMsgRep> createDoclistFromBinarySmf(RuntimeProperties pubprops) {
		
		/*
		 * Create the doclist to be used by all pubs: iterate over xmldocs,
		 * attachments and meta|topics
		 */
		
		List<BasicMsgRep> returnList = new ArrayList<BasicMsgRep>();
		
		List<ByteBuffer> listBinarySmf = (List<ByteBuffer>) pubprops
			.getProperty(RuntimeProperties.SMF_BINARY_FILE_LIST);

		
		if (listBinarySmf == null || listBinarySmf.size() < 1) {
			throw new IllegalStateException(
						"Error building messages from binary smf input..");
		}
		
		/*
		 * Create message rep objects.
		 */
		for (ByteBuffer smfIter : listBinarySmf)
		{
			// Create a message representation
			BasicMsgRep msgRep = new BasicMsgRep();
			msgRep.configureForSmfBytesMsg(smfIter.array());
			returnList.add(msgRep);
		}

		if (Trace.isDebugEnabled()) {
			Trace.debug(String.format("Created %s messages, dumping message list:", returnList.size()));
			for (BasicMsgRep m : returnList) {
				Trace.debug(m.toString());
			}
		}
		
		return returnList;
	}
	
	protected void waitForAdPubAcks(RuntimeProperties pubprops) throws InterruptedException {
    
	    // Back to back publishing of AD messages can lead to having ACKs for previously published
	    // messages arriving after having started the next publish.  (With less than 1/3 of the AD
	    // publish window used, we will be getting a timed ACK for the last few messages.)  The
	    // timed ACK will occur within 1 sec of the last message published.  We will give time
	    // for this ACK to arrive before starting the next publish.
		if (pubprops.getBooleanProperty(RuntimeProperties.AD_WANT_PUB_ACK_ORDER_CHECK) &&
				(pubprops.getProperty(RuntimeProperties.PUB_MESSAGE_TYPE) != GenericMessageDeliveryMode.DIRECT) &&
				(this.getLastPubTimeInNanos() > 0)) {
	        // Wait at least 1.1 sec since our last published message.
	        long pubStartDelayInNs = (getLastPubTimeInNanos() + 1100000000) - System.nanoTime();
	        if (pubStartDelayInNs > 0) {
	        	Thread.sleep((int)(pubStartDelayInNs / 1000000));
	        }
		}
	}
	
	
}
