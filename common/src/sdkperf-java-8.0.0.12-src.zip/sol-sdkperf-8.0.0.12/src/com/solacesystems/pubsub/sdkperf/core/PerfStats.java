/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.mutable.MutableLong;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.pubsub.sdkperf.util.Helpers;
import com.solacesystems.pubsub.sdkperf.util.Timing;

/**
 * Calculates tool specific client stats such as num messages
 * received, latency, etc.
 * 
 * For latency calculations, min, max and average are calculated
 * as messages arrive.  For other latency measurements, latency
 * buckets are used.  When latency stats are updated, the corresponding
 * bucket count is updated for the given latency.  Then in post
 * processing latency for 95%, 99%, and 99.9% can be calculated using
 * the buckets and corresponding message counts.
 */
public class PerfStats {

	public enum PerfStatType {
		NUM_MSGS_RECV,
		NUM_MSGS_PRI_0,
		NUM_MSGS_PRI_1,
		NUM_MSGS_PRI_2,
		NUM_MSGS_PRI_3,
		NUM_MSGS_PRI_4,
		NUM_MSGS_PRI_5,
		NUM_MSGS_PRI_6,
		NUM_MSGS_PRI_7,
		NUM_MSGS_PRI_8,
		NUM_MSGS_PRI_9,
		NUM_MSGS_CID,
		NUM_MSGS_XML_PAY,
		NUM_MSGS_BIN_ATTACH,
		NUM_MSGS_USERDATA,
		NUM_MSGS_TOPIC,
		LATENCY_USEC_MIN,
		LATENCY_USEC_AVG,
		LATENCY_USEC_MAX,
		NUM_LATENCY_MSGS,
		NUM_TPUT_MSGS,
		NUM_MSGS_CRC_OK,
		NUM_MSGS_CRC_FAIL,
		NUM_MSGS_CRC_XML_PAY_OK,
		NUM_MSGS_CRC_XML_PAY_FAIL,
		NUM_MSGS_CRC_BIN_ATT_OK,
		NUM_MSGS_CRC_BIN_ATT_FAIL,
		NUM_MSGS_CRC_SDM_OK,
		NUM_MSGS_CRC_SDM_FAIL,
		NUM_MSGS_USERDATA_OK,
		NUM_MSGS_USERDATA_FAIL,
		NUM_MSGS_ORDER_CHECKED,
		NUM_MSGS_REDELIVERED,
		NUM_CACHE_REQ_SENT,
		NUM_CACHE_RESP_RECV,
		NUM_LIVE_MSGS_RECV,
		NUM_CACHE_MSGS_RECV,
		NUM_CACHE_SUSPECT_RECV,
		NUM_CACHE_REQ_OK,
		NUM_CACHE_REQ_INCOMP_NODATA,
		NUM_CACHE_REQ_INCOMP_SUSPECT,
		NUM_CACHE_REQ_INCOMP_TIMEOUT,
		NUM_CACHE_REQ_INCOMP_CANCELLED,
		NUM_CACHE_REQ_ERROR,
		NUM_MSGS_DI_SET,
		PSM_MAX_CYCLES_BEHIND,
        PSM_NUM_TIMES_BEHIND,
        NUM_MSGS_CLIENT_ACKED,
        NUM_ACK_EVENTS,
        NUM_NACK_EVENTS,
        NUM_PUB_MSGS_ACKED,
        NUM_MSGS_REPUBLISHED,
        NUM_MSGS_RECEIVED_UNSTRUCTURED_TOTAL,
        NUM_MSGS_RECEIVED_UNSTRUCTURED_BYTES,
        NUM_MSGS_RECEIVED_UNSTRUCTURED_XML,
        NUM_MSGS_RECEIVED_STRUCTURED_TOTAL,
        NUM_MSGS_RECEIVED_STRUCTURED_TEXT,
        NUM_MSGS_RECEIVED_STRUCTURED_MAP,
        NUM_MSGS_RECEIVED_STRUCTURED_STREAM,
        // Session Event statistics (JNI)
        SESSION_EVENT_ACKNOWLEDGEMENT,
        SESSION_EVENT_ASSURED_DELIVERY_DOWN,
        SESSION_EVENT_CAN_SEND,
        SESSION_EVENT_CONNECT_FAILED_ERROR,
        SESSION_EVENT_DOWN_ERROR,
        SESSION_EVENT_MODIFYPROP_FAIL,
        SESSION_EVENT_MODIFYPROP_OK,
        SESSION_EVENT_PROVISION_ERROR,
        SESSION_EVENT_PROVISION_OK,
        SESSION_EVENT_RECONNECTED_NOTICE,
        SESSION_EVENT_RECONNECTING_NOTICE,
        SESSION_EVENT_REJECTED_MSG_ERROR,
        SESSION_EVENT_RX_MSG_TOO_BIG_ERROR,
        SESSION_EVENT_SUBSCRIPTION_OK,
        SESSION_EVENT_TE_UNSUBSCRIBE_ERROR,
        SESSION_EVENT_TE_UNSUBSCRIBE_OK,
        SESSION_EVENT_UP_NOTICE,
        // Session Event statistics (JCSMP/JMS)
        SESSION_EVENT_INCOMPLETE_LARGE_MESSAGE_RECVD,
        SESSION_EVENT_UNKNOWN_TRANSACTED_SESSION_NAME,
        // Session event (JCSMP, JMS, JNI)
        SESSION_EVENT_VIRTUAL_ROUTER_NAME_CHANGED,
        SESSION_EVENT_SUBSCRIPTION_ERROR,
        SESSION_EVENT_REPUBLISH_UNACKED_MESSAGES,
        // Handle unknown session events
        SESSION_EVENT_UNKNOWN
	}

	private static final Log Trace = LogFactory.getLog(PerfStats.class);
	
	// Used in order checking.  -1 is taken by default stream.  Next special 
	// stream is chosen as -2.
	public static final Integer C_DEFAULT_STREAM_ID = -1;
	public static final Integer C_TOPIC_SEQUENCE_STREAM_ID = -2;
	
	private final String _subName;
	private EnumMap<PerfStatType, MutableLong> _stats = 
		new EnumMap<PerfStatType, MutableLong>(PerfStatType.class);
	long _receiveStartTimeInNanos, _receiveEndTimeInNanos, _totalLatency;
	double _toUs;
	
	private HashMap<Integer, MutableLong> _cidBuckets;
	private HashMap<String, MutableLong> _demuxStats = new HashMap<String, MutableLong>();
	
	private List<MutableLong> _latencyBuckets;
	private int _latencyGranularity;
	private double _latencyWarmupInSecs;
	
	private HashMap<Integer, SingleStreamOrderCheckingData> _oooData;
	private HashMap<Integer, TransactionData> _transactionOrderData;
	private int _lastMessageStreamId = C_DEFAULT_STREAM_ID;
	private TransactionData _lastTransactionData = null;
	
	// Used for loss/duplicate checking
	private Map<Integer, ArrayList<Long>> _messageLossAndDuplicateDetection = new HashMap<Integer, ArrayList<Long>>();
	private int _totalLossAndDuplicateDetectionIdsStored = 0;
	// We will store at most 100 million message IDs in memory
	private final int MAX_LOSS_AND_DUP_IDS_STORED = 100000000;
	
	public Map<Integer, ArrayList<Long>> getMessageLossAndDuplicateDetectionMap() {
		return _messageLossAndDuplicateDetection;
	}


	private List<MutableLong> _orderMemory;

	public PerfStats(
		final String subname,
		final int latencyNumBuckets,
		final int latencyGranularityFactor,
		final double latencyWarmUpSecs) {

		_subName = subname;

		for (PerfStatType s : PerfStatType.values()) {
			_stats.put(s, new MutableLong(0));
		}

		_cidBuckets = new HashMap<Integer, MutableLong>();
		_latencyBuckets = new ArrayList<MutableLong>(latencyNumBuckets);
		for (int i = 0; i < latencyNumBuckets; i++) {
			_latencyBuckets.add(new MutableLong(0));
		}
		
		_latencyGranularity = latencyGranularityFactor;
		_latencyWarmupInSecs = latencyWarmUpSecs;
		_toUs = Timing.microSecDivisor(); // Ask which timer we're using.
		_totalLatency = 0;
		_receiveStartTimeInNanos = 0;
		_receiveEndTimeInNanos = 0;
		_stats.get(PerfStatType.LATENCY_USEC_MIN).setValue(Long.MAX_VALUE);
		_stats.get(PerfStatType.LATENCY_USEC_MAX).setValue(0);
		
		_oooData = new HashMap<Integer, SingleStreamOrderCheckingData>();
		_transactionOrderData = new HashMap<Integer, TransactionData>();
		_orderMemory = new ArrayList<MutableLong>();
	}

	// We need this additional constructor in order to have a safe way
	// to construct instances of PerfStats from the data where
	// the analysis has already been done. This is useful when using
	// web messaging client collections that want to report well-formed
	// PerfStats instances and have to set the members to good values. 
	public PerfStats(
	        final String subname,
	        final int latencyNumBuckets,
	        final int latencyGranularityFactor,
	        final double latencyWarmUpSecs,
	        EnumMap<PerfStatType, MutableLong> stats,
	        HashMap<Integer, SingleStreamOrderCheckingData> oooData,
	        ArrayList<MutableLong> orderMemory) {
	    this(subname, latencyNumBuckets, latencyGranularityFactor, latencyWarmUpSecs);
	    _stats = stats;
	    _oooData = oooData;
	    _orderMemory = orderMemory;
	}
	
	
	public void updateTimeRecvd(long timeRecvd) {
		_receiveEndTimeInNanos = timeRecvd;
		_receiveStartTimeInNanos = (_receiveStartTimeInNanos == 0) ? timeRecvd : _receiveStartTimeInNanos;
		// Must transfer num messages to throughput messages when endtime is updated.
        _stats.get(PerfStatType.NUM_TPUT_MSGS).setValue(
		_stats.get(PerfStatType.NUM_MSGS_RECV).longValue());
	}
	
	public void addMessageForLossAndDuplicateDetection(int streamId, long msgId) {
		// Limit the amount of messages we will store in memory
		if(_totalLossAndDuplicateDetectionIdsStored >= MAX_LOSS_AND_DUP_IDS_STORED) {
			Trace.warn("Cannot store more message IDs for duplicate and loss detection.");
			return;
		}
		
		if(!_messageLossAndDuplicateDetection.containsKey(streamId)) {
			_messageLossAndDuplicateDetection.put(streamId, new ArrayList<Long>());
		}
		
		_messageLossAndDuplicateDetection.get(streamId).add(msgId);
		_totalLossAndDuplicateDetectionIdsStored++;
	}
	
	
	public void checkOrder(ToolData toolData, boolean redelivered, Long topicSequence) {

		int streamId = toolData.getStreamId();
		boolean republished = toolData.getRepublished();
		long msgId = toolData.getMessageIdentifier();
				
		if (msgId > 0) {
			// If we have a streamId then check order based on the stream.  By default if the 
			// message does not have any stream ID in it then the ToolData returns -1.  So we'll
			// use this to indicate the default stream for common processing.
			if (_oooData.containsKey(streamId)) {
				this.checkStreamOrder(
						_oooData.get(streamId),
						msgId,
						redelivered,
						republished);
			} else {
				// This then must be the first message on this stream.  So just initialize order checking for 
				// the stream.
				SingleStreamOrderCheckingData newData = new SingleStreamOrderCheckingData();
				newData.prevMsgId = msgId;
				newData.prevCommittedMsgId = msgId - 1;
				_oooData.put(streamId, newData);
			}
		}
		
		// If we have a valid topic sequence then check order of the topic sequence as well.
		if (topicSequence != null) {
			if (_oooData.containsKey(C_TOPIC_SEQUENCE_STREAM_ID)) {
				this.checkStreamOrder(
						_oooData.get(C_TOPIC_SEQUENCE_STREAM_ID),
						topicSequence,
						redelivered,
						republished);
			} else {
				// This then must be the first message on this stream.  So just initialize order checking for 
				// the stream.
				SingleStreamOrderCheckingData newData = new SingleStreamOrderCheckingData();
				newData.prevMsgId = topicSequence;
				_oooData.put(C_TOPIC_SEQUENCE_STREAM_ID, newData);
			}
		}
		
		if (toolData.hasTransactionIdentifier()) {

			if (_lastTransactionData != null && _lastMessageStreamId != streamId) {
				// If this message is from a different stream, 
				// make sure the last transaction was complete!
				if (!_lastTransactionData.lastTransactionComplete()) {
					if (Trace.isErrorEnabled()) {
						Trace.error("Received message on different stream before all messages from transaction were received.");
					}
				}
			}
			
			if(_transactionOrderData.containsKey(streamId)) {
				TransactionData td = _transactionOrderData.get(streamId);
				td.checkTransactionOrder(toolData);
			} else {
				TransactionData td = new TransactionData();
				td.checkTransactionOrder(toolData);
				_transactionOrderData.put(streamId, td);
			}
			
		}

	}

	public void checkStreamOrder(
			SingleStreamOrderCheckingData orderData,
			long msgId, 
			boolean redelivered,
			boolean republished) {

	    long prevMsgId = orderData.prevMsgId;
	    
	    if (msgId != (prevMsgId + 1)) {
	        // message is out of order        
	        if(msgId < prevMsgId) {
	    	    // remove from lost msg list
	    	    // if it wasn't in the lost msg list, it is a duplicate
	        	MutableLong oooMsgId = new MutableLong(msgId);
	    		if(!orderData.lostMsgIds.contains(oooMsgId)) {
	    	    	if (redelivered) {
	    	    		orderData.redeliveredDupMsgIds.add(oooMsgId);
	    	    	} else if (republished) {
	    	    	    orderData.republishedDupMsgIds.add(oooMsgId);
	    	    	} else {
	    	    		orderData.dupMsgIds.add(oooMsgId);
	    	    		// A redelivered duplicate message is never considered out of order.  
	                    // The redelivered flag is out get out jail card.  These
	                    // messages can arrive at any time (based on the api contract)
	    	    		orderData.oooMsgIds.put(oooMsgId, new MutableLong(prevMsgId));
	    	    	}
	    	    } else {
	    	    	orderData.lostMsgIds.remove(oooMsgId);
	    	        // However a message that was lost and now found 
	                // is always an out of order message even if
	                // redelivered.
	    	    	orderData.oooMsgIds.put(oooMsgId, new MutableLong(prevMsgId));
	    	    }
	            // don't increment expected msg
	        }
	        
	        if(msgId > (prevMsgId +1)) {
	            // update the missing list with range of missing values
	            updateLostMsgs(orderData, prevMsgId,msgId);
	            orderData.prevMsgId = msgId;
	        }
	        
	        if(msgId == prevMsgId) {
                if (redelivered) {
                    orderData.redeliveredDupMsgIds.add(new MutableLong(msgId));
                } else if (republished) {
                    orderData.republishedDupMsgIds.add(new MutableLong(msgId));
                } else {
    	    		orderData.dupMsgIds.add(new MutableLong(msgId));
    	    	}
	            // don't increment expected msg
	        }
	    } else {
	        // In order message received so update previous message id.
	    	orderData.prevMsgId++;
	    }
	}
	
	private void updateLostMsgs( 
			SingleStreamOrderCheckingData orderData,
			long prevMsgId, 
	        long endId)
	{
	    // Protect against tool misuse by not blindly running out of memory if suddenly  
	    // millions of messages are missing.  We'll error in this case.
	    if (endId - prevMsgId > 10000) {
	    	Trace.warn("STATS " + _subName + "Error during loss check. " +
	    			    "> 10000 msgs lost.  Current msg ID: " + prevMsgId + 
	    			    " Next msg ID received: " + endId);
	    	orderData.lostMsgIds.add(new MutableLong(prevMsgId + 1));
	    	return;
	    } 
	    
	    for(long id = (prevMsgId + 1); id < endId; id++) {
	    	orderData.lostMsgIds.add(new MutableLong(id));
	    }
	       
	}

	public void updateOrderMemory(long msgId, int streamId) {
		
		MutableLong value = new MutableLong(((long)streamId) << 48 | (0x00FFFFFF & msgId));
		_orderMemory.add(value);
	}
	
	public void commit() {
		for (SingleStreamOrderCheckingData stream : _oooData.values()) {
			stream.prevCommittedMsgId = stream.prevMsgId;
		}
	}
	
	public void rollback() {
		for (SingleStreamOrderCheckingData stream : _oooData.values()) {
			stream.prevMsgId = stream.prevCommittedMsgId;
		}		
	}
	
	public boolean incStat(PerfStatType type, long inc) {
		// It is illegal to directly increment some stats (from sdkperf_cpp)
		if (type == PerfStatType.LATENCY_USEC_AVG
			|| type == PerfStatType.LATENCY_USEC_MAX
			|| type == PerfStatType.LATENCY_USEC_MIN
			|| type == PerfStatType.NUM_LATENCY_MSGS
			|| type == PerfStatType.PSM_MAX_CYCLES_BEHIND) {
			return false;
		}

		synchronized (this) {
			_stats.get(type).add(inc);
		}
		return true;
	}

	public void setStat(PerfStatType type, long value) {
		synchronized (this) {
			_stats.get(type).setValue(value);
		}
	}

	public boolean incStat(PerfStatType type, long timeRecvd, long inc) {
		synchronized (this) {
			if (!incStat(type, inc))
				return false;
			updateTimeRecvd(timeRecvd);
			return true;
		}
	}

	public boolean incPriorityStat(int msgPriority, long timeRecvd, long inc) {
		throw new UnsupportedOperationException();
	}

	
	
	public void incLatency(long timeRecvd, long latency) {
		updateTimeRecvd(timeRecvd);

	    // If we're in the warmup period then skip this stat.
	    if ((double)timeRecvd < ((double)_receiveStartTimeInNanos + 
	                              _latencyWarmupInSecs * 1000000000.0)) {
	        return;
	    }

	    
	    // Convert latency to usec.
	    long usecLatency = (long)((double)latency / _toUs);
	    
	    MutableLong minLat = _stats.get(PerfStatType.LATENCY_USEC_MIN);
	    if(minLat.longValue() > usecLatency) { 
	    	minLat.setValue(usecLatency);
	    }
	    
	    MutableLong maxLat = _stats.get(PerfStatType.LATENCY_USEC_MAX);
	    if(maxLat.longValue() < usecLatency) { 
	    	maxLat.setValue(usecLatency);
	    }
	    
	    _totalLatency += usecLatency;
	    
	    _stats.get(PerfStatType.NUM_LATENCY_MSGS).increment();
	    
	    // Update the buckets
	    long bucketIndex = usecLatency >> _latencyGranularity;
	    if (bucketIndex >= _latencyBuckets.size()) {
	        bucketIndex = _latencyBuckets.size() - 1;
	    }
	    
	    if (bucketIndex < 0) {
	    	Trace.error("Negative latency: " + usecLatency);
	    	bucketIndex = 0;
	    }
	    
	    _latencyBuckets.get((int) bucketIndex).increment() ;
	}
	
	public void incCidBucket(int cid, MutableLong inc){
		MutableLong cidValue = _cidBuckets.get((Integer)cid);
		if (cidValue != null){
			cidValue.add(inc);
			_cidBuckets.put(cid, cidValue);
		} else {
			_cidBuckets.put(cid, inc);
		}
	}	

	public void resetStats() {
		for (MutableLong ml : _stats.values()) {
			ml.setValue(0);
		}
		_receiveEndTimeInNanos = 0;
		_receiveStartTimeInNanos = 0;
		_totalLatency = 0;

		_cidBuckets.clear();
		_demuxStats.clear();
		
		for (MutableLong bucket : _latencyBuckets) {
			bucket.setValue(0);
		}
		_stats.get(PerfStatType.LATENCY_USEC_MIN).setValue(Long.MAX_VALUE);
		_stats.get(PerfStatType.LATENCY_USEC_MAX).setValue(0);
		
		_oooData.clear();
		_transactionOrderData.clear();
		_orderMemory.clear();
		
		for(ArrayList<Long> v : _messageLossAndDuplicateDetection.values()) {
			v.clear();
		}
		_messageLossAndDuplicateDetection.clear();
		_totalLossAndDuplicateDetectionIdsStored = 0;
	}

	public boolean aggregate(final PerfStats input) {
		if (_receiveStartTimeInNanos > input._receiveStartTimeInNanos || _receiveStartTimeInNanos == 0) {
			_receiveStartTimeInNanos = input._receiveStartTimeInNanos;
		}
		if (_receiveEndTimeInNanos < input._receiveEndTimeInNanos) {
			_receiveEndTimeInNanos = input._receiveEndTimeInNanos;
		}

		Map<PerfStatType, MutableLong> inpStats = input.getStatsMap();
		for (Entry<PerfStatType, MutableLong> e : inpStats.entrySet()) {
			switch (e.getKey()) {
			case LATENCY_USEC_MIN:
				// can you say "awkward syntax?"
				if (inpStats.get(e.getKey()).longValue() < _stats.get(e.getKey()).longValue()) {
					_stats.put(e.getKey(), new MutableLong(inpStats.get(e.getKey()).longValue()));
				}
				break;
			case LATENCY_USEC_MAX:
			case PSM_MAX_CYCLES_BEHIND:
					if (inpStats.get(e.getKey()).longValue() > _stats.get(e.getKey()).longValue()) {
					_stats.put(e.getKey(), new MutableLong(inpStats.get(e.getKey()).longValue()));
				}
				break;
			default:
				_stats.get(e.getKey()).add(inpStats.get(e.getKey()).longValue());
				break;
			}
		}
		
		for (Entry<Integer, MutableLong> bucketEntry : input.getCidBuckets().entrySet()) {
			Integer currentBucket = (Integer)bucketEntry.getKey();
			incCidBucket(currentBucket, bucketEntry.getValue());
		}
		
		_totalLatency += input._totalLatency;
		
		// Method of combining below has a serious draw back if lists are the same.
		// you should only aggregate like PerfStats.
		List<MutableLong> inputBuckets = input.getLatencyBuckets();
		if (inputBuckets.size() != _latencyBuckets.size()) {
			Trace.error("Aggregating perf stats whose latency buckets are not equal in length");
			
		}
		
		for(int i = 0; i < inputBuckets.size(); i++) {
			_latencyBuckets.get(i).add(inputBuckets.get(i));			
		}
		
		// Merge message order stuff
		for (Map.Entry<Integer, SingleStreamOrderCheckingData> oooEntry : input.getOrderData().entrySet()) {
	    	if (_oooData.containsKey(oooEntry.getKey())) {
	    		_oooData.get(oooEntry.getKey()).aggregate(oooEntry.getValue());
	    	} else {
	    		_oooData.put(oooEntry.getKey(), new SingleStreamOrderCheckingData(oooEntry.getValue()));
	    	}
	    }
		
		// Merge Transaction Order Data
		for (Map.Entry<Integer, TransactionData> e : input.getTransactionOrderData().entrySet()) {
	    	if (_transactionOrderData.containsKey(e.getKey())) {
	    		_transactionOrderData.get(e.getKey()).aggregateStats(e.getValue());
	    	} else {
	    		_transactionOrderData.put(e.getKey(), new TransactionData(e.getValue()));
	    	}
	    }

	    _orderMemory.addAll(input.getOrderMemory());
	    
	    // Demux stats aggregate
		for(Entry<String, MutableLong> entry : input.getDemuxStats().entrySet()) {
			if(_demuxStats.containsKey(entry.getKey())) {
				_demuxStats.get(entry.getKey()).add(entry.getValue());
			} else {
				_demuxStats.put(entry.getKey(), new MutableLong(entry.getValue().longValue()));
			}			
		}
		
		
	    // Message Loss & Duplicate aggregate
		for(Entry<Integer, ArrayList<Long>> entry : input._messageLossAndDuplicateDetection.entrySet()) {
			
			if(_messageLossAndDuplicateDetection.containsKey(entry.getKey())) {
				_messageLossAndDuplicateDetection.get(entry.getKey()).addAll(entry.getValue());
			} else {
				_messageLossAndDuplicateDetection.put(entry.getKey(), new ArrayList<Long>(entry.getValue()));
			}
		}
		
		return true;
	}

	public String getName() {
		return _subName;
	}

	public double getThruPut(PerfStatType type) {
		double result;
		
		long startTime = _receiveStartTimeInNanos;
		if (type == PerfStatType.NUM_LATENCY_MSGS) {
			startTime = _receiveStartTimeInNanos + (long)(_latencyWarmupInSecs * 1000000000.0);
		}
		if (startTime >= _receiveEndTimeInNanos) {
			result = 0;
		} else {
			result = ((double)getStatElement(type) * 1000000000.0 / 
					 (double)(_receiveEndTimeInNanos - startTime));
		}
		return result;
	}

	public double getPriorityThruPut(int msgPriority) {
		throw new UnsupportedOperationException();
	}

	public long getStat(PerfStatType type) {
		long val = 0;
		switch (type) {
		case LATENCY_USEC_AVG:
			if (_stats.get(PerfStatType.NUM_LATENCY_MSGS).longValue() != 0) {
				val = _totalLatency / _stats.get(PerfStatType.NUM_LATENCY_MSGS).longValue();
			} else {
				// Leave value as 0;
			}
			break;
		case LATENCY_USEC_MIN:
			if (_stats.get(PerfStatType.LATENCY_USEC_MIN).longValue() == Long.MAX_VALUE) {
				val = 0;
			} else {
				val = _stats.get(PerfStatType.LATENCY_USEC_MIN).longValue();
			}
			break;
		default:
			val = getStatElement(type);
		}

		return val;
	}

	public long getPercentileLatencyInUSec( double perc )
	{
	    long percentNumSamples = (long)
	    	(_stats.get(PerfStatType.NUM_LATENCY_MSGS).longValue() * perc / 100);
	    long numSamples = 0;
	    double latencyUSec = 0.0;
	    boolean isDone = false;
	    double bucketSizeUSec = ((double)(((long)1) << _latencyGranularity));
	    double bucketEndUSec = bucketSizeUSec;
	    
	    for (int bucketLoop = 0;
	         bucketLoop < _latencyBuckets.size() &&
	         isDone != true;
	         bucketLoop++) {
	        if (_latencyBuckets.get(bucketLoop).longValue() > 0) {
	            numSamples += _latencyBuckets.get(bucketLoop).longValue();
	            if (numSamples >= percentNumSamples &&
	                bucketLoop != (_latencyBuckets.size() - 1)) {
	                isDone = true;
	                latencyUSec = bucketEndUSec;
	            }
	        }
	        bucketEndUSec += bucketSizeUSec;
	    }

	    return (long) latencyUSec;
	}
	
	public long getLatencyStdDevInUSec()
	{
	    long numSamples = _stats.get(PerfStatType.NUM_LATENCY_MSGS).longValue();
	    double stdDevSum = 0.0;
	    double bucketSizeUSec = ((double)(((long)1) << _latencyGranularity));
	    double bucketEndUSec = bucketSizeUSec;
	    double avgLatency = getStat(PerfStatType.LATENCY_USEC_AVG);
	    double stdDev = 0;
	    
	    for (int bucketLoop = 0;
	         bucketLoop < _latencyBuckets.size();
	         bucketLoop++) {
	        if (_latencyBuckets.get(bucketLoop).longValue() > 0) {
	        	double tempSum = (bucketEndUSec - avgLatency) * (bucketEndUSec - avgLatency);
	        	stdDevSum += tempSum * _latencyBuckets.get(bucketLoop).longValue();
	        }
	        bucketEndUSec += bucketSizeUSec;
	    }

	    stdDev = Math.sqrt(stdDevSum / numSamples);
	    return (long) stdDev;
	}
	
	// Useful for stats stored in seconds.
	public double getStatInUSec(PerfStatType type) 
	{ 
		return ((double)getStat(type) / _toUs); 
	}
	

	public List<MutableLong> getLatencyBuckets() {
		return _latencyBuckets;
	}

	public EnumMap<PerfStatType, MutableLong> getStatsMap() {
		return _stats;
	}

	public HashMap<Integer, SingleStreamOrderCheckingData> getOrderData() {
		return _oooData;
	}
	
	public HashMap<Integer, TransactionData> getTransactionOrderData() {
		return _transactionOrderData;
	}
	
	public List<MutableLong> getOrderMemory() {
		return _orderMemory;
	}
	
	public double getLatencyBucketSize() {
		return ((((long)1) << _latencyGranularity));
	}
	
	public HashMap<Integer, MutableLong> getCidBuckets() {
		return _cidBuckets;
	}
	
	public HashMap<String, MutableLong> getDemuxStats() {
		return _demuxStats;
	}
	
	public void incDemuxStats(String stat) {	
		if (!_demuxStats.containsKey(stat)) {
			_demuxStats.put(stat, new MutableLong(1));
		} else {
			_demuxStats.get(stat).increment();
		}
	}
	
	private long getStatElement(PerfStatType key) {
		return _stats.get(key).longValue();
	}
	
	@Override
	public String toString() {
		StringBuffer buf = new StringBuffer();
		for (Entry<PerfStatType, MutableLong> e : _stats.entrySet()) {
			buf.append(String.format("%s : %s%n", e.getKey().name(), e.getValue().longValue()));
		}
		
	    int bucketLoop = 0;
	    for (MutableLong bucket: _latencyBuckets) {

	        if (bucket != null && bucket.longValue() > 0) {
	        	buf.append(String.format("BI: %d LAT: %d NUM: %d %n",
	        			bucketLoop,
	        			 (long)((bucketLoop << _latencyGranularity)),
	        			 bucket.longValue()));
	        }
	        bucketLoop++;
	    }
		return buf.toString();
	}
	
	
	/**
	 * Cache of config switches to save on map lookups in the fast path.
	 * 
	 */
	public static class SingleStreamOrderCheckingData {
		public List<MutableLong> lostMsgIds;
		public List<MutableLong> dupMsgIds;
		public List<MutableLong> redeliveredDupMsgIds;
		public List<MutableLong> republishedDupMsgIds;
		public HashMap<MutableLong, MutableLong> oooMsgIds;
		public long prevMsgId;
		public long prevCommittedMsgId;
		
		public SingleStreamOrderCheckingData() {
			lostMsgIds = new ArrayList<MutableLong>();
			dupMsgIds = new ArrayList<MutableLong>();
			redeliveredDupMsgIds = new ArrayList<MutableLong>();
			republishedDupMsgIds = new ArrayList<MutableLong>();
			oooMsgIds = new HashMap<MutableLong, MutableLong>();
			prevMsgId = -1;
			prevCommittedMsgId = prevMsgId;
		}
		
		/**
		  * Copy constructor.
		  */
		public SingleStreamOrderCheckingData(SingleStreamOrderCheckingData input) {
			lostMsgIds = Helpers.cloneMutableLongArrayList(input.lostMsgIds);
			dupMsgIds = Helpers.cloneMutableLongArrayList(input.dupMsgIds);
			redeliveredDupMsgIds = Helpers.cloneMutableLongArrayList(input.redeliveredDupMsgIds);
			republishedDupMsgIds = Helpers.cloneMutableLongArrayList(input.republishedDupMsgIds);
			oooMsgIds = Helpers.cloneMutableLongHashMap(input.oooMsgIds);
			prevMsgId = input.prevMsgId;
			prevCommittedMsgId = input.prevCommittedMsgId;
		}
		  
		public void aggregate (SingleStreamOrderCheckingData input) {
			lostMsgIds.addAll(input.lostMsgIds);
			dupMsgIds.addAll(input.dupMsgIds);
			redeliveredDupMsgIds.addAll(input.redeliveredDupMsgIds);
			republishedDupMsgIds.addAll(input.republishedDupMsgIds);
			oooMsgIds.putAll(input.oooMsgIds);
		}
		
		public String toString() {
			StringBuffer buf = new StringBuffer();
			
			if (oooMsgIds.size() > 0) {
				buf.append("    ooo : ");
				for (MutableLong msgId : oooMsgIds.keySet()) {
					buf.append("(" + msgId + ":" + oooMsgIds.get(msgId) + ") ");
				}
				buf.append("\n");
			}
		
			if(lostMsgIds.size() > 0) {
				buf.append("    lost: ");
				long start_seq_no = lostMsgIds.get(0).longValue();
				long end_seq_no = start_seq_no;
				buf.append("(" + start_seq_no);
				for (MutableLong msgId : lostMsgIds) {
                    if (msgId.longValue() >  (end_seq_no + 1)) {
                    	buf.append("-" + end_seq_no + ")");
                        start_seq_no = msgId.longValue();
                        end_seq_no = msgId.longValue();
                        buf.append("(" + msgId);
                    } else {
                        end_seq_no = msgId.longValue();
                    }

                }
				buf.append("-" + end_seq_no + ") \n");
            }

			if (dupMsgIds.size() > 0) {
				buf.append("    dup : ");
				for (MutableLong msgId : dupMsgIds) {
					buf.append(msgId + " ");
				}
				buf.append("\n");
			}
        
            if (redeliveredDupMsgIds.size() > 0) {
                buf.append(" red dup: ");
                for (MutableLong msgId : redeliveredDupMsgIds) {
                    buf.append(msgId + " ");
                }
                buf.append("\n");
            }
        
            if (republishedDupMsgIds.size() > 0) {
                buf.append("rpub dup: ");
                for (MutableLong msgId : republishedDupMsgIds) {
                    buf.append(msgId + " ");
                }
                buf.append("\n");
            }
			
			return buf.toString();
		}
	}
	
	public static class TransactionData {
		
		long lastTransactionComplete = 0;
		long currTransactionId = -1;
		int currTranMsgId = -1;
		int currTranSize = -1;
		int messagesReceived = 0;
		
		
		// Stats
		long totMsgsProcessed = 0;
		long numFullTransactionsReceived = 0;
		long numTranErrorsRaised = 0;
		
		public long getNumFullTranReceived() {
			return numFullTransactionsReceived;
		}
		public long getNumTranErrorsRaised() {
			return numTranErrorsRaised;
		}
		public long getTotalNumberOfMessagesProcessed() {
			return totMsgsProcessed;
		}
		
		public TransactionData() {}
		
		public TransactionData(TransactionData td) {
			lastTransactionComplete = td.lastTransactionComplete;
			currTransactionId = td.currTransactionId; 
			currTranMsgId = td.currTranMsgId;
			currTranSize = td.currTranSize;
			messagesReceived = td.messagesReceived;
			
			totMsgsProcessed = td.totMsgsProcessed;
			numFullTransactionsReceived = td.numFullTransactionsReceived;
			numTranErrorsRaised = td.numTranErrorsRaised;
		}
		
		
		public void reset() {
			currTransactionId = -1;
			currTranMsgId = -1;
			currTranSize = -1;
			messagesReceived = 0;
		}
		
		public void aggregateStats(TransactionData td) {
			// Aggregate stats
			totMsgsProcessed += td.totMsgsProcessed;
			numFullTransactionsReceived += td.numFullTransactionsReceived;
			numTranErrorsRaised += td.numTranErrorsRaised;
		}
		
		public boolean lastTransactionComplete() {
			if (currTranSize == messagesReceived) {
				return true;
			}
			return false;
		}
		
		public void checkTransactionOrder(ToolData toolData) {
			long tranId = toolData.getTransactionIdentifier();
			int tranMsgId = toolData.getTransactionMessageIdentifier();
			int tranSize = toolData.getTransactionSize();

			boolean errorRaised = false;

			if (tranId != currTransactionId) {

				if (currTransactionId > 0) {

					if (tranId != lastTransactionComplete + 1) {
						if (Trace.isWarnEnabled()) {
							Trace.warn(String.format(
									"Last Transaction was #%d; received new transaction #%d; but was expecting #%d.",
									lastTransactionComplete, tranId, lastTransactionComplete + 1));
						}
					}

				}

				// New transaction
				reset();
			}

			messagesReceived++;
			totMsgsProcessed++;

			if (tranId != currTransactionId) {
				currTransactionId = tranId;
				currTranMsgId = tranMsgId;
				currTranSize = tranSize;

				if (tranMsgId != 1) {
					errorRaised = true;
					if (Trace.isWarnEnabled()) {
						Trace.warn(String.format(
								"Received new transaction (%d) but first message had msgId=%d (tranSize=%d).", tranId,
								tranMsgId, tranSize));
					}
				}
			} else {
				// Got message from same transaction as the last message

				if (messagesReceived != tranMsgId) {
					errorRaised = true;
					if (Trace.isWarnEnabled()) {
						Trace.warn(String
								.format("Received transaction message out of order (tranId=%d). Expecting Msg ID: %d, got: %d.",
										currTransactionId, messagesReceived, tranMsgId));
					}
				}

				if (currTranSize != tranSize) {
					errorRaised = true;
					if (Trace.isWarnEnabled()) {
						Trace.warn(String.format(
								"Unexpected transaction size received (tranId=%d). Expecting: %d, got: %d.",
								currTransactionId, currTranSize, tranSize));
					}
				}

				if (messagesReceived > currTranSize) {
					errorRaised = true;
					if (Trace.isWarnEnabled()) {
						Trace.warn(String
								.format("Received too many messages for transaction #%d. Messages received: %d; Message ID: %d; Transaction size: %d",
										currTransactionId, messagesReceived, tranMsgId, currTranSize));
					}
				}

			}

			if (messagesReceived == currTranSize) {
				// We got all messages, add to list of seen transactions
				lastTransactionComplete = currTransactionId;
				numFullTransactionsReceived++; // incr stat
			}

			if (errorRaised) {
				numTranErrorsRaised++; // incr stat
			}

		}
	}
	
}
