/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.core;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.pubsub.sdkperf.util.NetworkByteOrderNumberUtil;
import com.solacesystems.pubsub.sdkperf.util.SdkperfConstants;

/**
 *  This class is used to encode and decode tool specific data.
 *  Tool data is published and received in the binary attachment
 *  portion of a message in a format that is platform independent
 *  and common across all tools.
 *  
 *  Information carried in the tool data currently is:
 *       - Latency time stamp (in cpu ticks.)
 *       - Message ID (order checking)
 *       - CRC for binary attachments
 *       - CRC for xml payloads
 *       - (unused) CRC for xml metadata
 *       - (unused) CRC for binary metadata
 *       - Transaction ID, Transaction Message ID & Transaction Size
 */
public class ToolData {
	private static final Log Trace = LogFactory.getLog(SdkperfPubThread.class);
	
	private boolean _hasLatency;
	private long _latency;
	
	private long _xmlPayloadHash;
	private long _binAttachHash;
	private long _messageIdentifier;
	private long _streamId;
	private int  _decodedSize;
	private boolean _republished;
	
	// Transaction Identifier
	private long _transactionId;
	private int _transactionMsgId;
	private int _transactionSize;
	
	// Tool Data Property Keys
	public final static String PROP_XML_PAYLOAD_HASH = "x";
	public final static String PROP_BIN_PAYLOAD_HASH = "b";
	public final static String PROP_STREAM_ID = "s";
	public final static String PROP_MESSAGE_ID = "m";
	public final static String PROP_LATENCY = "l";
	public final static String PROP_REPUBLISHED = "r";
	
	public ToolData () {
		reset();
	}
	
	public void reset () {
		_hasLatency = false;
		_latency = 0;
		_xmlPayloadHash = -1;
		_binAttachHash = -1;
		_messageIdentifier = -1;
		_streamId = -1;
		_decodedSize = 0;
		_republished = false;
		_transactionId = -1;
		_transactionMsgId = -1;
		_transactionSize = -1;
	}
	
	public void encode(byte[] dest){
		
		
		//encode the data we have
		if (hasData()) {
			if (getEncodedSize() > dest.length) {
				Trace.error("Encode destination too small");
			}
			
			//reset tool data pointer to beginning of byte array
			int toolDataEnd = 0;
			
			long presenceData = 0;
			
			//first put in our magic number
			System.arraycopy(SdkperfConstants.magicWord, 0, dest, toolDataEnd, SdkperfConstants.magicWord.length);
			toolDataEnd += SdkperfConstants.magicWord.length;
			
			//leave space for presence stuff, it will be inserted at the end
			toolDataEnd += 4;
		
			//add xmlpayload hash if present
			if (hasXmlPayloadHash()) {

				//set the presence bit
				presenceData = setBits(presenceData, 1, 1, SdkperfConstants.xmlPayloadBit);

				//fill in the xml payload hash bytes
				NetworkByteOrderNumberUtil.intToFourByte(_xmlPayloadHash, dest, toolDataEnd);
				toolDataEnd += 4;
				
			}
			
			if (hasStreamId()) {

				//set the presence bit
				presenceData = setBits(presenceData, 1, 1, SdkperfConstants.streamIdBit);

				//fill in the stream id bytes
				NetworkByteOrderNumberUtil.intToFourByte(_streamId, dest, toolDataEnd);
				toolDataEnd += 4;
				
			}
			
			//add xmlpayload hash if present
			if (hasBinAttachHash()) {

				//set the presence bit
				presenceData = setBits(presenceData, 1, 1, SdkperfConstants.binAttachBit);

				//fill in the binary attachment hash
				NetworkByteOrderNumberUtil.intToFourByte(_binAttachHash, dest, toolDataEnd);
				// Increase tool data size by 4 bytes
				toolDataEnd += 4;
				
			}
			
			//add message identifier
			if(hasMessageIdentifier()) {

				//set the presence bit
				presenceData = setBits(presenceData, 1, 1, SdkperfConstants.messageIdentifierBit);

				//fill in the latency bytes
				NetworkByteOrderNumberUtil.longToEightByte(_messageIdentifier, dest, toolDataEnd);
				// Increase tool data size by 8 bytes
				toolDataEnd += 8;
			}
	
			//add latency hash if present
			if (hasLatency()) {

				//set the presence bit
				presenceData = setBits(presenceData, 1, 1, SdkperfConstants.latencyBit);

				//fill in the latency bytes
				NetworkByteOrderNumberUtil.longToEightByte(_latency, dest, toolDataEnd);
				// Increase tool data size by 8 bytes
				toolDataEnd += 8;
			}
			
			if (getRepublished()) {
			    presenceData = setBits(presenceData, 1, 1, SdkperfConstants.republishedBit);
			}

			// Add Transaction Identifier
			if(hasTransactionIdentifier()) {
				//set the presence bit
				presenceData = setBits(presenceData, 1, 1, SdkperfConstants.transactionIdentifierBit);

				// fill in the Transaction ID bytes
				NetworkByteOrderNumberUtil.longToEightByte(_transactionId, dest, toolDataEnd);
				// Increase tool data size by 8 bytes
				toolDataEnd += 8;
				// fill in the Transaction Message ID bytes
				NetworkByteOrderNumberUtil.intToFourByte(_transactionMsgId, dest, toolDataEnd);
				// Increase tool data size by 4 bytes
				toolDataEnd += 4;
				// fill in the Transaction Size bytes
				NetworkByteOrderNumberUtil.intToFourByte(_transactionSize, dest, toolDataEnd);
				// Increase tool data size by 4 bytes
				toolDataEnd += 4;
			}
			
			//now finally input our presence bits
			NetworkByteOrderNumberUtil.intToFourByte(presenceData, dest, 4);
		}
	}
	
	public void decode(byte[] msgBytes, int dataEnd) {

		reset();
		
		if (msgBytes.length >  (SdkperfConstants.magicWord.length + (Integer.SIZE/8)) && 
			NetworkByteOrderNumberUtil.fourByteToUInt(msgBytes) == SdkperfConstants.magicWordLong) {
			//first check for magic word
			_decodedSize = 0;
			
			//get the presence bytes and set flags for each toolData type
			long presenceData = NetworkByteOrderNumberUtil.fourByteToUInt(msgBytes, SdkperfConstants.presenceDataOffset);

			_decodedSize = SdkperfConstants.magicWord.length + SdkperfConstants.presenceDataOffset;
			
			if (Long.lowestOneBit(presenceData) == 1 << SdkperfConstants.xmlPayloadBit) {
				_xmlPayloadHash = NetworkByteOrderNumberUtil.fourByteToUInt(msgBytes, _decodedSize);
				_decodedSize += SdkperfConstants.xmlPayloadSize;
				presenceData = setBits(presenceData, 0, 1, SdkperfConstants.xmlPayloadBit);
			}
			
			if (Long.lowestOneBit(presenceData) == 1 << SdkperfConstants.streamIdBit) {
				_streamId = NetworkByteOrderNumberUtil.fourByteToUInt(msgBytes, _decodedSize);
				_decodedSize += SdkperfConstants.streamIdSize;
				presenceData = setBits(presenceData, 0, 1, SdkperfConstants.streamIdBit);
			}
			
			if (Long.lowestOneBit(presenceData) == 1 << SdkperfConstants.binAttachBit) {
				_binAttachHash = NetworkByteOrderNumberUtil.fourByteToUInt(msgBytes, _decodedSize);
				_decodedSize += SdkperfConstants.binAttachSize;
				presenceData = setBits(presenceData, 0, 1, SdkperfConstants.binAttachBit);
			}
			
			if (Long.lowestOneBit(presenceData) == 1 << SdkperfConstants.messageIdentifierBit) {
				_messageIdentifier = NetworkByteOrderNumberUtil.eightByteToUInt(msgBytes, _decodedSize);
				_decodedSize += SdkperfConstants.messageIdentifierSize;
				presenceData = setBits(presenceData, 0, 1, SdkperfConstants.messageIdentifierBit);
			}

			if (Long.lowestOneBit(presenceData) == 1 << SdkperfConstants.latencyBit) {
				_latency = NetworkByteOrderNumberUtil.eightByteToUInt(msgBytes, _decodedSize);
				_hasLatency = true;
				_decodedSize += SdkperfConstants.latencySize;
				presenceData = setBits(presenceData, 0, 1, SdkperfConstants.latencyBit);
			}

            if (Long.lowestOneBit(presenceData) == 1 << SdkperfConstants.republishedBit) {
                _republished = true;
                presenceData = setBits(presenceData, 0, 1, SdkperfConstants.republishedBit);
            }
            
			if (Long.lowestOneBit(presenceData) == 1 << SdkperfConstants.transactionIdentifierBit) {
				_transactionId = NetworkByteOrderNumberUtil.eightByteToUInt(msgBytes, _decodedSize);
				_decodedSize += SdkperfConstants.transactionIdentifierSize;
				_transactionMsgId = (int) NetworkByteOrderNumberUtil.fourByteToUInt(msgBytes, _decodedSize);
				_decodedSize += SdkperfConstants.transactionMessageIdentifierSize;
				_transactionSize = (int) NetworkByteOrderNumberUtil.fourByteToUInt(msgBytes, _decodedSize);
				_decodedSize += SdkperfConstants.transactionSizeBytes;
				presenceData = setBits(presenceData, 0, 1, SdkperfConstants.transactionIdentifierBit);
			}
		}
		
	}
		
	public boolean hasData() {
		return(hasLatency() ||
			   hasXmlPayloadHash()||
			   hasBinAttachHash() ||
			   hasMessageIdentifier() ||
			   hasStreamId() ||
			   getRepublished() ||
			   hasTransactionIdentifier());
	}
	
	public void setLatency(long latency) {
		_latency = latency; 
		_hasLatency = true;
	}
	public long getLatency() {
		return (_latency);
	}
	public boolean hasLatency(){
		return(_hasLatency);
	}
	
	public void setXmlPayloadHash(long xmlPayloadHash) {
		_xmlPayloadHash = xmlPayloadHash;
	}
	public long getXmlPayloadHash() {
		return(_xmlPayloadHash);
	}
	public boolean hasXmlPayloadHash() {
		return (_xmlPayloadHash > 0);
	}
	
	public void setBinAttachHash(long binAttachHash) {
		_binAttachHash = binAttachHash;
	}
	public long getBinAttachHash() {
		return(_binAttachHash);
	}
	public boolean hasBinAttachHash() {
		return (_binAttachHash > 0);
	}
	public void clearBinAttachHash() {
		_binAttachHash = -1;
	}
	
	public void setMessageIdentifier(long messageIdentifier) {
		_messageIdentifier = messageIdentifier;
	}
	public long getMessageIdentifier() {
		return (_messageIdentifier);
	}
	public boolean hasMessageIdentifier() {
		return (_messageIdentifier != -1);
	}
	
	
	public void setTransactionInfo(long transactionId, int transactionMsgId, int transactionSize) {
		_transactionId = transactionId;
		_transactionMsgId = transactionMsgId;
		_transactionSize = transactionSize;
	}
	public long getTransactionIdentifier() {
		return _transactionId;
	}
	public int getTransactionMessageIdentifier() {
		return _transactionMsgId;
	}
	public int getTransactionSize() {
		return _transactionSize;
	}
	
	public boolean hasTransactionIdentifier() {
		return (_transactionId != -1);
	}
	public void setStreamId(int value) {
		_streamId = value;
	}
	public int getStreamId() {
		return (int)(_streamId);
	}
	public boolean hasStreamId() {
		return (_streamId != -1);
	}
	
	public void setRepublished(boolean value) {
	    _republished = value;
	}
	public boolean getRepublished() {
	    return _republished;
	}
	
	public int getDecodedSize() {
		if (_decodedSize < 0) {
			return 0;
		}
		return(_decodedSize);
	}
	
	public int getEncodedSize() {
		int toolDataSize = 0;
		
		if(!hasData())
			return 0;
		
	    // Tool data and presence bitmap are always first.
		toolDataSize += SdkperfConstants.magicWord.length + 4;
		
		if(hasLatency()) { toolDataSize += 8; }
		if(hasXmlPayloadHash()) { toolDataSize += 4; }
		if(hasBinAttachHash()) { toolDataSize += 4; }
		if(hasMessageIdentifier()) { toolDataSize += 8; }
	    if(hasStreamId()) { toolDataSize += 4; }
	    if(hasTransactionIdentifier()) { toolDataSize += 16; }
		
		return toolDataSize;
	}
	
	@Override
	public String toString() {
		StringBuffer buf = new StringBuffer();
		
		if (hasXmlPayloadHash()) 
			buf.append(String.format(" XML Payload Integrity   = %d%n", _xmlPayloadHash));
		if (hasBinAttachHash())
			buf.append(String.format(" Bin attachment Integrity= %d%n", _binAttachHash));
		if (hasStreamId()) 
			buf.append(String.format(" Stream ID               = %d%n", _streamId));
		if (hasMessageIdentifier()) 
			buf.append(String.format(" Msg ID                  = %d%n", _messageIdentifier));
		if (hasLatency()) 
			buf.append(String.format(" Latency Time Stamp      = %d%n", _latency));
		if (getRepublished()) 
			buf.append(String.format(" Republished            = %b%n", _republished));
		if(hasTransactionIdentifier()) {
			buf.append(String.format(" Transaction ID         = %d%n", _transactionId));
			buf.append(String.format("   Transaction Msg ID   = %d%n", _transactionMsgId));
			buf.append(String.format("   Transaction Size     = %d%n", _transactionSize));
		}
		return buf.toString();
	}

	
	
	public static final long setBits(long data, long valToSet, int numBits, int shiftBits) {
		/* Apply interesting bits from 'valToSet' to data */
		
		/* 
		 * Pseudocode:
		 * 
		 * 	Calculate interest mask for input value
		 *	Apply interest mask and shift input value
		 *	Shift interest mask and invert to get data clearing mask
		 *	Clear target bits in data with data clearing mask
		 *	data := data | shifted value
		 * 
		 */
		
		long curMask = (1l << numBits)-1;
		long shiftedVal = (valToSet & curMask) << shiftBits;
		long dataClearMask = ~(curMask << shiftBits);
		data = data & dataClearMask;
		return (data | shiftedVal);
	}
	
}
