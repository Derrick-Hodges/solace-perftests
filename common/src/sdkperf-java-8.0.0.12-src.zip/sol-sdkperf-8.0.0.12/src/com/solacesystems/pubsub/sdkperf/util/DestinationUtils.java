package com.solacesystems.pubsub.sdkperf.util;

import com.solacesystems.pubsub.sdkperf.util.DataTypes.PublisherDestinationsType;

public class DestinationUtils {

	
    public static DestinationBean buildDestinationBeanFromExpression(String expression) {
	
    	DestinationBean bean = new DestinationBean();

		if(expression.startsWith("/QUEUE/")) {
			bean.setDestinationType(PublisherDestinationsType.QUEUE);
			bean.setDestinationName(expression.substring("/QUEUE/".length()));
		} else if(expression.startsWith("/TOPIC/")) {
			bean.setDestinationType(PublisherDestinationsType.TOPIC);
			bean.setDestinationName(expression.substring("/TOPIC/".length()));
		} else {			
			// default case
			bean.setDestinationType(PublisherDestinationsType.TOPIC);
			bean.setDestinationName(expression);
		}
		
		return bean;
	}
	
	
	
	
	public static class DestinationBean {
		
		String _destination;
		PublisherDestinationsType _type;
				
		public DestinationBean() {}

		public DestinationBean(String dest, PublisherDestinationsType type) {
			_destination = dest;
			_type = type;
		}
		
		public String getDestinationName() {
			return _destination;
		}
		public void setDestinationName(String destination) {
			this._destination = destination;
		}
		public PublisherDestinationsType getDestinationType() {
			return _type;
		}
		public void setDestinationType(PublisherDestinationsType type) {
			this._type = type;
		}

	}
	
}
