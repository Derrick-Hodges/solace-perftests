package com.solacesystems.pubsub.sdkperf.jms.core;

import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Topic;

import com.solacesystems.pubsub.sdkperf.core.FlowStatus;

public interface JmsMessageReceiver {

	public abstract MessageConsumer getJmsMessageConsumer();
	public abstract void setJmsMessageConsumer(MessageConsumer value);
	public abstract String getDestinationString();
	public abstract boolean isNonDurable();
	public abstract boolean isTopic();
	public abstract Topic getTopic();
	
	public abstract FlowStatus getFlowStatus();
	public abstract void startMessageListener() throws JMSException;

	public abstract void restartMessageListener() throws JMSException;

}