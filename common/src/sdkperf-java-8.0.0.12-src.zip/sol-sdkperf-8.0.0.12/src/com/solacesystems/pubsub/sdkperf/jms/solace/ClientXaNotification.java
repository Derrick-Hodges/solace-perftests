/** 
*  Copyright 2009-2017 Solace Corporation. All rights reserved.
*  
*  http://www.solacesystems.com
*  
*  This source is distributed WITHOUT ANY WARRANTY or support;
*  without even the implied warranty of MERCHANTABILITY or FITNESS FOR
*  A PARTICULAR PURPOSE.  All parts of this program are subject to
*  change without notice including the program's CLI options.
*
*  Unlimited use and re-distribution of this unmodified source code is   
*  authorized only with written permission.  Use of part or modified  
*  source code must carry prominent notices stating that you modified it, 
*  and give a relevant date.
*/
package com.solacesystems.pubsub.sdkperf.jms.solace;

import java.util.concurrent.ArrayBlockingQueue;

import javax.transaction.xa.XAResource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.solacesystems.jcsmp.JCSMPStreamingPublishEventHandler;
import com.solacesystems.jcsmp.XMLMessageListener;
import com.solacesystems.jcsmp.protocol.nio.impl.AbstractNotification;
import com.solacesystems.pubsub.sdkperf.core.Constants.XaTransactionAction;
import com.solacesystems.pubsub.sdkperf.jms.core.JmsClientXaSession;


// In an actual application, commit/rollback is called from the message
// callback (async) or from the thread on which the messages are being
// received (sync).  However, this is not an actual application.  For
// testing purposes, we will sometimes be triggering the commit/rollback
// from outside of this application or based on a timer.  However, these
// commits and/or rollbacks must still be executed on the thread on which
// the messages are being received.  Since this application always uses 
// async delivery on the dispatcher thread, we need to push the execution
// of these operations onto the dispatcher thread.

public class ClientXaNotification extends AbstractNotification {

	private static final Log Trace = LogFactory.getLog(ClientXaNotification.class);

	private final JmsClientXaSession xaSession;
	private final ArrayBlockingQueue<Object> responseQueue;
	private final XaTransactionAction action;
	private final String xid;
	private final boolean onePhase;
	private final int flags;
	
	public ClientXaNotification(JmsClientXaSession xaSession, ArrayBlockingQueue<Object> responseQueue, boolean wantRollback) {
		this.xaSession = xaSession;
		this.responseQueue = responseQueue;
		this.action = null;
		this.xid = null;
		this.onePhase = wantRollback;
		this.flags = -1;
	}
	
	public ClientXaNotification(JmsClientXaSession xaSession, ArrayBlockingQueue<Object> responseQueue, XaTransactionAction action, String xid, boolean onePhase) {
		this.xaSession = xaSession;
		this.responseQueue = responseQueue;
		this.action = action;
		this.xid = xid;
		this.onePhase = onePhase;
		this.flags = -1;
	}

	public ClientXaNotification(JmsClientXaSession xaSession, ArrayBlockingQueue<Object> responseQueue, XaTransactionAction action, String xid, int flags) {
		this.xaSession = xaSession;
		this.responseQueue = responseQueue;
		this.action = action;
		this.xid = xid;
		this.onePhase = true;
		this.flags = flags;
	}

	public ClientXaNotification(JmsClientXaSession xaSession, ArrayBlockingQueue<Object> responseQueue, XaTransactionAction action, String xid) {
		this.xaSession = xaSession;
		this.responseQueue = responseQueue;
		this.action = action;
		this.xid = xid;
		this.onePhase = true;
		this.flags = -1;
	}

	public ClientXaNotification(JmsClientXaSession xaSession, ArrayBlockingQueue<Object> responseQueue, XaTransactionAction action, boolean onePhase) {
		this.xaSession = xaSession;
		this.responseQueue = responseQueue;
		this.action = action;
		this.xid = null;
		this.onePhase = onePhase;
		this.flags = -1;
	}
	
	public ClientXaNotification(JmsClientXaSession xaSession, ArrayBlockingQueue<Object> responseQueue, XaTransactionAction action, int flag) {
		this.xaSession = xaSession;
		this.responseQueue = responseQueue;
		this.action = action;
		this.xid = null;
		this.onePhase = true;
		this.flags = flag;
	}
	
	public boolean usesListener(XMLMessageListener listener) {
		return false;
	}
	
	public boolean usesHandler(JCSMPStreamingPublishEventHandler handler) {
		return false;
	}
	
	public int handleNotification() {
		try {
			if (action == XaTransactionAction.COMMIT) {
				if (xid != null) {
					xaSession.commit(xid, onePhase);
				} else {
					xaSession.commit(onePhase);
				}
			} else if (action == XaTransactionAction.END) {
				xaSession.end(xid, flags);
			} else if (action == XaTransactionAction.FORGET) {
				xaSession.forget(xid);
			} else if (action == XaTransactionAction.PREPARE) {
				xaSession.prepare(xid);
			} else if (action == XaTransactionAction.RECOVER) {
				xaSession.recover(flags);
			} else if (action == XaTransactionAction.ROLLBACK) {
				xaSession.rollback(xid);
			} else if (action == XaTransactionAction.START) {
				xaSession.start(xid, flags);
			} else if (action == XaTransactionAction.ALL) {
				try {
					String activeXid = xid;
					if (activeXid == null) {
						activeXid = xaSession.getActiveXid();
					}
					xaSession.end(activeXid, XAResource.TMSUCCESS);
					if (!onePhase) {
						xaSession.prepare(activeXid);
					}
					xaSession.commit(activeXid, onePhase);
					xaSession.start(activeXid, XAResource.TMNOFLAGS);
				} catch (Exception e1) {
					String xid = xaSession.getActiveXid();
					if (xid == null) {
						xid = xaSession.getXids().get(0);
					}
					try {
						xaSession.rollback(xid);
					} catch (Exception e2) {
						xaSession.start(xid, XAResource.TMNOFLAGS);
						throw e2;
					}
					xaSession.start(xid, XAResource.TMNOFLAGS);
					throw e1;
				}
			}
		} catch (Exception e) {
			if (!responseQueue.offer(e)) {
				Trace.warn("Failed to add exception to response queue.");
			}
			return 0;
		}
		if(!responseQueue.offer(new Object())) {
			Trace.warn("Failed to add object to response queue.");
		}
		return 0;
	}

}
