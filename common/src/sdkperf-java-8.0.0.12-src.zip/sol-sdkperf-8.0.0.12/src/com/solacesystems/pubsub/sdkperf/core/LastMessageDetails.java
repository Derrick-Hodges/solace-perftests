package com.solacesystems.pubsub.sdkperf.core;

import com.solacesystems.pubsub.sdkperf.util.DataTypes.SubscriberDestinationsType;

public class LastMessageDetails {

	private String _replyToDestination = null;
	private SubscriberDestinationsType _replyToDestinationType = null;
	
	private String _destination = null;
	private SubscriberDestinationsType _destinationType = null;
	
	private String _httpContentType = null;
	private String _httpContentEncoding = null;
	
	private String _correlationId = null;
	private String _customPropertyList = null;
	
	private Long _expiration = null;
	private Integer _priority = null;
	private String _appMessageId = null;
	private String _appMessageType = null;
	private Long _senderTimestamp = null;
	private String _cos = null;
	private String _deliveryMode = null;
	private String _messageId = null;
	
	public LastMessageDetails() {}

	public String getReplyToDestination() {
		return _replyToDestination;
	}

	public void setReplyToDestination(String replyToDestination) {
		this._replyToDestination = replyToDestination;
	}

	public String getDestination() {
		return _destination;
	}

	public void setDestination(String destination) {
		this._destination = destination;
	}

	public SubscriberDestinationsType getReplyToDestinationType() {
		return _replyToDestinationType;
	}

	public void setReplyToDestinationType(SubscriberDestinationsType replyToDestinationType) {
		this._replyToDestinationType = replyToDestinationType;
	}

	public SubscriberDestinationsType getDestinationType() {
		return _destinationType;
	}

	public void setDestinationType(SubscriberDestinationsType destinationType) {
		this._destinationType = destinationType;
	}
	
	public String getHttpContentType() {
		return _httpContentType;
	}

	public void setHttpContentType(String httpContentType) {
		this._httpContentType = httpContentType;
	}
	
	public String getHttpContentEncoding() {
		return _httpContentEncoding;
	}

	public void setHttpContentEncoding(String httpContentEncoding) {
		this._httpContentEncoding = httpContentEncoding;
	}

	public void clear() {
		_replyToDestination = null;
		_replyToDestinationType = null;
		_destination = null;
		_destinationType = null;
		_httpContentType = null;
		_httpContentEncoding = null;
		_correlationId = null;
		_expiration = null;
		_priority = null;
		_appMessageId = null;
		_appMessageType = null;
		_senderTimestamp = null;
		_cos = null;
		_deliveryMode = null;
		_messageId = null;
		setCustomPropertyList(null);
	}

	public String getCorrelationId() {
		return _correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this._correlationId = correlationId;
	}

	public String getCustomPropertyList() {
		return _customPropertyList;
	}

	public void setCustomPropertyList(String customPropertyList) {
		this._customPropertyList = customPropertyList;
	}

	public Long getExpiration() {
		return _expiration;
	}

	public void setExpiration(Long expiration) {
		this._expiration = expiration;
	}

	public Integer getPriority() {
		return _priority;
	}

	public void setPriority(Integer priority) {
		this._priority = priority;
	}

	public String getApplicationMessageId() {
		return _appMessageId;
	}

	public void setApplicationMessageId(String appMessageId) {
		this._appMessageId = appMessageId;
	}
	
	public String getApplicationMessageType() {
		return _appMessageType;
	}

	public void setApplicationMessageType(String appMessageType) {
		this._appMessageType = appMessageType;
	}

	public Long getSenderTimestamp() {
		return _senderTimestamp;
	}

	public void setSenderTimestamp(Long senderTimestamp) {
		this._senderTimestamp = senderTimestamp;
	}

	public String getCos() {
		return _cos;
	}

	public void setCos(String cos) {
		this._cos = cos;
	}

	public String getDeliveryMode() {
		return _deliveryMode;
	}

	public void setDeliveryMode(String deliveryMode) {
		this._deliveryMode = deliveryMode;
	}

	public String getMessageId() {
		return _messageId;
	}

	public void setMessageId(String messageId) {
		this._messageId = messageId;
	}

	
}
