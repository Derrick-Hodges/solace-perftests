package com.solacesystems.pubsub.sdkperf.util;

public class NetworkByteOrderNumberUtil {

	
	private static final long MAX_32BITS = 4294967295L;
	
	private static final String ERR_VALUE_OOB = "Value out of bounds (%s)";
	private static final String ERR_ARRAY_OVERFLOW = "Array Overflow (len=%s, index=%s)";

	
	private NetworkByteOrderNumberUtil() {}
	
	// Converts an integer to 4 bytes and insert them in the given
	// byte array at the defined offset.
	public static void intToFourByte(long value, byte[] dest, int off) {
		if ((value < 0) || (value > MAX_32BITS))
			throw new IllegalArgumentException(String.format(ERR_VALUE_OOB, value));

		dest[off + 0] = (byte) ((value & 0xFF000000L) >>24);
		dest[off + 1] = (byte) ((value & 0x00FF0000L) >>16);
		dest[off + 2] = (byte) ((value & 0x0000FF00L) >>8);
		dest[off + 3] = (byte) ((value & 0x000000FFL));
	}
	// Converts a long to 8 bytes and insert them in the given
	// byte array at the defined offset.
	public static void longToEightByte(long value, byte[] dest, int off) {
		long val1 = (value & 0xFFFFFFFF00000000L) >>>32;
		long val2 = (value & 0x00000000FFFFFFFFL);
		intToFourByte(val1, dest, 0 + off);
		intToFourByte(val2, dest, 4 + off);
	}
	
	
	
    public static long fourByteToUInt (byte[] value) {
        return fourByteToUInt(value, 0);
    }
	public static long fourByteToUInt (byte[] value, int offset) {
		
		if ((offset + 4) > value.length)
			throw new IllegalArgumentException(String.format(ERR_ARRAY_OVERFLOW, value.length, offset));

		int b0, b1, b2, b3 = 0;
		
		b0 = (int)(0x000000FF & (value[offset]));
		b1 = (int)(0x000000FF & (value[offset+1]));
		b2 = (int)(0x000000FF & (value[offset+2]));
		b3 = (int)(0x000000FF & (value[offset+3]));
		long uint = ((long)b0 <<24 | (long)b1 <<16 | (long)b2 <<8 | (long)b3);
		return uint;
	}

	
	public static long eightByteToUInt (byte[] value, int offset) {
		if ((offset + 8) > value.length)
			throw new IllegalArgumentException(String.format(ERR_ARRAY_OVERFLOW, value.length,
				offset));

		long uint1 = (long)NetworkByteOrderNumberUtil.fourByteToUInt(value, offset);
		long uint2 = (long)NetworkByteOrderNumberUtil.fourByteToUInt(value, offset+4);
		long uint = (uint1 <<32 | uint2);
		return uint;
	}

	
}
